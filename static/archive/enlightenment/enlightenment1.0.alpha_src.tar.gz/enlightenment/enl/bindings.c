#include "../configure.h"

#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>

#include "enl.h"
#include "menus.h"
#include "misc.h"
#include "parse.h"
#include "screen.h"
#include "module.h"

struct charstring 
{
  char key;
  int  value;
};


/* The keys musat be in lower case! */
struct charstring win_contexts[]=
{
  {'w',C_WINDOW},
  {'t',C_TITLE},
  {'i',C_ICON},
  {'r',C_ROOT},
  {'f',C_FRAME},
  {'s',C_SIDEBAR},
  {'1',C_L1},
  {'2',C_R1},
  {'3',C_L2},
  {'4',C_R2},
  {'5',C_L3},
  {'6',C_R3},
  {'7',C_L4},
  {'8',C_R4},
  {'9',C_L5},
  {'0',C_R5},
  {'a',C_WINDOW|C_TITLE|C_ICON|C_ROOT|C_FRAME|C_SIDEBAR|
     C_L1|C_L2|C_L3|C_L4|C_L5|C_R1|C_R2|C_R3|C_R4|C_R5},
  {0,0}
};

/* The keys musat be in lower case! */
struct charstring key_modifiers[]=
{
  {'s',ShiftMask},
  {'c',ControlMask},
  {'m',Mod1Mask},
  {'1',Mod1Mask},
  {'2',Mod2Mask},
  {'3',Mod3Mask},
  {'4',Mod4Mask},
  {'5',Mod5Mask},
  {'a',AnyModifier},
  {'n',0},
  {0,0}
};

void find_context(char *string, int *output, struct charstring *table,
		  char *tline);

/****************************************************************************
 * 
 *  Parses a mouse binding
 *
 ****************************************************************************/ 
void ParseMouseEntry(XEvent *eventp,Window w,FvwmWindow *tmp_win,
		unsigned long junk, char *tline,int* Module)
{
  char context[20],modifiers[20],*ptr,*action,*token;
  Binding *temp;
  int button,i,j;
  int n1=0,n2=0,n3=0;
  int contexts;
  int mods;

  /* tline points after the key word "key" */
  ptr = tline;
  ptr = GetNextToken(ptr,&token);  
  if(token != NULL)
    {
      n1 = sscanf(token,"%d",&button);
      free(token);
    }

  ptr = GetNextToken(ptr,&token);  
  if(token != NULL)
    {
      n2 = sscanf(token,"%19s",context);
      free(token);
    }
  
  action = GetNextToken(ptr,&token); 
  if(token != NULL)
    {
      n3 = sscanf(token,"%19s",modifiers);
      free(token);
    }
  if((n1 != 1)||(n2 != 1)||(n3 != 1))
    fvwm_err("Mouse binding: Syntax error in line %s",tline,NULL,NULL);
  find_context(context,&contexts,win_contexts,tline);
  if((contexts != C_ALL) && (contexts & C_LALL))
    {
      /* check for nr_left_buttons */
      i=0;
      j=(contexts &C_LALL)/C_L1;
      while(j>0)
	{
	  i++;
	  j=j>>1;
	}
      if(Scr.nr_left_buttons <i)
	Scr.nr_left_buttons = i;
    }
  if((contexts != C_ALL) && (contexts & C_RALL))
    {
      /* check for nr_right_buttons */
      i=0;
      j=(contexts&C_RALL)/C_R1;
      while(j>0)
	{
	  i++;
	  j=j>>1;
	}
      if(Scr.nr_right_buttons <i)
	Scr.nr_right_buttons = i;
    }
  find_context(modifiers,&mods,key_modifiers,tline);
  if((mods & AnyModifier)&&(mods&(~AnyModifier)))
    {
      fvwm_err("Warning: Binding specified AnyModifier and other modifers too. Excess modifiers will be ignored.",NULL,NULL,NULL);
      
    }

  if((contexts & C_WINDOW)&&(((mods==0)||mods == AnyModifier)))
    {
      Scr.buttons2grab &= ~(1<<(button-1));
    }

  temp = Scr.AllBindings;
  Scr.AllBindings  = (Binding *)safemalloc(sizeof(Binding));
  Scr.AllBindings->IsMouse = 1;
  Scr.AllBindings->Button_Key = button;
  Scr.AllBindings->key_name = NULL;
  Scr.AllBindings->Context = contexts;
  Scr.AllBindings->Modifier = mods;
  Scr.AllBindings->Action = stripcpy(action);
  Scr.AllBindings->NextBinding = temp;
  return;
}

/****************************************************************************
 * 
 *  Processes a line with a key binding
 *
 ****************************************************************************/ 
void ParseKeyEntry(XEvent *eventp,Window w,FvwmWindow *tmp_win,
		unsigned long junk, char *tline,int* Module)
{
  char *action,context[20],modifiers[20],key[20],*ptr, *token;
  Binding *temp;
  int i,min,max;
  int n1=0,n2=0,n3=0;
  KeySym keysym;
  int contexts;
  int mods;

  /* tline points after the key word "key" */
  ptr = tline;

  ptr = GetNextToken(ptr,&token);  
  if(token != NULL)
    {
      n1 = sscanf(token,"%19s",key);
      free(token);
    }

  ptr = GetNextToken(ptr,&token);  
  if(token != NULL)
    {
      n2 = sscanf(token,"%19s",context);
      free(token);
    }
  action = GetNextToken(ptr,&token);  
  if(token != NULL)
    {
      n3 = sscanf(token,"%19s",modifiers);
      free(token);
    }

  if((n1 != 1)||(n2 != 1)||(n3 != 1))
    fvwm_err("Mouse binding: Syntax error in line %s",tline,NULL,NULL);

  find_context(context,&contexts,win_contexts,tline);
  find_context(modifiers,&mods,key_modifiers,tline);
  if((mods & AnyModifier)&&(mods&(~AnyModifier)))
    {
      fvwm_err("Warning: Binding specified AnyModifier and other modifers too. Excess modifiers will be ignored.",NULL,NULL,NULL);
    }


  /*
   * Don't let a 0 keycode go through, since that means AnyKey to the
   * XGrabKey call in GrabKeys().
   */
  if ((keysym = XStringToKeysym(key)) == NoSymbol ||
      (XKeysymToKeycode(dpy, keysym)) == 0)
    return;
  
 
  XDisplayKeycodes(dpy, &min, &max);
  for (i=min; i<=max; i++)
    if (XKeycodeToKeysym(dpy, i, 0) == keysym)
      {
	temp = Scr.AllBindings;
	Scr.AllBindings  = (Binding *)safemalloc(sizeof(Binding));
	Scr.AllBindings->IsMouse = 0;
	Scr.AllBindings->Button_Key = i;
	Scr.AllBindings->key_name = stripcpy(key);;
	Scr.AllBindings->Context = contexts;
	Scr.AllBindings->Modifier = mods;
	Scr.AllBindings->Action = stripcpy(action);
	Scr.AllBindings->NextBinding = temp;
      }
  return;
}

/****************************************************************************
 * 
 * Turns a  string context of context or modifier values into an array of 
 * true/false values (bits)
 *
 ****************************************************************************/ 
void find_context(char *string, int *output, struct charstring *table,
		  char *tline)
{
  int i=0,j=0;
  Bool matched;
  char tmp1;

  *output=0;
  i=0;
  while(i<strlen(string))
    {
      j=0;
      matched = FALSE;
      while((!matched)&&(table[j].key != 0))
	{
	  /* in some BSD implementations, tolower(c) is not defined
	   * unless isupper(c) is true */
	  tmp1=string[i];
	  if(isupper(tmp1))
	    tmp1=tolower(tmp1);
	  /* end of ugly BSD patch */

	  if(tmp1 == table[j].key)
	    {
	      *output |= table[j].value;
	      matched = TRUE;
	    }
	  j++;
	}
      if(!matched)
	{
	  fvwm_err("fvwm: bad context in line %s",tline,NULL,NULL);
	}
      i++;
    }
  return;
}

