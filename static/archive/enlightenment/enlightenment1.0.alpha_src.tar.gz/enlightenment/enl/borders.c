/****************************************************************************
 * This module is all original code 
 * by Rob Nation 
 * Copyright 1993, Robert Nation
 *     You may use this code for any purpose, as long as the original
 *     copyright remains in the source code and all documentation
 ****************************************************************************/


/***********************************************************************
 *
 * fvwm window border drawing code
 *
 ***********************************************************************/

#include "../configure.h"

#include <stdio.h>
#include <signal.h>
#include <string.h>

#include "enl.h"
#include "menus.h"
#include "misc.h"
#include "parse.h"
#include "screen.h"
#include "module.h"

#ifdef SHAPE
#include <X11/extensions/shape.h>
#endif

void DrawLinePattern(Window win,
                     GC ReliefGC,
                     GC ShadowGC,
                     int num_coords,
                     int *x_coord, 
                     int *y_coord,
                     int *line_style,
                     int th);

/* macro to change window background color/pixmap */
#define ChangeWindowColor(window) {\
        if(NewColor)\
        {\
          XChangeWindowAttributes(dpy,window,valuemask, &attributes);\
          XClearWindow(dpy,window);\
        }\
      }

extern Window PressedW;
XGCValues Globalgcv;
unsigned long Globalgcm;

/* Scales a pixmap */

void scale_pixmap(Pixmap p1, int w1, int h1, Pixmap p2, int w2, int h2)
{
   int x;
   double xx=0;
   double f;
   GC gc;
   XGCValues gcvals;
   
   gc=XCreateGC(dpy,p1,(unsigned long)0,&gcvals);   
   if (((w1==w2)||(h1==h2))&&(w2>0)&&(h2>0))
     {
	if((w2!=w1)&&(w2!=0))
	  {
	     f=(double)w1/(double)w2;
	     for(x=0;x<w2;x++)
	       {
		  XCopyArea(dpy,p1,p2,gc,(int)xx,0,1,h1,x,0);
		  xx+=f;
	       }
	     XFreeGC(dpy,gc);
	     return;
	  }
	else if((h2!=h1)&&(h2!=0))
	  {
	     f=(double)h1/(double)h2;
	     for(x=0;x<h2;x++)
	       {
		  XCopyArea(dpy,p1,p2,gc,0,(int)xx,w1,1,0,x);
		  xx+=f;
	       }
	     XFreeGC(dpy,gc);
	     return;
	  }
     }
}

/*
 * ***************************************************************************
 *
 * Redraws the windows borders
 *
 * ***************************************************************************
 */
void SetBorder(FvwmWindow *t,Bool onoroff,Bool force,Bool Mapped,Window expose_win)
{
   int y, i, x;
   GC ReliefGC,ShadowGC;
   Pixel BorderColor,BackColor;
   Pixmap BackPixmap,TextColor;
   Bool NewColor = False;
   XSetWindowAttributes attributes;
   unsigned long valuemask;
   static unsigned int corners[4];
   Window w;
   
   corners[0] = TOP_HILITE | LEFT_HILITE;
   corners[1] = TOP_HILITE | RIGHT_HILITE;
   corners[2] = BOTTOM_HILITE | LEFT_HILITE;
   corners[3] = BOTTOM_HILITE | RIGHT_HILITE;
   valuemask=0;
   
   if(!t)
     return;
   /*
    * Grab control of the server whilst we do the redraw etc, to make sure we
    * get all the prcessing, and programs don't go doing things whilst we do
    */
   XGrabServer(dpy);

   if (onoroff) 
     {
	/*
	 * If the highlighted window is this one already, and we're not being
	 * forced to redraw by a resize, exit
	 */
	if((!force)&&(Scr.Hilite == t))
	  {
	     XUngrabServer(dpy); 
	     return;
	  }
	
	/*
	 * Unhighlight the previously highlighted window, if it wasn't already
	 */
	if((Scr.Hilite != t)&&(Scr.Hilite != NULL))
	  SetBorder(Scr.Hilite,False,False,True,None);
	
	/* set the keyboard focus */
	if((Mapped)&&(t->flags&MAPPED)&&(Scr.Hilite != t)) w = t->w;
	else if((t->flags&ICONIFIED)&&(Scr.Hilite !=t)&&
		(!(t->flags &SUPPRESSICON)))
	  w = t->icon_w;
	Scr.Hilite = t;
	TextColor = Scr.HiColors.fore;
	BackColor = Scr.HiColors.back;
	ReliefGC = Scr.HiReliefGC;
	ShadowGC = Scr.HiShadowGC;
	BorderColor = Scr.HiRelief.back;
     }
   else
     {
	/* don't re-draw just for kicks */
	if((!force)&&(Scr.Hilite != t))
	  {
	     XUngrabServer(dpy); 
	     return;
	  }
	
	if(Scr.Hilite == t)
	  {
	     Scr.Hilite = NULL;
	     NewColor = True;
	  }
	
	TextColor =t->TextPixel;
	if(t->flags & STICKY)
	  BackColor = t->BackPixel;
	Globalgcv.foreground = t->ReliefPixel;
	Globalgcm = GCForeground;
	XChangeGC(dpy,Scr.ScratchGC1,Globalgcm,&Globalgcv); 
	ReliefGC = Scr.ScratchGC1;
	
	Globalgcv.foreground = t->ShadowPixel;
	XChangeGC(dpy,Scr.ScratchGC2,Globalgcm,&Globalgcv); 
	ShadowGC = Scr.ScratchGC2;
	BorderColor = t->ShadowPixel;
     }
   
   if(t->flags & ICONIFIED)
     {
	DrawIconWindow(t);
	XUngrabServer(dpy); 	     
	return;
     }
   if(t->flags & TITLE)
     {
	if (onoroff)
	  {
	     attributes.background_pixmap = Scr.title_pixmap;
	     valuemask = CWBackPixmap;
	  }
	else
	  {
	     attributes.background_pixmap = Scr.title__pixmap;
	     valuemask = CWBackPixmap;
	  }
	XChangeWindowAttributes(dpy,t->title_w,valuemask,&attributes);
	XClearWindow(dpy,t->title_w);
	for(i=0;i<Scr.nr_left_buttons;i++)
	  {
	     if(t->left_w[i] != None)
	       {
		  if (onoroff)
		    {
		       attributes.background_pixmap = Scr.bl_pixmap[i];
		       valuemask = CWBackPixmap;
		    }
		  else
		    {
		       attributes.background_pixmap = Scr.bl__pixmap[i];
		       valuemask = CWBackPixmap;
		    }
		  XChangeWindowAttributes(dpy,t->left_w[i],valuemask,&attributes);
		  XClearWindow(dpy,t->left_w[i]);
		  if(flush_expose(t->left_w[i])||(expose_win == t->left_w[i])||
		     (expose_win == None))
		    {	
		       if (onoroff){
			  if (PressedW==t->left_w[i])
			    {	
			       RelieveWindow(t,t->left_w[i],0,0,t->title_height,
					     t->title_height,
					     (PressedW==t->left_w[i]?ShadowGC:ReliefGC), 
					     (PressedW==t->left_w[i]?ReliefGC:ShadowGC), 
					     BOTTOM_HILITE);
			       DrawLinePattern(t->left_w[i],ReliefGC,ShadowGC,
					       Scr.left_num_coords[i],
					       Scr.left_x_coords[i], Scr.left_y_coords[i],
					       Scr.left_line_style[i],
					       t->title_height);
			    }
			  else
			    {
			       XClearWindow(dpy,t->left_w[i]);
			    }
		       }
		    }
	       }
	  }	     
	for(i=0;i<Scr.nr_right_buttons;i++)
	  {
	     if(t->right_w[i] != None)
	       {
		  if (onoroff)
		    {
		       attributes.background_pixmap = Scr.br_pixmap[i];
		       valuemask = CWBackPixmap;
		    }
		  else
		    {
		       attributes.background_pixmap = Scr.br__pixmap[i];
		       valuemask = CWBackPixmap;
		    }
		  XChangeWindowAttributes(dpy,t->right_w[i],valuemask,&attributes);
		  XClearWindow(dpy,t->right_w[i]);
		  if(flush_expose(t->right_w[i])||(expose_win==t->right_w[i])||
		     (expose_win == None))
		    {
		       GC sgc,rgc;
		       
		       sgc=ShadowGC;
		       rgc=ReliefGC;
		       if((t->flags & MWMButtons)&&(!i)&&(t->flags&MAXIMIZED))
			 {
			    sgc = ReliefGC;
			    rgc = ShadowGC;
			 }
		       if (onoroff){
			  if(PressedW==t->right_w[i])
			    {
			       RelieveWindow(t,t->right_w[i],0,0,t->title_height,
					     t->title_height,
					     (PressedW==t->right_w[i]
					      ?ShadowGC:ReliefGC),
					     (PressedW==t->right_w[i]
					      ?ReliefGC:ShadowGC), 
					     BOTTOM_HILITE);
			       DrawLinePattern(t->right_w[i],rgc,sgc,
					       Scr.right_num_coords[i],
					       Scr.right_x_coords[i], Scr.right_y_coords[i],
					       Scr.right_line_style[i],
					       t->title_height);
			    }
			  else
			    {
			       XClearWindow(dpy,t->right_w[i]);
			    }
		       }
		    }	      
	       }
	  }
	SetTitleBar(t,onoroff, False);
     }
   
   if(t->flags & BORDER)
     {	
	if ((t->shapew!=t->frame_width)||
	    (t->shapeh!=t->frame_height))
	  {
	     if (Scr.scale==0)
	       {
		  t->border_w[0]=Scr.border_w[0];
		  t->border_w[1]=Scr.border_w[1];
		  t->border_w[2]=Scr.border_w[2];
		  t->border_w[3]=Scr.border_w[3];
		  t->border__w[0]=Scr.border__w[0];
		  t->border__w[1]=Scr.border__w[1];
		  t->border__w[2]=Scr.border__w[2];
		  t->border__w[3]=Scr.border__w[3];
		  t->border_h[0]=Scr.border_h[0];
		  t->border_h[1]=Scr.border_h[1];
		  t->border_h[2]=Scr.border_h[2];
		  t->border_h[3]=Scr.border_h[3];
		  t->border__h[0]=Scr.border__h[0];
		  t->border__h[1]=Scr.border__h[1];
		  t->border__h[2]=Scr.border__h[2];
		  t->border__h[3]=Scr.border__h[3];
		  
		  t->border_pixmap[0]=Scr.border_pixmap[0];
		  t->border_pixmap[1]=Scr.border_pixmap[1];
		  t->border_pixmap[2]=Scr.border_pixmap[2];
		  t->border_pixmap[3]=Scr.border_pixmap[3];
		  t->border__pixmap[0]=Scr.border__pixmap[0];
		  t->border__pixmap[1]=Scr.border__pixmap[1];
		  t->border__pixmap[2]=Scr.border__pixmap[2];
		  t->border__pixmap[3]=Scr.border__pixmap[3];
		  t->bordermask_pixmap[0]=Scr.bordermask_pixmap[0];
		  t->bordermask_pixmap[1]=Scr.bordermask_pixmap[1];
		  t->bordermask_pixmap[2]=Scr.bordermask_pixmap[2];
		  t->bordermask_pixmap[3]=Scr.bordermask_pixmap[3];
		  t->bordermask__pixmap[0]=Scr.bordermask__pixmap[0];
		  t->bordermask__pixmap[1]=Scr.bordermask__pixmap[1];
		  t->bordermask__pixmap[2]=Scr.bordermask__pixmap[2];
		  t->bordermask__pixmap[3]=Scr.bordermask__pixmap[3];
	       }
	     else if (Scr.scale==1)
	       {
		  if ((t->scalew!=t->frame_width)||
		      (t->scaleh!=t->frame_height))
		    {
		       int ws,hs;
		       int num;
		       
		       ws=t->frame_width-2*(t->corner_width);
		       hs=t->frame_height-2*(t->corner_width);
		   			    
		       t->scalew=t->frame_width;
		       t->scaleh=t->frame_height;
		       
		       num=ws/Scr.border_w[0];
		       if((num*Scr.border_w[0])<ws) num++;
		       if(num<=0) num=1;
		       t->border_w[0]=ws/num;
		       t->border_w[1]=Scr.border_w[1];
		       num=ws/Scr.border_w[2];
		       if((num*Scr.border_w[2])<ws) num++;
		       if(num<=0) num=1;
		       t->border_w[2]=ws/num;
		       t->border_w[3]=Scr.border_w[3];
		       num=ws/Scr.border__w[0];
		       if((num*Scr.border__w[0])<ws) num++;
		       if(num<=0) num=1;
		       t->border__w[0]=ws/num;
		       t->border__w[1]=Scr.border__w[1];
		       num=ws/Scr.border__w[2];
		       if((num*Scr.border__w[2])<ws) num++;
		       if(num<=0) num=1;
		       t->border__w[2]=ws/num;
		       t->border__w[3]=Scr.border__w[3];
		       t->border_h[0]=Scr.border_h[0];
		       num=hs/Scr.border_h[1];
		       if((num*Scr.border_h[1])<hs) num++;
		       if(num<=0) num=1;
		       t->border_h[1]=hs/num;
		       t->border_h[2]=Scr.border_h[2];
		       num=hs/Scr.border_h[3];
		       if((num*Scr.border_h[3])<hs) num++;
		       if(num<=0) num=1;
		       t->border_h[3]=hs/num;
		       t->border__h[0]=Scr.border__h[0];
		       num=hs/Scr.border__h[1];
		       if((num*Scr.border__h[1])<hs) num++;
		       if(num<=0) num=1;
		       t->border__h[1]=hs/num;
		       t->border__h[2]=Scr.border__h[2];
		       num=hs/Scr.border__h[3];
		       if((num*Scr.border__h[3])<hs) num++;
		       if(num<=0) num=1;
		       t->border__h[3]=hs/num;
		       
		       for (i=0;i<4;i++)
			 {
			    if(t->border_pixmap[i]) XFreePixmap(dpy,t->border_pixmap[i]);
			    if(t->border__pixmap[i]) XFreePixmap(dpy,t->border__pixmap[i]);
			    if(t->bordermask_pixmap[i]) XFreePixmap(dpy,t->bordermask_pixmap[i]);
			    if(t->bordermask__pixmap[i]) XFreePixmap(dpy,t->bordermask__pixmap[i]);
			    t->border_pixmap[i]=XCreatePixmap(dpy,t->frame,
							      t->border_w[i],
							      t->border_h[i],
							      Scr.d_depth);
			    t->border__pixmap[i]=XCreatePixmap(dpy,t->frame,
							       t->border__w[i],
							       t->border__h[i],
							       Scr.d_depth);
			    scale_pixmap(Scr.border_pixmap[i],
					 Scr.border_w[i],
					 Scr.border_h[i],
					 t->border_pixmap[i],
					 t->border_w[i],
					 t->border_h[i]);
			    scale_pixmap(Scr.border__pixmap[i],
					 Scr.border__w[i],
					 Scr.border__h[i],
					 t->border__pixmap[i],
					 t->border__w[i],
					 t->border__h[i]);
			    if(Scr.bordermask_pixmap[i])
			      {
				 t->bordermask_pixmap[i]=XCreatePixmap(dpy,t->frame,
								       t->border_w[i],
								       t->border_h[i],
								       1);
				 scale_pixmap(Scr.bordermask_pixmap[i],
					      Scr.border_w[i],
					      Scr.border_h[i],
					      t->bordermask_pixmap[i],
					      t->border_w[i],
					      t->border_h[i]);
			      }
			    if(Scr.bordermask__pixmap[i])
			      {
				 t->bordermask__pixmap[i]=XCreatePixmap(dpy,t->frame,
									t->border__w[i],
									t->border__h[i],
									1);
				 scale_pixmap(Scr.bordermask__pixmap[i],
					      Scr.border__w[i],
					      Scr.border__h[i],
					      t->bordermask__pixmap[i],
					      t->border__w[i],
					      t->border__h[i]);
			      }
			 }
		    }
	       }
	     else if (Scr.scale==2)
	       {
		  if ((t->scalew!=t->frame_width)||
		      (t->scaleh!=t->frame_height))
		    {
		       int ws,hs,i;
		       
		       ws=t->frame_width-2*(t->corner_width);
		       hs=t->frame_height-2*(t->corner_width);
		       
		       t->scalew=t->frame_width;
		       t->scaleh=t->frame_height;
		       
		       t->border_w[0]=ws;
		       t->border_w[1]=Scr.border_w[1];
		       t->border_w[2]=ws;
		       t->border_w[3]=Scr.border_w[3];
		       t->border__w[0]=ws;
		       t->border__w[1]=Scr.border__w[1];
		       t->border__w[2]=ws;
		       t->border__w[3]=Scr.border__w[3];
		       t->border_h[0]=Scr.border_h[0];
		       t->border_h[1]=hs;
		       t->border_h[2]=Scr.border_h[2];
		       t->border_h[3]=hs;
		       t->border__h[0]=Scr.border__h[0];
		       t->border__h[1]=hs;
		       t->border__h[2]=Scr.border__h[2];
		       t->border__h[3]=hs;
		       
		       for (i=0;i<4;i++)
			 {
			    if(t->border_pixmap[i]) XFreePixmap(dpy,t->border_pixmap[i]);
			    if(t->border__pixmap[i]) XFreePixmap(dpy,t->border__pixmap[i]);
			    if(t->bordermask_pixmap[i]) XFreePixmap(dpy,t->bordermask_pixmap[i]);
			    if(t->bordermask__pixmap[i]) XFreePixmap(dpy,t->bordermask__pixmap[i]);
			    t->border_pixmap[i]=XCreatePixmap(dpy,t->frame,
							      t->border_w[i],
							      t->border_h[i],
							      Scr.d_depth);
			    t->border__pixmap[i]=XCreatePixmap(dpy,t->frame,
							       t->border__w[i],
							       t->border__h[i],
							       Scr.d_depth);
			    scale_pixmap(Scr.border_pixmap[i],
					 Scr.border_w[i],
					 Scr.border_h[i],
					 t->border_pixmap[i],
					 t->border_w[i],
					 t->border_h[i]);
			    scale_pixmap(Scr.border__pixmap[i],
					 Scr.border__w[i],
					 Scr.border__h[i],
					 t->border__pixmap[i],
					 t->border__w[i],
					 t->border__h[i]);
			    if(Scr.bordermask_pixmap[i])
			      {
				 t->bordermask_pixmap[i]=XCreatePixmap(dpy,t->frame,
								       t->border_w[i],
								       t->border_h[i],
								       1);
				 scale_pixmap(Scr.bordermask_pixmap[i],
					      Scr.border_w[i],
					      Scr.border_h[i],
					      t->bordermask_pixmap[i],
					      t->border_w[i],
					      t->border_h[i]);
			      }
			    if(Scr.bordermask__pixmap[i])
			      {
				 t->bordermask__pixmap[i]=XCreatePixmap(dpy,t->frame,
									t->border__w[i],
									t->border__h[i],
									1);
				 scale_pixmap(Scr.bordermask__pixmap[i],
					      Scr.border__w[i],
					      Scr.border__h[i],
					      t->bordermask__pixmap[i],
					      t->border__w[i],
					      t->border__h[i]);
			      }
			 }
		    }
	       }
	     XSync(dpy,False);
	  }
	for(i=0;i<4;i++)
	  {
	     if (onoroff)
	       {
		  if (i==1)
		    attributes.background_pixmap = t->border_pixmap[3];
		  else if (i==3)
		    attributes.background_pixmap = t->border_pixmap[1];
		  else
		    attributes.background_pixmap = t->border_pixmap[i];
		  valuemask = CWBackPixmap;
	       }
	     else
	       {
		  if (i==1)
		    attributes.background_pixmap = t->border__pixmap[3];
		  else if (i==3)
		    attributes.background_pixmap = t->border__pixmap[1];
		  else
		    attributes.background_pixmap = t->border__pixmap[i];
		  valuemask = CWBackPixmap;
	       }
	     XChangeWindowAttributes(dpy,t->sides[i],valuemask,&attributes);
	     if (onoroff)
	       {
		  attributes.background_pixmap = Scr.corner_pixmap[i];
		  valuemask = CWBackPixmap;
	       }
	     else
	       {
		  attributes.background_pixmap = Scr.corner__pixmap[i];
		  valuemask = CWBackPixmap;
	       }
	     XChangeWindowAttributes(dpy,t->corners[i],valuemask,&attributes);
	     t->shapew=-1;
	  }
	if((t->bordermask_pixmap[0])||
	   (t->bordermask_pixmap[1])||
	   (t->bordermask_pixmap[2])||
	   (t->bordermask_pixmap[3])||
	   (t->bordermask__pixmap[0])||
	   (t->bordermask__pixmap[1])||
	   (t->bordermask__pixmap[2])||
	   (t->bordermask__pixmap[3])||
	   (Scr.cornermask_pixmap[0])||	   
	   (Scr.cornermask_pixmap[1])||	   
	   (Scr.cornermask_pixmap[2])||	   
	   (Scr.cornermask_pixmap[3])||	   
	   (Scr.cornermask__pixmap[0])||	   
	   (Scr.cornermask__pixmap[1])||	   
	   (Scr.cornermask__pixmap[2])||	   
	   (Scr.cornermask__pixmap[3]))	   
	  {
	     int xi;
	     int ii,jj;
	     int aa,bb;
	     int xx,yy;
	     int csz;
	     int bsz;
	     int wid;
	     int hih;
	     GC gc=NULL;
	     XGCValues gcvals;
	     
	     if(!t->mask) t->shapew=-1;
	     if ((t->shapew!=t->frame_width)||
		 (t->shapeh!=t->frame_height)||
		 (t->sonoroff!=onoroff))
	       {
		  t->shapew=t->frame_width;
		  t->shapeh=t->frame_height;
		  t->sonoroff=onoroff;
		  
		  if(t->mask)
		    {
		       XFreePixmap(dpy,t->mask);
		    }
		  t->mask=XCreatePixmap(dpy,t->frame,
					t->frame_width,t->frame_height,1);
		  if (!gc) gc=XCreateGC(dpy,t->mask,(unsigned long)0,&gcvals);
		  XSetForeground(dpy,gc,0);
		  XFillRectangle(dpy,t->mask,gc,0,0,
				 t->frame_width,t->frame_height);
		  if (!gc) gc=XCreateGC(dpy,t->mask,(unsigned long)0,&gcvals);
		  bsz=t->boundary_width;
		  csz=t->corner_width;
		  wid=t->frame_width;
		  hih=t->frame_height;
		  
		  if (onoroff)
		    {
		       if (t->bordermask_pixmap[0])
			 {
			    for(xi=csz;xi<(wid-csz);xi+=t->border_w[0])
			      {
				 aa=t->border_w[0];
				 if ((wid-csz-xi)<aa) aa=wid-csz-xi;
				 XCopyArea(dpy,t->bordermask_pixmap[0],t->mask,
					   gc,0,0,aa,t->border_h[0],xi,0);
			      }
			 }
		       else
			 {
			    XSetForeground(dpy,gc,1);
			    XFillRectangle(dpy,t->mask,gc,
					   csz,0,
					   wid-2*csz,bsz);
			 }
		       if (t->bordermask_pixmap[1])
			 {
			    for(xi=csz;xi<(hih-csz);xi+=t->border_h[1])
			      {
				 aa=t->border_h[1];
				 if ((hih-csz-xi)<aa) aa=hih-csz-xi;
				 XCopyArea(dpy,t->bordermask_pixmap[1],t->mask,
					   gc,0,0,t->border_h[1],aa,0,xi);
			      }
			 }
		       else
			 {
			    XSetForeground(dpy,gc,1);
			    XFillRectangle(dpy,t->mask,gc,
					   0,csz,
					   bsz,hih-2*csz);
			 }
		       if (t->bordermask_pixmap[2])
			 {
			    for(xi=csz;xi<(wid-csz);xi+=t->border_w[2])
			      {
				 aa=t->border_w[2];
				 if ((wid-csz-xi)<aa) aa=wid-csz-xi;
				 XCopyArea(dpy,t->bordermask_pixmap[2],t->mask,
					   gc,0,0,aa,t->border_h[2],xi,hih-bsz);
			      }
			 }
		       else
			 {
			    XSetForeground(dpy,gc,1);
			    XFillRectangle(dpy,t->mask,gc,
					   csz,0,
					   wid-2*csz,bsz);
			 }
		       if (t->bordermask_pixmap[3])
			 {
			    for(xi=csz;xi<(hih-csz);xi+=t->border_h[3])
			      {
				 aa=t->border_h[3];
				 if ((hih-csz-xi)<aa) aa=hih-csz-xi;
				 XCopyArea(dpy,t->bordermask_pixmap[3],t->mask,
					   gc,0,0,t->border_h[3],aa,wid-bsz,xi);
			      }
			 }
		       else
			 {
			    XSetForeground(dpy,gc,1);
			    XFillRectangle(dpy,t->mask,gc,
					   0,csz,
					   bsz,hih-2*csz);
			 }

		       if (Scr.cornermask_pixmap[0])
			 {
			    XCopyArea(dpy,Scr.cornermask_pixmap[0],t->mask,
				      gc,0,0,
				      csz,csz,
				      0,0);
			 }
		       else
			 {
			    XSetForeground(dpy,gc,1);
			    XFillRectangle(dpy,t->mask,gc,
					   0,0,
					   csz,csz);
			 }
		       if (Scr.cornermask_pixmap[1])
			 {
			    XCopyArea(dpy,Scr.cornermask_pixmap[1],t->mask,
				      gc,0,0,
				      csz,csz,
				      wid-csz,0);
			 }
		       else
			 {
			    XSetForeground(dpy,gc,1);
			    XFillRectangle(dpy,t->mask,gc,
					   wid-csz,0,
					   csz,csz);
			 }
		       if (Scr.cornermask_pixmap[2])
			 {
			    XCopyArea(dpy,Scr.cornermask_pixmap[2],t->mask,
				      gc,0,0,
				      csz,csz,
				      0,hih-csz);
			 }
		       else
			 {
			    XSetForeground(dpy,gc,1);
			    XFillRectangle(dpy,t->mask,gc,
					   0,hih-csz,
					   csz,csz);
			 }
		       if (Scr.cornermask_pixmap[3])
			 {
			    XCopyArea(dpy,Scr.cornermask_pixmap[3],t->mask,
				      gc,0,0,
				      csz,csz,
				      wid-csz,hih-csz);
			 }
		       else
			 {
			    XSetForeground(dpy,gc,1);
			    XFillRectangle(dpy,t->mask,gc,
					   wid-csz,hih-csz,
					   csz,csz);
			 }
		    }
		  else
		    {
		       if (t->bordermask__pixmap[0])
			 {
			    for(xi=csz;xi<(wid-csz);xi+=t->border_w[0])
			      {
				 aa=t->border_w[0];
				 if ((wid-csz-xi)<aa) aa=wid-csz-xi;
				 XCopyArea(dpy,t->bordermask__pixmap[0],t->mask,
					   gc,0,0,aa,t->border_h[0],xi,0);
			      }
			 }
		       else
			 {
			    XSetForeground(dpy,gc,1);
			    XFillRectangle(dpy,t->mask,gc,
					   csz,0,
					   wid-2*csz,bsz);
			 }
		       if (t->bordermask__pixmap[1])
			 {
			    for(xi=csz;xi<(hih-csz);xi+=t->border_h[1])
			      {
				 aa=t->border_h[1];
				 if ((hih-csz-xi)<aa) aa=hih-csz-xi;
				 XCopyArea(dpy,t->bordermask__pixmap[1],t->mask,
					   gc,0,0,t->border_h[1],aa,0,xi);
			      }
			 }
		       else
			 {
			    XSetForeground(dpy,gc,1);
			    XFillRectangle(dpy,t->mask,gc,
					   0,csz,
					   bsz,hih-2*csz);
			 }
		       if (t->bordermask__pixmap[2])
			 {
			    for(xi=csz;xi<(wid-csz);xi+=t->border_w[2])
			      {
				 aa=t->border_w[2];
				 if ((wid-csz-xi)<aa) aa=wid-csz-xi;
				 XCopyArea(dpy,t->bordermask__pixmap[2],t->mask,
					   gc,0,0,aa,t->border_h[2],xi,hih-bsz);
			      }
			 }
		       else
			 {
			    XSetForeground(dpy,gc,1);
			    XFillRectangle(dpy,t->mask,gc,
					   csz,0,
					   wid-2*csz,bsz);
			 }
		       if (t->bordermask__pixmap[3])
			 {
			    for(xi=csz;xi<(hih-csz);xi+=t->border_h[3])
			      {
				 aa=t->border_h[3];
				 if ((hih-csz-xi)<aa) aa=hih-csz-xi;
				 XCopyArea(dpy,t->bordermask__pixmap[3],t->mask,
					   gc,0,0,t->border_h[3],aa,wid-bsz,xi);
			      }
			 }
		       else
			 {
			    XSetForeground(dpy,gc,1);
			    XFillRectangle(dpy,t->mask,gc,
					   0,csz,
					   bsz,hih-2*csz);
			 }

		       if (Scr.cornermask__pixmap[0])
			 {
			    XCopyArea(dpy,Scr.cornermask__pixmap[0],t->mask,
				      gc,0,0,
				      csz,csz,
				      0,0);
			 }
		       else
			 {
			    XSetForeground(dpy,gc,1);
			    XFillRectangle(dpy,t->mask,gc,
					   0,0,
					   csz,csz);
			 }
		       if (Scr.cornermask__pixmap[1])
			 {
			    XCopyArea(dpy,Scr.cornermask__pixmap[1],t->mask,
				      gc,0,0,
				      csz,csz,
				      wid-csz,0);
			 }
		       else
			 {
			    XSetForeground(dpy,gc,1);
			    XFillRectangle(dpy,t->mask,gc,
					   wid-csz,0,
					   csz,csz);
			 }
		       if (Scr.cornermask__pixmap[2])
			 {
			    XCopyArea(dpy,Scr.cornermask__pixmap[2],t->mask,
				      gc,0,0,
				      csz,csz,
				      0,hih-csz);
			 }
		       else
			 {
			    XSetForeground(dpy,gc,1);
			    XFillRectangle(dpy,t->mask,gc,
					   0,hih-csz,
					   csz,csz);
			 }
		       if (Scr.cornermask__pixmap[3])
			 {
			    XCopyArea(dpy,Scr.cornermask__pixmap[3],t->mask,
				      gc,0,0,
				      csz,csz,
				      wid-csz,hih-csz);
			 }
		       else
			 {
			    XSetForeground(dpy,gc,1);
			    XFillRectangle(dpy,t->mask,gc,
					   wid-csz,hih-csz,
					   csz,csz);
			 }
		    }
		  XSetForeground(dpy,gc,1);
		  XFillRectangle(dpy,t->mask,gc,
				 t->boundary_width,
				 t->boundary_width,
				 t->frame_width-(2*t->boundary_width),
				 t->frame_height-(2*t->boundary_width));
		  XShapeCombineMask(dpy,t->frame,ShapeBounding,0,0,
				    t->mask,ShapeSet);
		  for(i=0;i<4;i++)
		    {
		       XClearWindow(dpy,t->sides[i]);
		       XClearWindow(dpy,t->corners[i]);
		    }
	       }
	     if (gc) XFreeGC(dpy,gc);
	  }
     }
   else      /* no decorative border ie transients....*/
     {
	/* for color, make it the color of the decoration background */
	GC rgc,sgc;
	
	rgc=ReliefGC;
	sgc=ShadowGC;
	if(!(t->flags & MWMButtons)&&(PressedW == t->frame))
	  {
	     sgc=ReliefGC;
	     rgc=ShadowGC;
	  }

	attributes.background_pixmap = Scr.menu_pixmap;
	valuemask = CWBackPixmap;
	XChangeWindowAttributes(dpy,t->frame,valuemask,&attributes);
	XClearWindow(dpy,t->frame);

	if((flush_expose(t->frame))||(expose_win == t->frame)||
	   (expose_win == None))
	  {
	     RelieveWindow(t,t->frame,t->boundary_width-1 - t->bw,
			   t->boundary_width-1-t->bw,
			   t->frame_width-
			   (t->boundary_width<<1)+2+3*t->bw,
			   t->frame_height-
			   (t->boundary_width<<1)+2+3*t->bw,
			   sgc,rgc,
			   TOP_HILITE|LEFT_HILITE|RIGHT_HILITE|
			   BOTTOM_HILITE);
	     RelieveWindow(t,t->frame,0,0,t->frame_width+t->bw,
			   t->frame_height+t->bw,rgc,sgc,
			   TOP_HILITE|LEFT_HILITE|RIGHT_HILITE|
			   BOTTOM_HILITE);
	  }
     }
   /* Give control of the server back again */
   XUngrabServer(dpy); 
   /* Sync to make the border-color change look fast! */
   XSync(dpy,0);
}


/****************************************************************************
 *
 *  Redraws just the title bar
 *
 ****************************************************************************/
void SetTitleBar (FvwmWindow *t,Bool onoroff, Bool NewTitle)
{
   int hor_off, w,i;
   GC ReliefGC,ShadowGC,tGC;
   Pixel Forecolor, BackColor;
   XGCValues gcvals;
   int drk,txt,lit;
   
  if(!t)
    return;
  if(!(t->flags & TITLE))
    return;

  if (onoroff) 
  {
    Forecolor = Scr.HiColors.fore;
    BackColor = Scr.HiColors.back;
    ReliefGC = Scr.HiReliefGC;
    ShadowGC = Scr.HiShadowGC;
  }
  else
  {
    Forecolor =t->TextPixel;
    BackColor = t->BackPixel;
    Globalgcv.foreground = t->ReliefPixel;
    Globalgcm = GCForeground;
    XChangeGC(dpy,Scr.ScratchGC1,Globalgcm,&Globalgcv); 
    ReliefGC = Scr.ScratchGC1;
      
    Globalgcv.foreground = t->ShadowPixel;
    XChangeGC(dpy,Scr.ScratchGC2,Globalgcm,&Globalgcv); 
    ShadowGC = Scr.ScratchGC2;
  }
  if(PressedW==t->title_w)
  {
    tGC = ShadowGC;
    ShadowGC = ReliefGC;
    ReliefGC = tGC;
  }
  flush_expose(t->title_w);
  
  if(t->name != (char *)NULL)
  {
    w=XTextWidth(Scr.WindowFont.font,t->name,strlen(t->name));
    if(w > t->title_width-12)
      w = t->title_width-4;
    if(w < 0)
      w = 0;
  }
  else
    w = 0;


  switch (Scr.TitleStyle.justify)
  {
    case JUSTIFY_LEFT:
      hor_off = 10;
      break;
    case JUSTIFY_RIGHT:
      hor_off = t->title_width - w - 10;
      break;
    case JUSTIFY_CENTER:
    default:
      hor_off = (t->title_width - w)/2;
      break;
  }
  
  NewFontAndColor(Scr.WindowFont.font->fid,Forecolor, BackColor);
  
  if(NewTitle)
    XClearWindow(dpy,t->title_w);
  
  /* for mono, we clear an area in the title bar where the window
   * title goes, so that its more legible. For color, no need */
  if(Scr.d_depth<2)
  {
     RelieveWindow(t,t->title_w,0,0,hor_off-2,t->title_height,
                  ReliefGC, ShadowGC, BOTTOM_HILITE);
    RelieveWindow(t,t->title_w,hor_off+w+2,0,
                  t->title_width - w - hor_off-2,t->title_height,
                  ReliefGC, ShadowGC, BOTTOM_HILITE);
    XFillRectangle(dpy,t->title_w,
                   (PressedW==t->title_w?ShadowGC:ReliefGC),
                   hor_off - 2, 0, w+4,t->title_height);
      
    XDrawLine(dpy,t->title_w,ShadowGC,hor_off+w+1,0,hor_off+w+1,
              t->title_height);
    if(t->name != (char *)NULL)
      XDrawString (dpy, t->title_w,Scr.ScratchGC3,hor_off, Scr.WindowFont.y+1, 
                   t->name, strlen(t->name));
  }
   else
     { 
	switch (Scr.TitleStyle.appearance)
	  {
	   case TITLE_FLAT:
	     break;
	   case TITLE_SUNK:
/*
 *	  if (onoroff){
 *       RelieveWindow(t,t->title_w,0,0,t->title_width,t->title_height,
 *                     ShadowGC, ReliefGC, BOTTOM_HILITE);
 *	  }
 */
	     break;
	   case TITLE_RAISED:
	   default:
	     if (onoroff)
	       {
		  if (PressedW==t->title_w)
		    {
		       RelieveWindow(t,t->title_w,0,0,t->title_width,
				     t->title_height, ReliefGC, ShadowGC, 
				     BOTTOM_HILITE);
		    }
		  else
		    {
		       XClearWindow(dpy,t->title_w);
		    }
	       }
	     break;
	  }
	if(t->name != (char *)NULL)
	  {
	    if(PressedW==t->title_w)
	      {
		XGetGCValues(dpy,ReliefGC,GCForeground,&gcvals);
		drk=gcvals.foreground;
		XGetGCValues(dpy,ShadowGC,GCForeground,&gcvals);
		lit=gcvals.foreground;
		XGetGCValues(dpy,Scr.ScratchGC3,GCForeground,&gcvals);
		txt=gcvals.foreground;
		XSetForeground(dpy,Scr.ScratchGC3,drk);
		XDrawString (dpy, t->title_w,Scr.ScratchGC3,hor_off, 
			     Scr.WindowFont.y+1,t->name, strlen(t->name));
		XDrawString (dpy, t->title_w,Scr.ScratchGC3,hor_off-1, 
			     Scr.WindowFont.y+2,t->name, strlen(t->name));
		XSetForeground(dpy,Scr.ScratchGC3,lit);
		XDrawString (dpy, t->title_w,Scr.ScratchGC3,hor_off+1, 
			     Scr.WindowFont.y+3,t->name, strlen(t->name));
		XDrawString (dpy, t->title_w,Scr.ScratchGC3,hor_off+2, 
			     Scr.WindowFont.y+2,t->name, strlen(t->name));
		XSetForeground(dpy,Scr.ScratchGC3,txt);
		XDrawString (dpy, t->title_w,Scr.ScratchGC3,hor_off+1, 
			     Scr.WindowFont.y+2,t->name, strlen(t->name));
	      }
	    else
	      {
		XGetGCValues(dpy,ShadowGC,GCForeground,&gcvals);
		drk=gcvals.foreground;
		XGetGCValues(dpy,Scr.ScratchGC3,GCForeground,&gcvals);
		txt=gcvals.foreground;
		XSetForeground(dpy,Scr.ScratchGC3,drk);
		XDrawString (dpy, t->title_w,Scr.ScratchGC3,hor_off+1, 
			     Scr.WindowFont.y+2,t->name, strlen(t->name));
		XSetForeground(dpy,Scr.ScratchGC3,txt);
		XDrawString (dpy, t->title_w,Scr.ScratchGC3,hor_off, 
			     Scr.WindowFont.y+1,t->name, strlen(t->name));
	      }
	  }
     }
   /* now, draw lines in title bar if it's a sticky window */
  if(t->flags & STICKY)
  {
    for(i=0 ;i< t->title_height/2-3;i+=4)
    {
      XDrawLine(dpy,t->title_w,ShadowGC,4,t->title_height/2 - i-1,
                hor_off-6,t->title_height/2-i-1);
      XDrawLine(dpy,t->title_w,ShadowGC,6+hor_off+w,t->title_height/2 -i-1,
                t->title_width-5,t->title_height/2- i-1);
      XDrawLine(dpy,t->title_w,ReliefGC,4,t->title_height/2 - i,
                hor_off-6,t->title_height/2 - i);
      XDrawLine(dpy,t->title_w,ReliefGC,6+hor_off+w,t->title_height/2-i,
                t->title_width-5,t->title_height/2 - i);

      XDrawLine(dpy,t->title_w,ShadowGC,4,t->title_height/2 + i-1,
                hor_off-6,t->title_height/2+i-1);
      XDrawLine(dpy,t->title_w,ShadowGC,6+hor_off+w,t->title_height/2+i-1,
                t->title_width-5,t->title_height/2 + i-1);
      XDrawLine(dpy,t->title_w,ReliefGC,4,t->title_height/2 + i,
                hor_off-6,t->title_height/2 + i);
      XDrawLine(dpy,t->title_w,ReliefGC,6+hor_off+w,t->title_height/2+i,
                t->title_width-5,t->title_height/2 + i);
    }
  }
  

  XFlush(dpy);
}




/****************************************************************************
 *
 *  Draws the relief pattern around a window
 *
 ****************************************************************************/
E_INLINE void RelieveWindow(FvwmWindow *t,Window win,
			       int x,int y,int w,int h,
			       GC ReliefGC,GC ShadowGC, int hilite)
{
  XSegment seg[4];
  int i;
  int edge;

   
  edge = 0; 
  if((win == t->sides[0])||(win == t->sides[1])||
     (win == t->sides[2])||(win == t->sides[3]))
    edge = -1;
  if(win == t->corners[0])
    edge = 1;
  if(win == t->corners[1])
    edge = 2;
  if(win == t->corners[2])
    edge = 3;
  if(win == t->corners[3])
    edge = 4;

  i=0;
  seg[i].x1 = x;        seg[i].y1   = y;
  seg[i].x2 = w+x-1;    seg[i++].y2 = y;

  seg[i].x1 = x;        seg[i].y1   = y;
  seg[i].x2 = x;        seg[i++].y2 = h+y-1;

  if(((t->boundary_width > 2)||(edge == 0))&&
     ((t->boundary_width > 3)||(edge < 1))&&
     (!(t->flags & MWMBorders)||
      (((edge==0)||(t->boundary_width > 3))&&(hilite & TOP_HILITE))))
  {
    seg[i].x1 = x+1;      seg[i].y1   = y+1;
    seg[i].x2 = x+w-2;    seg[i++].y2 = y+1;
  }
  if(((t->boundary_width > 2)||(edge == 0))&&
     ((t->boundary_width > 3)||(edge < 1))&&
     (!(t->flags & MWMBorders)||
      (((edge==0)||(t->boundary_width > 3))&&(hilite & LEFT_HILITE))))
  {
    seg[i].x1 = x+1;      seg[i].y1   = y+1;
    seg[i].x2 = x+1;      seg[i++].y2 = y+h-2;
  }
  XDrawSegments(dpy, win, ReliefGC, seg, i);

  i=0;
  seg[i].x1 = x;        seg[i].y1   = y+h-1;
  seg[i].x2 = w+x-1;    seg[i++].y2 = y+h-1;

  if(((t->boundary_width > 2)||(edge == 0))&&
     (!(t->flags & MWMBorders)||
      (((edge==0)||(t->boundary_width > 3))&&(hilite & BOTTOM_HILITE))))
  {
    seg[i].x1 = x+1;      seg[i].y1   = y+h-2;
    seg[i].x2 = x+w-2;    seg[i++].y2 = y+h-2;
  }

  seg[i].x1 = x+w-1;    seg[i].y1   = y;
  seg[i].x2 = x+w-1;    seg[i++].y2 = y+h-1;

  if(((t->boundary_width > 2)||(edge == 0))&&
     (!(t->flags & MWMBorders)||
      (((edge==0)||(t->boundary_width > 3))&&(hilite & RIGHT_HILITE))))
  {
    seg[i].x1 = x+w-2;    seg[i].y1   = y+1;
    seg[i].x2 = x+w-2;    seg[i++].y2 = y+h-2;
  }
  XDrawSegments(dpy, win, ShadowGC, seg, i);
}

void RelieveParts(FvwmWindow *t,int i,GC hor, GC vert)
{
  XSegment seg[2];
  int n = 0;

  if((t->flags & MWMBorders)||(t->boundary_width < 3))
  {
    switch(i)
    {
      case 0:
        seg[0].x1 = t->boundary_width-1;
        seg[0].x2 = t->corner_width;
        seg[0].y1 = t->boundary_width-1;
        seg[0].y2 = t->boundary_width-1;
        n=1;
        break;
      case 1:
        seg[0].x1 = 0;
        seg[0].x2 = t->corner_width - t->boundary_width /* -1*/ ;
        seg[0].y1 = t->boundary_width-1;
        seg[0].y2 = t->boundary_width-1;
        n=1;
        break;
      case 2:
        seg[0].x1 = t->boundary_width-1;
        seg[0].x2 = t->corner_width-2;
        seg[0].y1 = t->corner_width - t->boundary_width+t->bw;
        seg[0].y2 = t->corner_width - t->boundary_width+t->bw;
        n=1;
        break;
      case 3:
        seg[0].x1 = 0;
        seg[0].x2 = t->corner_width - t->boundary_width;
        seg[0].y1 = t->corner_width - t->boundary_width+t->bw;
        seg[0].y2 = t->corner_width - t->boundary_width+t->bw;
        n=1;
        break;
    }
    XDrawSegments(dpy, t->corners[i], hor, seg, n);
    switch(i)
    {
      case 0:
        seg[0].y1 = t->boundary_width-1;
        seg[0].y2 = t->corner_width;
        seg[0].x1 = t->boundary_width-1;
        seg[0].x2 = t->boundary_width-1;
        n=1;
        break;
      case 1:
        seg[0].y1 = t->boundary_width -1;
        seg[0].y2 = t->corner_width-2;
        seg[0].x1 = t->corner_width - t->boundary_width;
        seg[0].x2 = t->corner_width - t->boundary_width;
        n=1;
        break;
      case 2:
        seg[0].y1 = 0;
        seg[0].y2 = t->corner_width - t->boundary_width;
        seg[0].x1 = t->boundary_width-1;
        seg[0].x2 = t->boundary_width-1;
        n=1;
        break;
      case 3:
        seg[0].y1 = 0;
        seg[0].y2 = t->corner_width - t->boundary_width + t->bw;
        seg[0].x1 = t->corner_width - t->boundary_width;
        seg[0].x2 = t->corner_width - t->boundary_width;
        n=1;
        break;
    }
    XDrawSegments(dpy, t->corners[i], vert, seg, 1);
  }
  else
  {
    switch(i)
    {
      case 0:
        seg[0].x1 = t->boundary_width-2;
        seg[0].x2 = t->corner_width;
        seg[0].y1 = t->boundary_width-2;
        seg[0].y2 = t->boundary_width-2;
	  
        seg[1].x1 = t->boundary_width-2;
        seg[1].x2 = t->corner_width;
        seg[1].y1 = t->boundary_width-1;
        seg[1].y2 = t->boundary_width-1;
        n=2;
        break;
      case 1:
        seg[0].x1 = 1;
        seg[0].x2 = t->corner_width - t->boundary_width;
        seg[0].y1 = t->boundary_width-2;
        seg[0].y2 = t->boundary_width-2;
	
        seg[1].x1 = 0;
        seg[1].x2 = t->corner_width - t->boundary_width-1;
        seg[1].y1 = t->boundary_width-1;
        seg[1].y2 = t->boundary_width-1;
        n=2;
        break;
      case 2:
        seg[0].x1 = t->boundary_width-1;
        seg[0].x2 = t->corner_width-2;
        seg[0].y1 = t->corner_width - t->boundary_width+1;
        seg[0].y2 = t->corner_width - t->boundary_width+1;
        n=1;
        if(t->boundary_width > 3)
        {
          seg[1].x1 = t->boundary_width-2;
          seg[1].x2 = t->corner_width-3;
          seg[1].y1 = t->corner_width - t->boundary_width + 2;
          seg[1].y2 = t->corner_width - t->boundary_width + 2;
          n=2;
        }
        break;
      case 3:
        seg[0].x1 = 0;
        seg[0].x2 = t->corner_width - t->boundary_width;
        seg[0].y1 = t->corner_width - t->boundary_width+1;
        seg[0].y2 = t->corner_width - t->boundary_width+1;
        n=1;
        if(t->boundary_width > 3)
        {
          seg[0].x2 = t->corner_width - t->boundary_width + 1;

          seg[1].x1 = 0;
          seg[1].x2 = t->corner_width - t->boundary_width + 1;
          seg[1].y1 = t->corner_width - t->boundary_width + 2;
          seg[1].y2 = t->corner_width - t->boundary_width + 2;
          n=2;
        }
        break;
    }
    XDrawSegments(dpy, t->corners[i], hor, seg, n);
    switch(i)
    {
      case 0:
        seg[0].y1 = t->boundary_width-2;
        seg[0].y2 = t->corner_width;
        seg[0].x1 = t->boundary_width-2;
        seg[0].x2 = t->boundary_width-2;
	  
        seg[1].y1 = t->boundary_width-2;
        seg[1].y2 = t->corner_width;
        seg[1].x1 = t->boundary_width-1;
        seg[1].x2 = t->boundary_width-1;
        n=2;
        break;
      case 1:
        seg[0].y1 = t->boundary_width-1;
        seg[0].y2 = t->corner_width-2;
        seg[0].x1 = t->corner_width - t->boundary_width;
        seg[0].x2 = t->corner_width - t->boundary_width;
        n=1;
        if(t->boundary_width > 3)
        {
          seg[1].y1 = t->boundary_width-2;
          seg[1].y2 = t->corner_width-3;
          seg[1].x1 = t->corner_width - t->boundary_width+1;
          seg[1].x2 = t->corner_width - t->boundary_width+1;
          n=2;
        }
        break;
      case 2:
        seg[0].y1 = 1;
        seg[0].y2 = t->corner_width - t->boundary_width+1;
        seg[0].x1 = t->boundary_width-2;
        seg[0].x2 = t->boundary_width-2;
        n=1;

        if(t->boundary_width > 3)
        {
          seg[1].y1 = 0;
          seg[1].y2 = t->corner_width - t->boundary_width;
          seg[1].x1 = t->boundary_width-1;
          seg[1].x2 = t->boundary_width-1;
        }
        break;
      case 3:
        seg[0].y1 = 0;
        seg[0].y2 = t->corner_width - t->boundary_width + 1;
        seg[0].x1 = t->corner_width - t->boundary_width;
        seg[0].x2 = t->corner_width - t->boundary_width;
        n=1;

        if(t->boundary_width > 3)
        {
          seg[0].y2 = t->corner_width - t->boundary_width + 2;
          seg[1].y1 = 0;
          seg[1].y2 = t->corner_width - t->boundary_width + 2;
          seg[1].x1 = t->corner_width - t->boundary_width + 1;
          seg[1].x2 = t->corner_width - t->boundary_width + 1;
          n=2;
        }
        break;
    }
    XDrawSegments(dpy, t->corners[i], vert, seg, n);
  }
}
/****************************************************************************
 *
 *  Draws a little pattern within a window (more complex)
 *
 ****************************************************************************/
void DrawLinePattern(Window win,
                     GC ReliefGC,
                     GC ShadowGC,
                     int num_coords,
                     int *x_coord, 
                     int *y_coord,
                     int *line_style,
                     int th)
{
  int i;

  for (i=1;i<num_coords;i++)
  {
    XDrawLine(dpy,win,line_style[i]?ReliefGC:ShadowGC,
              th*x_coord[i-1]/100,
              th*y_coord[i-1]/100,
              th*x_coord[i]/100,
              th*y_coord[i]/100);
  }
}



/***********************************************************************
 *
 *  Procedure:
 *      Setupframe - set window sizes, this was called from either
 *              AddWindow, EndResize, or HandleConfigureNotify.
 *
 *  Inputs:
 *      tmp_win - the FvwmWindow pointer
 *      x       - the x coordinate of the upper-left outer corner of the frame
 *      y       - the y coordinate of the upper-left outer corner of the frame
 *      w       - the width of the frame window w/o border
 *      h       - the height of the frame window w/o border
 *
 *  Special Considerations:
 *      This routine will check to make sure the window is not completely
 *      off the display, if it is, it'll bring some of it back on.
 *
 *      The tmp_win->frame_XXX variables should NOT be updated with the
 *      values of x,y,w,h prior to calling this routine, since the new
 *      values are compared against the old to see whether a synthetic
 *      ConfigureNotify event should be sent.  (It should be sent if the
 *      window was moved but not resized.)
 *
 ************************************************************************/

void SetupFrame(FvwmWindow *tmp_win,int x,int y,int w,int h,Bool sendEvent)
{
  XEvent client_event;
  XWindowChanges frame_wc, xwc;
  unsigned long frame_mask, xwcm;
  int cx,cy,i;
  Bool Resized = False;
  int xwidth,ywidth,left,right;
  
  /* if windows is not being maximized, save size in case of maximization */
  if (!(tmp_win->flags & MAXIMIZED))
  {
    tmp_win->orig_x = x;
    tmp_win->orig_y = y;
    tmp_win->orig_wd = w;
    tmp_win->orig_ht = h;
  }
  if (x >= Scr.MyDisplayWidth + Scr.VxMax - Scr.Vx-16)
    x = Scr.MyDisplayWidth + Scr.VxMax -Scr.Vx - 16;
  if (y >= Scr.MyDisplayHeight+Scr.VyMax - Scr.Vy -16)
    y = Scr.MyDisplayHeight + Scr.VyMax - Scr.Vy - 16;

  /*
   * According to the July 27, 1988 ICCCM draft, we should send a
   * "synthetic" ConfigureNotify event to the client if the window
   * was moved but not resized.
   */
  if ((x != tmp_win->frame_x || y != tmp_win->frame_y) &&
      (w == tmp_win->frame_width && h == tmp_win->frame_height))
    sendEvent = TRUE;

  if((w != tmp_win->frame_width) || (h != tmp_win->frame_height))
    Resized = True;

  if(Resized)
  {
    left = tmp_win->nr_left_buttons;
    right = tmp_win->nr_right_buttons;
      
    if (tmp_win->flags & TITLE) 
      tmp_win->title_height = Scr.TitleHeight + tmp_win->bw;

    tmp_win->title_width= w- 
      (left+right)*tmp_win->title_height 
      -2*tmp_win->boundary_width+tmp_win->bw;


    if(tmp_win->title_width < 1) 
      tmp_win->title_width = 1;

    if (tmp_win->flags & TITLE) 
    {
      xwcm = CWWidth | CWX | CWY | CWHeight;
      tmp_win->title_x = tmp_win->boundary_width+
        (left)*tmp_win->title_height;
      if(tmp_win->title_x >=  w - tmp_win->boundary_width)
        tmp_win->title_x = -10;
      tmp_win->title_y = tmp_win->boundary_width;
	  
      xwc.width = tmp_win->title_width;

      xwc.height = tmp_win->title_height;
      xwc.x = tmp_win->title_x;
      xwc.y = tmp_win->title_y;
      XConfigureWindow(dpy, tmp_win->title_w, xwcm, &xwc);


      xwcm = CWX | CWY | CWHeight | CWWidth;
      xwc.height = tmp_win->title_height;
      xwc.width = tmp_win->title_height;

      xwc.y = tmp_win->boundary_width;
      xwc.x = tmp_win->boundary_width;
      for(i=0;i<Scr.nr_left_buttons;i++)
      {
        if(tmp_win->left_w[i] != None)
        {
          if(xwc.x + tmp_win->title_height < w-tmp_win->boundary_width)
            XConfigureWindow(dpy, tmp_win->left_w[i], xwcm, &xwc);
          else
          {
            xwc.x = -tmp_win->title_height;
            XConfigureWindow(dpy, tmp_win->left_w[i], xwcm, &xwc);
          }
          xwc.x += tmp_win->title_height;
        }
      }
	  
      xwc.x=w-tmp_win->boundary_width+tmp_win->bw;
      for(i=0;i<Scr.nr_right_buttons;i++)
      {
        if(tmp_win->right_w[i] != None)
        {
          xwc.x -=tmp_win->title_height;
          if(xwc.x > tmp_win->boundary_width)
            XConfigureWindow(dpy, tmp_win->right_w[i], xwcm, &xwc);
          else
          {
            xwc.x = -tmp_win->title_height;
            XConfigureWindow(dpy, tmp_win->right_w[i], xwcm, &xwc);
          }
        }
      }
    }

    if(tmp_win->flags & BORDER)
    {
      tmp_win->corner_width = Scr.TitleHeight + tmp_win->bw + 
        tmp_win->boundary_width ;

      if(w < 2*tmp_win->corner_width)
        tmp_win->corner_width = w/3;
      if(h < 2*tmp_win->corner_width)
        tmp_win->corner_width = h/3;
      xwidth = w - 2*tmp_win->corner_width+tmp_win->bw;
      ywidth = h - 2*tmp_win->corner_width;
      xwcm = CWWidth | CWHeight | CWX | CWY;
      if(xwidth<2)
        xwidth = 2;
      if(ywidth<2)
        ywidth = 2;

      for(i=0;i<4;i++)
      {
        if(i==0)
        {
          xwc.x = tmp_win->corner_width;
          xwc.y = 0;
          xwc.height = tmp_win->boundary_width;
          xwc.width = xwidth;
        }
        else if (i==1)
        {
          xwc.x = w - tmp_win->boundary_width+tmp_win->bw;	
          xwc.y = tmp_win->corner_width;
          xwc.width = tmp_win->boundary_width;
          xwc.height = ywidth;

        }
        else if(i==2)
        {
          xwc.x = tmp_win->corner_width;
          xwc.y = h - tmp_win->boundary_width+tmp_win->bw;
          xwc.height = tmp_win->boundary_width+tmp_win->bw;
          xwc.width = xwidth;
        }
        else
        {
          xwc.x = 0;
          xwc.y = tmp_win->corner_width;
          xwc.width = tmp_win->boundary_width;
          xwc.height = ywidth;
        }
        XConfigureWindow(dpy, tmp_win->sides[i], xwcm, &xwc);
      }

      xwcm = CWX|CWY|CWWidth|CWHeight;
      xwc.width = tmp_win->corner_width;
      xwc.height = tmp_win->corner_width;
      for(i=0;i<4;i++)
      {
        if(i%2)
          xwc.x = w - tmp_win->corner_width+tmp_win->bw;
        else
          xwc.x = 0;
	      
        if(i/2)
          xwc.y = h - tmp_win->corner_width;
        else
          xwc.y = 0;

        XConfigureWindow(dpy, tmp_win->corners[i], xwcm, &xwc);
      }

    }
  }
  tmp_win->attr.width = w - 2*tmp_win->boundary_width;
  tmp_win->attr.height = h - tmp_win->title_height 
    - 2*tmp_win->boundary_width;
  /* may need to omit the -1 for shaped windows, next two lines*/
  cx = tmp_win->boundary_width-tmp_win->bw;
  cy = tmp_win->title_height + tmp_win->boundary_width-tmp_win->bw;

  XResizeWindow(dpy, tmp_win->w, tmp_win->attr.width,
		tmp_win->attr.height);
  XMoveResizeWindow(dpy, tmp_win->Parent, cx,cy,
		    tmp_win->attr.width, tmp_win->attr.height);

  /* 
   * fix up frame and assign size/location values in tmp_win
   */
  frame_wc.x = tmp_win->frame_x = x;
  frame_wc.y = tmp_win->frame_y = y;
  frame_wc.width = tmp_win->frame_width = w;
  frame_wc.height = tmp_win->frame_height = h;
  frame_mask = (CWX | CWY | CWWidth | CWHeight);
  XConfigureWindow (dpy, tmp_win->frame, frame_mask, &frame_wc);


#ifdef SHAPE
  if ((Resized)&&(tmp_win->wShaped))
  {
    SetShape(tmp_win,w);
  }
#endif /* SHAPE */
  XSync(dpy,0);
  if (sendEvent)
  {
    client_event.type = ConfigureNotify;
    client_event.xconfigure.display = dpy;
    client_event.xconfigure.event = tmp_win->w;
    client_event.xconfigure.window = tmp_win->w;
      
    client_event.xconfigure.x = x + tmp_win->boundary_width;
    client_event.xconfigure.y = y + tmp_win->title_height+
      tmp_win->boundary_width;
    client_event.xconfigure.width = w-2*tmp_win->boundary_width;
    client_event.xconfigure.height =h-2*tmp_win->boundary_width -
      tmp_win->title_height;

    client_event.xconfigure.border_width =tmp_win->bw;
    /* Real ConfigureNotify events say we're above title window, so ... */
    /* what if we don't have a title ????? */
    client_event.xconfigure.above = tmp_win->frame;
    client_event.xconfigure.override_redirect = False;
    XSendEvent(dpy, tmp_win->w, False, StructureNotifyMask, &client_event);
  }

  BroadcastConfig(M_CONFIGURE_WINDOW,tmp_win);
}


/****************************************************************************
 *
 * Sets up the shaped window borders 
 * 
 ****************************************************************************/
void SetShape(FvwmWindow *tmp_win, int w)
{
#ifdef SHAPE
  XRectangle rect;

  XShapeCombineShape (dpy, tmp_win->frame, ShapeBounding,
		      tmp_win->boundary_width,
		      tmp_win->title_height+tmp_win->boundary_width,
		      tmp_win->w,
		      ShapeBounding, ShapeSet);
  if (tmp_win->title_w) 
  {
    /* windows w/ titles */
    rect.x = tmp_win->boundary_width;
    rect.y = tmp_win->title_y;
    rect.width = w - 2*tmp_win->boundary_width+tmp_win->bw;
    rect.height = tmp_win->title_height;
      
      
    XShapeCombineRectangles(dpy,tmp_win->frame,ShapeBounding,
                            0,0,&rect,1,ShapeUnion,Unsorted);
  }
#endif
}

