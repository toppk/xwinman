#define VERSION "Enlightenment 1.0 beta"

