/*
 * Function prototypes
 */

void Arg_Get(char *a, char *s,int argc, char **argv);
void X_Connect(char *s);
void DecorationDraw(EWin *ewin);
int main(int argc, char **argv);
