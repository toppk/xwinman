void GetWinName(Window win, char *s);
void GetWinSize(Window win,EWin *ewin);
void GetWinColors(Window win,EWin *ewin);
void UnmapClients();
void MapClients(listhead *l);

