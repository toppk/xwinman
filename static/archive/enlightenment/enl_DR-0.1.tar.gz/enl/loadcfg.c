#include "enlightenment.h"

void LoadConfig(char *file)
{
   FILE *f;
   char s[10240];
   char ss[10240];
   char s1[256],s2[256],s3[256];
   char s4[256],s5[256],s6[256];
   int line=0;
   int num;
   int numm;
   int num1,num2,num3,num4;
   int r,g,b;
   char *home;
   int nest_level=0;
   int nest_stack[256];
   int wait_till_end=0;
   int wait_nest_level=-1;
   int done=0;
   int i,j,k;
   ImColor icl;
   
   for(k=0;k<64;k++)
     {
	for(j=0;j<3;j++)
	  {
	     for(i=0;i<4;i++)
	       {
		  cfg.subwin_action[k][j][i].id=0;
		  cfg.subwin_action[k][j][i].params[0]=0;
	       }
	  }
     }
   cfg.shape_mode=0;
   cfg.move_mode=0;
   cfg.resize_mode=0;
   cfg.border_l=0;
   cfg.border_r=0;
   cfg.border_t=0;
   cfg.border_b=0;
   cfg.num_subwins=0;
   cfg.root_pname=NULL;
   cfg.root_width=0;
   cfg.root_height=0;
   cfg.font=NULL;
   cfg.font_style=0;
   bl.first=NULL;
   for (i=0;i<64;i++)
     {
	cfg.subwin_type[i]=0;
	cfg.subwin_level[i]=0;
	cfg.subwin_scale_method[i]=0;
	cfg.subwin_pos_method1[i]=0;
	cfg.subwin_pos_method2[i]=0;
	cfg.subwin_pos_x1[i]=0;
	cfg.subwin_pos_y1[i]=0;
	cfg.subwin_pos_x2[i]=0;
	cfg.subwin_pos_y2[i]=0;
	cfg.subwin_pmname_clk[i]=NULL;
	cfg.subwin_pmname_sel[i]=NULL;
	cfg.subwin_pmname_uns[i]=NULL;
	cfg.subwin_transp_clk[i].r=-1;
	cfg.subwin_transp_clk[i].g=-1;
	cfg.subwin_transp_clk[i].b=-1;
	cfg.subwin_transp_sel[i].r=-1;
	cfg.subwin_transp_sel[i].g=-1;
	cfg.subwin_transp_sel[i].b=-1;
	cfg.subwin_transp_uns[i].r=-1;
	cfg.subwin_transp_uns[i].g=-1;
	cfg.subwin_transp_uns[i].b=-1;
     }
   strcpy(s1,"./.enlightenment/");
   strcat(s1,file);
   f=fopen(s1,"r");
   if (!f)
     {
	home=getenv("HOME");
	if (home)
	  {
	     strcpy(s1,home);
	     strcat(s1,"/.enlightenment/");
	     strcat(s1,file);
	     f=fopen(s1,"r");
	     free(home);
	  }
     }
   if (!f)
     {
	strcpy(s1,"/usr/local/enlightenment/system_config/");
	strcat(s1,file);
	f=fopen(s1,"r");
     }
   if (!f)
     {
	fprintf(stderr,"PANIC!!!: can't load config file %s\n",s);
	fprintf(stderr,"have tried:\n");
	fprintf(stderr,"./.enlightenment/%s\n",file);
	fprintf(stderr,"~/.enlightenment/%s\n",file);
	fprintf(stderr,"/usr/local/enlightenment/config_system/%s\n",file);
	fprintf(stderr,"....... no data to go on..... Bailing out NOW!\n");
	exit(1);
     }
   nest_stack[0]=CTXT_NONE;
   while(fgets(s,1024,f))
     {
	line++;
        if (s[0]=='#') continue;
	if (s[0]=='\n') continue;
	if (s[0]==0) continue;
	if (s[0]=='%')
	  {
	     sscanf(s,"%s %s %s %s %s %i %i %i",s1,s2,s3,s4,s5,&num1,&num2,&num3);
	     if (!strcmp(s2,"status"))
	       {
		  if (strcmp(s4,"shapemode")) continue;
		  if (!strcmp(s5,"off")) 
		    {
		       icl.r=-1;icl.g=-1;icl.b=-1;
		    }
		  else
		    {
		       icl.r=num1;icl.g=num2;icl.b=num3;
		    }
		  numm=8;
		  i=0;
		  while (numm>0)
		    {
		       if (s[i++]==' ') numm--;
		    }
		  j=0;
		  while (s[i]) ss[j++]=s[i++];
		  ss[j]=0;
		  ShowStatus(ss,s3,&icl);
		  continue;
	       }
	     else if (!strcmp(s2,"sleep"))
	       {
		  sscanf(s,"%s %s %i",s1,s2,&num);
		  sleep(num);
		  continue;
	       }
	     else if (!strcmp(s2,"black"))
	       {
		  r=0,g=0;b=0;
		  XSetWindowBackground(disp,root,ImlibBestColorMatch(imd,&r,&g,&b));
		  XClearWindow(disp,root);
		  XSync(disp,False);
		  continue;
	       }
	  }
	done=0;
	sscanf(s,"%s",s1);
	if (wait_till_end)
	  {
	     done=1;
	     if (wait_nest_level==nest_level) wait_till_end=0;
	  }
	if (!strcmp(s1,"begin"))
	  {
	     done=1;
	     sscanf(s,"%s %s",s1,s2);
	     if (!strcmp(s2,"window"))
	       {
		  nest_stack[++nest_level]=CTXT_WINDOW;
	       }
	     else if (!strcmp(s2,"border"))
	       {
		  nest_stack[++nest_level]=CTXT_BORDER;
	       }
	     else if (!strcmp(s2,"subwin"))
	       {
		  nest_stack[++nest_level]=CTXT_SUBWIN;
		  cfg.num_subwins++;
	       }
	     else if (!strcmp(s2,"root"))
	       {
		  nest_stack[++nest_level]=CTXT_ROOT;
	       }
	     else if (!strcmp(s2,"text"))
	       {
		  nest_stack[++nest_level]=CTXT_TEXT;
	       }
	     else if (!strcmp(s2,"status"))
	       {
		  nest_stack[++nest_level]=CTXT_STATUS;
	       }
	     else
	       {
		  if (!wait_till_end)
		    {
		       fprintf(stderr,"WARNING!\n");
		       fprintf(stderr,"File: %s, Line %i: ERROR.........\n",file,line);
		       fprintf(stderr,"---> %s",s);
		       fprintf(stderr,"Section context %s Unknown.\n",s2);
		       fprintf(stderr,"Ignoring entire context chunk\n");
		       wait_till_end=1;
		       wait_nest_level=nest_level++;
		       nest_stack[nest_level]=CTXT_NONE;
		    }
		  else
		    {
		       nest_level++;
		    }
	       }
	  }
	
	else if (!strcmp(s1,"end"))
	  {
	     if (nest_stack[nest_level]==CTXT_TEXT) 
	       InitTextInfo();
	     if (nest_stack[nest_level]==CTXT_STATUS) 
	       Init_StatusWin();
	     if (nest_stack[nest_level]==CTXT_ROOT) 
	       SetRoot();
	     done=1;
	     if (nest_level>0)
	       {
		  nest_level--;
	       }
	     else
	       {
		  nest_level=0;
		  fprintf(stderr,"WARNING!\n");
		  fprintf(stderr,"File: %s, Line %i: ERROR.........\n",file,line);
		  fprintf(stderr,"---> %s",s);
		  fprintf(stderr,"Keyword end with no begin\n",s1);
		  fprintf(stderr,"Ignoring end Keyword\n");
	       }
	  }
	if (!wait_till_end)
	  {
	     if(nest_stack[nest_level]==CTXT_WINDOW)
	       {
		  if (!strcmp(s1,"shaped"))
		    {
		       done=1;
		       sscanf(s,"%s %s",s1,s2);
		       if (!strcmp(s2,"on")) cfg.shape_mode=1;
		       else if (!strcmp(s2,"off")) cfg.shape_mode=0;
		       else 
			 {
			    fprintf(stderr,"WARNING!\n");
			    fprintf(stderr,"File: %s, Line %i: ERROR.........\n",file,line);
			    fprintf(stderr,"---> %s",s);
			    fprintf(stderr,"Unknown SHAPED mode %s\n",s1); 
			    fprintf(stderr,"Allowed: [on,off]\n");
			    fprintf(stderr,"Assuming off\n");
			    cfg.shape_mode=0;
			 }
		    }
		  else if (!strcmp(s1,"move"))
		    {
		       done=1;
		       sscanf(s,"%s %s",s1,s2);
		       if (!strcmp(s2,"box")) cfg.move_mode=0;
		       else if (!strcmp(s2,"shape")) cfg.move_mode=1;
		       else if (!strcmp(s2,"opaque")) cfg.move_mode=2;
		       else 
			 {
			    fprintf(stderr,"WARNING!\n");
			    fprintf(stderr,"File: %s, Line %i: ERROR.........\n",file,line);
			    fprintf(stderr,"---> %s",s);
			    fprintf(stderr,"Unknown MOVE mode %s\n",s1); 
			    fprintf(stderr,"Allowed: [box,shape,opaque]\n");
			    fprintf(stderr,"Assuming box\n");
			    cfg.move_mode=0;
			 }
		    }
		  else if (!strcmp(s1,"resize"))
		    {
		       done=1;
		       sscanf(s,"%s %s",s1,s2);
		       if (!strcmp(s2,"box")) cfg.resize_mode=0;
		       else if (!strcmp(s2,"shape")) cfg.resize_mode=1;
		       else if (!strcmp(s2,"opaque")) cfg.resize_mode=2;
		       else 
			 {
			    fprintf(stderr,"WARNING!\n");
			    fprintf(stderr,"File: %s, Line %i: ERROR.........\n",file,line);
			    fprintf(stderr,"---> %s",s);
			    fprintf(stderr,"Unknown RESIZE mode %s\n",s1); 
			    fprintf(stderr,"Allowed: [box,shape,opaque]\n");
			    fprintf(stderr,"Assuming box\n");
			    cfg.resize_mode=0;
			 }
		    }
	       }
	     if(nest_stack[nest_level]==CTXT_SUBWIN)
	       {
		  if (!strcmp(s1,"type"))
		    {
		       done=1;
		       sscanf(s,"%s %s",s1,s2);
		       if (!strcmp(s2,"decoration")) cfg.subwin_type[cfg.num_subwins-1]=0;
		       else if (!strcmp(s2,"button")) cfg.subwin_type[cfg.num_subwins-1]=1;
		       else if (!strcmp(s2,"title")) cfg.subwin_type[cfg.num_subwins-1]=2;
		       else 
			 {
			    fprintf(stderr,"WARNING!\n");
			    fprintf(stderr,"File: %s, Line %i: ERROR.........\n",file,line);
			    fprintf(stderr,"---> %s",s);
			    fprintf(stderr,"Unknown TYPE %s\n",s1); 
			    fprintf(stderr,"Allowed: [decoration,button,title]\n");
			    fprintf(stderr,"Assuming decoration\n");
			    cfg.subwin_type[cfg.num_subwins-1]=0;
			 }
		    }
		  else if (!strcmp(s1,"coord1_relative"))
		    {
		       done=1;
		       sscanf(s,"%s %s",s1,s2);
		       if (!strcmp(s2,"topleft")) cfg.subwin_pos_method1[cfg.num_subwins-1]=0;
		       else if (!strcmp(s2,"topright")) cfg.subwin_pos_method1[cfg.num_subwins-1]=1;
		       else if (!strcmp(s2,"bottomleft")) cfg.subwin_pos_method1[cfg.num_subwins-1]=2;
		       else if (!strcmp(s2,"bottomright")) cfg.subwin_pos_method1[cfg.num_subwins-1]=3;
		       else 
			 {
			    fprintf(stderr,"WARNING!\n");
			    fprintf(stderr,"File: %s, Line %i: ERROR.........\n",file,line);
			    fprintf(stderr,"---> %s",s);
			    fprintf(stderr,"Unknown COORD_RELATIVE %s\n",s1); 
			    fprintf(stderr,"Allowed: [topleft,topright,bottomleft,bottomright]\n");
			    fprintf(stderr,"Assuming topleft\n");
			    cfg.subwin_pos_method1[cfg.num_subwins-1]=0;
			 }
		    }
		  else if (!strcmp(s1,"coord1"))
		    {
		       done=1;
		       sscanf(s,"%s %i %i",s1,&num,&numm);
		       cfg.subwin_pos_x1[cfg.num_subwins-1]=num;
		       cfg.subwin_pos_y1[cfg.num_subwins-1]=numm;
		    }
		  else if (!strcmp(s1,"coord2_relative"))
		    {
		       done=1;
		       sscanf(s,"%s %s",s1,s2);
		       if (!strcmp(s2,"topleft")) cfg.subwin_pos_method2[cfg.num_subwins-1]=0;
		       else if (!strcmp(s2,"topright")) cfg.subwin_pos_method2[cfg.num_subwins-1]=1;
		       else if (!strcmp(s2,"bottomleft")) cfg.subwin_pos_method2[cfg.num_subwins-1]=2;
		       else if (!strcmp(s2,"bottomright")) cfg.subwin_pos_method2[cfg.num_subwins-1]=3;
		       else 
			 {
			    fprintf(stderr,"WARNING!\n");
			    fprintf(stderr,"File: %s, Line %i: ERROR.........\n",file,line);
			    fprintf(stderr,"---> %s",s);
			    fprintf(stderr,"Unknown COORD_RELATIVE %s\n",s1); 
			    fprintf(stderr,"Allowed: [topleft,topright,bottomleft,bottomright]\n");
			    fprintf(stderr,"Assuming topleft\n");
			    cfg.subwin_pos_method2[cfg.num_subwins-1]=0;
			 }
		    }
		  else if (!strcmp(s1,"coord2"))
		    {
		       done=1;
		       sscanf(s,"%s %i %i",s1,&num,&numm);
		       cfg.subwin_pos_x2[cfg.num_subwins-1]=num;
		       cfg.subwin_pos_y2[cfg.num_subwins-1]=numm;
		    }
		  else if (!strcmp(s1,"image"))
		    {
		       done=1;
		       sscanf(s,"%s %s",s1,s2);
		       if (!strcmp(s2,"clicked")) 
			 {
			    sscanf(s,"%s %s %s %s %s %i %i %i",s1,s2,s3,s4,s5,&num1,&num2,&num3);
			    cfg.subwin_pmname_clk[cfg.num_subwins-1]=malloc(sizeof(char)*(strlen(s3)+1));
			    strcpy(cfg.subwin_pmname_clk[cfg.num_subwins-1],s3);
			    if (!strcmp(s4,"shapecolor"))
			      {
				 if (!strcmp(s5,"on"))
				   {
				      cfg.subwin_transp_clk[cfg.num_subwins-1].r=num1;
				      cfg.subwin_transp_clk[cfg.num_subwins-1].g=num2;
				      cfg.subwin_transp_clk[cfg.num_subwins-1].b=num3;
				   }
				 else if (!strcmp(s5,"off"))
				   {
				      cfg.subwin_transp_clk[cfg.num_subwins-1].r=-1;
				      cfg.subwin_transp_clk[cfg.num_subwins-1].g=-1;
				      cfg.subwin_transp_clk[cfg.num_subwins-1].b=-1;
				   }
				 else
				   {
				      fprintf(stderr,"WARNING!\n");
				      fprintf(stderr,"File: %s, Line %i: ERROR.........\n",file,line);
				      fprintf(stderr,"---> %s",s);
				      fprintf(stderr,"Unknown IMAGE SHAPECOLOR %s\n",s5); 
				      fprintf(stderr,"Allowed: [on,off]\n");
				      fprintf(stderr,"Assuming off\n");
				      cfg.subwin_transp_clk[cfg.num_subwins-1].r=-1;
				      cfg.subwin_transp_clk[cfg.num_subwins-1].g=-1;
				      cfg.subwin_transp_clk[cfg.num_subwins-1].b=-1;
				   }
			      }
			    else
			      {
				 fprintf(stderr,"WARNING!\n");
				 fprintf(stderr,"File: %s, Line %i: ERROR.........\n",file,line);
				 fprintf(stderr,"---> %s",s);
				 fprintf(stderr,"Unknown IMAGE modifier %s\n",s4); 
				 fprintf(stderr,"Allowed: [shapecolor]\n");
				 fprintf(stderr,"Assuming shapecolor off\n");
				 cfg.subwin_transp_clk[cfg.num_subwins-1].r=-1;
				 cfg.subwin_transp_clk[cfg.num_subwins-1].g=-1;
				 cfg.subwin_transp_clk[cfg.num_subwins-1].b=-1;
			      }
			 }
		       else if (!strcmp(s2,"selected")) 
			 {
			    sscanf(s,"%s %s %s %s %s %i %i %i",s1,s2,s3,s4,s5,&num1,&num2,&num3);
			    cfg.subwin_pmname_sel[cfg.num_subwins-1]=malloc(sizeof(char)*(strlen(s3)+1));
			    strcpy(cfg.subwin_pmname_sel[cfg.num_subwins-1],s3);
			    if (!strcmp(s4,"shapecolor"))
			      {
				 if (!strcmp(s5,"on"))
				   {
				      cfg.subwin_transp_sel[cfg.num_subwins-1].r=num1;
				      cfg.subwin_transp_sel[cfg.num_subwins-1].g=num2;
				      cfg.subwin_transp_sel[cfg.num_subwins-1].b=num3;
				   }
				 else if (!strcmp(s5,"off"))
				   {
				      cfg.subwin_transp_sel[cfg.num_subwins-1].r=-1;
				      cfg.subwin_transp_sel[cfg.num_subwins-1].g=-1;
				      cfg.subwin_transp_sel[cfg.num_subwins-1].b=-1;
				   }
				 else
				   {
				      fprintf(stderr,"WARNING!\n");
				      fprintf(stderr,"File: %s, Line %i: ERROR.........\n",file,line);
				      fprintf(stderr,"---> %s",s);
				      fprintf(stderr,"Unknown IMAGE SHAPECOLOR %s\n",s5); 
				      fprintf(stderr,"Allowed: [on,off]\n");
				      fprintf(stderr,"Assuming off\n");
				      cfg.subwin_transp_sel[cfg.num_subwins-1].r=-1;
				      cfg.subwin_transp_sel[cfg.num_subwins-1].g=-1;
				      cfg.subwin_transp_sel[cfg.num_subwins-1].b=-1;
				   }
			      }
			    else
			      {
				 fprintf(stderr,"WARNING!\n");
				 fprintf(stderr,"File: %s, Line %i: ERROR.........\n",file,line);
				 fprintf(stderr,"---> %s",s);
				 fprintf(stderr,"Unknown IMAGE modifier %s\n",s4); 
				 fprintf(stderr,"Allowed: [shapecolor]\n");
				 fprintf(stderr,"Assuming shapecolor off\n");
				 cfg.subwin_transp_sel[cfg.num_subwins-1].r=-1;
				 cfg.subwin_transp_sel[cfg.num_subwins-1].g=-1;
				 cfg.subwin_transp_sel[cfg.num_subwins-1].b=-1;
			      }
			 }
		       else if (!strcmp(s2,"unselected")) 
			 {
			    sscanf(s,"%s %s %s %s %s %i %i %i",s1,s2,s3,s4,s5,&num1,&num2,&num3);
			    cfg.subwin_pmname_uns[cfg.num_subwins-1]=malloc(sizeof(char)*(strlen(s3)+1));
			    strcpy(cfg.subwin_pmname_uns[cfg.num_subwins-1],s3);
			    if (!strcmp(s4,"shapecolor"))
			      {
				 if (!strcmp(s5,"on"))
				   {
				      cfg.subwin_transp_uns[cfg.num_subwins-1].r=num1;
				      cfg.subwin_transp_uns[cfg.num_subwins-1].g=num2;
				      cfg.subwin_transp_uns[cfg.num_subwins-1].b=num3;
				   }
				 else if (!strcmp(s5,"off"))
				   {
				      cfg.subwin_transp_uns[cfg.num_subwins-1].r=-1;
				      cfg.subwin_transp_uns[cfg.num_subwins-1].g=-1;
				      cfg.subwin_transp_uns[cfg.num_subwins-1].b=-1;
				   }
				 else
				   {
				      fprintf(stderr,"WARNING!\n");
				      fprintf(stderr,"File: %s, Line %i: ERROR.........\n",file,line);
				      fprintf(stderr,"---> %s",s);
				      fprintf(stderr,"Unknown IMAGE SHAPECOLOR %s\n",s5); 
				      fprintf(stderr,"Allowed: [on,off]\n");
				      fprintf(stderr,"Assuming off\n");
				      cfg.subwin_transp_uns[cfg.num_subwins-1].r=-1;
				      cfg.subwin_transp_uns[cfg.num_subwins-1].g=-1;
				      cfg.subwin_transp_uns[cfg.num_subwins-1].b=-1;
				   }
			      }
			    else
			      {
				 fprintf(stderr,"WARNING!\n");
				 fprintf(stderr,"File: %s, Line %i: ERROR.........\n",file,line);
				 fprintf(stderr,"---> %s",s);
				 fprintf(stderr,"Unknown IMAGE modifier %s\n",s4); 
				 fprintf(stderr,"Allowed: [shapecolor]\n");
				 fprintf(stderr,"Assuming shapecolor off\n");
				 cfg.subwin_transp_uns[cfg.num_subwins-1].r=-1;
				 cfg.subwin_transp_uns[cfg.num_subwins-1].g=-1;
				 cfg.subwin_transp_uns[cfg.num_subwins-1].b=-1;
			      }
			 }
		       else if (!strcmp(s2,"scale_method")) 
			 {
			    sscanf(s,"%s %s %s",s1,s2,s3);
			    if (!strcmp(s3,"tile")) cfg.subwin_scale_method[cfg.num_subwins-1]=0;
			    else if (!strcmp(s3,"scaletile")) cfg.subwin_scale_method[cfg.num_subwins-1]=1;
			    else if (!strcmp(s3,"scale")) cfg.subwin_scale_method[cfg.num_subwins-1]=2;
			    else 
			      {
				 fprintf(stderr,"WARNING!\n");
				 fprintf(stderr,"File: %s, Line %i: ERROR.........\n",file,line);
				 fprintf(stderr,"---> %s",s);
				 fprintf(stderr,"Unknown SCALE_METHOD %s\n",s1); 
				 fprintf(stderr,"Allowed: [tile,scaletile,scale]\n");
				 fprintf(stderr,"Assuming tile\n");
				 cfg.subwin_scale_method[cfg.num_subwins-1]=0;
			      }
			 }
		       else 
			 {
			    fprintf(stderr,"WARNING!\n");
			    fprintf(stderr,"File: %s, Line %i: ERROR.........\n",file,line);
			    fprintf(stderr,"---> %s",s);
			    fprintf(stderr,"Unknown IMAGE detail %s\n",s1); 
			    fprintf(stderr,"Allowed: [clicked,selected,unselected,scale_method]\n");
			    fprintf(stderr,"Ignoring statement. WARNING. This may lead to strange effects on screen.\n");
			 }
		    }
		  else if (!strcmp(s1,"level"))
		    {
		       done=1;
		       sscanf(s,"%s %s",s1,s2);
		       if (!strcmp(s2,"above")) cfg.subwin_level[cfg.num_subwins-1]=1;
		       else if (!strcmp(s2,"below")) cfg.subwin_level[cfg.num_subwins-1]=0;
		       else 
			 {
			    fprintf(stderr,"WARNING!\n");
			    fprintf(stderr,"File: %s, Line %i: ERROR.........\n",file,line);
			    fprintf(stderr,"---> %s",s);
			    fprintf(stderr,"Unknown LEVEL mode %s\n",s1); 
			    fprintf(stderr,"Allowed: [above,below]\n");
			    fprintf(stderr,"Assuming below\n");
			    cfg.subwin_level[cfg.num_subwins-1]=0;
			 }
		    }
		  else if (!strcmp(s1,"action"))
		    {
		       done=1;
		       sscanf(s,"%s %s %i %s %s",s1,s2,&num,s3,s4);
		       if ((num>0)&&(num<4))
			 {
			    if (!strcmp(s2,"none")) 
			      {
				 numm=0;
			      }
			    else if (!strcmp(s2,"shift")) 
			      {
				 numm=1;
			      }
			    else if (!strcmp(s2,"ctrl")) 
			      {
				 numm=2;
			      }
			    else if (!strcmp(s2,"alt")) 
			      {
				 numm=3;
			      }
			    else 
			      {
				 fprintf(stderr,"WARNING!\n");
				 fprintf(stderr,"File: %s, Line %i: ERROR.........\n",file,line);
				 fprintf(stderr,"---> %s",s);
				 fprintf(stderr,"Unknown ACTION modifier %s\n",s1); 
				 fprintf(stderr,"Allowed: [none,shift,ctrl,alt]\n");
				 fprintf(stderr,"Assuming none\n");
				 numm=0;
			      }
			    if (!strcmp(s3,"move")) 
			      {
				 cfg.subwin_action[cfg.num_subwins-1][num-1][numm].id=1;
			      }
			    else if (!strcmp(s3,"resize")) 
			      {
				 cfg.subwin_action[cfg.num_subwins-1][num-1][numm].id=2;
			      }
			    else if (!strcmp(s3,"iconify")) 
			      {
				 cfg.subwin_action[cfg.num_subwins-1][num-1][numm].id=3;
			      }
			    else if (!strcmp(s3,"kill")) 
			      {
				 cfg.subwin_action[cfg.num_subwins-1][num-1][numm].id=4;
			      }
			    else if (!strcmp(s3,"raise")) 
			      {
				 cfg.subwin_action[cfg.num_subwins-1][num-1][numm].id=5;
			      }
			    else if (!strcmp(s3,"lower")) 
			      {
				 cfg.subwin_action[cfg.num_subwins-1][num-1][numm].id=6;
			      }
			    else if (!strcmp(s3,"raise_lower")) 
			      {
				 cfg.subwin_action[cfg.num_subwins-1][num-1][numm].id=7;
			      }
			    else if (!strcmp(s3,"max_height")) 
			      {
				 cfg.subwin_action[cfg.num_subwins-1][num-1][numm].id=8;
			      }
			    else if (!strcmp(s3,"max_width")) 
			      {
				 cfg.subwin_action[cfg.num_subwins-1][num-1][numm].id=9;
			      }
			    else if (!strcmp(s3,"max_size")) 
			      {
				 cfg.subwin_action[cfg.num_subwins-1][num-1][numm].id=10;
			      }
			    else if (!strcmp(s3,"configure")) 
			      {
				 cfg.subwin_action[cfg.num_subwins-1][num-1][numm].id=11;
			      }
			    else if (!strcmp(s3,"menu")) 
			      {
				 cfg.subwin_action[cfg.num_subwins-1][num-1][numm].id=12;
				 strcpy(cfg.subwin_action[cfg.num_subwins-1][num-1][numm].params,s4);
			      }
			    else if (!strcmp(s3,"exec")) 
			      {
				 cfg.subwin_action[cfg.num_subwins-1][num-1][numm].id=13;
				 strcpy(cfg.subwin_action[cfg.num_subwins-1][num-1][numm].params,strstr(s,s4));
			      }
			    else if (!strcmp(s3,"none")) 
			      {
				 cfg.subwin_action[cfg.num_subwins-1][num-1][numm].id=255;
			      }
			    else
			      {
				 fprintf(stderr,"WARNING!\n");
				 fprintf(stderr,"File: %s, Line %i: ERROR.........\n",file,line);
				 fprintf(stderr,"---> %s",s);
				 fprintf(stderr,"Unknown ACTION %s\n",s3); 
				 fprintf(stderr,"Allowed: [move,resize,iconify,kill,raise,lower,raise_lower,max_height,max_width,max_size,configure,menu,exec]\n");
				 fprintf(stderr,"Ignoring statement\n");
			      }
			 }
		       else
			 {
			    fprintf(stderr,"WARNING!\n");
			    fprintf(stderr,"File: %s, Line %i: ERROR.........\n",file,line);
			    fprintf(stderr,"---> %s",s);
			    fprintf(stderr,"Unknown ACTION button %i\n",num); 
			    fprintf(stderr,"Allowed: [1,2,3]\n");
			    fprintf(stderr,"Ignoring action statement\n");
			 }
		    }
	       }
	     if(nest_stack[nest_level]==CTXT_BORDER)
	       {
		  if (!strcmp(s1,"left"))
		    {
		       done=1;
		       sscanf(s,"%s %i",s1,&num);
		       cfg.border_l=num;
		    }
		  else if (!strcmp(s1,"right"))
		    {
		       done=1;
		       sscanf(s,"%s %i",s1,&num);
		       cfg.border_r=num;
		    }
		  else if (!strcmp(s1,"top"))
		    {
		       done=1;
		       sscanf(s,"%s %i",s1,&num);
		       cfg.border_t=num;
		    }
		  else if (!strcmp(s1,"bottom"))
		    {
		       done=1;
		       sscanf(s,"%s %i",s1,&num);
		       cfg.border_b=num;
		    }
	       }
	     if(nest_stack[nest_level]==CTXT_ROOT)
	       {
		  if (!strcmp(s1,"backgroundimage"))
		    {
		       done=1;
		       sscanf(s,"%s %i %i %s",s1,&num,&numm,s2);
		       cfg.root_width=num;
		       cfg.root_height=numm;
		       cfg.root_pname=malloc(sizeof(char)*(strlen(s2)+1));
		       strcpy(cfg.root_pname,s2);
		    }
	       }
	     if(nest_stack[nest_level]==CTXT_TEXT)
	       {
		  if (!strcmp(s1,"fontface"))
		    {
		       done=1;
		       sscanf(s,"%s %s",s1,s2);
		       cfg.font=malloc(sizeof(char)*(strlen(s2)+1));
		       strcpy(cfg.font,s2);
		    }
		  else if (!strcmp(s1,"style"))
		    {
		       done=1;
		       sscanf(s,"%s %s",s1,s2);
		       if (!strcmp(s2,"bold")) cfg.font_style|=BOLD;
		       if (!strcmp(s2,"italic")) cfg.font_style|=ITALIC;
		    }
		  else if (!strcmp(s1,"appearance"))
		    {
		       done=1;
		       sscanf(s,"%s %s",s1,s2);
		       if (!strcmp(s2,"plain")) ;
		       if (!strcmp(s2,"outline")) cfg.font_style|=OUTLINE;
		       if (!strcmp(s2,"shadow")) cfg.font_style|=SHADOW;
		    }
		  else if (!strcmp(s1,"justification"))
		    {
		       done=1;
		       sscanf(s,"%s %s",s1,s2);
		       if (!strcmp(s2,"left")) ;
		       if (!strcmp(s2,"center")) cfg.font_style|=J_CENTER;
		       if (!strcmp(s2,"right")) cfg.font_style|=J_RIGHT;
		    }
		  else if (!strcmp(s1,"foreground"))
		    {
		       done=1;
		       sscanf(s,"%s %i %i %i",s1,&num1,&num2,&num3);
		       cfg.font_fg=ImlibBestColorMatch(imd,&num1,&num2,&num3);
		    }
		  else if (!strcmp(s1,"background"))
		    {
		       done=1;
		       sscanf(s,"s %i %i %i",s1,&num1,&num2,&num3);
		       cfg.font_bg=ImlibBestColorMatch(imd,&num1,&num2,&num3);
		    }
	       }
	     if(nest_stack[nest_level]==CTXT_STATUS)
	       {
		  if (!strcmp(s1,"icons"))
		    {
		       done=1;
		       sscanf(s,"%s %s",s1,s2);
		       if (!strcmp(s2,"background"))
			 {
			    sscanf(s,"%s %s %i %i %i %i %s %s %s %i %i %i",s1,s1,&num1,&num2,&num3,&num4,s2,s3,s4,&r,&g,&b);
			    scfg.icons_x=num1;
			    scfg.icons_y=num2;
			    scfg.icons_w=num3;
			    scfg.icons_h=num4;
			    scfg.icons_bg=malloc(strlen(s2)+1);
			    strcpy(scfg.icons_bg,s2);
			    if (!strcmp(s4,"off")) scfg.icons_icl=NULL;
			    else
			      {
				 scfg.icons_icl=malloc(sizeof(ImColor));
				 scfg.icons_icl->r=r;
				 scfg.icons_icl->r=g;
				 scfg.icons_icl->r=b;
			      }
			 }
		       else if (!strcmp(s2,"box"))
			 {
			    sscanf(s,"%s %s %i %i %i %i %s %s %s %i %i %i",s1,s1,&num1,&num2,&num3,&num4,s2,s3,s4,&r,&g,&b);
			    scfg.iconsbox_x=num1;
			    scfg.iconsbox_y=num2;
			    scfg.iconsbox_w=num3;
			    scfg.iconsbox_h=num4;
			    scfg.iconsbox_bg=malloc(strlen(s2)+1);
			    strcpy(scfg.iconsbox_bg,s2);
			    if (!strcmp(s4,"off")) scfg.iconsbox_icl=NULL;
			    else
			      {
				 scfg.iconsbox_icl=malloc(sizeof(ImColor));
				 scfg.iconsbox_icl->r=r;
				 scfg.iconsbox_icl->r=g;
				 scfg.iconsbox_icl->r=b;
			      }
			 }
		    }
		  else if (!strcmp(s1,"text"))
		    {
		       done=1;
		       sscanf(s,"%s %s",s1,s2);
		       if (!strcmp(s2,"background"))
			 {
			    sscanf(s,"%s %s %i %i %i %i %s %s %s %i %i %i",s1,s1,&num1,&num2,&num3,&num4,s2,s3,s4,&r,&g,&b);
			    scfg.text_x=num1;
			    scfg.text_y=num2;
			    scfg.text_w=num3;
			    scfg.text_h=num4;
			    scfg.text_bg=malloc(strlen(s2)+1);
			    strcpy(scfg.text_bg,s2);
			    if (!strcmp(s4,"off")) scfg.text_icl=NULL;
			    else
			      {
				 scfg.text_icl=malloc(sizeof(ImColor));
				 scfg.text_icl->r=r;
				 scfg.text_icl->r=g;
				 scfg.text_icl->r=b;
			      }
			 }
		       else if (!strcmp(s2,"box"))
			 {
			    sscanf(s,"%s %s %i %i %i %i %s %s %s %i %i %i",s1,s1,&num1,&num2,&num3,&num4,s2,s3,s4,&r,&g,&b);
			    scfg.textbox_x=num1;
			    scfg.textbox_y=num2;
			    scfg.textbox_w=num3;
			    scfg.textbox_h=num4;
			    scfg.textbox_bg=malloc(strlen(s2)+1);
			    strcpy(scfg.textbox_bg,s2);
			    if (!strcmp(s4,"off")) scfg.textbox_icl=NULL;
			    else
			      {
				 scfg.textbox_icl=malloc(sizeof(ImColor));
				 scfg.textbox_icl->r=r;
				 scfg.textbox_icl->r=g;
				 scfg.textbox_icl->r=b;
			      }
			 }
		    }
	       }
	  }
	if (!done)
	  {
	     fprintf(stderr,"SYNTAX ERROR!\n");
	     fprintf(stderr,"File: %s, Line %i: ERROR.........\n",file,line);
	     fprintf(stderr,"---> %s",s);
	     fprintf(stderr,"Unrecognised Keyword: %s\n",s1);
	     fprintf(stderr,"....... Bailing out of here!\n");
	     exit(1);
	  }
	done=0;
     }
   if (nest_level>0)
     {
	fprintf(stderr,"WARNING!\n");
	fprintf(stderr,"File: %s: ERROR .........\n",file);
	fprintf(stderr,"Premature EOF. Context section(s) not terminated with and end Keyword\n");
	fprintf(stderr,"Continuing.........\n");
     }
   fclose(f);
   for (i=0;i<cfg.num_subwins;i++)
     {
	cfg.subwin_img_clk[i]=ImlibLoadImage(imd,cfg.subwin_pmname_clk[i],&cfg.subwin_transp_clk[i]);
	if (!cfg.subwin_img_clk[i]) 
	  {
	     fprintf(stderr,"ERROR: cannot load image: %s\n",cfg.subwin_pmname_clk[i]);
	     exit(1);
	  }
	cfg.subwin_img_sel[i]=ImlibLoadImage(imd,cfg.subwin_pmname_sel[i],&cfg.subwin_transp_sel[i]);
	if (!cfg.subwin_img_sel[i]) 
	  {
	     fprintf(stderr,"ERROR: cannot load image: %s\n",cfg.subwin_pmname_sel[i]);
	     exit(1);
	  }
	cfg.subwin_img_uns[i]=ImlibLoadImage(imd,cfg.subwin_pmname_uns[i],&cfg.subwin_transp_uns[i]);
	if (!cfg.subwin_img_uns[i]) 
	  {
	     fprintf(stderr,"ERROR: cannot load image: %s\n",cfg.subwin_pmname_uns[i]);
	     exit(1);
	  }
     }
}

