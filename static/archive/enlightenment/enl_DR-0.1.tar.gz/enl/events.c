#include "enlightenment.h"

XErrorHandler handleError(Display *dpy, XErrorEvent *ev)
{
   return 0;
}

void handleEvent(XEvent *ev,listhead *l)
{
   switch (ev->type)
     {
      case KeyPress:
	handleKeyDown(ev,l);
	break;
      case KeyRelease:
	handleKeyUp(ev,l);
	break;
      case ButtonPress:
	handleButtonDown(ev,l);
	break;
      case ButtonRelease:
	handleButtonUp(ev,l);
	break;
      case MotionNotify:
	handleMotion(ev,l);
	break;
      case EnterNotify:
	handleEnter(ev,l);
	break;
      case LeaveNotify:
	handleLeave(ev,l);
	break;
      case FocusIn:
	handleFocusIn(ev,l);
	break;
      case FocusOut:
	handleFocusOut(ev,l);
	break;
      case KeymapNotify:
	break;
      case Expose:
	break;
      case GraphicsExpose:
	break;
      case NoExpose:
	break;
      case VisibilityNotify:
	break;
      case CreateNotify:
	break;
      case DestroyNotify:
	handleDestroy(ev,l);
	break;
      case UnmapNotify:
	handleUnmap(ev,l);
	break;
      case MapNotify:
	break;
      case MapRequest:
	handleMap(ev,l);
	break;
      case ReparentNotify:
	break;
      case ConfigureNotify:
	break;
      case ConfigureRequest:
	handleConfigure(ev,l);
	break;
      case GravityNotify:
	break;
      case ResizeRequest:
	handleResize(ev,l);
	break;
      case CirculateNotify:
	break;
      case CirculateRequest:
	handleCirculate(ev,l);
	break;
      case PropertyNotify:
	handleProperty(ev,l);
	break;
      case SelectionClear:
	break;
      case SelectionRequest:
	break;
      case SelectionNotify:
	break;
      case ColormapNotify:
	break;
      case ClientMessage:
	break;
      case MappingNotify:
	break;
      default:
	break;
     }
}

void handleKeyDown(XEvent *ev,listhead *l)
{
}

void handleKeyUp(XEvent *ev,listhead *l)
{
}

void handleButtonDown(XEvent *ev,listhead *l)
{
   Window tmp_win;
   int button;
   int modifier;
   int win_button;
   EWin *ewin;
   BWin *bwin;
   
   tmp_win=ev->xbutton.subwindow;
   button=ev->xbutton.button;
   modifier=ev->xbutton.state;
   if (modifier==0) modifier=0;
   else if (modifier==1) modifier=1;
   else if (modifier==4) modifier=2;
   else if (modifier==8) modifier=3;
   else modifier=0;
   if (tmp_win==root)
     {
	DoRootMenu(button,modifier,ev->xbutton.x,ev->xbutton.y);
     }
   else if (ewin=ListGetSubWinID(l,tmp_win))
     {
	win_button=GetEWinButtonID(ewin,tmp_win);
	DoWindowButton(ewin,tmp_win,button,modifier,win_button);
     }
   else if (bwin=GetButtonWinID(tmp_win))
     {
     }
}

void handleButtonUp(XEvent *ev,listhead *l)
{
   if (evmd.ewin) evmd.ewin->subwin_state[evmd.wbtn]=NORM;
   if ((evmd.wbtn>=0)&&(evmd.ewin)) DrawButton(evmd.ewin,evmd.wbtn);
   evmd.mode=MODE_NORMAL;
   evmd.ewin=NULL;
   evmd.wbtn=-1;
}

void handleMotion(XEvent *ev,listhead *l)
{
   XEvent xev;
   int sx,sy;
   Window w1,w2;
   int x,y,xx,yy;
   int d;
   int wx,wy;
   
   if (evmd.mode==MODE_NORMAL) return;
   else if (evmd.mode==MODE_MOVE)
     {
	if (XCheckTypedEvent(disp,MotionNotify,&xev)) return;
	XQueryPointer(disp,root,&w1,&w2,&sx,&sy,&xx,&yy,&d);
	x=evmd.ewin->frame_x+sx-evmd.px;
	y=evmd.ewin->frame_y+sy-evmd.py;
	ModifyEWin(evmd.ewin,x,y,evmd.ewin->client_width,evmd.ewin->client_height);
	evmd.px=sx;
	evmd.py=sy;
     }
   else if (evmd.mode==MODE_RESIZE)
     {
	if (XCheckTypedEvent(disp,MotionNotify,&xev)) return;
        XQueryPointer(disp,root,&w1,&w2,&sx,&sy,&xx,&yy,&d);
	wx=sx-evmd.px;
	while ((wx%evmd.ewin->sizeinc_x)>0) wx--;
	while ((wx%evmd.ewin->sizeinc_x)<0) wx++;
	wy=sy-evmd.py;
	while ((wy%evmd.ewin->sizeinc_y)>0) wy--;
	while ((wy%evmd.ewin->sizeinc_y)<0) wy++;
	if ((wx!=0)||(wy!=0))
	  {
	     if (evmd.resize_mode==0)
	       {
		  if ((wx>0)&&(evmd.x2<wx)) wx=0;
		  if ((wy>0)&&(evmd.y2<wy)) wy=0;
		  evmd.x1+=wx;evmd.y1+=wy;
		  evmd.x2-=wx;evmd.y2-=wy;
	       }
	     else if (evmd.resize_mode==1)
	       {
		  if ((wx<0)&&(evmd.x2<-wx)) wx=0;
		  if ((wy>0)&&(evmd.y2<wy)) wy=0;
		  evmd.y1+=wy;
		  evmd.x2+=wx;evmd.y2-=wy;
	       }
	     else if (evmd.resize_mode==2)
	       {
		  if ((wx>0)&&(evmd.x2<wx)) wx=0;
		  if ((wy<0)&&(evmd.y2<-wy)) wy=0;
		  evmd.x1+=wx;
		  evmd.x2-=wx;evmd.y2+=wy;
	       }
	     else if (evmd.resize_mode==3)
	       {
		  if ((wx<0)&&(evmd.x2<-wx)) wx=0;
		  if ((wy<0)&&(evmd.y2<-wy)) wy=0;
		  evmd.x2+=wx;evmd.y2+=wy;
	       }
	     if (evmd.x2>evmd.ewin->max_width) evmd.x2=evmd.ewin->max_width;
	     if (evmd.x2<evmd.ewin->min_width) evmd.x2=evmd.ewin->min_width;
	     if (evmd.y2>evmd.ewin->max_height) evmd.y2=evmd.ewin->max_height;
	     if (evmd.y2<evmd.ewin->min_height) evmd.y2=evmd.ewin->min_height;
	     ModifyEWin(evmd.ewin,evmd.x1,evmd.y1,evmd.x2,evmd.y2);
	     evmd.px+=wx;
	     evmd.py+=wy;
	  }
     }
}

void handleEnter(XEvent *ev,listhead *l)
{
   Window tmp_win;
   EWin *ewin;
   
   if (evmd.mode!=MODE_NORMAL) return;
   tmp_win=ev->xcrossing.window;
   if (FocusWin!=tmp_win) /* if the new focus isnt the current one */
     {
	if (FocusWin) /* if there was a previous focus win */
	  {
	     if (ewin=ListGetWinID(l,FocusWin)) /* if it exists */
	       {
		  ewin->state&=~SELECTED; /* unfocus it */
		  ewin->changes|=MOD_SELECT;
		  DrawWindowBorder(ewin); /* redraw the window */
	       }
	  }
	FocusWin=tmp_win; /* change the focus to the new window */
	if (FocusWin==root) /* if the new focus win is root */
	  {
	     FocusWin=0; /* nullify the focus... so all windows */
	     XInstallColormap(disp,root_cmap);		  
	     return; /* are unfocused..... */
	  }
	if (ewin=ListGetWinID(l,tmp_win)) /* if it exists */
	  {
	     ewin->state|=SELECTED; /* focus it */
	     if (ewin->colormap) XInstallColormap(disp,ewin->colormap);
	     else XInstallColormap(disp,root_cmap);
	     ewin->changes|=MOD_SELECT;
	     DrawWindowBorder(ewin); /* redraw the window */
	  }
     }
}

void handleLeave(XEvent *ev,listhead *l)
{
}

void handleFocusIn(XEvent *ev,listhead *l)
{
}

void handleFocusOut(XEvent *ev,listhead *l)
{
}

void handleDestroy(XEvent *ev,listhead *l)
{
   Window tmp_win;
   EWin *ewin;
   
   tmp_win=ev->xdestroywindow.window;
   if (ewin=ListGetClientWinID(l,tmp_win)) /* if it was a client */
     {
	ListDelWinID(l,ewin->frame_win); /* get rid of the ewin */
     }
}

void handleUnmap(XEvent *ev,listhead *l)
{
   Window tmp_win;
   EWin *ewin;
   
   tmp_win=ev->xmap.event;
   if ((ewin=ListGetWinID(l,tmp_win))&& /* if its a client */
       (ewin->state&MAPPED))  /* and the frame was mapped then */
     {
	XUnmapWindow(disp,ewin->frame_win); /* unmap the frame */
	ewin->state&=(ALL-MAPPED); /* and flag it as unmapped */
     }
}

void handleMap(XEvent *ev,listhead *l)
{
   Window tmp_win;
   EWin *ewin;
   
   tmp_win=ev->xmap.window;
   if (ListGetWinID(l,tmp_win)) return;
   if (GetButtonWinID(tmp_win)) return;
   if (!(ewin=ListGetClientWinID(l,tmp_win)))
     {
	ewin=InitEWin(tmp_win); 
	ListAdd(l,ewin);
     }
   XRaiseWindow(disp,ewin->frame_win);
   XMapSubwindows(disp,ewin->frame_win);
   if (!(ewin->state&ICONIFIED)) XMapWindow(disp,ewin->frame_win);
   ewin->state|=MAPPED;
}

void handleReparent(XEvent *ev,listhead *l)
{
   Window tmp_win;
   EWin *ewin;
   
   tmp_win=ev->xreparent.window;
   if (ListGetClientWinID(l,tmp_win))
     {
		  if (!(ewin=ListGetWinID(l,ev->xreparent.parent))) 
			 ListDelWinID(l,ewin->frame_win); 
     }
}

void handleConfigure(XEvent *ev,listhead *l)
{
   Window tmp_win;
   EWin *ewin;

   tmp_win=ev->xconfigure.window;
   if (ewin=ListGetClientWinID(l,tmp_win))
     {
		  GetWinName(tmp_win,ewin->title);
		  ewin->changes|=MOD_TITLE;
		  GetWinColors(tmp_win,ewin);
		  ModifyEWin(ewin,ev->xconfigure.x,ev->xconfigure.y,
						 ev->xconfigure.width,ev->xconfigure.height);
     }
   else
     {
		  XMoveWindow(disp,tmp_win,ev->xconfigure.x,ev->xconfigure.y);
		  XResizeWindow(disp,tmp_win,ev->xconfigure.width,ev->xconfigure.height);
     }
}

void handleResize(XEvent *ev,listhead *l)
{
}

void handleCirculate(XEvent *ev,listhead *l)
{
}

void handleProperty(XEvent *ev,listhead *l)
{
   EWin *ewin;
   Window tmp_win;
   int state;
   
   tmp_win=ev->xproperty.window;
   
   if (ListGetClientWinID(l,tmp_win))
     {
		  switch (ev->xproperty.atom)
			 {
			  case XA_WM_NAME:
				 GetWinName(tmp_win,ewin->title);
				 ewin->changes|=MOD_TITLE;
				 DrawWindowBorder(ewin);
				 break;
			  case XA_WM_ICON_NAME:
				 break;
			  case XA_WM_HINTS:
				 state=ewin->state;
				 GetWinSize(tmp_win,ewin);
				 if (state!=ewin->state) ewin->changes|=MOD_STATE;
				 DrawWindowBorder(ewin);
				 break;
			  case XA_WM_NORMAL_HINTS:
				 state=ewin->state;
				 GetWinSize(tmp_win,ewin);
				 if (state!=ewin->state) ewin->changes|=MOD_STATE;
				 DrawWindowBorder(ewin);
				 break;
			  default:
				 break;
			 }
     }
}


