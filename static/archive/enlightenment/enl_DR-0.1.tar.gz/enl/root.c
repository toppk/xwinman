#include "enlightenment.h"

void SetRoot(void)
{
   Image *root_im;
   int w,h,dummy;
   Pixmap pmap;
   Window wdummy;
   int im_w,im_h;
   int r,g,b;
   
   if (!cfg.root_pname) return;
   r=0,g=0;b=0;
   XSetWindowBackground(disp,root,ImlibBestColorMatch(imd,&r,&g,&b));
   XClearWindow(disp,root);
   XSync(disp,False);
     root_im=ImlibLoadImage(imd,cfg.root_pname,NULL);
   if (!root_im) return;
   XGetGeometry(disp,root,&wdummy,&dummy,&dummy,&w,&h,&dummy,&dummy);
   if (cfg.root_width==0) im_w=root_im->rgb_width;
   else if (cfg.root_width==-1) im_w=w;
   else im_w=cfg.root_width;
   if (cfg.root_height==0) im_h=root_im->rgb_height;
   else if (cfg.root_height==-1) im_h=h;
   else im_w=cfg.root_height;
   ImlibRender(imd,root_im,im_w,im_h);
   pmap=ImlibMoveImageToPixmap(imd,root_im);
   ImlibDestroyImage(imd,root_im);
   XSetWindowBackgroundPixmap(disp,root,pmap);
   XClearWindow(disp,root);
   if (root_pm) XFreePixmap(disp,root_pm);
   root_pm=pmap;
   XSync(disp,0x00);
}

