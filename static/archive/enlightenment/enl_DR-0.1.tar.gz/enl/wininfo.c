#include "enlightenment.h"

void GetWinName(Window win, char *s)
{
   XTextProperty xtp;
   
   
   if (XGetWMName(disp,win,&xtp))
     {
		  strncpy(s,xtp.value,256);
     }
   else strcpy(s,"No Title");
}

void GetWinSize(Window win,EWin *ewin)
{
   Window www;
   int nx,ny,nw,nh,dum,dumm;
   XWMHints *hints1;
   XSizeHints hints2;
   long mask;
   
   XGetGeometry(disp,win,&www,&nx,&ny,&nw,&nh,&dum,&dum);
   if (!XGetTransientForHint(disp,win,&ewin->group_win)) ewin->group_win=0;
   hints1=XGetWMHints(disp,win);
   if (hints1)
     {
		  if (hints1->flags&StateHint)
			 {
				 if (hints1->initial_state&IconicState)
					ewin->state|=ICONIFIED;
			 }
		  XFree (hints1);
     }
   if (XGetWMNormalHints(disp,win,&hints2,&mask))
     {
		  if (hints2.flags&PResizeInc)
			 {
				 ewin->sizeinc_x=hints2.width_inc;
				 ewin->sizeinc_y=hints2.height_inc;
				 if (ewin->sizeinc_x<=0) ewin->sizeinc_x=1;
				 if (ewin->sizeinc_y<=0) ewin->sizeinc_y=1;
			 }
		  else
			 {
				 ewin->sizeinc_x=1;
				 ewin->sizeinc_y=1;
			 }
		  if (hints2.flags&PBaseSize)
			 {
				 if (hints2.flags&PMinSize)
					{
						ewin->min_width=hints2.min_width;
						ewin->min_height=hints2.min_height;
					}
				 else
					{
						ewin->min_width=hints2.base_width;
						ewin->min_height=hints2.base_height;
					}
			 }
		  else if (hints2.flags&PMinSize)
			 {
				 ewin->min_width=hints2.min_width;
				 ewin->min_height=hints2.min_height;
			 }
		  else
			 {
				 ewin->min_width=1;
				 ewin->min_height=1;
			 }
		  if (hints2.flags&PMaxSize)
			 {
				 ewin->max_width=hints2.max_width;
				 ewin->max_height=hints2.max_height;
			 }
		  else
			 {
				 ewin->max_width=MAX_WIDTH;
				 ewin->max_height=MAX_HEIGHT;
			 }
		  if (ewin->min_height<=0) ewin->min_height=1;
		  if (ewin->min_width<=0) ewin->min_width=1;
		  if (ewin->max_width<ewin->min_width) 
			 ewin->max_width=ewin->min_width;
		  if (ewin->max_height<ewin->min_height) 
			 ewin->max_height=ewin->min_height;
     }
	else
	  {
		  ewin->sizeinc_x=1;
		  ewin->sizeinc_y=1;
		  ewin->min_width=1;
		  ewin->min_height=1;
		  ewin->max_width=MAX_WIDTH;
		  ewin->max_height=MAX_HEIGHT;
	  }
   ewin->client_width=nw; /* record the client info for widht & height */
   ewin->client_height=nh;
	if (ewin->client_width>ewin->max_width) ewin->client_width=ewin->max_width;
	if (ewin->client_height>ewin->max_height) ewin->client_height=ewin->max_height;
	if (ewin->client_width<ewin->min_width) ewin->client_width=ewin->min_width;
	if (ewin->client_height<ewin->min_height) ewin->client_height=ewin->min_height;
   nw=ewin->client_width; 
   nh=ewin->client_height;
	XResizeWindow(disp,ewin->client_win,ewin->client_width,ewin->client_height);
   ewin->frame_x=nx; /* X & Y locations desired by client */
   ewin->frame_y=ny;
   ewin->frame_width=nw+ewin->border_l+ewin->border_r; /* width & */
   ewin->frame_height=nh+ewin->border_t+ewin->border_b; /* height for frame */
}

void GetWinColors(Window win,EWin *ewin)
{
   XWindowAttributes xwa;
   if (XGetWindowAttributes(disp,win,&xwa))
     {
		  if (xwa.colormap) ewin->colormap=xwa.colormap;
		  else ewin->colormap=0;
     }
   else ewin->colormap=0;
}

void UnmapClients()
{
	Window rt;
	Window par;
	Window *list;
	int num;
	int i;
	
	XQueryTree(disp,root,&rt,&par,&list,&num);
	if (list)
	  {
		  for (i=0;i<num;i++)
			 {
				 XUnmapWindow(disp,list[i]);
			 }
		  XFlush(disp);
		  free(list);
	  }
}

void MapClients(listhead *l)
{
	Window rt;
	Window par;
	Window *list;
	int num;
	int i;
	EWin *ewin;
	
	XQueryTree(disp,root,&rt,&par,&list,&num);
	if (list)
	  {
		  for (i=0;i<num;i++)
			 {
				 ewin=InitEWin(list[i]); 
				 ListAdd(l,ewin);
				 XRaiseWindow(disp,ewin->frame_win);
				 XMapSubwindows(disp,ewin->frame_win);
				 if (!(ewin->state&ICONIFIED)) XMapWindow(disp,ewin->frame_win);
				 ewin->state|=MAPPED;
			 }
		  XFlush(disp);
		  free(list);
	  }
}

