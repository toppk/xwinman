/*
 * X includes
 */
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/extensions/shape.h>
#include <X11/imlib.h>

/*
 * Standard system includes
 */
#include <stdio.h>
#include <stdlib.h>

/*
 * Constant defines
 */
#define MAX_WIDTH 32767
#define MAX_HEIGHT 32767

/*
 * Data structures global to enlightenment
 */
/*States for an EWin window to be in */
#define SELECTED    (1<<0)
#define ICONIFIED   (1<<1)
#define MAPPED      (1<<2)
#define ALL         (0xffffffff)

/*Changes to be flaged for an EWin */
#define MOD_SIZE    (1<<0)
#define MOD_TITLE   (1<<1)
#define MOD_SELECT  (1<<2)
#define MOD_STATE   (1<<3)
#define MOD_ALL     (0xffffffff)

/*Realtive pos's for EWin Subwindows */
#define POS_TL    (1<<0)
#define POS_TR    (1<<1)
#define POS_BL    (1<<2)
#define POS_BR    (1<<3)

/*Subwin states */
#define NORM 0
#define CLICKED 1

/*Text formatting defined flags*/
#define SHADOW     (1<<0)
#define OUTLINE    (1<<1)
#define J_RIGHT    (1<<2)
#define J_CENTER   (1<<3)
#define ITALIC     (1<<4)
#define BOLD       (1<<5)

/*Modes that enlightenment can be in during its event handling loop*/
#define MODE_NORMAL 0
#define MODE_MOVE   1
#define MODE_RESIZE 2

typedef struct
{
   Window frame_win;
   Window client_win;
   Window group_win;
   int state;
   char title[256];
   
   int changes;
   Colormap colormap;
   int frame_x;
   int frame_y;
   int frame_width;
   int frame_height;
   int sizeinc_x;
   int sizeinc_y;
   int min_width;
   int min_height;
   int max_width;
   int max_height;
   int client_x;
   int client_y;
   int client_width;
   int client_height;
   int border_l;
   int border_r;
   int border_t;
   int border_b;

   int num_subwins;
   Window subwins[64];
   int subwin_state[64];
   Pixmap subwin_pm_clk[64];
   Pixmap subwin_pm_sel[64];
   Pixmap subwin_pm_uns[64];
   Pixmap subwin_pm_clk_mask[64];
   Pixmap subwin_pm_sel_mask[64];
   Pixmap subwin_pm_uns_mask[64];
   Pixmap mask_sel;
   Pixmap mask_uns;
   int lastop;
   int prev_frame_x;
   int prev_frame_y;
   int prev_client_width;
   int prev_client_height;
   int top;
} EWin;

typedef struct
{
   int id;
   char params[256];
} Action;

typedef struct
{
   int shape_mode;
   int move_mode;
   int resize_mode;
   int border_l;
   int border_r;
   int border_t;
   int border_b;
   int num_subwins;
   int subwin_type[64];
   int subwin_level[64];
   int subwin_scale_method[64];
   int subwin_pos_method1[64];
   int subwin_pos_method2[64];
   int subwin_pos_x1[64];
   int subwin_pos_y1[64];
   int subwin_pos_x2[64];
   int subwin_pos_y2[64];
   Action subwin_action[64][3][4];
   char *subwin_pmname_clk[64];
   char *subwin_pmname_sel[64];
   char *subwin_pmname_uns[64];
   ImColor subwin_transp_clk[64];
   ImColor subwin_transp_sel[64];
   ImColor subwin_transp_uns[64];
   Image *subwin_img_clk[64];
   Image *subwin_img_sel[64];
   Image *subwin_img_uns[64];
   char *root_pname;
   int root_width;
   int root_height;
   char *font;
   int font_style;
   int font_fg;
   int font_bg;
} ConfigWin;

typedef struct
{
	int mode;
	EWin *ewin;
	int wbtn;
	int pw;
	int ph;
	int px;
	int py;
	int resize_mode;
	int x1;
	int x2;
	int y1;
	int y2;
} Event_Mode_Data;

/*
 * Global Variables
 */

/* for X */
Display *disp;
int screen;
Window root;
Visual *visual;
int depth;
int scr_width;
int scr_height;
Colormap root_cmap;

/* Imlib */

ImlibData *imd;

/*
 * Enligthenment includes
 */
#include "main.h"
#include "lists.h"
#include "draw.h"
#include "events.h"
#include "wininfo.h"
#include "actions.h"
#include "ewin.h"
#include "loadcfg.h"
#include "root.h"
#include "text.h"
#include "status.h"
#include "buttons.h"

/* for Enlightenment */

Window FocusWin;
ConfigWin cfg;
listhead *global_l;
EWin *global_killewin;
Pixmap root_pm;
Event_Mode_Data evmd;
char font_weight[32];
char font_slant[32];
