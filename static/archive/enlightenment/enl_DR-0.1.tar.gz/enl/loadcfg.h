#define CTXT_NONE            0
#define CTXT_WINDOW          1
#define CTXT_SUBWIN          2
#define CTXT_BORDER          3
#define CTXT_ROOT            4
#define CTXT_TEXT            5
#define CTXT_STATUS          6

void LoadConfig(char *file);

