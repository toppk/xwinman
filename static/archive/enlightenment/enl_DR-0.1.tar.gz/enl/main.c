#include "enlightenment.h"

/* get the option immediately following option a, and place the string in */
/* s. If the option found s is immediately null-terminated */
void Arg_Get(char *a, char *s,int argc, char **argv)
{
   int i;
   
   s[0]=0; /* set the return stirn to be immediately null terminated */
   for (i=0;i<argc;i++) /* loop through all arguments */
     {
	if ((!strcmp(argv[i],a))&&(i!=(argc-1))) /* we have a match */
	  {
	     strcpy(s,argv[i+1]); /* copy the following arg into s */
	     i=argc; /* make ,sure we terminate */
	  }
     }
}

void X_Connect(char *s)
{
   XWindowAttributes xwa;

   if (s[0]==0) s=NULL; /* if the string is empty, use the default display */
   disp=XOpenDisplay(s); /* open the display connection */
   if (disp==NULL) /* if we couldn't open the connection.. error */
     {
		  fprintf(stderr,"Enlightenment: cannot connect to Display  %s\n",
					 XDisplayName(s));
		  exit(1); /* bad error.. we have to exit */
     }
   /* now get some imperative info about the display */
   screen=DefaultScreen(disp); /* the screen number */
   root=DefaultRootWindow(disp); /* the root window id */
   visual=DefaultVisual(disp,screen); /* the visual type */
   depth=DefaultDepth(disp,screen); /* the depth of the screen in bpp */
   scr_width=DisplayWidth(disp,screen); /* the width of the screen */
   scr_height=DisplayHeight(disp,screen); /* height of the screen */
	UnmapClients();
   XSelectInput(disp,root,SubstructureNotifyMask|ButtonPressMask|
					 ButtonReleaseMask|EnterWindowMask|LeaveWindowMask|
					 ButtonMotionMask|FocusChangeMask|ColormapChangeMask|
					 PropertyChangeMask|SubstructureRedirectMask|
					 StructureNotifyMask|KeyPressMask|KeyReleaseMask|
					 PointerMotionMask|PointerMotionHintMask|ResizeRedirectMask|
					 FocusChangeMask|OwnerGrabButtonMask);
   /* set up an apporpriate event mask */
   if (XGetWindowAttributes(disp,root,&xwa))
     {
		  if (xwa.colormap) root_cmap=xwa.colormap;
		  else root_cmap=0;
     }
   else root_cmap=0;
	XSetErrorHandler((XErrorHandler)handleError);
}

int 
main(int argc, char **argv)
{
   char s[1024];
   XEvent event;
   listhead *l;
   
   Arg_Get("-display",s,argc,argv); /* see if -display was specified */
   X_Connect(s); /* connect to the display nominated */
   
   imd=ImlibInit(disp); /* Inititalise Imlib..... */
   if (!imd) /* uh oh.. problems... imlib had a bad day... */
     { 
	fprintf(stderr,"FATAL.... cannot initialise Imlib!!! Outa here!\n");
	exit(1);
     }
   
   l=ListInit(); /* initialise the window list */
   global_l=l;
   LoadConfig("windowstyles");
   
   evmd.mode=MODE_NORMAL;
   evmd.ewin=NULL;
   evmd.wbtn=-1;
   Kill_StatusWin();
   MapClients(l);
   while(1) /* loop continuously and reacting to events */
     {
	if (global_killewin)
	  {
	     ListDelWinID(l,global_killewin->frame_win);
	     global_killewin=NULL;
	  }
	XNextEvent(disp,&event); /* Get the next event to the display */
	/*XGrabServer(disp);*/ /* grab the server.. dont let clients play around */
	handleEvent(&event,l);
	XSync(disp,0x00);
	/*XUngrabServer(disp);*/
     }
}

