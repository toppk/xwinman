void FontField(char *font, int num, char *ret);
void InitTextInfo();
void DrawText(Pixmap p, char *txt, int w, int h);
