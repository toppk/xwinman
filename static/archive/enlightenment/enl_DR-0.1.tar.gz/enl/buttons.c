#include "enlightenment.h"

BWin *GetButtonWinID(Window w)
{
   struct blist *ptr;
   
   ptr=bl.first;
   while (ptr)
     {
	if (ptr->bwin->win==w) return ptr->bwin;
	ptr=ptr->next;
     }
   return 0;
}

void AddButton(BWin *bwin)
{
   struct blist *pptr;
   struct blist *ptr;
   
   ptr=bl.first;
   while (ptr)
     {
	pptr=ptr;
	ptr=ptr->next;
     }
   if (ptr==NULL)
     {
	bl.first=malloc(sizeof(struct blist));
	bl.first->next=NULL;
	bl.first->bwin=bwin;
     }
   else
     {
	pptr->next=malloc(sizeof(struct blist));
	pptr->next=NULL;
	pptr->bwin=bwin;
     }
}

void DelButton(Window w)
{
}

