#include "imlib.h"

int ImlibBestColorMatch(ImlibData *id, int *r,int *g,int *b)
{
   int i;
   int dif;
   int dr,dg,db;
   int col;
   int mindif=0x7fffffff;
   int ddr,ddg,ddb;
   
   if (!id)
     {
        fprintf(stderr,"ImLib ERROR: No ImlibData initialised\n");
	return -1;
     }
   for (i=0;i<id->num_colors;i++)
     {
	dr=*r-id->palette[i].r;
	if (dr<0) dr=-dr;
	dg=*g-id->palette[i].g;
	if (dg<0) dg=-dg;
	db=*b-id->palette[i].b;
	if (db<0) db=-db;
	dif=dr+dg+db;
	if (dif<mindif)
	  {
	     mindif=dif;
	     col=id->palette[i].pixel;
	     ddr=*r-id->palette[i].r;
	     ddg=*g-id->palette[i].g;
	     ddb=*b-id->palette[i].b;
	  }
     }
   *r=ddr;*g=ddg;*b=ddb;
   return col;
}

int ImlibRender(ImlibData *id, Image *im, int w, int h)
{
   XImage *xim,*sxim;
   GC tgc,stgc;
   XGCValues gcv;
   int x,y,val,r,g,b;
   int inc__x,inc__y,pos_x,pos_y,w3;
   unsigned char *ptr1,*ptr2,*ptr22,*tmp,*stmp;
   int *error,*er1,*er2,*ter;
   int ex;
   int er,eg,eb;
   
   if (w<=0) return;
   if (h<=0) return;
   inc__x=(im->rgb_width<<16)/w;
   inc__y=(im->rgb_height<<16)/h;
   pos_x=0;
   pos_y=0;
   im->width=w;
   im->height=h;
   if (im->pixmap) XFreePixmap(id->x.disp,im->pixmap);
   im->pixmap=XCreatePixmap(id->x.disp,id->x.root,w,h,id->x.depth);
   if ((im->shape_color.r>=0)&&(im->shape_color.g>=0)&&(im->shape_color.b>=0))
     {
		  if (im->shape_mask) XFreePixmap(id->x.disp,im->shape_mask);
		  im->shape_mask=XCreatePixmap(id->x.disp,id->x.root,w,h,1);
		  stmp=(unsigned char *)malloc(w*h);
		  if (!stmp)
			 {
				 fprintf(stderr,"ERROR: Cannot allocate RAM for shape image data\n");
				 return 0;
			 }
		  sxim=XCreateImage(id->x.disp,id->x.visual,1,XYBitmap,0,stmp,w,h,8,0);
		  if (!sxim)
			 {
				 fprintf(stderr,"ERROR: Cannot allocate Ximage shape buffer\n");
				 return 0;
			 }
		  stgc=XCreateGC(id->x.disp,im->shape_mask,(unsigned long)0,&gcv);
     }
   if (id->x.depth<8) tmp=(unsigned char *)malloc(w*h);
   if (id->x.depth==8) tmp=(unsigned char *)malloc(w*h);
   else if (id->x.depth==15) tmp=(unsigned char *)malloc(w*h*2);
   else if (id->x.depth==16) tmp=(unsigned char *)malloc(w*h*2);
   else if (id->x.depth==24) tmp=(unsigned char *)malloc(w*h*4);
   else if (id->x.depth==32) tmp=(unsigned char *)malloc(w*h*4);
   if (!tmp)
     {
		  fprintf(stderr,"ERROR: Cannot allocate RAM for image data\n");
		  return 0;
     }
   error=(int *)malloc(sizeof(int)*w*2*3);
   if (!error)
     {
		  fprintf(stderr,"ERROR: Cannot allocate RAM for image dither buffer\n");
		  return 0;
     }
   xim=XCreateImage(id->x.disp,id->x.visual,id->x.depth,ZPixmap,0,tmp,w,h,8,0);
   if (!xim)
     {
		  fprintf(stderr,"ERROR: Cannot allocate Ximage buffer\n");
		  return 0;
     }
   er1=error;
   er2=error+(w*3);
   ptr1=tmp;
   ptr22=im->rgb_data;
   w3=im->rgb_width*3;
   tgc=XCreateGC(id->x.disp,im->pixmap,(unsigned long)0,&gcv);
   for (ex=0;ex<(w*3*2);ex++) error[ex]=0;
   if ((im->shape_color.r>=0)&&(im->shape_color.g>=0)&&(im->shape_color.b>=0))
     {
		  if (id->x.depth<8)
			 {
				 switch (id->render_type)
					{
					 case RT_PLAIN_PALETTE:
						for(y=0;y<h;y++)
						  {
							  pos_x=0;
							  for(x=0;x<w;x++)
								 {
									 ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
									 r=(int)*ptr2++;
									 g=(int)*ptr2++;
									 b=(int)*ptr2++;
									 if ((r==im->shape_color.r)&&
										  (g==im->shape_color.g)&&
										  (b==im->shape_color.b))
										{
											XPutPixel(sxim,x,y,1);
										}
									 else
										{
											XPutPixel(sxim,x,y,0);
										}
									 val=ImlibBestColorMatch(id,&r,&g,&b);
									 XPutPixel(xim,x,y,val);
									 pos_x+=inc__x;
								 }
							  pos_y+=inc__y;
							  ptr22=im->rgb_data+((pos_y>>16)*w3);
						  }
						break;
					 case RT_PLAIN_PALETTE_FAST:
						for(y=0;y<h;y++)
						  {
							  pos_x=0;
							  for(x=0;x<w;x++)
								 {
									 ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
									 r=(int)*ptr2++;
									 g=(int)*ptr2++;
									 b=(int)*ptr2++;
									 if ((r==im->shape_color.r)&&
										  (g==im->shape_color.g)&&
										  (b==im->shape_color.b))
										{
											XPutPixel(sxim,x,y,1);
										}
									 else
										{
											XPutPixel(sxim,x,y,0);
										}
									 val=id->fast_rgb[r>>3][g>>3][b>>3];
									 XPutPixel(xim,x,y,val);
									 pos_x+=inc__x;
								 }
							  pos_y+=inc__y;
							  ptr22=im->rgb_data+((pos_y>>16)*w3);
						  }
						break;
					 case RT_DITHER_PALETTE:
						for(y=0;y<h;y++)
						  {
							  pos_x=0;
							  ter=er1;
							  er1=er2;
							  er2=ter;
							  for (ex=0;ex<w*3;ex++) er2[ex]=0;
							  ex=0;
							  for(x=0;x<w;x++)
								 {
									 ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
									 r=(int)*ptr2++;
									 g=(int)*ptr2++;
									 b=(int)*ptr2++;
									 if ((r==im->shape_color.r)&&
										  (g==im->shape_color.g)&&
										  (b==im->shape_color.b))
										{
											XPutPixel(sxim,x,y,1);
										}
									 else
										{
											XPutPixel(sxim,x,y,0);
										}
									 er=r+er1[ex++];eg=g+er1[ex++];eb=b+er1[ex++];
									 if (er>255) er=255;
									 if (er<0) er=0;
									 if (eg>255) eg=255;
			    if (eg<0) eg=0;
			    if (eb>255) eb=255;
			    if (eb<0) eb=0;
			    val=ImlibBestColorMatch(id,&er,&eg,&eb);
			    if (x<(w-1))
			      {
				 er1[ex+0]+=(er*7)/16;
				 er1[ex+1]+=(eg*7)/16;
				 er1[ex+2]+=(eb*7)/16;
			      }
			    if (y<(h-1))
			      {
				 if (x>0)
				   {
				      er2[ex-6]+=(er*3)/16;
				      er2[ex-5]+=(eg*3)/16;
				      er2[ex-4]+=(eb*3)/16;
				   }
				 er2[ex-3]+=(er*5)/16;
				 er2[ex-2]+=(eg*5)/16;
				 er2[ex-1]+=(eb*5)/16;
				 if (x<(w-1))
				   {
				      er2[ex+0]+=(er*1)/16;
				      er2[ex+1]+=(eg*1)/16;
				      er2[ex+2]+=(eb*1)/16;
				   }
			      }
			    XPutPixel(xim,x,y,val);
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_DITHER_PALETTE_FAST:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       ter=er1;
		       er1=er2;
		       er2=ter;
		       for (ex=0;ex<w*3;ex++) er2[ex]=0;
		       ex=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    if ((r==im->shape_color.r)&&
			      (g==im->shape_color.g)&&
			      (b==im->shape_color.b))
			      {
				XPutPixel(sxim,x,y,1);
			      }
			    else
			      {
				XPutPixel(sxim,x,y,0);
			      }
			    er=r+er1[ex++];eg=g+er1[ex++];eb=b+er1[ex++];
			    if (er>255) er=255;
			    if (er<0) er=0;
			    if (eg>255) eg=255;
			    if (eg<0) eg=0;
			    if (eb>255) eb=255;
			    if (eb<0) eb=0;
			    val=id->fast_rgb[er>>3][eg>>3][eb>>3];
			    r=id->fast_err[er>>3][eg>>3][eb>>3];
			    g=id->fast_erg[er>>3][eg>>3][eb>>3];
			    b=id->fast_erb[er>>3][eg>>3][eb>>3];
			    er=r;eg=g;eb=b;
			    if (x<(w-1))
			      {
				 er1[ex+0]+=(er*7)/16;
				 er1[ex+1]+=(eg*7)/16;
				 er1[ex+2]+=(eb*7)/16;
			      }
			    if (y<(h-1))
			      {
				 if (x>0)
				   {
				      er2[ex-6]+=(er*3)/16;
				      er2[ex-5]+=(eg*3)/16;
				      er2[ex-4]+=(eb*3)/16;
				   }
				 er2[ex-3]+=(er*5)/16;
				 er2[ex-2]+=(eg*5)/16;
				 er2[ex-1]+=(eb*5)/16;
				 if (x<(w-1))
				   {
				      er2[ex+0]+=(er*1)/16;
				      er2[ex+1]+=(eg*1)/16;
				      er2[ex+2]+=(eb*1)/16;
				   }
			      }
			    XPutPixel(xim,x,y,val);
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		default:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    if ((r==im->shape_color.r)&&
			      (g==im->shape_color.g)&&
			      (b==im->shape_color.b))
			      {
				XPutPixel(sxim,x,y,1);
			      }
			    else
			      {
				XPutPixel(sxim,x,y,0);
			      }
			    val=0;
			    XPutPixel(xim,x,y,val);
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
	       }
	  }
	if (id->x.depth==8)
	  {
	     switch (id->render_type)
	       {
		case RT_PLAIN_PALETTE:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    if ((r==im->shape_color.r)&&
			      (g==im->shape_color.g)&&
			      (b==im->shape_color.b))
			      {
				 XPutPixel(sxim,x,y,1);
			      }
			    else
			      {
				 XPutPixel(sxim,x,y,0);
			      }
			    val=ImlibBestColorMatch(id,&r,&g,&b);
			    *ptr1++=val;
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_PLAIN_PALETTE_FAST:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    if ((r==im->shape_color.r)&&
			      (g==im->shape_color.g)&&
			      (b==im->shape_color.b))
			      {
				XPutPixel(sxim,x,y,1);
			      }
			    else
			      {
				XPutPixel(sxim,x,y,0);
			      }
			    val=id->fast_rgb[r>>3][g>>3][b>>3];
			    *ptr1++=val;
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_DITHER_PALETTE:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       ter=er1;
		       er1=er2;
		       er2=ter;
		       for (ex=0;ex<w*3;ex++) er2[ex]=0;
		       ex=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    if ((r==im->shape_color.r)&&
			      (g==im->shape_color.g)&&
			      (b==im->shape_color.b))
			      {
				XPutPixel(sxim,x,y,1);
			      }
			    else
			      {
				XPutPixel(sxim,x,y,0);
			      }
			    er=r+er1[ex++];eg=g+er1[ex++];eb=b+er1[ex++];
			    if (er>255) er=255;
			    if (er<0) er=0;
			    if (eg>255) eg=255;
			    if (eg<0) eg=0;
			    if (eb>255) eb=255;
			    if (eb<0) eb=0;
			    val=ImlibBestColorMatch(id,&er,&eg,&eb);
			    if (x<(w-1))
			      {
				 er1[ex+0]+=(er*7)/16;
				 er1[ex+1]+=(eg*7)/16;
				 er1[ex+2]+=(eb*7)/16;
			      }
		       if (y<(h-1))
			      {
				 if (x>0)
				   {
				      er2[ex-6]+=(er*3)/16;
				      er2[ex-5]+=(eg*3)/16;
				      er2[ex-4]+=(eb*3)/16;
				   }
				 er2[ex-3]+=(er*5)/16;
				 er2[ex-2]+=(eg*5)/16;
				 er2[ex-1]+=(eb*5)/16;
				 if (x<(w-1))
				   {
				      er2[ex+0]+=(er*1)/16;
				      er2[ex+1]+=(eg*1)/16;
				      er2[ex+2]+=(eb*1)/16;
				   }
			      }
			    *ptr1++=val;
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_DITHER_PALETTE_FAST:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       ter=er1;
		       er1=er2;
		       er2=ter;
		       for (ex=0;ex<w*3;ex++) er2[ex]=0;
		       ex=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    if ((r==im->shape_color.r)&&
			      (g==im->shape_color.g)&&
			      (b==im->shape_color.b))
			      {
				XPutPixel(sxim,x,y,1);
			      }
			    else
			      {
				XPutPixel(sxim,x,y,0);
			      }
			    er=r+er1[ex++];eg=g+er1[ex++];eb=b+er1[ex++];
			    if (er>255) er=255;
			    if (er<0) er=0;
			    if (eg>255) eg=255;
			    if (eg<0) eg=0;
			    if (eb>255) eb=255;
			    if (eb<0) eb=0;
			    val=id->fast_rgb[er>>3][eg>>3][eb>>3];
			    r=id->fast_err[er>>3][eg>>3][eb>>3];
			    g=id->fast_erg[er>>3][eg>>3][eb>>3];
			    b=id->fast_erb[er>>3][eg>>3][eb>>3];
			    er=r;eg=g;eb=b;
			    if (x<(w-1))
			      {
				 er1[ex+0]+=(er*7)/16;
				 er1[ex+1]+=(eg*7)/16;
				 er1[ex+2]+=(eb*7)/16;
			      }
			    if (y<(h-1))
			      {
				 if (x>0)
				   {
				      er2[ex-6]+=(er*3)/16;
				      er2[ex-5]+=(eg*3)/16;
				      er2[ex-4]+=(eb*3)/16;
				   }
				 er2[ex-3]+=(er*5)/16;
				 er2[ex-2]+=(eg*5)/16;
				 er2[ex-1]+=(eb*5)/16;
				 if (x<(w-1))
				   {
				      er2[ex+0]+=(er*1)/16;
				      er2[ex+1]+=(eg*1)/16;
				      er2[ex+2]+=(eb*1)/16;
				   }
			      }
			    *ptr1++=val;
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		default:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    if ((r==im->shape_color.r)&&
			      (g==im->shape_color.g)&&
			      (b==im->shape_color.b))
			      {
				XPutPixel(sxim,x,y,1);
			      }
			    else
			      {
				XPutPixel(sxim,x,y,0);
			      }
			    val=0;
			    *ptr1++=val;
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
	       }
	  }
	if (id->x.depth==15)
	  {
	     switch (id->render_type)
	       {
		case RT_PLAIN_PALETTE:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    if ((r==im->shape_color.r)&&
			      (g==im->shape_color.g)&&
			      (b==im->shape_color.b))
			      {
				XPutPixel(sxim,x,y,1);
			      }
			    else
			      {
				XPutPixel(sxim,x,y,0);
			      }
			    val=ImlibBestColorMatch(id,&r,&g,&b);
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=(val>>8);
			      }
			    else
			      {
				 *ptr1++=(val>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_PLAIN_PALETTE_FAST:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    if ((r==im->shape_color.r)&&
			      (g==im->shape_color.g)&&
			      (b==im->shape_color.b))
			      {
				XPutPixel(sxim,x,y,1);
			      }
			    else
			      {
				XPutPixel(sxim,x,y,0);
			      }
			    val=id->fast_rgb[r>>3][g>>3][b>>3];
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=(val>>8);
			      }
			    else
			      {
				 *ptr1++=(val>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_DITHER_PALETTE:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       ter=er1;
		       er1=er2;
		       er2=ter;
		       for (ex=0;ex<w*3;ex++) er2[ex]=0;
		       ex=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    if ((r==im->shape_color.r)&&
			      (g==im->shape_color.g)&&
			      (b==im->shape_color.b))
			      {
				XPutPixel(sxim,x,y,1);
			      }
			    else
			      {
				XPutPixel(sxim,x,y,0);
			      }
			    er=r+er1[ex++];eg=g+er1[ex++];eb=b+er1[ex++];
			    if (er>255) er=255;
			    if (er<0) er=0;
			    if (eg>255) eg=255;
			    if (eg<0) eg=0;
			    if (eb>255) eb=255;
			    if (eb<0) eb=0;
			    val=ImlibBestColorMatch(id,&er,&eg,&eb);
			    if (x<(w-1))
			      {
				 er1[ex+0]+=(er*7)/16;
				 er1[ex+1]+=(eg*7)/16;
				 er1[ex+2]+=(eb*7)/16;
			      }
			    if (y<(h-1))
			      {
				 if (x>0)
				   {
				      er2[ex-6]+=(er*3)/16;
				      er2[ex-5]+=(eg*3)/16;
				      er2[ex-4]+=(eb*3)/16;
				   }
				 er2[ex-3]+=(er*5)/16;
				 er2[ex-2]+=(eg*5)/16;
				 er2[ex-1]+=(eb*5)/16;
				 if (x<(w-1))
				   {
				      er2[ex+0]+=(er*1)/16;
				      er2[ex+1]+=(eg*1)/16;
				      er2[ex+2]+=(eb*1)/16;
				   }
			      }
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=(val>>8);
			      }
			    else
			      {
				 *ptr1++=(val>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_DITHER_PALETTE_FAST:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       ter=er1;
		       er1=er2;
		       er2=ter;
		       for (ex=0;ex<w*3;ex++) er2[ex]=0;
		       ex=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    if ((r==im->shape_color.r)&&
			      (g==im->shape_color.g)&&
			      (b==im->shape_color.b))
			      {
				XPutPixel(sxim,x,y,1);
			      }
			    else
			      {
				XPutPixel(sxim,x,y,0);
			      }
			    er=r+er1[ex++];eg=g+er1[ex++];eb=b+er1[ex++];
			    if (er>255) er=255;
			    if (er<0) er=0;
			    if (eg>255) eg=255;
			    if (eg<0) eg=0;
			    if (eb>255) eb=255;
			    if (eb<0) eb=0;
			    val=id->fast_rgb[er>>3][eg>>3][eb>>3];
			    r=id->fast_err[er>>3][eg>>3][eb>>3];
			    g=id->fast_erg[er>>3][eg>>3][eb>>3];
			    b=id->fast_erb[er>>3][eg>>3][eb>>3];
			    er=r;eg=g;eb=b;
			    if (x<(w-1))
			      {
				 er1[ex+0]+=(er*7)/16;
				 er1[ex+1]+=(eg*7)/16;
				 er1[ex+2]+=(eb*7)/16;
			      }
			    if (y<(h-1))
			      {
				 if (x>0)
				   {
				      er2[ex-6]+=(er*3)/16;
				      er2[ex-5]+=(eg*3)/16;
				      er2[ex-4]+=(eb*3)/16;
				   }
				 er2[ex-3]+=(er*5)/16;
				 er2[ex-2]+=(eg*5)/16;
				 er2[ex-1]+=(eb*5)/16;
				 if (x<(w-1))
				   {
				      er2[ex+0]+=(er*1)/16;
				      er2[ex+1]+=(eg*1)/16;
				      er2[ex+2]+=(eb*1)/16;
				   }
			      }
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=(val>>8);
			      }
			    else
			      {
				 *ptr1++=(val>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		default:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    if ((r==im->shape_color.r)&&
			      (g==im->shape_color.g)&&
			      (b==im->shape_color.b))
			      {
				XPutPixel(sxim,x,y,1);
			      }
			    else
			      {
				XPutPixel(sxim,x,y,0);
			      }
			    val=((r&0xf8)<<7)|((g&0xf8)<<2)|((b&0xf8)>>3);
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=(val>>8);
			      }
			    else
			      {
				 *ptr1++=(val>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
	       }
	  }
	if (id->x.depth==16)
	  {
	     switch (id->render_type)
	       {
		case RT_PLAIN_PALETTE:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    if ((r==im->shape_color.r)&&
			      (g==im->shape_color.g)&&
			      (b==im->shape_color.b))
			      {
				XPutPixel(sxim,x,y,1);
			      }
			    else
			      {
				XPutPixel(sxim,x,y,0);
			      }
			    val=ImlibBestColorMatch(id,&r,&g,&b);
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=(val>>8);
			      }
			    else
			      {
				 *ptr1++=(val>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_PLAIN_PALETTE_FAST:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    if ((r==im->shape_color.r)&&
			      (g==im->shape_color.g)&&
			      (b==im->shape_color.b))
			      {
				XPutPixel(sxim,x,y,1);
			      }
			    else
			      {
				XPutPixel(sxim,x,y,0);
			      }
			    val=id->fast_rgb[r>>3][g>>3][b>>3];
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=(val>>8);
			      }
			    else
			      {
				 *ptr1++=(val>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_DITHER_PALETTE:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       ter=er1;
		       er1=er2;
		       er2=ter;
		       for (ex=0;ex<w*3;ex++) er2[ex]=0;
		       ex=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    if ((r==im->shape_color.r)&&
			      (g==im->shape_color.g)&&
			      (b==im->shape_color.b))
			      {
				XPutPixel(sxim,x,y,1);
			      }
			    else
			      {
				XPutPixel(sxim,x,y,0);
			      }
			    er=r+er1[ex++];eg=g+er1[ex++];eb=b+er1[ex++];
			    if (er>255) er=255;
			    if (er<0) er=0;
			    if (eg>255) eg=255;
			    if (eg<0) eg=0;
			    if (eb>255) eb=255;
			    if (eb<0) eb=0;
			    val=ImlibBestColorMatch(id,&er,&eg,&eb);
			    if (x<(w-1))
			      {
				 er1[ex+0]+=(er*7)/16;
				 er1[ex+1]+=(eg*7)/16;
				 er1[ex+2]+=(eb*7)/16;
			      }
			    if (y<(h-1))
			      {
				 if (x>0)
				   {
				      er2[ex-6]+=(er*3)/16;
				      er2[ex-5]+=(eg*3)/16;
				      er2[ex-4]+=(eb*3)/16;
				   }
				 er2[ex-3]+=(er*5)/16;
				 er2[ex-2]+=(eg*5)/16;
				 er2[ex-1]+=(eb*5)/16;
				 if (x<(w-1))
				   {
				      er2[ex+0]+=(er*1)/16;
				      er2[ex+1]+=(eg*1)/16;
				      er2[ex+2]+=(eb*1)/16;
				   }
			      }
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=(val>>8);
			      }
			    else
			      {
				 *ptr1++=(val>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_DITHER_PALETTE_FAST:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       ter=er1;
		       er1=er2;
		       er2=ter;
		       for (ex=0;ex<w*3;ex++) er2[ex]=0;
		       ex=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    if ((r==im->shape_color.r)&&
			      (g==im->shape_color.g)&&
			      (b==im->shape_color.b))
			      {
				XPutPixel(sxim,x,y,1);
			      }
			    else
			      {
				XPutPixel(sxim,x,y,0);
			      }
			    er=r+er1[ex++];eg=g+er1[ex++];eb=b+er1[ex++];
			    if (er>255) er=255;
			    if (er<0) er=0;
			    if (eg>255) eg=255;
			    if (eg<0) eg=0;
			    if (eb>255) eb=255;
			    if (eb<0) eb=0;
			    val=id->fast_rgb[er>>3][eg>>3][eb>>3];
			    r=id->fast_err[er>>3][eg>>3][eb>>3];
			    g=id->fast_erg[er>>3][eg>>3][eb>>3];
			    b=id->fast_erb[er>>3][eg>>3][eb>>3];
			    er=r;eg=g;eb=b;
			    if (x<(w-1))
			      {
				 er1[ex+0]+=(er*7)/16;
				 er1[ex+1]+=(eg*7)/16;
				 er1[ex+2]+=(eb*7)/16;
			      }
			    if (y<(h-1))
			      {
				 if (x>0)
				   {
				      er2[ex-6]+=(er*3)/16;
				      er2[ex-5]+=(eg*3)/16;
				      er2[ex-4]+=(eb*3)/16;
				   }
				 er2[ex-3]+=(er*5)/16;
				 er2[ex-2]+=(eg*5)/16;
				 er2[ex-1]+=(eb*5)/16;
				 if (x<(w-1))
				   {
				      er2[ex+0]+=(er*1)/16;
				      er2[ex+1]+=(eg*1)/16;
				      er2[ex+2]+=(eb*1)/16;
				   }
			      }
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=(val>>8);
			      }
			    else
			      {
				 *ptr1++=(val>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		default:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    if ((r==im->shape_color.r)&&
			      (g==im->shape_color.g)&&
			      (b==im->shape_color.b))
			      {
				XPutPixel(sxim,x,y,1);
			      }
			    else
			      {
				XPutPixel(sxim,x,y,0);
			      }
			    val=((r&0xf8)<<8)|((g&0xfc)<<3)|((b&0xf8)>>3);
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=(val>>8);
			      }
			    else
			      {
				 *ptr1++=(val>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
	       }
	  }
	if ((id->x.depth==32)||(id->x.depth==24))
	  {
	     switch (id->render_type)
	       {
		case RT_PLAIN_PALETTE:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    if ((r==im->shape_color.r)&&
			      (g==im->shape_color.g)&&
			      (b==im->shape_color.b))
			      {
				XPutPixel(sxim,x,y,1);
			      }
			    else
			      {
				XPutPixel(sxim,x,y,0);
			      }
			    val=ImlibBestColorMatch(id,&r,&g,&b);
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=((val&0xff00)>>8);
				 *ptr1++=(val>>16);
				 *ptr1++=0;
			      }
			    else
			      {
				 *ptr1++=0;
				 *ptr1++=(val>>16);
				 *ptr1++=((val&0xff00)>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_PLAIN_PALETTE_FAST:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    if ((r==im->shape_color.r)&&
			      (g==im->shape_color.g)&&
			      (b==im->shape_color.b))
			      {
				XPutPixel(sxim,x,y,1);
			      }
			    else
			      {
				XPutPixel(sxim,x,y,0);
			      }
			    val=id->fast_rgb[r>>3][g>>3][b>>3];
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=((val&0xff00)>>8);
				 *ptr1++=(val>>16);
				 *ptr1++=0;
			      }
			    else
			      {
				 *ptr1++=0;
				 *ptr1++=(val>>16);
				 *ptr1++=((val&0xff00)>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_DITHER_PALETTE:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       ter=er1;
		       er1=er2;
		       er2=ter;
		       for (ex=0;ex<w*3;ex++) er2[ex]=0;
		       ex=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    if ((r==im->shape_color.r)&&
			      (g==im->shape_color.g)&&
			      (b==im->shape_color.b))
			      {
				XPutPixel(sxim,x,y,1);
			      }
			    else
			      {
				XPutPixel(sxim,x,y,0);
			      }
			    er=r+er1[ex++];eg=g+er1[ex++];eb=b+er1[ex++];
			    if (er>255) er=255;
			    if (er<0) er=0;
			    if (eg>255) eg=255;
			    if (eg<0) eg=0;
			    if (eb>255) eb=255;
			    if (eb<0) eb=0;
			    val=ImlibBestColorMatch(id,&er,&eg,&eb);
			    if (x<(w-1))
			      {
				 er1[ex+0]+=(er*7)/16;
				 er1[ex+1]+=(eg*7)/16;
				 er1[ex+2]+=(eb*7)/16;
			      }
			    if (y<(h-1))
			      {
				 if (x>0)
				   {
				      er2[ex-6]+=(er*3)/16;
				      er2[ex-5]+=(eg*3)/16;
				      er2[ex-4]+=(eb*3)/16;
				   }
				 er2[ex-3]+=(er*5)/16;
				 er2[ex-2]+=(eg*5)/16;
				 er2[ex-1]+=(eb*5)/16;
				 if (x<(w-1))
				   {
				      er2[ex+0]+=(er*1)/16;
				      er2[ex+1]+=(eg*1)/16;
				      er2[ex+2]+=(eb*1)/16;
				   }
			      }
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=((val&0xff00)>>8);
				 *ptr1++=(val>>16);
				 *ptr1++=0;
			      }
			    else
			      {
				 *ptr1++=0;
				 *ptr1++=(val>>16);
				 *ptr1++=((val&0xff00)>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_DITHER_PALETTE_FAST:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       ter=er1;
		       er1=er2;
		       er2=ter;
		       for (ex=0;ex<w*3;ex++) er2[ex]=0;
		       ex=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    if ((r==im->shape_color.r)&&
			      (g==im->shape_color.g)&&
			      (b==im->shape_color.b))
			      {
				XPutPixel(sxim,x,y,1);
			      }
			    else
			      {
				XPutPixel(sxim,x,y,0);
			      }
			    er=r+er1[ex++];eg=g+er1[ex++];eb=b+er1[ex++];
			    if (er>255) er=255;
			    if (er<0) er=0;
			    if (eg>255) eg=255;
			    if (eg<0) eg=0;
			    if (eb>255) eb=255;
			    if (eb<0) eb=0;
			    val=id->fast_rgb[er>>3][eg>>3][eb>>3];
			    r=id->fast_err[er>>3][eg>>3][eb>>3];
			    g=id->fast_erg[er>>3][eg>>3][eb>>3];
			    b=id->fast_erb[er>>3][eg>>3][eb>>3];
			    er=r;eg=g;eb=b;
			    if (x<(w-1))
			      {
				 er1[ex+0]+=(er*7)/16;
				 er1[ex+1]+=(eg*7)/16;
				 er1[ex+2]+=(eb*7)/16;
			      }
			    if (y<(h-1))
			      {
				 if (x>0)
				   {
				      er2[ex-6]+=(er*3)/16;
				      er2[ex-5]+=(eg*3)/16;
				      er2[ex-4]+=(eb*3)/16;
				   }
				 er2[ex-3]+=(er*5)/16;
				 er2[ex-2]+=(eg*5)/16;
				 er2[ex-1]+=(eb*5)/16;
				 if (x<(w-1))
				   {
				      er2[ex+0]+=(er*1)/16;
				      er2[ex+1]+=(eg*1)/16;
				      er2[ex+2]+=(eb*1)/16;
				   }
			      }
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=((val&0xff00)>>8);
				 *ptr1++=(val>>16);
				 *ptr1++=0;
			      }
			    else
			      {
				 *ptr1++=0;
				 *ptr1++=(val>>16);
				 *ptr1++=((val&0xff00)>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		default:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    if ((r==im->shape_color.r)&&
			      (g==im->shape_color.g)&&
			      (b==im->shape_color.b))
			      {
				XPutPixel(sxim,x,y,1);
			      }
			    else
			      {
				XPutPixel(sxim,x,y,0);
			      }
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=b;
				 *ptr1++=g;
				 *ptr1++=r;
				 *ptr1++=0;
			      }
			    else
			      {
				 *ptr1++=0;
				 *ptr1++=r;
				 *ptr1++=g;
				 *ptr1++=b;
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
	       }
	  }
	XPutImage(id->x.disp,im->pixmap,tgc,xim,0,0,0,0,w,h);
	XPutImage(id->x.disp,im->shape_mask,stgc,sxim,0,0,0,0,w,h);
	XSync(id->x.disp,0x00);
	XFreeGC(id->x.disp,tgc);
	XFreeGC(id->x.disp,stgc);
	XFree(xim);
	XFree(sxim);
	free(tmp);
	free(stmp);
	free(error);
     }
   else
     {
	if (id->x.depth<8)
	  {
	     switch (id->render_type)
	       {
		case RT_PLAIN_PALETTE:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    val=ImlibBestColorMatch(id,&r,&g,&b);
			    XPutPixel(xim,x,y,val);
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_PLAIN_PALETTE_FAST:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    val=id->fast_rgb[r>>3][g>>3][b>>3];
			    XPutPixel(xim,x,y,val);
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_DITHER_PALETTE:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       ter=er1;
		       er1=er2;
		       er2=ter;
		       for (ex=0;ex<w*3;ex++) er2[ex]=0;
		       ex=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    er=r+er1[ex++];eg=g+er1[ex++];eb=b+er1[ex++];
			    if (er>255) er=255;
			    if (er<0) er=0;
			    if (eg>255) eg=255;
			    if (eg<0) eg=0;
			    if (eb>255) eb=255;
			    if (eb<0) eb=0;
			    val=ImlibBestColorMatch(id,&er,&eg,&eb);
			    if (x<(w-1))
			      {
				 er1[ex+0]+=(er*7)/16;
				 er1[ex+1]+=(eg*7)/16;
				 er1[ex+2]+=(eb*7)/16;
			      }
		       if (y<(h-1))
			      {
				 if (x>0)
				   {
				      er2[ex-6]+=(er*3)/16;
				      er2[ex-5]+=(eg*3)/16;
				      er2[ex-4]+=(eb*3)/16;
				   }
				 er2[ex-3]+=(er*5)/16;
				 er2[ex-2]+=(eg*5)/16;
				 er2[ex-1]+=(eb*5)/16;
				 if (x<(w-1))
				   {
				      er2[ex+0]+=(er*1)/16;
				      er2[ex+1]+=(eg*1)/16;
				      er2[ex+2]+=(eb*1)/16;
				   }
			      }
			    XPutPixel(xim,x,y,val);
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_DITHER_PALETTE_FAST:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       ter=er1;
		       er1=er2;
		       er2=ter;
		       for (ex=0;ex<w*3;ex++) er2[ex]=0;
		       ex=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    er=r+er1[ex++];eg=g+er1[ex++];eb=b+er1[ex++];
			    if (er>255) er=255;
			    if (er<0) er=0;
			    if (eg>255) eg=255;
			    if (eg<0) eg=0;
			    if (eb>255) eb=255;
			    if (eb<0) eb=0;
			    val=id->fast_rgb[er>>3][eg>>3][eb>>3];
			    r=id->fast_err[er>>3][eg>>3][eb>>3];
			    g=id->fast_erg[er>>3][eg>>3][eb>>3];
			    b=id->fast_erb[er>>3][eg>>3][eb>>3];
			    er=r;eg=g;eb=b;
			    if (x<(w-1))
			      {
				 er1[ex+0]+=(er*7)/16;
				 er1[ex+1]+=(eg*7)/16;
				 er1[ex+2]+=(eb*7)/16;
			      }
			    if (y<(h-1))
			      {
				 if (x>0)
				   {
				      er2[ex-6]+=(er*3)/16;
				      er2[ex-5]+=(eg*3)/16;
				      er2[ex-4]+=(eb*3)/16;
				   }
				 er2[ex-3]+=(er*5)/16;
				 er2[ex-2]+=(eg*5)/16;
				 er2[ex-1]+=(eb*5)/16;
				 if (x<(w-1))
				   {
				      er2[ex+0]+=(er*1)/16;
				      er2[ex+1]+=(eg*1)/16;
				      er2[ex+2]+=(eb*1)/16;
				   }
			      }
			    XPutPixel(xim,x,y,val);
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		default:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
		       ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    val=0;
			    XPutPixel(xim,x,y,val);
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
	       }
	  }
	if (id->x.depth==8)
	  {
	     switch (id->render_type)
	       {
		case RT_PLAIN_PALETTE:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    val=ImlibBestColorMatch(id,&r,&g,&b);
			    *ptr1++=val;
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_PLAIN_PALETTE_FAST:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    val=id->fast_rgb[r>>3][g>>3][b>>3];
			    *ptr1++=val;
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_DITHER_PALETTE:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       ter=er1;
		       er1=er2;
		       er2=ter;
		       for (ex=0;ex<w*3;ex++) er2[ex]=0;
		       ex=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    er=r+er1[ex++];eg=g+er1[ex++];eb=b+er1[ex++];
			    if (er>255) er=255;
			    if (er<0) er=0;
			    if (eg>255) eg=255;
			    if (eg<0) eg=0;
			    if (eb>255) eb=255;
			    if (eb<0) eb=0;
			    val=ImlibBestColorMatch(id,&er,&eg,&eb);
			    if (x<(w-1))
			      {
				 er1[ex+0]+=(er*7)/16;
				 er1[ex+1]+=(eg*7)/16;
				 er1[ex+2]+=(eb*7)/16;
			      }
		       if (y<(h-1))
			      {
				 if (x>0)
				   {
				      er2[ex-6]+=(er*3)/16;
				      er2[ex-5]+=(eg*3)/16;
				      er2[ex-4]+=(eb*3)/16;
				   }
				 er2[ex-3]+=(er*5)/16;
				 er2[ex-2]+=(eg*5)/16;
				 er2[ex-1]+=(eb*5)/16;
				 if (x<(w-1))
				   {
				      er2[ex+0]+=(er*1)/16;
				      er2[ex+1]+=(eg*1)/16;
				      er2[ex+2]+=(eb*1)/16;
				   }
			      }
			    *ptr1++=val;
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_DITHER_PALETTE_FAST:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       ter=er1;
		       er1=er2;
		       er2=ter;
		       for (ex=0;ex<w*3;ex++) er2[ex]=0;
		       ex=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    er=r+er1[ex++];eg=g+er1[ex++];eb=b+er1[ex++];
			    if (er>255) er=255;
			    if (er<0) er=0;
			    if (eg>255) eg=255;
			    if (eg<0) eg=0;
			    if (eb>255) eb=255;
			    if (eb<0) eb=0;
			    val=id->fast_rgb[er>>3][eg>>3][eb>>3];
			    r=id->fast_err[er>>3][eg>>3][eb>>3];
			    g=id->fast_erg[er>>3][eg>>3][eb>>3];
			    b=id->fast_erb[er>>3][eg>>3][eb>>3];
			    er=r;eg=g;eb=b;
			    if (x<(w-1))
			      {
				 er1[ex+0]+=(er*7)/16;
				 er1[ex+1]+=(eg*7)/16;
				 er1[ex+2]+=(eb*7)/16;
			      }
			    if (y<(h-1))
			      {
				 if (x>0)
				   {
				      er2[ex-6]+=(er*3)/16;
				      er2[ex-5]+=(eg*3)/16;
				      er2[ex-4]+=(eb*3)/16;
				   }
				 er2[ex-3]+=(er*5)/16;
				 er2[ex-2]+=(eg*5)/16;
				 er2[ex-1]+=(eb*5)/16;
				 if (x<(w-1))
				   {
				      er2[ex+0]+=(er*1)/16;
				      er2[ex+1]+=(eg*1)/16;
				      er2[ex+2]+=(eb*1)/16;
				   }
			      }
			    *ptr1++=val;
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		default:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
		       ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    val=0;
			    *ptr1++=val;
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
	       }
	  }
	if (id->x.depth==15)
	  {
	     switch (id->render_type)
	       {
		case RT_PLAIN_PALETTE:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    val=ImlibBestColorMatch(id,&r,&g,&b);
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=(val>>8);
			      }
			    else
			      {
				 *ptr1++=(val>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_PLAIN_PALETTE_FAST:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    val=id->fast_rgb[r>>3][g>>3][b>>3];
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=(val>>8);
			      }
			    else
			      {
				 *ptr1++=(val>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_DITHER_PALETTE:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       ter=er1;
		       er1=er2;
		       er2=ter;
		       for (ex=0;ex<w*3;ex++) er2[ex]=0;
		       ex=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    er=r+er1[ex++];eg=g+er1[ex++];eb=b+er1[ex++];
			    if (er>255) er=255;
			    if (er<0) er=0;
			    if (eg>255) eg=255;
			    if (eg<0) eg=0;
			    if (eb>255) eb=255;
			    if (eb<0) eb=0;
			    val=ImlibBestColorMatch(id,&er,&eg,&eb);
			    if (x<(w-1))
			      {
				 er1[ex+0]+=(er*7)/16;
				 er1[ex+1]+=(eg*7)/16;
				 er1[ex+2]+=(eb*7)/16;
			      }
			    if (y<(h-1))
			      {
				 if (x>0)
				   {
				      er2[ex-6]+=(er*3)/16;
				      er2[ex-5]+=(eg*3)/16;
				      er2[ex-4]+=(eb*3)/16;
				   }
				 er2[ex-3]+=(er*5)/16;
				 er2[ex-2]+=(eg*5)/16;
				 er2[ex-1]+=(eb*5)/16;
				 if (x<(w-1))
				   {
				      er2[ex+0]+=(er*1)/16;
				      er2[ex+1]+=(eg*1)/16;
				      er2[ex+2]+=(eb*1)/16;
				   }
			      }
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=(val>>8);
			      }
			    else
			      {
				 *ptr1++=(val>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_DITHER_PALETTE_FAST:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       ter=er1;
		       er1=er2;
		       er2=ter;
		       for (ex=0;ex<w*3;ex++) er2[ex]=0;
		       ex=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    er=r+er1[ex++];eg=g+er1[ex++];eb=b+er1[ex++];
			    if (er>255) er=255;
			    if (er<0) er=0;
			    if (eg>255) eg=255;
			    if (eg<0) eg=0;
			    if (eb>255) eb=255;
			    if (eb<0) eb=0;
			    val=id->fast_rgb[er>>3][eg>>3][eb>>3];
			    r=id->fast_err[er>>3][eg>>3][eb>>3];
			    g=id->fast_erg[er>>3][eg>>3][eb>>3];
			    b=id->fast_erb[er>>3][eg>>3][eb>>3];
			    er=r;eg=g;eb=b;
			    if (x<(w-1))
			      {
				 er1[ex+0]+=(er*7)/16;
				 er1[ex+1]+=(eg*7)/16;
				 er1[ex+2]+=(eb*7)/16;
			      }
			    if (y<(h-1))
			      {
				 if (x>0)
				   {
				      er2[ex-6]+=(er*3)/16;
				      er2[ex-5]+=(eg*3)/16;
				      er2[ex-4]+=(eb*3)/16;
				   }
				 er2[ex-3]+=(er*5)/16;
				 er2[ex-2]+=(eg*5)/16;
				 er2[ex-1]+=(eb*5)/16;
				 if (x<(w-1))
				   {
				      er2[ex+0]+=(er*1)/16;
				      er2[ex+1]+=(eg*1)/16;
				      er2[ex+2]+=(eb*1)/16;
				   }
			      }
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=(val>>8);
			      }
			    else
			      {
				 *ptr1++=(val>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		default:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    val=((r&0xf8)<<7)|((g&0xf8)<<2)|((b&0xf8)>>3);
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=(val>>8);
			      }
			    else
			      {
				 *ptr1++=(val>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
	       }
	  }
	if (id->x.depth==16)
	  {
	     switch (id->render_type)
	       {
		case RT_PLAIN_PALETTE:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    val=ImlibBestColorMatch(id,&r,&g,&b);
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=(val>>8);
			      }
			    else
			      {
				 *ptr1++=(val>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_PLAIN_PALETTE_FAST:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    val=id->fast_rgb[r>>3][g>>3][b>>3];
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=(val>>8);
			      }
			    else
			      {
				 *ptr1++=(val>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_DITHER_PALETTE:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       ter=er1;
		       er1=er2;
		       er2=ter;
		       for (ex=0;ex<w*3;ex++) er2[ex]=0;
		       ex=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    er=r+er1[ex++];eg=g+er1[ex++];eb=b+er1[ex++];
			    if (er>255) er=255;
			    if (er<0) er=0;
			    if (eg>255) eg=255;
			    if (eg<0) eg=0;
			    if (eb>255) eb=255;
			    if (eb<0) eb=0;
			    val=ImlibBestColorMatch(id,&er,&eg,&eb);
			    if (x<(w-1))
			      {
				 er1[ex+0]+=(er*7)/16;
				 er1[ex+1]+=(eg*7)/16;
				 er1[ex+2]+=(eb*7)/16;
			      }
			    if (y<(h-1))
			      {
				 if (x>0)
				   {
				      er2[ex-6]+=(er*3)/16;
				      er2[ex-5]+=(eg*3)/16;
				      er2[ex-4]+=(eb*3)/16;
				   }
				 er2[ex-3]+=(er*5)/16;
				 er2[ex-2]+=(eg*5)/16;
				 er2[ex-1]+=(eb*5)/16;
				 if (x<(w-1))
				   {
				      er2[ex+0]+=(er*1)/16;
				      er2[ex+1]+=(eg*1)/16;
				      er2[ex+2]+=(eb*1)/16;
				   }
			      }
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=(val>>8);
			      }
			    else
			      {
				 *ptr1++=(val>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_DITHER_PALETTE_FAST:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       ter=er1;
		       er1=er2;
		       er2=ter;
		       for (ex=0;ex<w*3;ex++) er2[ex]=0;
		       ex=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    er=r+er1[ex++];eg=g+er1[ex++];eb=b+er1[ex++];
			    if (er>255) er=255;
			    if (er<0) er=0;
			    if (eg>255) eg=255;
			    if (eg<0) eg=0;
			    if (eb>255) eb=255;
			    if (eb<0) eb=0;
			    val=id->fast_rgb[er>>3][eg>>3][eb>>3];
			    r=id->fast_err[er>>3][eg>>3][eb>>3];
			    g=id->fast_erg[er>>3][eg>>3][eb>>3];
			    b=id->fast_erb[er>>3][eg>>3][eb>>3];
			    er=r;eg=g;eb=b;
			    if (x<(w-1))
			      {
				 er1[ex+0]+=(er*7)/16;
				 er1[ex+1]+=(eg*7)/16;
				 er1[ex+2]+=(eb*7)/16;
			      }
			    if (y<(h-1))
			      {
				 if (x>0)
				   {
				      er2[ex-6]+=(er*3)/16;
				      er2[ex-5]+=(eg*3)/16;
				      er2[ex-4]+=(eb*3)/16;
				   }
				 er2[ex-3]+=(er*5)/16;
				 er2[ex-2]+=(eg*5)/16;
				 er2[ex-1]+=(eb*5)/16;
				 if (x<(w-1))
				   {
				      er2[ex+0]+=(er*1)/16;
				      er2[ex+1]+=(eg*1)/16;
				      er2[ex+2]+=(eb*1)/16;
				   }
			      }
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=(val>>8);
			      }
			    else
			      {
				 *ptr1++=(val>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		default:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    val=((r&0xf8)<<8)|((g&0xfc)<<3)|((b&0xf8)>>3);
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=(val>>8);
			      }
			    else
			      {
				 *ptr1++=(val>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
	       }
	  }
	if ((id->x.depth==32)||(id->x.depth==24))
	  {
	     switch (id->render_type)
	       {
		case RT_PLAIN_PALETTE:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    val=ImlibBestColorMatch(id,&r,&g,&b);
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=((val&0xff00)>>8);
				 *ptr1++=(val>>16);
				 *ptr1++=0;
			      }
			    else
			      {
				 *ptr1++=0;
				 *ptr1++=(val>>16);
				 *ptr1++=((val&0xff00)>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_PLAIN_PALETTE_FAST:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    val=id->fast_rgb[r>>3][g>>3][b>>3];
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=((val&0xff00)>>8);
				 *ptr1++=(val>>16);
				 *ptr1++=0;
			      }
			    else
			      {
				 *ptr1++=0;
				 *ptr1++=(val>>16);
				 *ptr1++=((val&0xff00)>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_DITHER_PALETTE:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       ter=er1;
		       er1=er2;
		       er2=ter;
		       for (ex=0;ex<w*3;ex++) er2[ex]=0;
		       ex=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    er=r+er1[ex++];eg=g+er1[ex++];eb=b+er1[ex++];
			    if (er>255) er=255;
			    if (er<0) er=0;
			    if (eg>255) eg=255;
			    if (eg<0) eg=0;
			    if (eb>255) eb=255;
			    if (eb<0) eb=0;
			    val=ImlibBestColorMatch(id,&er,&eg,&eb);
			    if (x<(w-1))
			      {
				 er1[ex+0]+=(er*7)/16;
				 er1[ex+1]+=(eg*7)/16;
				 er1[ex+2]+=(eb*7)/16;
			      }
			    if (y<(h-1))
			      {
				 if (x>0)
				   {
				      er2[ex-6]+=(er*3)/16;
				      er2[ex-5]+=(eg*3)/16;
				      er2[ex-4]+=(eb*3)/16;
				   }
				 er2[ex-3]+=(er*5)/16;
				 er2[ex-2]+=(eg*5)/16;
				 er2[ex-1]+=(eb*5)/16;
				 if (x<(w-1))
				   {
				      er2[ex+0]+=(er*1)/16;
				      er2[ex+1]+=(eg*1)/16;
				      er2[ex+2]+=(eb*1)/16;
				   }
			      }
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=((val&0xff00)>>8);
				 *ptr1++=(val>>16);
				 *ptr1++=0;
			      }
			    else
			      {
				 *ptr1++=0;
				 *ptr1++=(val>>16);
				 *ptr1++=((val&0xff00)>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		case RT_DITHER_PALETTE_FAST:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       ter=er1;
		       er1=er2;
		       er2=ter;
		       for (ex=0;ex<w*3;ex++) er2[ex]=0;
		       ex=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    er=r+er1[ex++];eg=g+er1[ex++];eb=b+er1[ex++];
			    if (er>255) er=255;
			    if (er<0) er=0;
			    if (eg>255) eg=255;
			    if (eg<0) eg=0;
			    if (eb>255) eb=255;
			    if (eb<0) eb=0;
			    val=id->fast_rgb[er>>3][eg>>3][eb>>3];
			    r=id->fast_err[er>>3][eg>>3][eb>>3];
			    g=id->fast_erg[er>>3][eg>>3][eb>>3];
			    b=id->fast_erb[er>>3][eg>>3][eb>>3];
			    er=r;eg=g;eb=b;
			    if (x<(w-1))
			      {
				 er1[ex+0]+=(er*7)/16;
				 er1[ex+1]+=(eg*7)/16;
				 er1[ex+2]+=(eb*7)/16;
			      }
			    if (y<(h-1))
			      {
				 if (x>0)
				   {
				      er2[ex-6]+=(er*3)/16;
				      er2[ex-5]+=(eg*3)/16;
				      er2[ex-4]+=(eb*3)/16;
				   }
				 er2[ex-3]+=(er*5)/16;
				 er2[ex-2]+=(eg*5)/16;
				 er2[ex-1]+=(eb*5)/16;
				 if (x<(w-1))
				   {
				      er2[ex+0]+=(er*1)/16;
				      er2[ex+1]+=(eg*1)/16;
				      er2[ex+2]+=(eb*1)/16;
				   }
			      }
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=(val&0xff);
				 *ptr1++=((val&0xff00)>>8);
				 *ptr1++=(val>>16);
				 *ptr1++=0;
			      }
			    else
			      {
				 *ptr1++=0;
				 *ptr1++=(val>>16);
				 *ptr1++=((val&0xff00)>>8);
				 *ptr1++=(val&0xff);
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
		default:
		  for(y=0;y<h;y++)
		    {
		       pos_x=0;
		       for(x=0;x<w;x++)
			 {
			    ptr2=ptr22+(pos_x>>16)+(pos_x>>16)+(pos_x>>16);
			    r=(int)*ptr2++;
			    g=(int)*ptr2++;
			    b=(int)*ptr2++;
			    if (xim->bitmap_bit_order==LSBFirst)
			      {
				 *ptr1++=b;
				 *ptr1++=g;
				 *ptr1++=r;
				 *ptr1++=0;
			      }
			    else
			      {
				 *ptr1++=0;
				 *ptr1++=r;
				 *ptr1++=g;
				 *ptr1++=b;
			      }
			    pos_x+=inc__x;
			 }
		       pos_y+=inc__y;
		       ptr22=im->rgb_data+((pos_y>>16)*w3);
		    }
		  break;
	       }
	  }
	XPutImage(id->x.disp,im->pixmap,tgc,xim,0,0,0,0,w,h);
	XSync(id->x.disp,0x00);
	XFreeGC(id->x.disp,tgc);
	XFree(xim);
	free(tmp);
	free(error);
     }
}

   
