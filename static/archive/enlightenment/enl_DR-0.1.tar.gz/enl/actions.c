#include "enlightenment.h"

void DoWindowButton(EWin *ewin, Window win, int btn, int mod, int wbtn)
{
   int i,j;
   
   /* if it wasnt a left, middle or right mouse button... ignore it */
   if ((btn<1)||(btn>3)) return;
   /* if the subwindow clicked is a decoration subwindow.. ignore the click */
   if (cfg.subwin_type[wbtn]==0) return;
   /* flag the button as clicked ... */
   ewin->subwin_state[wbtn]=CLICKED;
   /* redraw the button */
   DrawButton(ewin,wbtn);
   /* set the event mode windowbutton pressed to this one */
   evmd.wbtn=wbtn;
   if (cfg.subwin_action[wbtn][btn-1][mod].id==1)
     {
	Do_MoveWin(ewin);
	return;
     }
   else if (cfg.subwin_action[wbtn][btn-1][mod].id==2)
     {
	Do_ResizeWin(ewin);
	return;
     }
   else if (cfg.subwin_action[wbtn][btn-1][mod].id==3)
     {
	Do_IconifyWin(ewin);	
	evmd.ewin=ewin;
	evmd.wbtn=wbtn;
	evmd.mode=MODE_NORMAL;
/*	ewin->subwin_state[wbtn]=NORM;*/
/*	DrawButton(ewin,wbtn);*/
	return;
     }
   else if (cfg.subwin_action[wbtn][btn-1][mod].id==4)
     {
	Do_KillWin(ewin);
	evmd.ewin=ewin;
	evmd.wbtn=wbtn;
	evmd.mode=MODE_NORMAL;
	return;
     }
   else if (cfg.subwin_action[wbtn][btn-1][mod].id==5)
     {
	Do_RaiseWin(ewin);
	evmd.ewin=ewin;
	evmd.wbtn=wbtn;
	evmd.mode=MODE_NORMAL;
	return;
     }
   else if (cfg.subwin_action[wbtn][btn-1][mod].id==6)
     {
	Do_LowerWin(ewin);
	evmd.ewin=ewin;
	evmd.wbtn=wbtn;
	evmd.mode=MODE_NORMAL;
	return;
     }
   else if (cfg.subwin_action[wbtn][btn-1][mod].id==7)
     {
	Do_RaiseLowerWin(ewin);
	evmd.ewin=ewin;
	evmd.wbtn=wbtn;
	evmd.mode=MODE_NORMAL;
	return;
     }
   else if (cfg.subwin_action[wbtn][btn-1][mod].id==8)
     {
	Do_MaxHeightWin(ewin);
	evmd.ewin=ewin;
	evmd.wbtn=wbtn;
	evmd.mode=MODE_NORMAL;
	return;
     }
   else if (cfg.subwin_action[wbtn][btn-1][mod].id==9)
     {
	Do_MaxWidthWin(ewin);
	evmd.ewin=ewin;
	evmd.wbtn=wbtn;
	evmd.mode=MODE_NORMAL;
	return;
     }
   else if (cfg.subwin_action[wbtn][btn-1][mod].id==10)
     {
	Do_MaxSizeWin(ewin);
	evmd.ewin=ewin;
	evmd.wbtn=wbtn;
	evmd.mode=MODE_NORMAL;
	return;
     }
   else if (cfg.subwin_action[wbtn][btn-1][mod].id==11)
     {
	Do_Configure();
	evmd.ewin=ewin;
	evmd.wbtn=wbtn;
	evmd.mode=MODE_NORMAL;
	return;
     }
   else if (cfg.subwin_action[wbtn][btn-1][mod].id==12)
     {
	Do_MenuWin(ewin);
	evmd.ewin=ewin;
	evmd.wbtn=wbtn;
	evmd.mode=MODE_NORMAL;
	return;
     }
   else if (cfg.subwin_action[wbtn][btn-1][mod].id==13)
     {
	Do_Exec(cfg.subwin_action[wbtn][btn-1][mod].params);
	evmd.ewin=ewin;
	evmd.wbtn=wbtn;
	evmd.mode=MODE_NORMAL;
	return;
     }
   else
     {
	evmd.ewin=ewin;
	evmd.wbtn=wbtn;
	evmd.mode=MODE_NORMAL;
	return;
     }
   return;
}

void DoRootMenu(int btn, int mod, int x, int y)
{
}

void Do_MoveWin(EWin *ewin)
{
   XEvent ev;
   int x,y;
   int sx,sy,d;
   Window w1,w2;
   
   XQueryPointer(disp,root,&w1,&w2,&sx,&sy,&x,&y,&d);
   evmd.mode=MODE_MOVE;
   evmd.ewin=ewin;
   evmd.px=sx;
   evmd.py=sy;
}

void Do_ResizeWin(EWin *ewin)
{
   XEvent ev;
   int x,y;
   int sx,sy,d;
   Window w1,w2;
   int wx,wy;
   int mode;
   int x1,y1,x2,y2;
   
   XQueryPointer(disp,root,&w1,&w2,&sx,&sy,&x,&y,&d);
   evmd.px=sx;
   evmd.py=sy;
   x1=ewin->frame_x;
   y1=ewin->frame_y;
   x2=ewin->client_width;
   y2=ewin->client_height;
   wx=x-x1;
   wy=y-y1;
   if ((wx<ewin->frame_width/2)&&(wy<ewin->frame_height/2)) mode=0;
   if ((wx>=ewin->frame_width/2)&&(wy<ewin->frame_height/2)) mode=1;
   if ((wx<ewin->frame_width/2)&&(wy>=ewin->frame_height/2)) mode=2;
   if ((wx>=ewin->frame_width/2)&&(wy>=ewin->frame_height/2)) mode=3;
   evmd.x1=x1;
   evmd.x2=x2;
   evmd.y1=y1;
   evmd.y2=y2;
   evmd.resize_mode=mode;
   evmd.ewin=ewin;
   evmd.mode=MODE_RESIZE;
}

void Do_IconifyWin(EWin *ewin)
{
}

void Do_KillWin(EWin *ewin)
{
   XClientMessageEvent xev;
   Atom atm[1];
   XEvent ev;
   XID xid;
   int nasty=1;
   
   XUnmapWindow(disp,ewin->frame_win);
   atm[0]=XInternAtom(disp,"WM_SAVE_YOURSELF",False);
   xev.type=ClientMessage;
   xev.window=ewin->client_win;
   xev.format=32;
   xev.data.l[0]=atm[0];
   xev.data.l[1]=CurrentTime;
   XSendEvent(disp,ewin->client_win,False,0,(XEvent *)&xev);
   atm[0]=XInternAtom(disp,"WM_DELETE_WINDOW",False);
   xev.type=ClientMessage;
   xev.window=ewin->client_win;
   xev.format=32;
   xev.data.l[0]=atm[0];
   xev.data.l[1]=CurrentTime;
   XSendEvent(disp,ewin->client_win,False,0,(XEvent *)&xev);
   if (nasty) XKillClient(disp,(XID)ewin->client_win);
}

void Do_RaiseWin(EWin *ewin)
{
   XRaiseWindow(disp,ewin->frame_win);
   ewin->top=1;
}

void Do_LowerWin(EWin *ewin)
{
   XLowerWindow(disp,ewin->frame_win);
   ewin->top=0;
}

void Do_RaiseLowerWin(EWin *ewin)
{
   XWindowChanges xwc;
   
   if (ewin->top) 
     {
	XLowerWindow(disp,ewin->frame_win);
	ewin->top=0;
     }
   else
     {
	XRaiseWindow(disp,ewin->frame_win);
	ewin->top=1;
     }
}

void Do_MaxHeightWin(EWin *ewin)
{
   int h;
   int y;
   
   if (ewin->lastop==OP_MAXHEIGHT)
     {
	h=ewin->prev_client_height;
	y=ewin->prev_frame_y;
	ewin->prev_client_height=ewin->client_height;
	ewin->prev_client_width=ewin->client_width;
	ewin->prev_frame_x=ewin->frame_x;
	ewin->prev_frame_y=ewin->frame_y;
     }
   else
     {
	ewin->prev_client_height=ewin->client_height;
	ewin->prev_client_width=ewin->client_width;
	ewin->prev_frame_x=ewin->frame_x;
	ewin->prev_frame_y=ewin->frame_y;
	h=DisplayHeight(disp,screen);
	h-=ewin->border_t;
	h-=ewin->border_b;
	while ((h%ewin->sizeinc_y)>0) h--;
	while ((h%ewin->sizeinc_y)<0) h++;
	y=0;
     }
   ModifyEWin(ewin,ewin->frame_x,y,ewin->client_width,h);
   ewin->lastop=OP_MAXHEIGHT;
}

void Do_MaxWidthWin(EWin *ewin)
{
   int w;
   int x;
   
   if (ewin->lastop==OP_MAXWIDTH)
     {
	w=ewin->prev_client_width;
	x=ewin->prev_frame_x;
	ewin->prev_client_height=ewin->client_height;
	ewin->prev_client_width=ewin->client_width;
	ewin->prev_frame_x=ewin->frame_x;
	ewin->prev_frame_y=ewin->frame_y;
     }
   else
     {
	ewin->prev_client_height=ewin->client_height;
	ewin->prev_client_width=ewin->client_width;
	ewin->prev_frame_x=ewin->frame_x;
	ewin->prev_frame_y=ewin->frame_y;
	w=DisplayWidth(disp,screen);
	w-=ewin->border_l;
	w-=ewin->border_r;
	while ((w%ewin->sizeinc_x)>0) w--;
	while ((w%ewin->sizeinc_x)<0) w++;
	x=0;
     }
   ModifyEWin(ewin,x,ewin->frame_y,w,ewin->client_height);
   ewin->lastop=OP_MAXWIDTH;
}

void Do_MaxSizeWin(EWin *ewin)
{
   int h;
   int y;
   int w;
   int x;
   
   if (ewin->lastop==OP_MAXSIZE)
     {
	h=ewin->prev_client_height;
	y=ewin->prev_frame_y;
	w=ewin->prev_client_width;
	x=ewin->prev_frame_x;
	ewin->prev_client_height=ewin->client_height;
	ewin->prev_client_width=ewin->client_width;
	ewin->prev_frame_x=ewin->frame_x;
	ewin->prev_frame_y=ewin->frame_y;
     }
   else
     {
	ewin->prev_client_height=ewin->client_height;
	ewin->prev_client_width=ewin->client_width;
	ewin->prev_frame_x=ewin->frame_x;
	ewin->prev_frame_y=ewin->frame_y;
	h=DisplayHeight(disp,screen);
	h-=ewin->border_t;
	h-=ewin->border_b;
	while ((h%ewin->sizeinc_y)>0) h--;
	while ((h%ewin->sizeinc_y)<0) h++;
	y=0;
	w=DisplayWidth(disp,screen);
	w-=ewin->border_l;
	w-=ewin->border_r;
	while ((w%ewin->sizeinc_x)>0) w--;
	while ((w%ewin->sizeinc_x)<0) w++;
	x=0;
     }
   ModifyEWin(ewin,x,y,w,h);
   ewin->lastop=OP_MAXSIZE;
}

void Do_Configure()
{
}

void Do_MenuWin(EWin *ewin)
{
}

void Do_Exec(char *line)
{
   char *args[2048];
   int i,j,k;
   char arg[1024];
   int inquote=0;
   int q1,q2;
   
   if (fork()) return;
   i=0;
   while (line[i]!=0) 
     {
	if (line[i]=='\n') line[i]=0;
	i++;
     }
   i=0;j=0;k=0;
   q1=0;q2=0;
   while (line[i]==' ') i++;
   while (line[i])
     {
	if ((line[i]!='"')&&(line[i]!='\'')) arg[j]=line[i];
	if (line[i]=='"')
	  {
	     if (q1) 
	       {
		  q1=0;
		  inquote--;
	       }
	     else
	       {
		  q1=1;
		  inquote++;
	       }
	  }
	if (line[i]=='\'')
	  {
	     if (q2) 
	       {
		  q2=0;
		  inquote--;
	       }
	     else
	       {
		  q2=1;
		  inquote++;
	       }
	  }
	if ((line[i]==' ')&&(inquote==0)) 
	  {
	     arg[j]=0;
	     args[k]=malloc(strlen(arg)+1);
	     j=-1;
	  }
	if ((line[i]!='"')&&(line[i]!='\'')) j++;
	i++;
     }
   if (j)
     {
	arg[j]=0;
	args[k]=malloc(strlen(arg)+1);
     }
   args[k]=NULL;

   if (!execvp(args[0],args)) exit(0);
   else exit(0);
}

