#define OP_MAXHEIGHT 1
#define OP_MAXWIDTH 2
#define OP_MAXSIZE 3

void DoWindowButton(EWin *ewin, Window win, int btn, int mod, int wbtn);
void DoRootMenu(int btn, int mod, int x, int y);
void Do_MoveWin(EWin *ewin);
void Do_ResizeWin(EWin *ewin);
void Do_IconifyWin(EWin *ewin);
void Do_KillWin(EWin *ewin);
void Do_RaiseWin(EWin *ewin);
void Do_LowerWin(EWin *ewin);
void Do_RaiseLowerWin(EWin *ewin);
void Do_MaxHeightWin(EWin *ewin);
void Do_MaxWidthWin(EWin *ewin);
void Do_MaxSizeWin(EWin *ewin);
void Do_Configure();
void Do_MenuWin(EWin *ewin);
void Do_Exec(char *line);
