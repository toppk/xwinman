#include "imlib.h"

int ImlibBestColorMatch(ImlibData *id, int *r,int *g,int *b)
{
   int i;
   int dif;
   int dr,dg,db;
   int col;
   int mindif=0x7fffffff;
   int ddr,ddg,ddb;
   XColor xcl;
   
   if (!id)
     {
	fprintf(stderr,"ImLib ERROR: No ImlibData initialised\n");
	return -1;
     }
   if (id->render_type&RT_PLAIN_TRUECOL)
     {
	xcl.red=(unsigned short)((*r<<8)|(*r));
	xcl.green=(unsigned short)((*g<<8)|(*g));
	xcl.blue=(unsigned short)((*b<<8)|(*b));
	xcl.flags=DoRed|DoGreen|DoBlue;
	XAllocColor(id->x.disp,id->x.root_cmap,&xcl);
	*r=xcl.red>>8;
	*g=xcl.green>>8;
	*b=xcl.blue>>8;
	return xcl.pixel;
     }
   for (i=0;i<id->num_colors;i++)
     {
	dr=*r-id->palette[i].r;
	if (dr<0) dr=-dr;
	dg=*g-id->palette[i].g;
	if (dg<0) dg=-dg;
	db=*b-id->palette[i].b;
	if (db<0) db=-db;
	dif=dr+dg+db;
	if (dif<mindif)
	  {
	     mindif=dif;
	     col=id->palette[i].pixel;
	     ddr=*r-id->palette[i].r;
	     ddg=*g-id->palette[i].g;
	     ddb=*b-id->palette[i].b;
	  }
     }
   *r=ddr;*g=ddg;*b=ddb;
   return col;
}

void render_shaped_15(ImlibData *id, Image *im, int w, int h, XImage *xim, 
		      XImage *sxim, int *er1, int *er2, int *xarray,
		      unsigned char **yarray)
{
   int x,y,val,r,g,b,*ter,ex,er,eg,eb;
   unsigned char *ptr2;
   
   for(y=0;y<h;y++)
     {
	for(x=0;x<w;x++)
	  {
	     ptr2=yarray[y]+xarray[x];
	     r=(int)*ptr2++;
	     g=(int)*ptr2++;
	     b=(int)*ptr2;
	     if ((r==im->shape_color.r)&&
		 (g==im->shape_color.g)&&
		 (b==im->shape_color.b))
	       XPutPixel(sxim,x,y,0);
	     else
	       {
		  XPutPixel(sxim,x,y,1);
		  val=((r&0xf8)<<7)|((g&0xf8)<<2)|((b&0xf8)>>3);
		  XPutPixel(xim,x,y,val);
	       }
	  }
     }
}

void render_15(ImlibData *id, Image *im, int w, int h, XImage *xim, 
	       XImage *sxim, int *er1, int *er2, int *xarray,
	       unsigned char **yarray)
{
   int x,y,val,r,g,b,*ter,ex,er,eg,eb;
   unsigned char *ptr2;
   
   for(y=0;y<h;y++)
     {
	for(x=0;x<w;x++)
	  {
	     ptr2=yarray[y]+xarray[x];
	     r=(int)*ptr2++;
	     g=(int)*ptr2++;
	     b=(int)*ptr2;
	     val=((r&0xf8)<<7)|((g&0xf8)<<2)|((b&0xf8)>>3);
	     XPutPixel(xim,x,y,val);
	  }
     }
}

void render_shaped_16(ImlibData *id, Image *im, int w, int h, XImage *xim, 
		      XImage *sxim, int *er1, int *er2, int *xarray,
		      unsigned char **yarray)
{
   int x,y,val,r,g,b,*ter,ex,er,eg,eb;
   unsigned char *ptr2;
   
   for(y=0;y<h;y++)
     {
	for(x=0;x<w;x++)
	  {
	     ptr2=yarray[y]+xarray[x];
	     r=(int)*ptr2++;
	     g=(int)*ptr2++;
	     b=(int)*ptr2;
	     if ((r==im->shape_color.r)&&
		 (g==im->shape_color.g)&&
		 (b==im->shape_color.b))
	       XPutPixel(sxim,x,y,0);
	     else
	       {
		  XPutPixel(sxim,x,y,1);
		  val=((r&0xf8)<<8)|((g&0xfc)<<3)|((b&0xf8)>>3);
		  XPutPixel(xim,x,y,val);
	       }
	  }
     }
}

void render_16(ImlibData *id, Image *im, int w, int h, XImage *xim, 
       XImage *sxim, int *er1, int *er2, int *xarray,
	       unsigned char **yarray)
{
   int x,y,val,r,g,b,*ter,ex,er,eg,eb;
   unsigned char *ptr2;
   
   for(y=0;y<h;y++)
     {
	for(x=0;x<w;x++)
	  {
	     ptr2=yarray[y]+xarray[x];
	     r=(int)*ptr2++;
	     g=(int)*ptr2++;
	     b=(int)*ptr2;
	     val=((r&0xf8)<<8)|((g&0xfc)<<3)|((b&0xf8)>>3);
	     XPutPixel(xim,x,y,val);
	  }
     }
}

void render_shaped_24(ImlibData *id, Image *im, int w, int h, XImage *xim, 
		      XImage *sxim, int *er1, int *er2, int *xarray,
		      unsigned char **yarray)
{
   int x,y,val,r,g,b,*ter,ex,er,eg,eb;
   unsigned char *ptr2;
   
   if (id->byte_order==BYTE_ORD_24_RGB)
     {
	for(y=0;y<h;y++)
	  {
	     for(x=0;x<w;x++)
	       {
		  ptr2=yarray[y]+xarray[x];
		  r=(int)*ptr2++;
		  g=(int)*ptr2++;
		  b=(int)*ptr2;
		  if ((r==im->shape_color.r)&&
		      (g==im->shape_color.g)&&
		      (b==im->shape_color.b))
		    XPutPixel(sxim,x,y,0);
		  else
		    {
		       XPutPixel(sxim,x,y,1);
		       val=(r<<16)|(g<<8)|b;
		       XPutPixel(xim,x,y,val);
		    }
	       }
	  }
     }
   else if (id->byte_order==BYTE_ORD_24_RBG)
     {
	for(y=0;y<h;y++)
	  {
	     for(x=0;x<w;x++)
	       {
		  ptr2=yarray[y]+xarray[x];
		  r=(int)*ptr2++;
		  g=(int)*ptr2++;
		  b=(int)*ptr2;
		  if ((r==im->shape_color.r)&&
		      (g==im->shape_color.g)&&
		      (b==im->shape_color.b))
		    XPutPixel(sxim,x,y,0);
		  else
		    {
		       XPutPixel(sxim,x,y,1);
		       val=(r<<16)|(b<<8)|g;
		       XPutPixel(xim,x,y,val);
		    }
	       }
	  }
     }
   else if (id->byte_order==BYTE_ORD_24_BRG)
     {
	for(y=0;y<h;y++)
	  {
	     for(x=0;x<w;x++)
	       {
		  ptr2=yarray[y]+xarray[x];
		  r=(int)*ptr2++;
		  g=(int)*ptr2++;
		  b=(int)*ptr2;
		  if ((r==im->shape_color.r)&&
		      (g==im->shape_color.g)&&
		      (b==im->shape_color.b))
		    XPutPixel(sxim,x,y,0);
		  else
		    {
		       XPutPixel(sxim,x,y,1);
		       val=(b<<16)|(r<<8)|g;
		       XPutPixel(xim,x,y,val);
		    }
	       }
	  }
     }
   else if (id->byte_order==BYTE_ORD_24_BGR)
     {
	for(y=0;y<h;y++)
	  {
	     for(x=0;x<w;x++)
	       {
		  ptr2=yarray[y]+xarray[x];
		  r=(int)*ptr2++;
		  g=(int)*ptr2++;
		  b=(int)*ptr2;
		  if ((r==im->shape_color.r)&&
		      (g==im->shape_color.g)&&
		      (b==im->shape_color.b))
		    XPutPixel(sxim,x,y,0);
		  else
		    {
		       XPutPixel(sxim,x,y,1);
		       val=(b<<16)|(g<<8)|r;
		       XPutPixel(xim,x,y,val);
		    }
	       }
	  }
     }
   else if (id->byte_order==BYTE_ORD_24_GRB)
     {
	for(y=0;y<h;y++)
	  {
	     for(x=0;x<w;x++)
	       {
		  ptr2=yarray[y]+xarray[x];
		  r=(int)*ptr2++;
		  g=(int)*ptr2++;
		  b=(int)*ptr2;
		  if ((r==im->shape_color.r)&&
		      (g==im->shape_color.g)&&
		      (b==im->shape_color.b))
		    XPutPixel(sxim,x,y,0);
		  else
		    {
		       XPutPixel(sxim,x,y,1);
		       val=(g<<16)|(r<<8)|b;
		       XPutPixel(xim,x,y,val);
		    }
	       }
	  }
     }
   else if (id->byte_order==BYTE_ORD_24_GBR)
     {
	for(y=0;y<h;y++)
	  {
	     for(x=0;x<w;x++)
	       {
		  ptr2=yarray[y]+xarray[x];
		  r=(int)*ptr2++;
		  g=(int)*ptr2++;
		  b=(int)*ptr2;
		  if ((r==im->shape_color.r)&&
		      (g==im->shape_color.g)&&
		      (b==im->shape_color.b))
		    XPutPixel(sxim,x,y,0);
		  else
		    {
		       XPutPixel(sxim,x,y,1);
		       val=(g<<16)|(b<<8)|r;
		       XPutPixel(xim,x,y,val);
		    }
	       }
	  }
     }
}
void render_24(ImlibData *id, Image *im, int w, int h, XImage *xim, 
	       XImage *sxim, int *er1, int *er2, int *xarray,
	       unsigned char **yarray)
{
   int x,y,val,r,g,b,*ter,ex,er,eg,eb;
   unsigned char *ptr2;
   
   if (id->byte_order==BYTE_ORD_24_RGB)
     {
	for(y=0;y<h;y++)
	  {
	     for(x=0;x<w;x++)
	       {
		  ptr2=yarray[y]+xarray[x];
		  r=(int)*ptr2++;
		  g=(int)*ptr2++;
		  b=(int)*ptr2;
		  val=(r<<16)|(g<<8)|b;
		  XPutPixel(xim,x,y,val);
	       }
	  }
     }
   else if (id->byte_order==BYTE_ORD_24_RBG)
     {
	for(y=0;y<h;y++)
	  {
	     for(x=0;x<w;x++)
	       {
		  ptr2=yarray[y]+xarray[x];
		  r=(int)*ptr2++;
		  g=(int)*ptr2++;
		  b=(int)*ptr2;
		  val=(r<<16)|(b<<8)|g;
		  XPutPixel(xim,x,y,val);
	       }
	  }
     }
   else if (id->byte_order==BYTE_ORD_24_BRG)
     {
	for(y=0;y<h;y++)
	  {
	     for(x=0;x<w;x++)
	       {
		  ptr2=yarray[y]+xarray[x];
		  r=(int)*ptr2++;
		  g=(int)*ptr2++;
		  b=(int)*ptr2;
		  val=(b<<16)|(r<<8)|g;
		  XPutPixel(xim,x,y,val);
	       }
	  }
     }
   else if (id->byte_order==BYTE_ORD_24_BGR)
     {
	for(y=0;y<h;y++)
	  {
	     for(x=0;x<w;x++)
	       {
		  ptr2=yarray[y]+xarray[x];
		  r=(int)*ptr2++;
		  g=(int)*ptr2++;
		  b=(int)*ptr2;
		  val=(b<<16)|(g<<8)|r;
		  XPutPixel(xim,x,y,val);
	       }
	  }
     }
   else if (id->byte_order==BYTE_ORD_24_GRB)
     {
	for(y=0;y<h;y++)
	  {
	     for(x=0;x<w;x++)
	       {
		  ptr2=yarray[y]+xarray[x];
		  r=(int)*ptr2++;
		  g=(int)*ptr2++;
		  b=(int)*ptr2;
		  val=(g<<16)|(r<<8)|b;
		  XPutPixel(xim,x,y,val);
	       }
	  }
     }
   else if (id->byte_order==BYTE_ORD_24_GBR)
     {
	for(y=0;y<h;y++)
	  {
	     for(x=0;x<w;x++)
	       {
		  ptr2=yarray[y]+xarray[x];
		  r=(int)*ptr2++;
		  g=(int)*ptr2++;
		  b=(int)*ptr2;
		  val=(g<<16)|(b<<8)|r;
		  XPutPixel(xim,x,y,val);
	       }
	  }
     }
}

void render_shaped(ImlibData *id, Image *im, int w, int h, XImage *xim, 
		   XImage *sxim, int *er1, int *er2, int *xarray,
		   unsigned char **yarray, int bpp)
{ 
   int x,y,val,r,g,b,*ter,ex,er,eg,eb;
   unsigned char *ptr2;
   
   switch (id->render_type)
     {
      case RT_PLAIN_PALETTE:
	for(y=0;y<h;y++)
	  {
	     for(x=0;x<w;x++)
	       {
		  ptr2=yarray[y]+xarray[x];
		  r=(int)*ptr2++;
		  g=(int)*ptr2++;
		  b=(int)*ptr2;
		  if ((r==im->shape_color.r)&&
		      (g==im->shape_color.g)&&
		      (b==im->shape_color.b))
		    XPutPixel(sxim,x,y,0);
		  else
		    {
		       XPutPixel(sxim,x,y,1);
		       val=ImlibBestColorMatch(id,&r,&g,&b);
		       XPutPixel(xim,x,y,val);
		    }
	       }
	  }
	break;
      case RT_PLAIN_PALETTE_FAST:
	for(y=0;y<h;y++)
	  {
	     for(x=0;x<w;x++)
	       {
		  ptr2=yarray[y]+xarray[x];
		  r=(int)*ptr2++;
		  g=(int)*ptr2++;
		  b=(int)*ptr2;
		  if ((r==im->shape_color.r)&&
		      (g==im->shape_color.g)&&
		      (b==im->shape_color.b))
		    XPutPixel(sxim,x,y,0);
		  else
		    {
		       XPutPixel(sxim,x,y,1);
		       val=id->fast_rgb[r>>3][g>>3][b>>3];
		       XPutPixel(xim,x,y,val);
		    }
	       }
	  }
	break;
      case RT_DITHER_PALETTE:
	for(y=0;y<h;y++)
	  {
	     ter=er1;er1=er2;er2=ter;
	     for (ex=0;ex<(w+2)*3;ex++) er2[ex]=0;
	     ex=3;
	     for(x=0;x<w;x++)
	       {
		  ptr2=yarray[y]+xarray[x];
		  r=(int)*ptr2++;
		  g=(int)*ptr2++;
		  b=(int)*ptr2;
		  if ((r==im->shape_color.r)&&
		      (g==im->shape_color.g)&&
		      (b==im->shape_color.b))
		    {
		       XPutPixel(sxim,x,y,0);
		       ex+=3;
		    }
		  else
		    {
		       XPutPixel(sxim,x,y,1);
		       er=r+er1[ex++];eg=g+er1[ex++];eb=b+er1[ex++];
		       if (er>255) er=255;
		       else if (er<0) er=0;
		       if (eg>255) eg=255;
		       else if (eg<0) eg=0;
		       if (eb>255) eb=255;
		       else if (eb<0) eb=0;
		       val=ImlibBestColorMatch(id,&er,&eg,&eb);
		       er=r;eg=g;eb=b;
		       er1[ex+0]+=(er*7)>>4;
		       er1[ex+1]+=(eg*7)>>4;
		       er1[ex+2]+=(eb*7)>>4;
		       er2[ex-6]+=(er*3)>>4;
		       er2[ex-5]+=(eg*3)>>4;
		       er2[ex-4]+=(eb*3)>>4;
		       er2[ex-3]+=(er*5)>>4;
		       er2[ex-2]+=(eg*5)>>4;
		       er2[ex-1]+=(eb*5)>>4;
		       er2[ex+0]+=(er*1)>>4;
		       er2[ex+1]+=(eg*1)>>4;
		       er2[ex+2]+=(eb*1)>>4;
		       XPutPixel(xim,x,y,val);
		    }
	       }
	  }
	break;
      case RT_DITHER_PALETTE_FAST:
	for(y=0;y<h;y++)
	  {
	     ter=er1;er1=er2;er2=ter;
	     for (ex=0;ex<(w+2)*3;ex++) er2[ex]=0;
	     ex=3;
	     for(x=0;x<w;x++)
	       {
		  ptr2=yarray[y]+xarray[x];
		  r=(int)*ptr2++;
		  g=(int)*ptr2++;
		  b=(int)*ptr2;
		  if ((r==im->shape_color.r)&&
		      (g==im->shape_color.g)&&
		      (b==im->shape_color.b))
		    {
		       XPutPixel(sxim,x,y,0);
		       ex+=3;
		    }
		  else
		    {
		       XPutPixel(sxim,x,y,1);
		       er=r+er1[ex++];eg=g+er1[ex++];eb=b+er1[ex++];
		       if (er>255) er=255;
		       else if (er<0) er=0;
		       if (eg>255) eg=255;
		       else if (eg<0) eg=0;
		       if (eb>255) eb=255;
		       else if (eb<0) eb=0;
		       val=id->fast_rgb[er>>3][eg>>3][eb>>3];
		       r=id->fast_err[er>>3][eg>>3][eb>>3];
		       g=id->fast_erg[er>>3][eg>>3][eb>>3];
		       b=id->fast_erb[er>>3][eg>>3][eb>>3];
		       er=r;eg=g;eb=b;
		       er1[ex+0]+=(er*7)>>4;
		       er1[ex+1]+=(eg*7)>>4;
		       er1[ex+2]+=(eb*7)>>4;
		       er2[ex-6]+=(er*3)>>4;
		       er2[ex-5]+=(eg*3)>>4;
		       er2[ex-4]+=(eb*3)>>4;
		       er2[ex-3]+=(er*5)>>4;
		       er2[ex-2]+=(eg*5)>>4;
		       er2[ex-1]+=(eb*5)>>4;
		       er2[ex+0]+=(er*1)>>4;
		       er2[ex+1]+=(eg*1)>>4;
		       er2[ex+2]+=(eb*1)>>4;
		       XPutPixel(xim,x,y,val);
		    }
	       }
	  }
	break;
      default:
	switch (bpp)
	  {
	   case 8:
	     break;
	   case 15:
	     render_shaped_15(id,im,w,h,xim,sxim,er1,er2,xarray,yarray);
	     break;
	   case 16:
	     render_shaped_16(id,im,w,h,xim,sxim,er1,er2,xarray,yarray);
	     break;
	   case 24:
	   case 32:
	     render_shaped_24(id,im,w,h,xim,sxim,er1,er2,xarray,yarray);
	     break;
	   default:
	     break;
	  }
	break;
     }
}

void render(ImlibData *id, Image *im, int w, int h, XImage *xim, 
	    XImage *sxim, int *er1, int *er2, int *xarray,
	    unsigned char **yarray, int bpp)
{ 
   int x,y,val,r,g,b,*ter,ex,er,eg,eb;
   unsigned char *ptr2;
   
   switch (id->render_type)
     {
      case RT_PLAIN_PALETTE:
	for(y=0;y<h;y++)
	  {
	     for(x=0;x<w;x++)
	       {
		  ptr2=yarray[y]+xarray[x];
		  r=(int)*ptr2++;
		  g=(int)*ptr2++;
		  b=(int)*ptr2;
		  val=ImlibBestColorMatch(id,&r,&g,&b);
		  XPutPixel(xim,x,y,val);
	       }
	  }
	break;
      case RT_PLAIN_PALETTE_FAST:
	for(y=0;y<h;y++)
	  {
	     for(x=0;x<w;x++)
	       {
		  ptr2=yarray[y]+xarray[x];
		  r=(int)*ptr2++;
		  g=(int)*ptr2++;
		  b=(int)*ptr2;
		  val=id->fast_rgb[r>>3][g>>3][b>>3];
		  XPutPixel(xim,x,y,val);
	       }
	  }
	break;
      case RT_DITHER_PALETTE:
	for(y=0;y<h;y++)
	  {
	     ter=er1;er1=er2;er2=ter;
	     for (ex=0;ex<(w+2)*3;ex++) er2[ex]=0;
	     ex=3;
	     for(x=0;x<w;x++)
	       {
		  ptr2=yarray[y]+xarray[x];
		  r=(int)*ptr2++;
		  g=(int)*ptr2++;
		  b=(int)*ptr2;
		  er=r+er1[ex++];eg=g+er1[ex++];eb=b+er1[ex++];
		  if (er>255) er=255;
		  else if (er<0) er=0;
		  if (eg>255) eg=255;
		  else if (eg<0) eg=0;
		  if (eb>255) eb=255;
		  else if (eb<0) eb=0;
		  val=ImlibBestColorMatch(id,&er,&eg,&eb);
		  er=r;eg=g;eb=b;
		  er1[ex+0]+=(er*7)>>4;
		  er1[ex+1]+=(eg*7)>>4;
		  er1[ex+2]+=(eb*7)>>4;
		  er2[ex-6]+=(er*3)>>4;
		  er2[ex-5]+=(eg*3)>>4;
		  er2[ex-4]+=(eb*3)>>4;
		  er2[ex-3]+=(er*5)>>4;
		  er2[ex-2]+=(eg*5)>>4;
		  er2[ex-1]+=(eb*5)>>4;
		  er2[ex+0]+=(er*1)>>4;
		  er2[ex+1]+=(eg*1)>>4;
		  er2[ex+2]+=(eb*1)>>4;
		  XPutPixel(xim,x,y,val);
	       }
	  }
	break;
      case RT_DITHER_PALETTE_FAST:
	for(y=0;y<h;y++)
	  {
	     ter=er1;er1=er2;er2=ter;
	     for (ex=0;ex<(w+2)*3;ex++) er2[ex]=0;
	     ex=3;
	     for(x=0;x<w;x++)
	       {
		  ptr2=yarray[y]+xarray[x];
		  r=(int)*ptr2++;
		  g=(int)*ptr2++;
		  b=(int)*ptr2;
		  er=r+er1[ex++];eg=g+er1[ex++];eb=b+er1[ex++];
		  if (er>255) er=255;
		  else if (er<0) er=0;
		  if (eg>255) eg=255;
		  else if (eg<0) eg=0;
		  if (eb>255) eb=255;
		  else if (eb<0) eb=0;
		  val=id->fast_rgb[er>>3][eg>>3][eb>>3];
		  r=id->fast_err[er>>3][eg>>3][eb>>3];
		  g=id->fast_erg[er>>3][eg>>3][eb>>3];
		  b=id->fast_erb[er>>3][eg>>3][eb>>3];
		  er=r;eg=g;eb=b;
		  er1[ex+0]+=(er*7)>>4;
		  er1[ex+1]+=(eg*7)>>4;
		  er1[ex+2]+=(eb*7)>>4;
		  er2[ex-6]+=(er*3)>>4;
		  er2[ex-5]+=(eg*3)>>4;
		  er2[ex-4]+=(eb*3)>>4;
		  er2[ex-3]+=(er*5)>>4;
		  er2[ex-2]+=(eg*5)>>4;
		  er2[ex-1]+=(eb*5)>>4;
		  er2[ex+0]+=(er*1)>>4;
		  er2[ex+1]+=(eg*1)>>4;
		  er2[ex+2]+=(eb*1)>>4;
		  XPutPixel(xim,x,y,val);
	       }
	  }
	break;
      default:
	switch (bpp)
	  {
	   case 8:
	     break;
	   case 15:
	     render_15(id,im,w,h,xim,sxim,er1,er2,xarray,yarray);
	     break;
	   case 16:
	     render_16(id,im,w,h,xim,sxim,er1,er2,xarray,yarray);
	     break;
	   case 24:
	   case 32:
	     render_24(id,im,w,h,xim,sxim,er1,er2,xarray,yarray);
	     break;
	   default:
	     break;
	  }
	break;
     }
}

int ImlibRender(ImlibData *id, Image *im, int w, int h)
{
   XImage *xim,*sxim;
   GC tgc,stgc;
   XGCValues gcv;
   int x,y,val,r,g,b;
   int inc,pos,w3;
   unsigned char *ptr1,*ptr2,*ptr22,*tmp,*stmp;
   int *error,*er1,*er2,*ter;
   unsigned char **yarray;
   int *xarray;
   int ex;
   int er,eg,eb;
   int bpp;
   int huge;
   XShmSegmentInfo shminfo;
   XShmSegmentInfo sshminfo;
   Pixmap pmap;
   Pixmap mask;
   
   if (!im) return 0;
   if (id->cache.on_pixmap)
     {
	pmap=0;
	find_pixmap(id,im,w,h,&pmap,&mask);
	if (pmap)
	  {
	     im->width=w;
	     im->height=h;
	     im->pixmap=pmap;
	     if (mask) im->shape_mask=mask;
	     else im->shape_mask=0;
	     return 1;
	  }
     }
   huge=0;
   if (w<=0) return 0;
   if (h<=0) return 0;
   if (id->x.depth<=8) bpp=1;
   else if (id->x.depth<=16) bpp=2;
   else bpp=4;
   if ((bpp*w*h)>id->max_shm) huge=1;
   im->width=w;im->height=h;
   im->pixmap=XCreatePixmap(id->x.disp,id->x.root,w,h,id->x.depth);
   if ((im->shape_color.r>=0)&&(im->shape_color.g>=0)&&(im->shape_color.b>=0))
     {
	im->shape_mask=XCreatePixmap(id->x.disp,id->x.root,w,h,1);
	if ((id->x.shm)&&(!huge))
	  {
	     sxim=XShmCreateImage(id->x.disp,id->x.visual,1,ZPixmap,NULL,&id->x.last_sshminfo,w,h);
	     if (!sxim)
	       {fprintf(stderr,"Imlib ERROR: Mit-SHM can't create XImage\n");return 0;}
	     id->x.last_sshminfo.shmid=shmget(IPC_PRIVATE,sxim->bytes_per_line*sxim->height,IPC_CREAT|0777);
	     if (id->x.last_sshminfo.shmid==-1)
	       {fprintf(stderr,"Imlib ERROR: SHM can't get SHM Identifier\n");return 0;}
	     id->x.last_sshminfo.shmaddr=sxim->data=shmat(id->x.last_sshminfo.shmid,0,0);
	     if (!XShmAttach(id->x.disp,&id->x.last_sshminfo))
	       {fprintf(stderr,"Imlib ERROR: MIT-SHM Can't attach SHM Identifier\n");return 0;}
	     stmp=sxim->data;
	     if (!stmp)
	       {fprintf(stderr,"ERROR: Cannot allocate RAM for shape image data\n");return 0;}
	     id->x.last_sxim=sxim;
	  }
	else
	  {
	     stmp=(unsigned char *)malloc(((w>>3)+8)*h);
	     if (!stmp)
	       {fprintf(stderr,"ERROR: Cannot allocate RAM for shape image data\n");return 0;
	       }
	     sxim=XCreateImage(id->x.disp,id->x.visual,1,ZPixmap,0,stmp,w,h,8,0);
	     if (!sxim)
	       {fprintf(stderr,"ERROR: Cannot allocate Ximage shape buffer\n");return 0;}
	  }
	stgc=XCreateGC(id->x.disp,im->shape_mask,(unsigned long)0,&gcv);
     }
   error=(int *)malloc(sizeof(int)*(w+2)*2*3);
   if (!error)
     {fprintf(stderr,"ERROR: Cannot allocate RAM for image dither buffer\n");return 0;}
   if ((id->x.shm)&&(!huge))
     {
	xim=XShmCreateImage(id->x.disp,id->x.visual,id->x.depth,ZPixmap,NULL,&id->x.last_shminfo,w,h);
	if (!xim)
	  {fprintf(stderr,"Imlib ERROR: Mit-SHM can't create XImage\n");return 0;}
	id->x.last_shminfo.shmid=shmget(IPC_PRIVATE,xim->bytes_per_line*xim->height,IPC_CREAT|0777);
	if (id->x.last_shminfo.shmid==-1)
	  {fprintf(stderr,"Imlib ERROR: SHM can't get SHM Identifier\n");return 0;}
	id->x.last_shminfo.shmaddr=xim->data=shmat(id->x.last_shminfo.shmid,0,0);
	if (!XShmAttach(id->x.disp,&id->x.last_shminfo))
	  {fprintf(stderr,"Imlib ERROR: MIT-SHM Can't attach SHM Identifier\n");return 0;}
	tmp=xim->data;
	if (!tmp)
	  {fprintf(stderr,"ERROR: Cannot allocate RAM for image data\n");return 0;}
	id->x.last_xim=xim;
     }
   else
     {
	tmp=(unsigned char *)malloc(w*h*bpp);
	if (!tmp)
	  {fprintf(stderr,"ERROR: Cannot allocate RAM for image data\n");return 0;}
	xim=XCreateImage(id->x.disp,id->x.visual,id->x.depth,ZPixmap,0,tmp,w,h,8,0);
	if (!xim)
	  {fprintf(stderr,"ERROR: Cannot allocate Ximage buffer\n");return 0;}
     }
   er1=error;er2=error+((w+2)*3);
   ptr1=tmp;ptr22=im->rgb_data;
   w3=im->rgb_width*3;
   tgc=XCreateGC(id->x.disp,im->pixmap,(unsigned long)0,&gcv);
   xarray=malloc(sizeof(int)*w);
   if (!xarray)
     {fprintf(stderr,"ERROR: Cannot allocate X co-ord buffer\n");return 0;}
   yarray=malloc(sizeof(unsigned char *)*h);
   if (!yarray)
     {free(xarray);fprintf(stderr,"ERROR: Cannot allocate Y co-ord buffer\n");return 0;
     }
   for (ex=0;ex<((w+2)*3*2);ex++) error[ex]=0;
     {
	int l,r,m;
	
	if (w<im->border.left+im->border.right)
	  {l=w>>1;r=w-l;m=0;}
	else
	  {l=im->border.left;r=im->border.right;m=w-l-r;}
	if (m>0) inc=((im->rgb_width-im->border.left-im->border.right)<<16)/m;
	pos=0;
	for (x=0;x<l;x++)
	  {xarray[x]=(pos>>16)+(pos>>16)+(pos>>16);pos+=0x10000;}
	if (m)
	  {
	     for (x=l;x<l+m;x++)
	       {xarray[x]=(pos>>16)+(pos>>16)+(pos>>16);pos+=inc;}
	  }
	pos=(im->rgb_width-r)<<16;
	for (x=w-r;x<w;x++)
	  {xarray[x]=(pos>>16)+(pos>>16)+(pos>>16);pos+=0x10000;}
	
	if (h<im->border.top+im->border.bottom)
	  {l=h>>1;r=h-l;m=0;}
	else
	  {l=im->border.top;r=im->border.bottom;m=h-l-r;}
	if (m>0) inc=((im->rgb_height-im->border.top-im->border.bottom)<<16)/m;
	pos=0;
	for (x=0;x<l;x++)
	  {yarray[x]=ptr22+((pos>>16)*w3);pos+=0x10000;}
	if (m)
	  {
	     for (x=l;x<l+m;x++)
	       {yarray[x]=ptr22+((pos>>16)*w3);pos+=inc;}
	  }
	pos=(im->rgb_height-r)<<16;
	for (x=h-r;x<h;x++)
	  {yarray[x]=ptr22+((pos>>16)*w3);pos+=0x10000;}
     }
   if ((im->shape_color.r>=0)&&(im->shape_color.g>=0)&&(im->shape_color.b>=0))
     {
	if (id->x.depth<=8)
	  render_shaped(id,im,w,h,xim,sxim,er1,er2,xarray,yarray,8);
	else
	  render_shaped(id,im,w,h,xim,sxim,er1,er2,xarray,yarray,id->x.depth);
	if ((id->x.shm)&&(!huge))
	  {
	     XShmPutImage(id->x.disp,im->pixmap,tgc,xim,0,0,0,0,w,h,False);
	     XShmPutImage(id->x.disp,im->shape_mask,stgc,sxim,0,0,0,0,w,h,False);
	  }
	else
	  {
	     XPutImage(id->x.disp,im->pixmap,tgc,xim,0,0,0,0,w,h);
	     XPutImage(id->x.disp,im->shape_mask,stgc,sxim,0,0,0,0,w,h);
	     XFree(xim);
	     XFree(sxim);
	     free(tmp);
	     free(stmp);
	  }
	XFreeGC(id->x.disp,tgc);
	XFreeGC(id->x.disp,stgc);
     }
   else
     {
	if (id->x.depth<=8)
	  render(id,im,w,h,xim,sxim,er1,er2,xarray,yarray,8);
	else
	  render(id,im,w,h,xim,sxim,er1,er2,xarray,yarray,id->x.depth);
	if ((id->x.shm)&&(!huge))
	  {
	     XShmPutImage(id->x.disp,im->pixmap,tgc,xim,0,0,0,0,w,h,False);
	  }
	else
	  {
	     XPutImage(id->x.disp,im->pixmap,tgc,xim,0,0,0,0,w,h);
	     XFree(xim);
	     free(tmp);
	  }
	XFreeGC(id->x.disp,tgc);
     }
   XSync(id->x.disp,False);
   if (id->x.last_xim)
     {
	XEvent ev;
	
	/*while (!XCheckTypedEvent(id->x.disp,id->x.shm_event,&ev));*/
	XShmDetach(id->x.disp,&id->x.last_shminfo);
	XDestroyImage(xim);
	shmdt(id->x.last_shminfo.shmaddr);
	shmctl(id->x.last_shminfo.shmid,IPC_RMID,0);
	id->x.last_xim=NULL;
     }
   if (id->x.last_sxim)
     {
	XEvent ev;
	
	/*while (!XCheckTypedEvent(id->x.disp,id->x.shm_event,&ev));*/
	XShmDetach(id->x.disp,&id->x.last_sshminfo);
	XDestroyImage(sxim);
	shmdt(id->x.last_sshminfo.shmaddr);
	shmctl(id->x.last_sshminfo.shmid,IPC_RMID,0);
	id->x.last_sxim=NULL;
     }
   free(error);
   free(xarray);
   free(yarray);
   add_pixmap(id,im,w,h);
   return 1;
}
