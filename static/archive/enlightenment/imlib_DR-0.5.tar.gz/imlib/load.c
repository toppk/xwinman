#include "imlib.h"

void _SplitID(char *file, char *id)
{
   int len;
   int i,j,k;
   
   len=strlen(file);
   k=0;
   i=len-1;
   if (i<0) 
     {
	id[0]=0;
	return;
     }
   while ((file[i]!=':')&&(i>=0)) i--;
   if (i<0) id[0]=0;
   else
     {
	for (j=i+1;j<len;j++)
	  {
	     id[k++]=(char)file[j];
	  }
	id[k]=0;
	file[i]=0;
     }
}

void _GetExtension(char *file, char *ext)
{
   int len;
   int i,j,k;
   
   len=strlen(file);
   k=0;
   i=len-1;
   if (i<0) 
     {
	ext[0]=0;
	return;
     }
   while ((file[i]!='.')&&(i>=0)) i--;
   if (i<0) ext[0]=0;
   else
     {
	for (j=i+1;j<len;j++)
	  {
	     ext[k++]=(char)tolower(file[j]);
	  }
	ext[k]=0;
     }
}

unsigned char *_LoadPPM(FILE *f, int *w, int *h)
{
   int done,x,y;
   unsigned char *ptr;
   unsigned char chr;
   char s[256];
   int a,b;
   int color;
   
   fgets(s,256,f);
   s[strlen(s)-1]=0;
   if (!strcmp(s,"P6")) color=1;
   else if (!strcmp(s,"P5")) color=0;
   else return NULL;
   done=1;
   while(done)
     {
	fgets(s,256,f);

	s[strlen(s)-1]=0;
	if (s[0]!='#')
	  {
	     done=0;
	     sscanf(s,"%i %i",w,h);
	     a=*w;
	     b=*h;
	     if (a>32767)
	       {
		  fprintf(stderr,"ImLib ERROR: Image width > 32767 pixels for file\n");
		  return NULL;
	       }
	     if (b>32767)
	       {
		  fprintf(stderr,"ImLib ERROR: Image height > 32767 pixels for file\n");
		  return NULL;
	       }
	     fgets(s,256,f);
	     s[strlen(s)-1]=0;
	     ptr=(unsigned char *)malloc(a*b*3);
	     if (!ptr)
	       {
		  fprintf(stderr,"ImLib ERROR: Cannot allocate RAM for RGB data in file");
		  return ptr;
	       }
	     if (color)
	       {
		  if (!fread(ptr,a*b*3,1,f)) return NULL;
	       }
	     else
	       {
		  b=(a*b*3);
		  a=0;
		  while((fread(&chr,1,1,f))&&(a<b))
		    {
		       ptr[a++]=chr;
		       ptr[a++]=chr;
		       ptr[a++]=chr;
		    }
	       }
	  }
     }
   return ptr;
}

Image *ImlibLoadImage(ImlibData *id, char *file, ImColor *icl)
{
   int w,h;
   int needs_conv = 1;
   unsigned char *data;
   Image *im;
   char s[4096];
   char iden[4096];
   char cmd[4096];
   FILE *p;
   int eim;
   
   eim=0;
   data=NULL;
   if (id->cache.on_image)
     if (im=find_image(id,file)) return im;
   _SplitID(file,iden);
   _GetExtension(file,s);
   if (!strcasecmp(s,"ppm")) needs_conv = 0;
   if (!strcasecmp(s,"pgm")) needs_conv = 0;
   if (!strcasecmp(s,"eim")) 
     {
	needs_conv = 0;
	eim=1;
     }
   if (needs_conv)
     {
	sprintf(cmd,"%s/convert %s pnm:-", CONVERT_PATH, file);
	p=popen(cmd,"r");
     }
   else
     {
	p=fopen(file,"r");
     }
   if ((!eim)&&(!data)) data=_LoadPPM(p,&w,&h);
   if ((!eim)&&(!data))
     {
	if (p)
	  {
	     if (needs_conv) pclose(p);
	     else fclose(p);
	  }
	if (!strcasecmp(s,"jpeg")) sprintf(cmd,"%s/djpeg %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"jpg")) sprintf(cmd,"%s/djpeg %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"bmp")) sprintf(cmd,"%s/bmptoppm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"ilbm")) sprintf(cmd,"%s/ilbmtoppm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"ilb")) sprintf(cmd,"%s/ilbmtoppm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"iff")) sprintf(cmd,"%s/ilbmtoppm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"img")) sprintf(cmd,"%s/imgtoppm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"mtv")) sprintf(cmd,"%s/mtvtoppm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"pcx")) sprintf(cmd,"%s/pcxtoppm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"pgm")) sprintf(cmd,"%s/pgmtoppm rgb:ffff/ffff/ffff %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"pi1")) sprintf(cmd,"%s/pi1toppm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"pict")) sprintf(cmd,"%s/picttoppm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"pic")) sprintf(cmd,"%s/picttoppm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"pj")) sprintf(cmd,"%s/pjtoppm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"qrt")) sprintf(cmd,"%s/qrttoppm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"sld")) sprintf(cmd,"%s/sldtoppm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"spc")) sprintf(cmd,"%s/spctoppm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"spu")) sprintf(cmd,"%s/sputoppm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"tga")) sprintf(cmd,"%s/tgatoppm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"xim")) sprintf(cmd,"%s/ximtoppm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"xpm")) sprintf(cmd,"%s/xpmtoppm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"gif")) sprintf(cmd,"%s/giftopnm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"rast")) sprintf(cmd,"%s/rasttopnm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"ras")) sprintf(cmd,"%s/rasttopnm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"sgi")) sprintf(cmd,"%s/sgitopnm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"sir")) sprintf(cmd,"%s/sirtopnm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"tiff")) sprintf(cmd,"%s/tifftopnm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"tif")) sprintf(cmd,"%s/tifftopnm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"wxd")) sprintf(cmd,"%s/wxdtopnm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"zeiss")) sprintf(cmd,"%s/zeisstopnm -ppm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"zei")) sprintf(cmd,"%s/zeisstopnm -ppm %s", NETPBM_PATH, file);
	else if (!strcasecmp(s,"zis")) sprintf(cmd,"%s/zeisstopnm -ppm %s", NETPBM_PATH, file);
	else sprintf(cmd,"%s/anytopnm %s", NETPBM_PATH, file);
	p=popen(cmd,"r"); 
	if (!p)
	  {
	     fprintf(stderr,"ImLib ERROR: Cannot exec %s to load image %s\n",cmd,file);
	     return NULL;
	  }
	data=_LoadPPM(p,&w,&h);
     }
   if ((!eim)&&(!data)) 
     {
	fprintf(stderr,"ImLib ERROR: Cannot load image: %s\n",file);
	if (p)
	  {
	     if (needs_conv) pclose(p);
	     else fclose(p);
	  }
	return NULL;
     }
   if (p)
     {
	if (needs_conv) pclose(p);
	else fclose(p);
     }
   
   im=(Image *)malloc(sizeof(Image));
   if (!im)
     {
	fprintf(stderr,"Imlib ERROR: Cannot allocate RAM for image data\n");
	return NULL;
     }
   im->border.left=0;
   im->border.right=0;
   im->border.top=0;
   im->border.bottom=0;
   im->cache=1;
   im->rgb_data=data;
   im->rgb_width=w;
   im->rgb_height=h;
   im->pixmap=0;
   im->shape_mask=0;
   if (icl) 
     {
	im->shape_color.r=icl->r;
	im->shape_color.g=icl->g;
	im->shape_color.b=icl->b;
     }
   else
     {
	im->shape_color.r=-1;
	im->shape_color.g=-1;
	im->shape_color.b=-1;
     }
   if (eim)
     {
	char s1[256],s2[256];
	int num,size;
	int r,g,b;
	int br,bl,bt,bb;
	
	/* Load Native-as-can-be EIM format (Enlightenment IMlib format) */
	p=fopen(file,"r");
	if (!p) 
	  {
	     free(im);
	     return NULL;
	  }
	fgets(s,4096,p);
	if ((s[0]!='E')&&(s[1]!='I')&&(s[2]!='M')&&(s[3]!=' '))
	  {
	     fclose(p);
	     free(im);
	     return NULL;
	  }
	sscanf(s,"%s %i",s1,&num);
	if (num<=0)
	  {
	     fclose(p);
	     free(im);
	     return NULL;
	  }
	while(fgets(s,4096,p))
	  {
	     sscanf(s,"%s",s1);
	     if (!strcmp("IMAGE",s1))
	       {
		  sscanf(s,"%s %i %s %i %i %i %i %i %i %i %i %i",s1,&size,s2,&w,&h,&r,&g,&b,&bl,&br,&bt,&bb);
		  if (!iden[0]) break;
		  else if (!strcmp(iden,s2)) break;
		  if (size>0) fseek(p,size,SEEK_CUR);
	       }
	  }
	im->rgb_data=malloc(w*h*3);
	if (!im->rgb_data)
	  {
	     fclose(p);
	     free(im);
	     return NULL;
	  }
	im->shape_color.r=r;im->shape_color.g=g;im->shape_color.b=b;
	im->rgb_width=w;im->rgb_height=h;
	im->border.left=bl;im->border.right=br;im->border.top=bt;im->border.bottom=bb;
	fread(im->rgb_data,1,w*h*3,p);
	fclose(p);
	if (iden[0])
	  {
	     strcat(file,":");
	     strcat(file,iden);
	  }
     }
   if ((id->cache.on_image)&&(im)) add_image(id,im,file);
   return im;
}

int ImlibSaveImageToEIM(ImlibData *id, Image *im, char *file)
{
   char iden[1024];
   FILE *f;
   
   if ((!id)||(!im)||(!file)) return 0;
   _SplitID(file,iden);
   if (!iden[0]) strcpy(iden,"default");
   f=fopen(file,"w");
   if (!f) return 0;
   fprintf(f,"EIM 1\n");
   fprintf(f,"IMAGE %i %s %i %i %i %i %i %i %i %i %i\n",
	   im->rgb_width*im->rgb_height*3,
	   iden,
	   im->rgb_width,
	   im->rgb_height,
	   im->shape_color.r,
	   im->shape_color.g,
	   im->shape_color.b,
	   im->border.left,
	   im->border.right,
	   im->border.top,
	   im->border.bottom);
   fwrite(im->rgb_data,1,im->rgb_width*im->rgb_height*3,f);
   fclose(f);
   return 1;
}

int ImlibAddImageToEIM(ImlibData *id, Image *im, char *file)
{
   char iden[1024];
   FILE *f;
   
   if ((!id)||(!im)||(!file)) return 0;
   _SplitID(file,iden);
   if (!iden[0]) strcpy(iden,"default");
   f=fopen(file,"a");
   if (!f) return 0;
   fprintf(f,"IMAGE %i %s %i %i %i %i %i %i %i %i %i\n",
	   im->rgb_width*im->rgb_height*3,
	   iden,
	   im->rgb_width,
	   im->rgb_height,
	   im->shape_color.r,
	   im->shape_color.g,
	   im->shape_color.b,
	   im->border.left,
	   im->border.right,
	   im->border.top,
	   im->border.bottom);
   fwrite(im->rgb_data,1,im->rgb_width*im->rgb_height*3,f);
   fclose(f);
   return 1;
}

int ImlibSaveImageToPPM(ImlibData *id, Image *im, char *file)
{
   FILE *f;
   
   if ((!id)||(!im)||(!file)) return 0;
   f=fopen(file,"w");
   if (!f) return 0;
   fprintf(f,"P6\n");
   fprintf(f,"%i %i\n255\n",
	   im->rgb_width,
	   im->rgb_height);
   fwrite(im->rgb_data,1,im->rgb_width*im->rgb_height*3,f);
   fclose(f);
   return 1;
}

