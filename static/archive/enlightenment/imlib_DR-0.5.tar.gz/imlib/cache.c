#include "imlib.h"

void find_pixmap(ImlibData *id, Image *im, int width, int height, Pixmap *pmap, Pixmap *mask)
{
   struct pixmap_cache *ptr;
   
   ptr=id->cache.pixmap;
   while (ptr)
     {
	if ((ptr->im==im)&&(ptr->width==width)&&(ptr->height==height))
	  {
	     if (ptr->refnum) ptr->refnum++;
	     else
	       {
		  ptr->refnum++;
		  id->cache.num_pixmap++;
		  id->cache.used_pixmap-=width*height*id->x.depth;
		  if (id->cache.used_pixmap<0)
		    {
		       id->cache.used_pixmap=0;
		       fprintf(stderr,"IMLIB: uhoh.. caching problems.... meep meep\n");
		    }
	       }
	     if (ptr->prev)
	       {
		  ptr->prev->next=ptr->next;
		  if (ptr->next) 
		    ptr->next->prev=ptr->prev;
		  ptr->next=id->cache.pixmap;
		  id->cache.pixmap=ptr;
		  ptr->prev=NULL;
	       }
	     *pmap=ptr->pmap;
	     *mask=ptr->shape_mask;
	     return;
	  }
	ptr=ptr->next;
     }
   *pmap=0;
   *mask=0;
}

Image *find_image(ImlibData *id, char *file)
{
   struct image_cache *ptr;
   
   ptr=id->cache.image;
   while (ptr)
     {
	if (!strcmp(file,ptr->file))
	  {
	     if (ptr->refnum) ptr->refnum++;
	     else
	       {
		  ptr->refnum++;
		  id->cache.num_image++;
		  id->cache.used_image-=ptr->im->rgb_width*ptr->im->rgb_height*3;
		  if (id->cache.used_image<0)
		    {
		       id->cache.used_image=0;
		       fprintf(stderr,"IMLIB: uhoh.. caching problems.... meep meep\n");
		    }
	       }
	     if (ptr->prev)
	       {
		  ptr->prev->next=ptr->next;
		  if (ptr->next)
		    ptr->next->prev=ptr->prev;
		  ptr->next=id->cache.image;
		  id->cache.image=ptr;
		  ptr->prev=NULL;
	       }
	     return ptr->im;
	  }
	ptr=ptr->next;
     }
   return NULL;
}

void free_pixmap(ImlibData *id, Image *im, int width, int height)
{
   struct pixmap_cache *ptr;
   
   ptr=id->cache.pixmap;
   while (ptr)
     {
	if ((ptr->im==im)&&(ptr->width==width)&&(ptr->height==height))
	  {
	     if (ptr->refnum) 
	       {
		  ptr->refnum--;
		  if (!ptr->refnum)
		    {
		       id->cache.num_pixmap--;
		       id->cache.used_pixmap+=width*height*id->x.depth;
		    }
	       }
	     return;
	  }
	ptr=ptr->next;
     }
}

void free_pixmappmap(ImlibData *id, Pixmap pmap)
{
   struct pixmap_cache *ptr;
   
   ptr=id->cache.pixmap;
   while (ptr)
     {
	if ((ptr->pmap==pmap)||(ptr->shape_mask==pmap))
	  {
	     if (ptr->shape_mask==pmap) return;
	     if (ptr->refnum) 
	       {
		  ptr->refnum--;
		  if (!ptr->refnum)
		    {
		       id->cache.num_pixmap--;
		       id->cache.used_pixmap+=ptr->width*ptr->height*id->x.depth;
		    }
	       }
	     return;
	  }
	ptr=ptr->next;
     }
   XFreePixmap(id->x.disp,pmap);
}

void free_image(ImlibData *id, Image *im)
{
   struct image_cache *ptr;
   
   ptr=id->cache.image;
   while (ptr)
     {
	if (im==ptr->im)
	  {
	     if (ptr->refnum) 
	       {
		  ptr->refnum--;
		  if (!ptr->refnum)
		    {
		       id->cache.num_image--;
		       id->cache.used_image+=ptr->im->rgb_width*ptr->im->rgb_height*3;
		    }
	       }
	     return;
	  }
	ptr=ptr->next;
     }
}

void flush_image(ImlibData *id, Image *im)
{
   struct image_cache *ptr;
   
   ptr=id->cache.image;
   while (ptr)
     {
	if (im==ptr->im)
	  {
	     ptr->im->cache=0;
	     return;
	  }
	ptr=ptr->next;
     }
}

void add_image(ImlibData *id, Image *im, char *file)
{
   struct image_cache *ptr;
   struct image_cache *n;
   
   if ((!im)||(!file)) return;
   ptr=id->cache.image;
   n=malloc(sizeof(struct image_cache));
   if (!n) return;
   n->prev=NULL;
   n->next=ptr;
   n->file=malloc(strlen(file)+2);
   if (!n->file) 
     {
	free(n);
	return;
     }
   strcpy(n->file,file);
   n->im=im;
   n->refnum=1;
   if (n->next) n->next->prev=n;
   id->cache.image=n;
   id->cache.num_image++;
}

void add_pixmap(ImlibData *id, Image *im, int width, int height)
{
   struct pixmap_cache *ptr;
   struct pixmap_cache *n;
   
   if (!im) return;
   ptr=id->cache.pixmap;
   n=malloc(sizeof(struct pixmap_cache));
   if (!n) return;
   n->prev=NULL;
   n->next=ptr;
   n->im=im;
   n->refnum=1;
   n->width=width;
   n->height=height;
   n->pmap=im->pixmap;
   n->shape_mask=im->shape_mask;
   if (n->next) n->next->prev=n;
   id->cache.pixmap=n;
   id->cache.num_pixmap++;
}

void clean_caches(ImlibData *id)
{
     {
	struct image_cache *ptr;
	struct image_cache *pptr;
	struct image_cache *last;
	int newlast;
	
	/* find the back of the list */
	ptr=id->cache.image;
	while (ptr)
	  {
	     last=ptr;
	     ptr=ptr->next;
	  }
	newlast=0;
	ptr=last;
	/* remove all images that are tagged non-cachable, and have 0 */
	/* references , even if the cache has spare room. */
	while (ptr)
	  {
	     if (!ptr->refnum)
	       {
		  if (!ptr->im->cache)
		    {
		       if (ptr==last) newlast=1;
		       id->cache.used_image-=ptr->im->rgb_width*ptr->im->rgb_height*3;
		       nullify_image(id,ptr->im);
		       pptr=ptr->next;
		       if (!pptr) pptr->prev;
		       if (ptr->prev) ptr->prev->next=ptr->next;
		       if (ptr->next) ptr->next->prev=ptr->prev;
		       if ((!ptr->next)&&(!ptr->prev))
			 id->cache.image=NULL;
		       free(ptr->file);
		       free(ptr);
		       ptr=pptr;
		    }
	       }
	     if (ptr) ptr=ptr->prev;
	     if (newlast)
	       {
		  ptr=id->cache.image;
		  while (ptr)
		    {
		       last=ptr;
		       ptr=ptr->next;
		    }
		  newlast=0;
		  ptr=last;
	       }
	  }
	/* find the back of the list */
	ptr=id->cache.image;
	last=NULL;
	while (ptr)
	  {
	     last=ptr;
	     ptr=ptr->next;
	  }
	newlast=0;
	ptr=last;
	/* while the amount of data in the cache is greater than the set */
	/* amount, delete the last entry (last used) from the unreferenced */
	/* cached 24-bit images */
	while (id->cache.used_image>id->cache.size_image)
	  {
	     while (ptr)
	       {
		  if (!ptr->refnum)
		    {
		       if (ptr==last) newlast=1;
		       id->cache.used_image-=ptr->im->rgb_width*ptr->im->rgb_height*3;
		       nullify_image(id,ptr->im);
		       if (ptr->prev) ptr->prev->next=ptr->next;
		       if (ptr->next) ptr->next->prev=ptr->prev;
		       if ((!ptr->next)&&(!ptr->prev))
			 id->cache.image=NULL;
		       free(ptr->file);
		       free(ptr);
		       ptr=NULL;
		       break;
		    }
		  if (ptr) ptr=ptr->prev;
	       }
	     if (newlast)
	       {
		  ptr=id->cache.image;
		  while (ptr)
		    {
		       last=ptr;
		       ptr=ptr->next;
		    }
		  newlast=0;
		  ptr=last;
	       }
	     if (!ptr) break;
	  }
     }
     {
	struct pixmap_cache *ptr;
	struct pixmap_cache *last;
	int newlast;

	/* find the back of the list */
	ptr=id->cache.pixmap;
	last=NULL;
	while (ptr)
	  {
	     last=ptr;
	     ptr=ptr->next;
	  }
	newlast=0;
	ptr=last;
	/* while the amount of data in the cache is greater than the set */
	/* amount, delete the last entry (last used) from the unreferenced */
	/* cached pixmaps */
	while (id->cache.used_pixmap>id->cache.size_pixmap)
	  {
	     while (ptr)
	       {
		  if (!ptr->refnum)
		    {
		       if (ptr==last) newlast=1;
		       id->cache.used_pixmap-=ptr->width*ptr->height*id->x.depth;
		       if (ptr->pmap) XFreePixmap(id->x.disp,ptr->pmap);
		       if (ptr->shape_mask) XFreePixmap(id->x.disp,ptr->shape_mask);
		       if (ptr->prev) ptr->prev->next=ptr->next;
		       if (ptr->next) ptr->next->prev=ptr->prev;
		       if ((!ptr->next)&&(!ptr->prev))
			 id->cache.pixmap=NULL;
		       free(ptr);
		       ptr=NULL;
		       break;
		    }
		  if (ptr) ptr=ptr->prev;
	       }
	     if (newlast)
	       {
		  last=NULL;
		  ptr=id->cache.pixmap;
		  while (ptr)
		    {
		       last=ptr;
		       ptr=ptr->next;
		    }
		  newlast=0;
		  ptr=last;
	       }
	     if (!ptr) break;
	  }
     }
}

void nullify_image(ImlibData *id, Image *im)
{
   if (!im) return;
   if (im->rgb_data) free(im->rgb_data);
   if (im->pixmap) XFreePixmap(id->x.disp,im->pixmap);
   if (im->shape_mask) XFreePixmap(id->x.disp,im->shape_mask);
   free(im);
}
