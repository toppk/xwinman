#include "imlib.h"

int ImlibGetRenderType(ImlibData *id)
{
   if (id) return id->render_type;
   else
     {    
	fprintf(stderr,"ImLib ERROR: ImlibData struct not initialised\n");
	return -1;
     }
}

int ImlibSetRenderType(ImlibData *id, int rend_type)
{
   if (id)
     {
	if (id->x.depth>8) id->render_type=rend_type;
	else
	  {
	     if (rend_type==RT_PLAIN_TRUECOL)
	       id->render_type=RT_DITHER_PALETTE_FAST;
	     else
	       id->render_type=rend_type;
	  }
	return 1;
     }
   else
     {
	fprintf(stderr,"ImLib ERROR: ImlibData struct not initialised\n");
	return 0;
     }
}

ImlibData *ImlibInit(Display *disp)
{
   ImlibData *id;
   XWindowAttributes xwa;
   XVisualInfo xvi,*xvir;
   char *homedir;
   char file[4096];
   char s[4096],s1[1024],s2[1024];
   FILE *f;
   int override=0;
   int dither=0;
   int remap=1;
   int num;
   int i,max,maxn;
   int clas;
   
   id=(ImlibData *)malloc(sizeof(ImlibData));
   if (!id)
     {
	fprintf(stderr,"ImLib ERROR: Cannot alloc RAM for Initial data struct\n");
	return NULL;
     }
   id->x.disp=disp;
   id->x.screen=DefaultScreen(disp); /* the screen number */
   id->x.root=DefaultRootWindow(disp); /* the root window id */
   id->x.visual=DefaultVisual(disp,id->x.screen); /* the visual type */
   id->x.depth=DefaultDepth(disp,id->x.screen); /* the depth of the screen in bpp */
   if (XShmQueryExtension(id->x.disp)) 
     {
	id->x.shm=1;
	id->x.shm_event=XShmGetEventBase(id->x.disp)+ShmCompletion;
	id->x.last_xim=NULL;
	id->x.last_sxim=NULL;
	id->max_shm=0x7fffffff;
     }
   else id->x.shm=0;
   id->cache.on_image=0;
   id->cache.size_image=0;
   id->cache.num_image=0;
   id->cache.used_image=0;
   id->cache.image=NULL;
   id->cache.on_pixmap=0;
   id->cache.size_pixmap=0;
   id->cache.num_pixmap=0;
   id->cache.used_pixmap=0;
   id->cache.pixmap=NULL;
   id->byte_order=0;
   xvi.visual=id->x.visual;
   xvi.visualid=XVisualIDFromVisual(id->x.visual);
   xvi.screen=id->x.screen;
   xvir=XGetVisualInfo(disp,VisualScreenMask,&xvi,&num);
   if (xvir) 
     {
	max=0;
	maxn=0;
	clas=-1;
	for (i=0;i<num;i++)
	  {
	     if (xvir[i].depth>=max)
	       {
		  if (xvir[i].depth<8)
		    {
		       if ((xvir[i].class>=clas)&&(xvir[i].class!=DirectColor)&&(xvir[i].class!=TrueColor)&&(xvir[i].class!=PseudoColor))
			 {
			    clas=xvir[i].class;
			    maxn=i;
			    max=xvir[i].depth;
			 }
		    }
		  else if (xvir[i].depth==8)
		    {
		       if ((xvir[i].class>=clas)&&(xvir[i].class!=DirectColor)&&(xvir[i].class!=TrueColor))
			 {
			    clas=xvir[i].class;
			    maxn=i;
			    max=xvir[i].depth;
			 }
		    }
		  else
		    {
		       if ((xvir[i].class>=clas)&&(xvir[i].class!=DirectColor))
			 {
			    clas=xvir[i].class;
			    maxn=i;
			    max=xvir[i].depth;
			 }
		    }
	       }
	  }
	id->x.depth=xvir[maxn].depth;
	id->x.visual=xvir[maxn].visual;
	  {
	     unsigned long rmsk,gmsk,bmsk;
	     
	     rmsk=xvir[maxn].red_mask;
	     gmsk=xvir[maxn].green_mask;
	     bmsk=xvir[maxn].blue_mask;
	     
	     if ((rmsk>gmsk)&&(gmsk>bmsk))      id->byte_order=BYTE_ORD_24_RGB;
	     else if ((rmsk>bmsk)&&(bmsk>gmsk)) id->byte_order=BYTE_ORD_24_RBG;
	     else if ((bmsk>rmsk)&&(rmsk>gmsk)) id->byte_order=BYTE_ORD_24_BRG;
	     else if ((bmsk>gmsk)&&(gmsk>rmsk)) id->byte_order=BYTE_ORD_24_BGR;
	     else if ((gmsk>rmsk)&&(rmsk>bmsk)) id->byte_order=BYTE_ORD_24_GRB;
	     else if ((gmsk>bmsk)&&(bmsk>rmsk)) id->byte_order=BYTE_ORD_24_GBR;
	     else id->byte_order=0;
	  }
#ifdef DEBUG
	printf("<debug: THIS IS NOT A BUG>\n IMLIB: Chose the %i Bit depth Visual, ID 0x%x, to work with\n",id->x.depth,XVisualIDFromVisual(id->x.visual));
#endif
	XFree(xvir);
     }
   if (id->x.depth==16)
     {
	xvi.visual=id->x.visual;
	xvi.visualid=XVisualIDFromVisual(id->x.visual);
	xvir=XGetVisualInfo(disp,VisualIDMask,&xvi,&num);
	if (xvir) 
	  {
	     if (xvir->red_mask!=0xf800) id->x.depth=15;
	     XFree(xvir);
	  }
     }
   if (XGetWindowAttributes(disp,id->x.root,&xwa))
     {
	if (xwa.colormap) id->x.root_cmap=xwa.colormap;
	else id->x.root_cmap=0;
     }
   else id->x.root_cmap=0;
   id->num_colors=0;
   homedir=getenv("HOME");
   sprintf(file,"%s/.imrc",homedir);
   f=fopen(file,"r");
   if (!f) f=fopen(SYSTEM_IMRC,"r");
   if (f)
     {
	while (fgets(s,4096,f))
	  {
	     if (s[0]=='#') continue;
	     sscanf(s,"%s %s\n",s1,s2);
	     if (!strcasecmp("PaletteFile",s1))
	       {
		  ImlibLoadColors(id,s2);
	       }
	     if (!strcasecmp("PaletteOverride",s1))
	       {
		  if (!strcasecmp("yes",s2)) override=1;
		  else override=0;
	       }
	     if (!strcasecmp("Dither",s1))
	       {
		  if (!strcasecmp("yes",s2)) dither=1;
		  else dither=0;
	       }
	     if (!strcasecmp("Remap",s1))
	       {
		  if (!strcasecmp("fast",s2)) 
		    remap=1;
		  else 
		    remap=0;
	       }
	     if (!strcasecmp("Mit-Shm",s1))
	       {
		  if (!strcasecmp("off",s2)) id->x.shm=0;
	       }
	     if (!strcasecmp("Shm_Max_Size",s1))
	       {
		  sscanf(s,"%s %i",s1,&num);
		  id->max_shm=num;
	       }
	     if (!strcasecmp("Image_Cache_Size",s1))
	       {
		  sscanf(s,"%s %i",s1,&num);
		  id->cache.size_image=num;
		  
	       }
	     if (!strcasecmp("Pixmap_Cache_Size",s1))
	       {
		  sscanf(s,"%s %i",s1,&num);
		  id->cache.size_pixmap=num;
	       }
	     if (!strcasecmp("Image_Cache",s1))
	       {
		  if (!strcasecmp("on",s2)) id->cache.on_image=1;
	       }
	     if (!strcasecmp("Pixmap_Cache",s1))
	       {
		  if (!strcasecmp("on",s2)) id->cache.on_pixmap=1;
	       }
	  }
	fclose(f);
     }
   if ((id->x.depth<=8)||(override==1)) 
     {
	if (dither==1)
	  {
	     if (remap==1) id->render_type=RT_DITHER_PALETTE_FAST;
	     else id->render_type=RT_DITHER_PALETTE;
	  }
	else
	  {
	     if (remap==1) id->render_type=RT_PLAIN_PALETTE_FAST;
	     else id->render_type=RT_PLAIN_PALETTE;
	  }
	if (id->num_colors==0)
	  {
	     fprintf(stderr,"IMLIB: Cannot Find Palette. A Palette is required for this mode\n");
	     free(id);
	     return NULL;
	  }
     }
   else 
     {
	id->render_type=RT_PLAIN_TRUECOL;
     }
   return id;
}

Pixmap ImlibCopyImageToPixmap(ImlibData *id, Image *im)
{
   Pixmap p;
   GC tgc;
   XGCValues gcv;
   
   if (!im || !im->pixmap) return ((Pixmap) NULL);
   p=XCreatePixmap(id->x.disp,id->x.root,im->width,im->height,id->x.depth);
   tgc=XCreateGC(id->x.disp,im->pixmap,(unsigned long)0,&gcv);
   XCopyArea(id->x.disp,im->pixmap,p,tgc,0,0,im->width,im->height,0,0);
   XFreeGC(id->x.disp,tgc);
   return p;
}

Pixmap ImlibMoveImageToPixmap(ImlibData *id, Image *im)
{
   Pixmap p;

   if (!im) return ((Pixmap) NULL);
   p=im->pixmap;
   im->pixmap=0;
   return p;
}

Pixmap ImlibCopyMaskToPixmap(ImlibData *id, Image *im)
{
   Pixmap p;
   GC tgc;
   XGCValues gcv;
   
   if (!im || !im->shape_mask) return ((Pixmap) NULL);
   p=XCreatePixmap(id->x.disp,id->x.root,im->width,im->height,1);
   tgc=XCreateGC(id->x.disp,im->shape_mask,(unsigned long)0,&gcv);
   XCopyArea(id->x.disp,im->shape_mask,p,tgc,0,0,im->width,im->height,0,0);
   XFreeGC(id->x.disp,tgc);
   return p;
}

Pixmap ImlibMoveMaskToPixmap(ImlibData *id, Image *im)
{
   Pixmap p;
   
   if (!im) return ((Pixmap) NULL);
   p=im->shape_mask;
   im->shape_mask=0;
   return p;
}

void ImlibDestroyImage(ImlibData *id, Image *im)
{
   if (im)
     {
	if (id->cache.on_image)
	  {
	     free_image(id,im);
	     clean_caches(id);
	  }
	else
	  nullify_image(id,im);
     }
}

void ImlibKillImage(ImlibData *id, Image *im)
{
   if (im)
     {
	if (id->cache.on_image)
	  {
	     free_image(id,im);
	     flush_image(id,im);
	     clean_caches(id);
	  }
	else
	  nullify_image(id,im);
     }
}

void ImlibDestroyPixmaps(ImlibData *id, Image *im, int w, int h)
{
   if (im)
     {
	free_pixmap(id,im,w,h);
	clean_caches(id);
     }
}

void ImlibFreePixmap(ImlibData *id, Pixmap pmap)
{
   if (pmap)
     {
	free_pixmappmap(id,pmap);
	clean_caches(id);
     }
}

void ImlibSetImageBorder(ImlibData *id, Image *im, int l, int r, int t, int b)
{
   if (im)
     {
	if (l<0) l=0;
	if (r<0) r=0;
	if (t<0) t=0;
	if (b<0) b=0;
	im->border.left=l;
	im->border.right=r;
	im->border.top=t;
	im->border.bottom=b;
     }
}

void ImlibGetImageBorder(ImlibData *id, Image *im, int *l, int *r, int *t, int *b)
{
   if (im)
     {
	if (l) *l=im->border.left;
	if (r) *r=im->border.right;
	if (t) *t=im->border.top;
	if (b) *b=im->border.bottom;
     }
}

void ImlibGetImageTransparentColor(ImlibData *id, Image *im, ImColor *icl)
{
   if ((!im)||(!icl)) return;
   
   icl->r=im->shape_color.r;
   icl->g=im->shape_color.g;
   icl->b=im->shape_color.b;
}

void ImlibSetImageTransparentColor(ImlibData *id, Image *im, ImColor *icl)
{
   if ((!im)||(!icl)) return;
   
   im->shape_color.r=icl->r;
   im->shape_color.g=icl->g;
   im->shape_color.b=icl->b;
}

int ImlibGetImageCacheSize(ImlibData *id)
{
   if (!id) return 0;
   return id->cache.size_image;
}

void ImlibSetImageCacheSize(ImlibData *id, int size)
{
   if (!id) return;
   id->cache.size_image=size;
}

int ImlibGetImageCacheStatus(ImlibData *id)
{
   if (!id) return 0;
   return (int)id->cache.on_image;
}

void ImlibSetImageCacheStatus(ImlibData *id, int onoff)
{
   if (!id) return;
   id->cache.on_image=(char)onoff;
}

int ImlibGetPixmapCacheSize(ImlibData *id)
{
   if (!id) return 0;
   return id->cache.size_pixmap;
}

void ImlibSetPixmapCacheSize(ImlibData *id, int size)
{
   if (!id) return;
   id->cache.size_pixmap=size;
}

int ImlibGetPixmapCacheStatus(ImlibData *id)
{
   if (!id) return 0;
   return (int)id->cache.on_pixmap;
}

void ImlibSetPixmapCacheStatus(ImlibData *id, int onoff)
{
   if (!id) return;
   id->cache.on_pixmap=(char)onoff;
}

