#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <X11/Xlib.h>
#include "../imlib.h"
Display *disp;
Window Root; 
Window win;
Visual *vis; 
int scr; 
GC fg,bg;
int blk,wht;
int width,height;

void OpenWindow()
{
   XGCValues gcvals;
   int i;
   int dummy;
   
   disp=XOpenDisplay(NULL);
   if (disp)
     {
	Root=DefaultRootWindow(disp);
	scr=DefaultScreen(disp);
	blk=BlackPixel(disp,scr);
	wht=WhitePixel(disp,scr);
	vis=DefaultVisual(disp,scr);
	win=XCreateSimpleWindow(disp,Root,0,0,width+2,height+2,0,blk,blk);
	XMapWindow(disp,win);
	XSync(disp,False);
	fg=XCreateGC(disp,win,(unsigned long)0,&gcvals);
	bg=XCreateGC(disp,win,(unsigned long)0,&gcvals);
	XSetForeground(disp,fg,wht);
	XSetBackground(disp,bg,blk);
     }
   else
     {
	printf("Cannot open display\n");
	exit(1);
     }
}

main(int argc, char **argv)
{  
   int i,j,k;
   ImlibData *id;
   Image *im;
   ImColor icl;
   Pixmap pmap;
   int sec1,usec1,sec2,usec2;
   struct timeval timev;
   int c;
   double tim;
   
   printf(".\n");
   width=600;
   height=200;
   pmap=0;
   OpenWindow();
   id=ImlibInit(disp);
   printf("..\n");
   
   icl.r=-1,icl.g=-1;icl.b=-1;
   im=ImlibLoadImage(id,argv[1],&icl);
/*   ImlibSetImageBorder(id,im,15,15,15,15);*/
   printf("...\n");
   i=200,j=200;
   gettimeofday(&timev,NULL); 
   sec1=(int)timev.tv_sec; 
   usec1=(int)timev.tv_usec;
   c=0;
   while(1)
     {
	ImlibRender(id,im,i+((c%20)*5),j);
	pmap=ImlibMoveImageToPixmap(id,im);
	XSetWindowBackgroundPixmap(disp,win,pmap);
	XClearWindow(disp,win);
	XSync(disp,False);
	ImlibFreePixmap(id,pmap);
/*	if (!(c%10))
	  {
	     printf("Reload\n");
	     ImlibDestroyImage(id,im);
	     im=ImlibLoadImage(id,argv[1],&icl);
	  }
 */
	/*
	printf("image  cache: %i / %i : %i\n",id->cache.used_image,id->cache.size_image,id->cache.num_image);
	printf("pixmap cache: %i / %i : %i\n",id->cache.used_pixmap,id->cache.size_pixmap,id->cache.num_pixmap);
	 */
	c++;
	if (c==20)
	  {  
	     gettimeofday(&timev,NULL);
	     sec2=(int)timev.tv_sec;
	     usec2=(int)timev.tv_usec;
	     tim=((double)sec2+((double)usec2/1000000))-
	       ((double)sec1+((double)usec1/1000000));
	     printf("fps:  %3.5f\n",(double)c/tim);
	     c=0;
	     gettimeofday(&timev,NULL);
	     sec1=(int)timev.tv_sec;
	     usec1=(int)timev.tv_usec;
	  }
     }
}
