/* 
 *  Simple program that displays a window and when focused prints the key-
 *  codes of the key that you press. Neat when you want to fix your keybindings
 *  in mosquitorc :)
 * 
 *  lap <thyren@dataphone.se>
 */

#include <stdio.h>
#include <stdlib.h>
#include <X11/Xlib.h>

int main(int argc,char **argv)
{
   Display *disp;
   Window rootwin, win;
   XSetWindowAttributes winattr;
   XEvent e;    
      
   disp = XOpenDisplay(NULL);
   rootwin = XDefaultRootWindow(disp);
   
   winattr.background_pixel = 0;
   win = XCreateWindow(disp, rootwin, 10, 10, 100, 100, 2, CopyFromParent, InputOutput, CopyFromParent, CWBackPixel, &winattr);
   XSelectInput(disp, win, KeyPressMask);
   XMapWindow(disp, win);  
   
   while(e.xkey.keycode != 9) {
      XNextEvent(disp, &e);
      fprintf(stderr, "You pressed keycode: %d\n", e.xkey.keycode);
   }
   XCloseDisplay(disp);
   
   return(0);
}


