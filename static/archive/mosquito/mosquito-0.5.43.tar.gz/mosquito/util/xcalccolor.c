/* 
 *  Simple program that displays a window and when focused prints the key-
 *  codes of the key that you press. Neat when you want to fix your keybindings
 *  in mosquitorc :)
 * 
 *  lap <thyren@dataphone.se>
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <X11/Xlib.h>

int main(int argc,char **argv)
{
   unsigned int red, green, blue;
   double r, g, b;
   int depth, *active;
   int result;
   Display *disp;
   Window rootwin, win;
   XSetWindowAttributes winattr;
   XEvent e;    
      
   disp = XOpenDisplay(NULL);
   rootwin = XDefaultRootWindow(disp);
   
   red = green = blue = 0;
   active = &red;
   
   winattr.background_pixel = 0;
   win = XCreateWindow(disp, rootwin, 10, 10, 100, 100, 2, CopyFromParent, InputOutput, CopyFromParent, CWBackPixel, &winattr);
   XSelectInput(disp, win, KeyPressMask);
   XMapWindow(disp, win);  
   
   depth = XDefaultDepth(disp, XDefaultScreen(disp));
   
   while(e.xkey.keycode != 9) {
      
      XNextEvent(disp, &e);
      
      if(e.xkey.keycode == 27)
	active = &red;
      else if(e.xkey.keycode == 42)      
	active = &green;
      else if(e.xkey.keycode == 56)      
	active = &blue;
      else if(e.xkey.keycode == 98)
	(*active)++;
      else if(e.xkey.keycode == 104)
	(*active)--;
	
      switch(depth) {
       case 8:
	 if(red > 3)
	   red = 3;
	 if(blue > 7)
	   blue = 7;
	 if(green > 7)
	   green = 7;
	 
	 r = ((float)red / 3);
	 g = ((float)green / 7);
	 b = ((float)blue / 7);
	 
	 result = (red << 6) | (green << 3) | (blue);
	 break;
       case 16:
	 if(red > 31)
	   red = 31;
	 if(green > 63)
	   green = 63;
	 if(blue > 31)
	   blue = 31;
	 
	 
	 r = ((float)red / 31);
	 g = ((float)green / 63);
	 b = ((float)blue / 31);
	 
	 
	 result = (red << 11) | (green << 5) | (blue);
	 break;
       case 24:
	 if(*active > 255)
	   *active = 255;
	 
	 
	 r = ((float)red / 255);
	 g = ((float)green / 255);
	 b = ((float)blue / 255);
	 
	 
	 result = (red << 16) | (green << 8) | (blue);
	 break;
       case 32:
	 if(red > 1023)
	   red = 1023;
	 if(green > 2047)
	   green = 2047;
	 if(blue > 2047)
	   blue = 2047;
	 
	 
	 r = ((float)red / 1023);
	 g = ((float)green / 2047);
	 b = ((float)blue / 2047);
	 
	 
	 result = (red << 22) | (green << 11) | (blue);
	 break;
      }
      
      fprintf(stderr, "red %d, green %d, blue %d\n", red, green, blue);   
      XSetWindowBackground(disp, win, result);
      XClearWindow(disp, win);
   }
   
   fprintf(stderr, "red %.3f%%, green %.3f%%, blue %.3f%%\n", r, g, b);
   fprintf(stderr, "Totally: 0x%x\n", result);
   
   XCloseDisplay(disp);
   
   return(0);
}


