/******************************
 * Boring base-converter
 * from bin/hex/oct -> dec
 * by lap.
 ******************************/

#include <stdio.h>
#include <string.h>
#include <math.h>

int main(int argc, char **argv)
{

   if(argc != 2)
     {
	printf("Usage: %s 0x/0b/0o + the sequence of digits\n",argv[0]);
	exit(-1);
     }
   
   if((strncmp("0x",argv[1],2))==0)
     {
	int length,i,result;
	float talf;
	char mittal[255],temp[255];
	
	length=strlen(argv[1]);
	result=0;
	
	for(i=0;i<length-2;i++)
	  temp[i]=argv[1][i+2];
	length-=2;
	
	for(i=0;i<length;i++)
	  mittal[i]=temp[length-i-1];
	
	for(i=length-1;i>=0;i--)
	  {
	     switch(mittal[i]){
	      case 'A':
	      case 'a':
		talf=10*(int)pow(16,i);
		break;
	      case 'B':
	      case 'b':
		talf=11*(int)pow(16,i);
		break;
	      case 'C':
	      case 'c':
		talf=12*(int)pow(16,i);
		break;
	      case 'D':
	      case 'd':
		talf=13*(int)pow(16,i);
		break;
	      case 'E':
	      case 'e':
		talf=14*(int)pow(16,i);
		break;
	      case 'F':
	      case 'f':
		talf=15*(int)pow(16,i);
		break;
	      default:
		if((mittal[i]-48)>9 || (mittal[i]-48)<0)
		  {
		     printf("Hey, base is 16!\n");
		     exit(-1);
		  }
		  talf=(mittal[i]-48)*(int)pow(16,i);
		break;	   
	     }
	     result+=talf;
	  }
	printf("Hex %s -> Dec %d\n",argv[1],(int)result);
     }
   else if((strncmp("0b",argv[1],2))==0)
     {
	int length,i,result;
	float talf;
	char mittal[255],temp[255];
	
	length=strlen(argv[1]);
	result=0;
		
	for(i=0;i<length-2;i++)
	  temp[i]=argv[1][i+2];
	length-=2;
	
	for(i=0;i<length;i++)
	  mittal[i]=temp[length-i-1];
	
	for(i=length-1;i>=0;i--)
	  {
	     if((mittal[i]-48)!=1 && (mittal[i]-48)!=0)
	       {
		  printf("Hey, base is 2!\n");
		  exit(-1);
	       }
	     talf=(mittal[i]-48)*(int)pow(2,i);
	     result+=talf;
	  }
	printf("Bin %s -> Dec %d\n",argv[1],result);
     }
   else if((strncmp("0o",argv[1],2))==0)
     {
	int length,i,result;
	float talf;
	char mittal[255],temp[255];
	
	length=strlen(argv[1]);
	result=0;
		
	for(i=0;i<length-2;i++)
	  temp[i]=argv[1][i+2];
	length-=2;
	
	for(i=0;i<length;i++)
	  mittal[i]=temp[length-i-1];
	
	for(i=length-1;i>=0;i--)
	  {
	     if((mittal[i]-48)<0 || (mittal[i]-48)>7)
	       {
		  printf("Hey, base is 8!\n");
		  exit(-1);
	       }
	     talf=(mittal[i]-48)*(int)pow(8,i);
	     result+=talf;
	  }
	printf("Oct %s -> Dec %d\n",argv[1], result);
     }
   else
     {
	printf("Usage: %s 0x/0b/0o + the sequence of digits\n",argv[0]);
	exit(-1);
     }
   return(0);
}

