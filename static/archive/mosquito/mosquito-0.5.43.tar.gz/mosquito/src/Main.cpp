/*
 Mosquito Window Manager
 Copyright (C) 2001  Erik Thyren
  
 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.
 * 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 * 
 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdio.h>
#include "Configfile.h"
#include "Mwindow.h"
#include "Eventhandler.h"
#include "Signalhandler.h"
#include "Mosquito.h"
#include "Manager.h"
#include "Misc.h"

Manager Mgr;

int main(int argc, char **argv) {
   
   Eventhandler eventhandler;
   Signalhandler signalHandler;
   
   if((Mgr.scr.disp = XOpenDisplay(getenv("DISPLAY"))) == NULL) {
      fprintf(stderr, "Couldn't open display\n");
      exit(-1);
   }
      
   //Our Errorhandlers
   XSetErrorHandler((XErrorHandler)errorHandler);
   XSetIOErrorHandler((XIOErrorHandler)IOerrorHandler);
      
   //Retrieve info about our screen & such things
   Mgr.scr.rootwin = XDefaultRootWindow(Mgr.scr.disp);
   Mgr.scr.screen = XDefaultScreen(Mgr.scr.disp);
   Mgr.scr.gc = XDefaultGC(Mgr.scr.disp, Mgr.scr.screen);
   Mgr.scr.width = XDisplayWidth(Mgr.scr.disp, Mgr.scr.screen);
   Mgr.scr.height = XDisplayHeight(Mgr.scr.disp, Mgr.scr.screen);
   
   XSelectInput(Mgr.scr.disp,Mgr.scr.rootwin,(ButtonPressMask | ButtonReleaseMask | KeyPressMask | KeyReleaseMask | FocusChangeMask | PropertyChangeMask | SubstructureNotifyMask |SubstructureRedirectMask));
   
   uptime();
   
   Mgr.vscreenSetup();
   //Lets setup our stuff
   Mgr.generalSetup();

   Mgr.fontSetup();

   Mgr.colorSetup();

   Mgr.rootPopupMenuSetup();

   Mgr.keyBindingsSetup();

   Mgr.dockSetup();

   Mgr.autoStartSetup();         

   //Thats it, start handling user-generated events 
   eventhandler.getEvent();
   
   return(0);
}


