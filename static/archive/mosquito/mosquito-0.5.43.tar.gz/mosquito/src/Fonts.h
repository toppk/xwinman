/* 
 * A list of definitions of fonts for the fontarray, this should _never_ be
 * changed! Refer to mosquitorc if you wanna change a font.
 */

#ifndef _FONTS_H_
#define _FONTS_H_

#include "Mosquito.h"

#define NUMBEROFFONTS			7

#define TITLEBARFONT			0
#define ROOTPOPUPMENUFONT		1
#define MWINDOWPOPUPMENUFONT		2
#define ICONPOPUPMENUFONT		3
#define WSCHANGEWINDOWFONT		4
#define WSSENDTOWSWINDOWFONT		5
#define DOCKPOPUPMENUFONT		6

#endif
