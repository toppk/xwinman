#include <stdio.h>
#include <X11/Xlib.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "Vscreen.h"
#include "Fonts.h"
#include "Mwindow.h"    
#include "Misc.h"
#include "Mosquito.h"
#include "Eventhandler.h"
#include "Manager.h"

extern Manager Mgr;

Vscreen::Vscreen(void) {
   
   numOfWSs = 0;
   activeWS = 1;  //numero uno is default because I say so :)
}

int Vscreen::getActiveWS(void) {
   
   return(activeWS);
}

void Vscreen::setNumOfWSs(int numOfWSs) {
   
   int i;
   struct wsData *ptr;
   
   ptr = new struct wsData[numOfWSs];
   for(i = 0;i < numOfWSs;i++) {
      ptr[i].x = -1;
      ptr[i].y = -1;
      ptr[i].focus = 0;
   }
     
   if(this->numOfWSs != 0) {
         
      for(i = 0;i < this->numOfWSs;i++) {
	 ptr[i].x = wsData[i].x;
	 ptr[i].y = wsData[i].y;
	 ptr[i].focus = wsData[i].focus;
      }
      
      delete [] wsData;
   }

   this->numOfWSs = numOfWSs;
   wsData = ptr;
}

int Vscreen::getNumOfWSs(void) {
   
   return(numOfWSs);
}

void Vscreen::saveWSData(void) {
   
   int Mwin;
   int x, y;
   int junkInt;
   unsigned int junkMask;
   Window currentFocus, junkWin;
   
   XGetInputFocus(Mgr.scr.disp, &currentFocus, &junkInt);
   XQueryPointer(Mgr.scr.disp, Mgr.scr.rootwin, &junkWin, &junkWin, &x, &y, &junkInt, &junkInt, &junkMask);
   
   if((Mwin = Mgr.winToMwin(currentFocus))) {
      Mgr.getMwindow(Mwin)->removeFocus();
   }
   
   wsData[getActiveWS() - 1].x = x;
   wsData[getActiveWS() - 1].y = y;
   wsData[getActiveWS() - 1].focus = currentFocus;
}

void Vscreen::restoreWSData(void) {
   
   int Mwin;
   XEvent event;
   
   if(wsData[getActiveWS() - 1].x != -1 && wsData[getActiveWS() - 1].y != -1)
     XWarpPointer(Mgr.scr.disp, None, Mgr.scr.rootwin, 0, 0, 0, 0, wsData[getActiveWS() - 1].x, wsData[getActiveWS() - 1].y);
   
   XCheckMaskEvent(Mgr.scr.disp, EnterWindowMask, &event);
   
   if((Mwin = Mgr.winToMwin(wsData[getActiveWS() - 1].focus))) {
      Mgr.getMwindow(Mwin)->setFocus();
   }
   
}

void Vscreen::switchWS(int ws) {
   
   int i;
         
   if(getActiveWS() != ws) {
      
      Mgr.noFocus();
      //saveWSData();
      
      for(i = 1;i <= Mgr.getNumOfMwins();i++) {
	 if(Mgr.getMwindow(i)->getWS() != ws && ((Mgr.getMwindow(i)->getState() & S_STICKY) == 0)) {
	    moveMwindowFromScreen(i);
	 }
      }
      
      for(i = 1;i <= Mgr.getNumOfMwins();i++) {
	 if((Mgr.getMwindow(i)->getState() & S_STICKY)) {
	    Mgr.getMwindow(i)->setWS(ws);
	 } else if(Mgr.getMwindow(i)->getWS() != ws) {
	    continue;
	 } else if((Mgr.getMwindow(i)->getState() & (S_MINIMIZED | S_UNMAPPED)) == 0) {
	    moveMwindowToScreen(i);
	 }
      }
      
      activeWS = ws;
      //restoreWSData();
   }
   
   
   //drawActiveWS();
}

void Vscreen::nextWS(void) {
   
   if(getActiveWS() == getNumOfWSs()) {
      switchWS(1);
   } else {
      switchWS(getActiveWS() + 1);
   }
}

void Vscreen::previousWS(void) {
   
   if(getActiveWS() == 1) {
      switchWS(getNumOfWSs()); 
   } else {
      switchWS(getActiveWS() - 1);
   }
}

void Vscreen::sendToWS(int Mwin) {
   
   int i;
   int junkInt;
   unsigned int junkMask;
   Window childWindow, junkWindow;
   Window parentWindow;
   Window *wsWindow;
   XTextItem textItem;
   XEvent event;
   XGCValues gcValues;
   GC gc;

   
   wsWindow = new Window[getNumOfWSs()];
   
   //wsWindow is 50 pixels wide & 50 pixels high
   parentWindow = XCreateSimpleWindow(Mgr.scr.disp, Mgr.scr.rootwin, (Mgr.scr.width / 2) - ((50 * getNumOfWSs()) / 2), (Mgr.scr.height / 2) - 25, 50 * getNumOfWSs(), 50, 2, Mgr.adaptToDepth(1, 0, 0), Mgr.adaptToDepth(0, 0, 0));
   
   for(i = 0;i < getNumOfWSs();i++) {
      wsWindow[i] = XCreateSimpleWindow(Mgr.scr.disp, parentWindow, i * 50, 0, 50, 50, 1, Mgr.adaptToDepth(0, 0, 0.6), Mgr.adaptToDepth(0, 0, 0));
      XSelectInput(Mgr.scr.disp, wsWindow[i], ButtonPressMask);
      XMapWindow(Mgr.scr.disp, wsWindow[i]);
   }
   XMapWindow(Mgr.scr.disp, parentWindow);
   
   textItem.font = XLoadFont(Mgr.scr.disp, Mgr.getFont(WSSENDTOWSWINDOWFONT));
   textItem.delta = 0;
   textItem.chars = new char[4];
   
   gcValues.function = GXcopy;
   gcValues.foreground = Mgr.adaptToDepth(0, 1, 0);
   gcValues.background = Mgr.adaptToDepth(0, 0, 0);
   gc = XCreateGC(Mgr.scr.disp, wsWindow[0], GCFunction | GCForeground | GCBackground, &gcValues);
   
   for(i = 0;i < getNumOfWSs();i++) {
      snprintf(textItem.chars, 4, "%d", i + 1);
      textItem.nchars = strlen(textItem.chars);
      XDrawText(Mgr.scr.disp, wsWindow[i], gc, 22, 30, &textItem, 1);
   }
   
   XGrabButton(Mgr.scr.disp, Button1, AnyModifier, parentWindow, False, ButtonPressMask, GrabModeAsync, GrabModeAsync, None, None);
   XMaskEvent(Mgr.scr.disp, ButtonPressMask, &event);
   if(event.xbutton.subwindow) {
      XQueryPointer(Mgr.scr.disp, event.xbutton.window, &junkWindow, &childWindow, &junkInt, &junkInt, &junkInt, &junkInt, &junkMask);
      for(i = 0;i < getNumOfWSs();i++) {
	 if(childWindow == wsWindow[i]) {
	    sendToWS(Mwin, i + 1);
	    break;
	 } 
      }
   }
   
   XUngrabButton(Mgr.scr.disp, Button1, AnyModifier, parentWindow);
   XUnmapWindow(Mgr.scr.disp, parentWindow);
   XDestroyWindow(Mgr.scr.disp, parentWindow);
   XFreeGC(Mgr.scr.disp, gc);
   delete [] textItem.chars;
   delete [] wsWindow;
}

// This one simply sends requested Mwindow to the requested WS
void Vscreen::sendToWS(int Mwin, int ws) {

   if(getActiveWS() != ws) {
      moveMwindowFromScreen(Mwin);
      Mgr.getMwindow(Mwin)->setWS(ws);
   }
}

void Vscreen::moveMwindowFromScreen(int Mwin) {
   
   int stateBeforeUnmap;
   
   stateBeforeUnmap = Mgr.getMwindow(Mwin)->getState();
   Mgr.getMwindow(Mwin)->unmap();
   XSync(Mgr.scr.disp, True);
   
   //We have to trick our Mwindow to think that its actually mapped
   if((stateBeforeUnmap & S_UNMAPPED) == False) {
      Mgr.getMwindow(Mwin)->setState(Mgr.getMwindow(Mwin)->getState() & (0xff - S_UNMAPPED)); //watch out, an int8 might be too small... why not invert this?!? :-)
   }
}

void Vscreen::moveMwindowToScreen(int Mwin) {
      
   Mgr.getMwindow(Mwin)->map();
}

void Vscreen::drawActiveWS(void) {
   
   Window wsWindow;
   XTextItem textItem;
   GC gc;
   XGCValues gcValues;
   
   XEvent e;
   Eventhandler eventHandler;
      
   
   //wsWindow is 50 pixels wide & 30 pixels high
   wsWindow = XCreateSimpleWindow(Mgr.scr.disp, Mgr.scr.rootwin, (Mgr.scr.width / 2) - 25, (Mgr.scr.height / 2) - 15, 50, 30, 2, Mgr.adaptToDepth(1, 0, 0), Mgr.adaptToDepth(0, 0, 0));
   XMapWindow(Mgr.scr.disp, wsWindow);
   
   textItem.font = XLoadFont(Mgr.scr.disp, Mgr.getFont(WSCHANGEWINDOWFONT));
   textItem.delta = 0;
   textItem.chars = new char[4];
   
   gcValues.function = GXcopy;
   gcValues.foreground = Mgr.adaptToDepth(0, 1, 0);
   gcValues.background = Mgr.adaptToDepth(0, 0, 0);
   gc = XCreateGC(Mgr.scr.disp, wsWindow, GCFunction | GCForeground | GCBackground, &gcValues);
      
   snprintf(textItem.chars, 4, "%d", getActiveWS());
   textItem.nchars = strlen(textItem.chars);
   
   XDrawText(Mgr.scr.disp, wsWindow, gc, 20, 20, &textItem, 1);
   
   XSync(Mgr.scr.disp, False);
   while(XPending(Mgr.scr.disp)) {
      
      XNextEvent(Mgr.scr.disp, &e);
      if(e.type != EnterNotify)
	eventHandler.handleEvent(e);
   }

   usleep(400000);
   
   XUnmapWindow(Mgr.scr.disp, wsWindow);
   XDestroyWindow(Mgr.scr.disp, wsWindow);
     
   delete [] textItem.chars;
   XFreeGC(Mgr.scr.disp, gc);
}

