#ifndef _EVENTHANDLER_H_
#define _EVENTHANDLER_H_

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <X11/Xproto.h>
#include <X11/Xutil.h> 
#include "Mosquito.h"

class Eventhandler {
   
 private:
   
 public:

   Eventhandler(void);
   ~Eventhandler(void);
   
   void getEvent(void);
   void handleEvent(XEvent e);
   void printEventName(int type);
   
   // Various handlers
   void configureRequestHandler(XConfigureRequestEvent cre);
   void configureNotifyHandler(XConfigureEvent cne);
   
   void mousePressHandler(XButtonEvent be);
   void mouseReleaseHandler(XButtonEvent be);
   
   void keyPressHandler(XKeyEvent ke);
   void keyReleaseHandler(XKeyEvent ke);
   
   void exposeHandler(XExposeEvent ee);
   
   void enterNotifyHandler(XCrossingEvent ce);
   void visibilityNotifyHandler(XVisibilityEvent ve);

   void mapRequestHandler(XMapRequestEvent mre);
   void mapNotifyHandler(XMapEvent me);
   void unmapNotifyHandler(XUnmapEvent ue);
   
   void destroyNotifyHandler(XDestroyWindowEvent de);
   
   void motionNotifyHandler(XMotionEvent me);
   
   void clientMessageHandler(XClientMessageEvent cme);
   
   void propertyNotifyHandler(XPropertyEvent pe);

};

#endif
