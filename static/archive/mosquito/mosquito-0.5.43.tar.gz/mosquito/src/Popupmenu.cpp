#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <X11/Xproto.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include "Mosquito.h"
#include "Manager.h"
#include "Popupmenu.h"
#include "PopupmenuItem.h"

extern Manager Mgr;
static int direction; //remove this sometime

Popupmenu::Popupmenu(void (*paintWindow)(Window window), void (*function)(const char *command), int numOfItems, int menuWidth, int menuHeight, int itemWidth, int itemHeight, Font font) {
   
   int i;
   XSetWindowAttributes windowAttributes;
   
   this->numOfItems = numOfItems;
   this->menuWidth = menuWidth;
   this->menuHeight = menuHeight;
   this->itemWidth = itemWidth;
   this->itemHeight = itemHeight;
   this->function = function;
   this->paintWindow = paintWindow;
   this->font = font;
   
   activeMenuItem = NULL;
   menuItem = new (PopupmenuItem *)[numOfItems];
   for(i = 0;i < numOfItems;i++)
     menuItem[i] = NULL;
   
   windowAttributes.event_mask = EnterWindowMask | ExposureMask;
   window = XCreateWindow(Mgr.scr.disp, Mgr.scr.rootwin, 0, 0, menuWidth, menuHeight, 0, CopyFromParent, InputOutput, CopyFromParent, CWEventMask, &windowAttributes);
}

Popupmenu::~Popupmenu(void) {
   
   int i;
   
   for(i = 0;i < numOfItems;i++) {
      delete menuItem[i];
   }
   XUnloadFont(Mgr.scr.disp, font);
   XDestroyWindow(Mgr.scr.disp, window);
}

Window Popupmenu::getParentWindow(void) {

   return(window);
}

void Popupmenu::createItem(const char *label, const char *command, Popupmenu *subMenu) {
   
   int i;
   XSetWindowAttributes windowAttributes;
   Window window;
   
   for(i = 0;menuItem[i] != NULL;i++);
   
   windowAttributes.event_mask = ButtonPressMask | EnterWindowMask;
   window = XCreateWindow(Mgr.scr.disp, getParentWindow(), (menuWidth - itemWidth) / 2,  i * itemHeight + ((menuHeight - itemHeight * numOfItems) / 2), itemWidth, itemHeight, 0, CopyFromParent, InputOutput, CopyFromParent, CWEventMask, &windowAttributes);
   
   if(command)
     menuItem[i] = new PopupmenuItem(window, font, subMenu, strdup(label), strdup(command));
   else
     menuItem[i] = new PopupmenuItem(window, font, subMenu, strdup(label), NULL);
}

void Popupmenu::createItem(const char *label, Popupmenu *subMenu) {
   
   createItem(label, NULL, subMenu);
}

void Popupmenu::createItem(const char *label, const char *command) {
   
   createItem(label, command, NULL);
}

PopupmenuItem *Popupmenu::windowToMenuItem(Window win) {
   
   int i;
   PopupmenuItem *item;
   
   for(i = 0;i < numOfItems;i++) {
      if(menuItem[i]->getWindow() == win) {
	 return(menuItem[i]);
      } else if(menuItem[i]->getSubMenu()) {
	 if((item = ((Popupmenu *)menuItem[i]->getSubMenu())->windowToMenuItem(win))) {
	    return(item);
	 }
      }
   }
   
   return(NULL);
}

Popupmenu *Popupmenu::windowToMenu(Window win) {
   
   int i;
   Popupmenu *menu;
   
   if(win == window) {
      return(this);
   }
   
   for(i = 0;i < numOfItems;i++) {
      if(menuItem[i]->getSubMenu()) {
	 if((menu = ((Popupmenu *)menuItem[i]->getSubMenu())->windowToMenu(win))) {
	    return(menu);
	 }
      }
   }
    
   return(NULL);
}

void Popupmenu::pop(int x, int y) {
   
   XEvent event;
   KeySym keySym;
   Bool done;
   Popupmenu *menu;
   PopupmenuItem *item;
   
   
   done = False;
   menu = this;
   
   if(x > Mgr.scr.width / 2)
     direction = LEFT;
   else 
     direction = RIGHT;
   
   convertToAllowedCoordinates(&x, &y);
   show(x, y);
   
      
   XGrabKeyboard(Mgr.scr.disp, Mgr.scr.rootwin, False, GrabModeAsync, GrabModeAsync, CurrentTime);
   XGrabButton(Mgr.scr.disp, Button2, AnyModifier, Mgr.scr.rootwin, True, NoEventMask, GrabModeAsync, GrabModeAsync, None, None);
   
   while(!done) {
      
      XMaskEvent(Mgr.scr.disp, ExposureMask | KeyPressMask | ButtonPressMask | EnterWindowMask, &event);
      
      switch(event.type) {
       case KeyPress:
	 keySym = XKeycodeToKeysym(Mgr.scr.disp, event.xkey.keycode, 0);
	 
	 switch(keySym) {
	  case XK_Up:
	    menu->previousMenuItem();
	    break;
	  case XK_Down:
	    menu->nextMenuItem();
	    break;
	  case XK_Right:
	    if(menu->getActiveMenuItem()) {
	       if(direction == RIGHT) {
		  if(menu->getActiveMenuItem()->getSubMenu()) {
		     menu = (Popupmenu *)menu->getActiveMenuItem()->getSubMenu();
		  }
	       } else {
		  if(getParentMenu(menu)) {
		     menu = getParentMenu(menu);
		  }
	       }
	       XWarpPointer(Mgr.scr.disp, Mgr.scr.rootwin, menu->getParentWindow(), 0, 0, Mgr.scr.width, Mgr.scr.height, 0, 0);
	    }
	    break;
	  case XK_Left:
	    if(menu->getActiveMenuItem()) {
	       if(direction == LEFT) {
		  if(menu->getActiveMenuItem()->getSubMenu()) {
		     menu = (Popupmenu *)menu->getActiveMenuItem()->getSubMenu();
		  }
	       } else {
		  if(getParentMenu(menu)) {
		     menu = getParentMenu(menu);
		  }
	       }
	       XWarpPointer(Mgr.scr.disp, Mgr.scr.rootwin, menu->getParentWindow(), 0, 0, Mgr.scr.width, Mgr.scr.height, 0, 0);
	    }
	    break;
	  case XK_Escape:
	    done = !done;
	    break;
	  case XK_Return:
	    if(menu->getActiveMenuItem()) {
	       if(menu->getActiveMenuItem()->getCommand()) {
		  (*function)(menu->getActiveMenuItem()->getCommand());
		  done = !done;
	       }
	    }
	    break;
	  default:
	    break;
	 }
	 break;
       
       case ButtonPress:
	 if(menu->getActiveMenuItem() && (windowToMenuItem(event.xbutton.window) == menu->getActiveMenuItem()) && menu->getActiveMenuItem()->getCommand() && event.xbutton.button == Button1) {
	    
	    (*function)(menu->getActiveMenuItem()->getCommand());
	 }
	 done = !done;
	 break;
	 
       case Expose:
	 if(windowToMenu(event.xexpose.window)) {
	    windowToMenu(event.xexpose.window)->repaint();
	 } else if(Mgr.winToMwin(event.xexpose.window)) {
	    Mgr.getMwindow(Mgr.winToMwin(event.xexpose.window))->repaint();
	 }
	 break;
       case EnterNotify:
	 if((item = windowToMenuItem(event.xcrossing.window))) {
	    menu->activateMenuItem(item);
	 } else if(windowToMenu(event.xcrossing.window)) {
	    menu = windowToMenu(event.xcrossing.window);
	 }
	 break;
      }
   }
   
   XUngrabKeyboard(Mgr.scr.disp, CurrentTime);
   XUngrabButton(Mgr.scr.disp, Button2, AnyModifier, Mgr.scr.rootwin);
   
   unpop();
}
      
void Popupmenu::pop(void) {
   
   int x, y;
   int junkInt;
   unsigned int ujunkInt;
   Window junkWin;
      
   XQueryPointer(Mgr.scr.disp, Mgr.scr.rootwin, &junkWin, &junkWin, &x, &y, &junkInt, &junkInt, &ujunkInt);

   pop(x, y);
}

void Popupmenu::unpop(void) {
   
   deactivateMenuItem();
   hide();
}

void Popupmenu::nextMenuItem(void) {
   
   int i;
   int item;
   
   if(activeMenuItem) {
      for(i = 0;menuItem[i] != activeMenuItem;i++);
      if(i == numOfItems - 1)
	item = 0;
      else
	item = i + 1;
   } else {
      item = 0;
   }
   
   activateMenuItem(menuItem[item]);
}

void Popupmenu::previousMenuItem(void) {
   
   int i;
   int item;
   
   if(activeMenuItem) {
      for(i = 0;menuItem[i] != activeMenuItem;i++);
      if(i == 0)
	item = numOfItems - 1;
      else
	item = i - 1;
   } else {
      item = numOfItems - 1;
   }
   
   activateMenuItem(menuItem[item]);
}

Popupmenu *Popupmenu::getParentMenu(Popupmenu *menu) {
   
   int i;
   Popupmenu *parentMenu;
   
   for(i = 0;i < numOfItems;i++) {
      if(menuItem[i]->getSubMenu()) {
	 if(menuItem[i]->getSubMenu() == menu) {
	    return(this);
	 } else if ((parentMenu = ((Popupmenu *)menuItem[i]->getSubMenu())->getParentMenu(menu))) {
	    return(parentMenu);
	 }
      }
   }
   
   return(NULL);
}

void Popupmenu::calculateCoordinates(int *x, int *y) {
   
   Window junkWindow;
   
   if(activeMenuItem) {
      XTranslateCoordinates(Mgr.scr.disp, activeMenuItem->getWindow(), Mgr.scr.rootwin, 0, 0, x, y, &junkWindow);
      if(direction == LEFT)
	*x -= menuWidth + ((menuWidth - itemWidth) / 2);
      else
	*x += itemWidth + ((menuWidth - itemWidth) / 2);
   }
}

void Popupmenu::convertToAllowedCoordinates(int *x, int *y) {
   
   if(*x > (Mgr.scr.width - menuWidth)) {
      *x = Mgr.scr.width - menuWidth;
   } else if(*x < 0) {
      *x = 0;
   }
   
   if(*y > (Mgr.scr.height - menuHeight)) {
      *y = Mgr.scr.height - menuHeight;
   } else if(*y < 0) {
      *y = 0;
   }
     
}

void Popupmenu::activateMenuItem(PopupmenuItem *item) {
   
   int x, y;
   
   deactivateMenuItem();
   
   activeMenuItem = item;
   activeMenuItem->turnOn();
   
   if(activeMenuItem->getSubMenu()) {
      calculateCoordinates(&x, &y);
      ((Popupmenu *)activeMenuItem->getSubMenu())->convertToAllowedCoordinates(&x, &y);
      ((Popupmenu *)activeMenuItem->getSubMenu())->show(x, y);
   }
}

void Popupmenu::deactivateMenuItem(void) {
   
   if(activeMenuItem) {
      activeMenuItem->turnOff();
   
      if(activeMenuItem->getSubMenu()) {
	 ((Popupmenu *)activeMenuItem->getSubMenu())->unpop();
      }
   }
   activeMenuItem = NULL;
}

void Popupmenu::show(int x, int y) {
   
   XMoveWindow(Mgr.scr.disp, getParentWindow(), x, y);
   XRaiseWindow(Mgr.scr.disp, getParentWindow());
   XMapWindow(Mgr.scr.disp, getParentWindow());
   repaint();
}

void Popupmenu::hide(void) {
   
   XUnmapWindow(Mgr.scr.disp, getParentWindow());
}

void Popupmenu::repaint(void) {
   
   int i;
   
   (*paintWindow)(getParentWindow());
   for(i = 0;i < numOfItems;i++) {
      if(activeMenuItem == menuItem[i])
	menuItem[i]->turnOn();
      else
	menuItem[i]->turnOff();
   }
   
   XSync(Mgr.scr.disp, False);
}

PopupmenuItem *Popupmenu::getActiveMenuItem(void) {
   
   return(activeMenuItem);
}
