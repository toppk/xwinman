#ifndef _DOCKPOPUPMENU_H_
#define _DOCKPOPUPMENU_H_

#include "Popupmenu.h"

class Dockpopupmenu {
 private:
   Popupmenu *menu[2];
   
 public:
   Dockpopupmenu(void);
   ~Dockpopupmenu(void);
   
   void pop(void);
};

#endif

