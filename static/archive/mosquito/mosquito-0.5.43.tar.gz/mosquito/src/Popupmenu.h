#ifndef _POPUPMENU_H_
#define _POPUPMENU_H_

#include <X11/Xlib.h>
#include "PopupmenuItem.h"

class Popupmenu {
 private:
   int numOfItems;
   int menuWidth, menuHeight;
   int itemWidth, itemHeight;
   Window window;
   Font font;
   PopupmenuItem **menuItem;
   PopupmenuItem *activeMenuItem;
   void (*function)(const char *command);
   void (*paintWindow)(Window window);
   
   
   void unpop(void);
   void unpopSubMenus(void);
   
   void show(int x, int y);
   void hide(void);
   void repaint(void);
   
   void nextMenuItem(void);
   void previousMenuItem(void);
   
   Popupmenu *getParentMenu(Popupmenu *menu);
   
   PopupmenuItem *windowToMenuItem(Window win);
   Popupmenu *windowToMenu(Window win);
   
   PopupmenuItem *getActiveMenuItem(void);
   Window getParentWindow(void);
   
   void calculateCoordinates(int *x, int *y);
   void convertToAllowedCoordinates(int *x, int *y);
   
   void activateMenuItem(PopupmenuItem *item);
   void deactivateMenuItem(void);
      
 public:
   Popupmenu(void (*paintWindow)(Window window), void (*function)(const char *command), int numOfItems, int menuWidth, int menuHeight, int itemWidth, int itemHeight, Font font);
   ~Popupmenu(void);
   
   void createItem(const char *label, const char *command, Popupmenu *subMenu);
   void createItem(const char *label, const char *command);
   void createItem(const char *label, Popupmenu *subMenu);

   void pop(void);
   void pop(int x, int y);
   
};

#endif
