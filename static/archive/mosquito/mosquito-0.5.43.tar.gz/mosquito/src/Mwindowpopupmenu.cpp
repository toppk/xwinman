/*  
 *  I've decided that this menu should be unconfigurable, dont know why.
 *  Mwindowpopupmenu is very influenced by Blackbox's popupmenu
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <X11/Xproto.h>
#include <X11/Xutil.h>
#include "Mwindowpopupmenu.h"
#include "Fonts.h"
#include "Colors.h"
#include "Mosquito.h"
#include "Manager.h"
#include "Misc.h"
#include "Configfile.h"

extern Manager Mgr;
static int Mwindow;  //fix this shit

static void windowOperation(const char *function) {
   
   if(!strcmp("SendToWS", function)) {
      Mgr.getVscreen()->sendToWS(Mwindow);
   } else if(!strcmp("Sticky", function)) {
      Mgr.getMwindow(Mwindow)->setSticky(True);
   } else if(!strcmp("Shade", function)) {
      Mgr.getMwindow(Mwindow)->shade(True);
   } else if(!strcmp("Minimize", function)) {
      Mgr.getMwindow(Mwindow)->minimize(True);
   } else if(!strcmp("Maximize", function)) {
      Mgr.getMwindow(Mwindow)->maximize(True);
   } else if(!strcmp("AlwaysOnTop", function)) {
      Mgr.getMwindow(Mwindow)->setAlwaysOnTop(True);
   } else if(!strcmp("Dock", function)) {
      Mgr.getMwindow(Mwindow)->addToDock();
   } else if(!strcmp("Raise", function)) {
      Mgr.getMwindow(Mwindow)->raise();
   } else if(!strcmp("Close", function)) {
      Mgr.getMwindow(Mwindow)->kill();
   }
}

Mwindowpopupmenu::Mwindowpopupmenu(int Mwin) {
   
   int numOfMenus, numOfItems;
   int itemWidth, itemHeight, menuBorderWidth, menuBorderHeight;
   
   Mwindow = Mwin;
   
   itemWidth = 100;
   itemHeight = 20;
   menuBorderWidth = 50;
   menuBorderHeight = 50;
   
   numOfMenus = 1;
   numOfItems = 9;
   
   menu = new Popupmenu(trekkify, windowOperation, numOfItems, itemWidth + menuBorderWidth, numOfItems * itemHeight + menuBorderHeight, itemWidth, itemHeight, XLoadFont(Mgr.scr.disp, Mgr.getFont(MWINDOWPOPUPMENUFONT)));
   
   menu->createItem("Send to WS", "SendToWS");
   menu->createItem("(Un)Sticky", "Sticky");
   menu->createItem("(Un)Shade", "Shade");
   menu->createItem("(Un)Minimize", "Minimize");
   menu->createItem("(Un)Maximize", "Maximize");
   menu->createItem("(Un)A-O-T", "AlwaysOnTop");
   menu->createItem("Raise/Lower", "Raise");
   menu->createItem("Dock", "Dock");
   menu->createItem("Close", "Close");
}

Mwindowpopupmenu::~Mwindowpopupmenu(void) {
   
   delete menu;
}

void Mwindowpopupmenu::pop(void) {
   
   menu->pop();
}

void Mwindowpopupmenu::pop(int x, int y) {
   
   menu->pop(x, y);
}

