#ifndef _MWINDOWPOPUPMENU_H_
#define _MWINDOWPOPUPMENU_H_

#include "Popupmenu.h"

class Mwindowpopupmenu {
 private:
   Popupmenu *menu;
   
 public:
   Mwindowpopupmenu(int Mwin);
   ~Mwindowpopupmenu();
   
   void pop(void);
   void pop(int x, int y);
};

#endif

