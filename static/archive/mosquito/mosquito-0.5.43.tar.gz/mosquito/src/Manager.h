#ifndef _MANAGER_H_
#define _MANAGER_H_

#include "Mosquito.h"
#include "Rootpopupmenu.h"
#include "Fonts.h"
#include "Colors.h"
#include "Dock.h"
#include "Vscreen.h"

#define MOVEMODEL_OPAQUE                0
#define MOVEMODEL_INTERACTIVE           1

#define FOCUSMODEL_SLOPPY               0
#define FOCUSMODEL_CLICKTOFOCUS         1
#define FOCUSMODEL_FOCUSFOLLOWSMOUSE    2

#define PLACEMENTMODEL_SMART            1
#define PLACEMENTMODEL_APP              2
#define PLACEMENTMODEL_POINTER          3

struct keyBinding {
   int numOfItems;
   int *key;
   int *modifiers;
   int *function;
   char **command;
};

struct Mscreen {
   int screen;
   int width, height;
   Display *disp;
   Window rootwin;
   GC gc;
};

class Manager {
   
 private:
   int numOfMwins;
      
   int colors[NUMBEROFCOLORS];
   int focusModel;                   // 0 = SloppyFocus,  1 = ClickToFocus, 2 = FocusFollowsMouse
   int moveModel;                    // 0 = OpaqueMove,   1 = InterActiveMove
   int placementModel;
   int doubleClickDelay;
   Bool debugMode;
   Bool stickyIcons;
   
   char *fonts[NUMBEROFFONTS];
   
   Mwindow *Mwin[1000];             //This kind of limits us a bit but hey...
   
   Rootpopupmenu *rootPopupMenu;
   
   Dock *dock;
   
   Vscreen *vscreen;
   
 public:
   struct Mscreen scr;
   struct keyBinding keyBinding;
   
   Manager();
   ~Manager();
   
   // Mwindow Section
   
   Mwindow *getMwindow(int Mwindow);
   void createMwindow(int Mwin);
   
   void listMwins(void);
   int getNumOfMwins(void);
   void setNumOfMwins(int num);
   void increaseNumOfMwins(void);
   void decreaseNumOfMwins(void);
      
   int winToMwin(Window w);
   
   void packMwinStack(void);
   void packMwinStack(int startWith);
   
   void circulateMwins(int direction);
   
   // Workspace section
   
   void vscreenSetup(void);
   void vscreenSetdown(void);
   Vscreen *getVscreen(void);
   
   //Setup Section
   
   void generalSetup(void);
   
   void fontSetup(void);
   void fontSetdown(void);
   char *getFont(int name);
   
   void colorSetup(void);
   int getColor(int color);
      
   void dockSetup(void);
   void dockSetdown(void);
   Dock *getDock(void);
   
   void rootPopupMenuSetup(void);
   void rootPopupMenuSetdown(void);
   Rootpopupmenu *getRootPopupMenu(void);   
   
   void keyBindingsSetup(void);
   void keyBindingsSetdown(void);
   void keyParseFunction(int function, const char *command, XKeyEvent *keyEvent);
   
   void autoStartSetup(void);
      
   //Look and feel section
   
   int getDoubleClickDelay(void);
   
   int getStickyIcons(void);
   
   Bool getDebugMode(void);
   void setDebugMode(Bool mode);
   
   int getFocusModel(void);
   void setFocusModel(int model);
   
   int getMoveModel(void);
   void setMoveModel(int model);
   
   int getPlacementModel(void);
   void setPlacementModel(int model);

   
   //System section      
   int adaptToDepth(float r, float g, float b);
   
   void runCommand(const char *command);
   
   void quit(int signal);
   void restart(void);
      
   Atom getAtom(const char *atomName);
   
   //Log section
   
   void printOut(const char *msg, ...);
   void printErr(const char *msg, ...);
      
   //This should probably be in some other place
   void noFocus(void);
   
};

#endif
