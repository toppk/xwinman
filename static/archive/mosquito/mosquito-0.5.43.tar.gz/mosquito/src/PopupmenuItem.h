#ifndef _POPUPMENUITEM_H_
#define _POPUPMENUITEM_H_

#include <X11/Xlib.h>

class PopupmenuItem {
 private:
   char *label;
   char *command;
   void *subMenu;
   
   Font font;
   Window window;
   GC gc;
   
   void drawLabel(int color);
   
 public:
   //PopupmenuItem(Window parentWindow, int position, char *label, char *command);
   PopupmenuItem(Window window, Font font, void *subMenu, char *label, char *command);
   ~PopupmenuItem(void);
   
   const char *getCommand(void);
   Window getWindow(void);
   void *getSubMenu(void);
      
   void turnOn(void);
   void turnOff(void);
   
   
};

#endif
