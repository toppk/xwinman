#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <X11/Xproto.h>
#include <X11/Xutil.h>
#include "Mwindow.h"
#include "Eventhandler.h"
#include "Mosquito.h"
#include "Manager.h"
#include "Misc.h"
#include "Dock.h"
#include "Mwindowpopupmenu.h"
#include "Iconpopupmenu.h"
#include "Dockpopupmenu.h"

extern Manager Mgr;

Eventhandler::Eventhandler(void) {

}

Eventhandler::~Eventhandler(void) {

}

void Eventhandler::getEvent(void) {
   
   XEvent e;
   
   while(1) {
      memset(&e, 0, sizeof(XEvent));
      XNextEvent(Mgr.scr.disp, &e);
      handleEvent(e);
   }         
}

void Eventhandler::printEventName(int type) {
   
   char eventName[80];
   
   
   switch(type) {
    case 2:
      strcpy(eventName, "KeyPress");
      break;
    case 3:
      strcpy(eventName, "KeyRelease");
      break;  
    case 4:
      strcpy(eventName, "ButtonPress");
      break;   
    case 5:
      strcpy(eventName, "ButtonRelease");
      break;   
    case 6:
      strcpy(eventName, "MotionNotify");
      break;   
    case 7:
      strcpy(eventName, "EnterNotify");
      break;   
    case 8:
      strcpy(eventName, "LeaveNotify");
      break;   
    case 9:
      strcpy(eventName, "FocusIN");
      break;   
    case 10:
      strcpy(eventName, "FocusOUT");
      break;   
    case 11:
      strcpy(eventName, "KeyMapNotify");
      break;   
    case 12:
      strcpy(eventName, "Expose");
      break;   
    case 13:
      strcpy(eventName, "GraphicsExpose");
      break;   
    case 14:
      strcpy(eventName, "NoExpose");
      break;   
    case 15:
      strcpy(eventName, "VisibilityNotify");
      break;   
    case 16:
      strcpy(eventName, "CreateNotify");
      break;
    case 17:
      strcpy(eventName, "DestroyNotify");
      break;  
    case 18:
      strcpy(eventName, "UnmapNotify");
      break;  
    case 19:
      strcpy(eventName, "MapNotify");
      break;  
    case 20:
      strcpy(eventName, "MapRequest");
      break;  
    case 21:
      strcpy(eventName, "ReparentNotify");
      break;  
    case 22:
      strcpy(eventName, "ConfigureNotify");
      break;  
    case 23:
      strcpy(eventName, "ConfigureRequest");
      break;  
    case 24:
      strcpy(eventName, "GravityNotify");
      break;  
    case 25:
      strcpy(eventName, "ResizeRequest");
      break;  
    case 26:
      strcpy(eventName, "CirculateNotify");
      break;  
    case 27:
      strcpy(eventName, "CirculateRequest");
      break;  
    case 28:
      strcpy(eventName, "PropertyNotify");
      break;  
    case 29:
      strcpy(eventName, "SelectionClear");
      break;  
    case 30:
      strcpy(eventName, "SelectionRequest");
      break;  
    case 31:
      strcpy(eventName, "SelectionNotify");
      break;  
    case 32:
      strcpy(eventName, "ColormapNotify");
      break;  
    case 33:
      strcpy(eventName, "ClientMessage");
      break; 
    case 34:
      strcpy(eventName, "MappingNotify");
      break;  
    case 35:
      strcpy(eventName, "LASTEvent");
      break;  
   }
      
   Mgr.printErr("Got %s\n", eventName);
}

void Eventhandler::handleEvent(XEvent e) {
   
   printEventName(e.type);
   
   switch(e.type) {
    case ButtonPress:
      mousePressHandler(e.xbutton);
      break;
    case ButtonRelease:
      mouseReleaseHandler(e.xbutton);
      break;
    case KeyPress:
      keyPressHandler(e.xkey);
      break;
    case KeyRelease:
      keyReleaseHandler(e.xkey);
      break;
    case MapRequest:
      mapRequestHandler(e.xmaprequest);
      break;
    case MapNotify:                                 // Shouldnt be necesarry
      mapNotifyHandler(e.xmap);
      break;
    case UnmapNotify:
      unmapNotifyHandler(e.xunmap);
      break;
    case ConfigureRequest:
      configureRequestHandler(e.xconfigurerequest);
      break;
    case ConfigureNotify:                           // shoudltn be necasasyr
      //configureNotifyHandler(e.xconfigure);
      break;                    
    case VisibilityNotify:
      visibilityNotifyHandler(e.xvisibility);
      break;
    case EnterNotify:
      enterNotifyHandler(e.xcrossing);
      break;
    case ClientMessage:
      clientMessageHandler(e.xclient);
      break;
    case Expose:
      exposeHandler(e.xexpose);
      break;
    case DestroyNotify:
      destroyNotifyHandler(e.xdestroywindow);
      break;
    case MotionNotify:
      motionNotifyHandler(e.xmotion);
      break;
    case PropertyNotify:
      propertyNotifyHandler(e.xproperty);
      break;
    default:    
      //Mgr.printErr("Received event: %d, ignoring it\n", e.type);
      break;
   }
}

void Eventhandler::configureRequestHandler(XConfigureRequestEvent cre) {
   
   int Mwin;
   XWindowChanges windowChanges;
   
//   XGrabServer(Mgr.scr.disp);
      
   if((Mwin = Mgr.winToMwin(cre.window))) {
           
      windowChanges.x = cre.x;
      windowChanges.y = cre.y;
      windowChanges.width = cre.width;
      windowChanges.height = cre.height;
      
      
      if(Mgr.getMwindow(Mwin)->getWindow(1)) {
	 windowChanges.width += 6;
	 windowChanges.height += 6;
      }
      if(Mgr.getMwindow(Mwin)->getWindow(6))
	windowChanges.height += 23;
      
      
      if(cre.value_mask & (CWX | CWY)) {
	 Mgr.getMwindow(Mwin)->move(windowChanges.x, windowChanges.y);
      }
      if(cre.value_mask & (CWWidth | CWHeight)) {
	 Mgr.getMwindow(Mwin)->resize(windowChanges.width, windowChanges.height);
      }
   } else {
            
      windowChanges.x = cre.x;
      windowChanges.y = cre.y;
      windowChanges.width = cre.width;
      windowChanges.height = cre.height;
      XConfigureWindow(Mgr.scr.disp, cre.window, cre.value_mask, &windowChanges);
      
   }
   
//   XUngrabServer(Mgr.scr.disp);
  
}

void Eventhandler::configureNotifyHandler(XConfigureEvent ce) {
   
}

void Eventhandler::mousePressHandler(XButtonEvent be) {

   int Mwin;
   Bool doubleClick;
   Iconpopupmenu *iconPopupMenu;
   Mwindowpopupmenu *MwindowPopupMenu;
   Dockpopupmenu *dockPopupMenu;
   
   doubleClick = isDoubleClick(&be);
   
   if(be.button == 1) {

      if(Mgr.getFocusModel() == FOCUSMODEL_CLICKTOFOCUS) {
	 
	 int revertTo;
	 Window currentFocus;
	 	 
	 if(be.window != Mgr.scr.rootwin) {
	    
	    XGetInputFocus(Mgr.scr.disp, &currentFocus, &revertTo);
	    Mwin = Mgr.winToMwin(be.window);

	    if(currentFocus != Mgr.getMwindow(Mwin)->getWindow(9)) {
	       
	       if((Mwin = Mgr.winToMwin(currentFocus))) {
		  Mgr.getMwindow(Mwin)->removeFocus();
	       }
	       
	       if((Mwin = Mgr.winToMwin(be.window))) {
		  Mgr.getMwindow(Mwin)->setFocus();
	       }
	       XUngrabButton(Mgr.scr.disp, 1, AnyModifier, be.window);
	       return;
	    } else {
	       XUngrabButton(Mgr.scr.disp, 1, AnyModifier, be.window);
	    }
	 }
      }
      
      if((Mwin = Mgr.winToMwin(be.window))) {
	 if(Mgr.getMwindow(Mwin)->isTitlebar(be.window)) {
	    Mgr.getMwindow(Mwin)->move();
	 } else if(Mgr.getMwindow(Mwin)->isKill(be.window)) {
	    Mgr.getMwindow(Mwin)->kill();
	 } else if(Mgr.getMwindow(Mwin)->isIcon(be.window)) {
	    Mgr.getMwindow(Mwin)->minimize(False);
	 } else if(Mgr.getMwindow(Mwin)->isResize(be.window)) {
	    Mgr.getMwindow(Mwin)->resize();
	 }
      } else if(be.window == Mgr.scr.rootwin && be.subwindow == 0) {
	
	 iconPopupMenu = new Iconpopupmenu();
	 
	 if(iconPopupMenu->getNumOfIcons()) {
	    iconPopupMenu->pop();
	 }
	 
	 delete iconPopupMenu;
      }
   } else if(be.button == 2) {
      if((Mwin = Mgr.winToMwin(be.window))) {
	 if(Mgr.getMwindow(Mwin)->isTitlebar(be.window)) {
	    if(doubleClick) {
	       Mgr.getMwindow(Mwin)->shade(True);
	    } else {
	       Mgr.getMwindow(Mwin)->raise();
	    } 
	 }
      } else if(be.window == Mgr.scr.rootwin && be.subwindow == 0) {
	 
	 dockPopupMenu = new Dockpopupmenu();
	 dockPopupMenu->pop();
	 delete dockPopupMenu;
      }
   } else if(be.button == 3) {
      if((Mwin = Mgr.winToMwin(be.window))) {
	 if(Mgr.getMwindow(Mwin)->isTitlebar(be.window)) {
	   
	    MwindowPopupMenu = new Mwindowpopupmenu(Mwin);
	    
	    MwindowPopupMenu->pop();
	    
	    delete MwindowPopupMenu;
	 }
      } else if(be.window == Mgr.scr.rootwin && be.subwindow == 0) {
	 Mgr.getRootPopupMenu()->pop();
      }
   }
}

void Eventhandler::mouseReleaseHandler(XButtonEvent be) {
   
}

void Eventhandler::keyPressHandler(XKeyEvent ke) {
   
   int i;
   
   for(i = 0; i < Mgr.keyBinding.numOfItems;i++) {
      if(ke.state == (unsigned int)Mgr.keyBinding.modifiers[i] && ke.keycode == (unsigned int)Mgr.keyBinding.key[i]) {
	 Mgr.keyParseFunction(Mgr.keyBinding.function[i], Mgr.keyBinding.command[i], &ke);
      }
   }
}

void Eventhandler::keyReleaseHandler(XKeyEvent ke) {
}

void Eventhandler::exposeHandler(XExposeEvent ee) {
   
   int Mwin;
   XEvent e;
   
   while(XCheckTypedWindowEvent(Mgr.scr.disp, ee.window, Expose, &e));
   
   if((Mwin = Mgr.winToMwin(ee.window))) {
      if(Mgr.getMwindow(Mwin)->isTitlebar(ee.window)) {
	 Mgr.getMwindow(Mwin)->repaint();
      }
   }
   
}

void Eventhandler::visibilityNotifyHandler(XVisibilityEvent ve) {
   
   //   int i;
   //XConfigureNotifyEvent configureNotify;
   
   if(Mgr.getDock()->isMember(ve.window)) {
      Mgr.getDock()->raise();
   }
   
   /* else if((Mwin = Mgr.winToMwin(ce.above)) && (Mgr.winToMwin(ce.window))) {
      if(Mgr.getMwindow(Mwin)->getState() & S_ALWAYSONTOP && ((Mgr.getMwindow(Mgr.winToMwin(ce.window))->getState() & S_ALWAYSONTOP) == 0)) {
	 Mgr.getMwindow(Mwin)->raise();
      }
   }*/
}

void Eventhandler::enterNotifyHandler(XCrossingEvent ce) {
   
   int Mwin, revertTo;
   Window currentFocus;
   
   XGetInputFocus(Mgr.scr.disp, &currentFocus, &revertTo);
      
   if(Mgr.getFocusModel() == FOCUSMODEL_SLOPPY) {
    
      if((Mwin = Mgr.winToMwin(currentFocus))) {  // Focus out the old window
	 Mgr.getMwindow(Mwin)->removeFocus();
      }
   
      if(ce.subwindow > 0) {     // and focus in the new window
	 Mwin = Mgr.winToMwin(ce.subwindow);
	 //	 Mgr.getMwindow(Mwin)->setFocus();
      } else {
	 Mwin = Mgr.winToMwin(ce.window);
	   //	 Mgr.getMwindow(Mwin)->setFocus();
      }

      if(Mwin)
	Mgr.getMwindow(Mwin)->setFocus();

   } else if(Mgr.getFocusModel() == FOCUSMODEL_CLICKTOFOCUS) {
      
      if(currentFocus != Mgr.getMwindow(Mgr.winToMwin(ce.window))->getWindow(9)) {
	 XGrabButton(Mgr.scr.disp, 1, AnyModifier, ce.window, False, NoEventMask, GrabModeAsync, GrabModeAsync, None, None);
      }
   }

}

void Eventhandler::mapRequestHandler(XMapRequestEvent mre) {
   
   int Mwin;
   XWindowAttributes windowAttributes;

   XGrabServer(Mgr.scr.disp);

   XGetWindowAttributes(Mgr.scr.disp, mre.window, &windowAttributes);
   Mwin = Mgr.winToMwin(mre.window);
   
   if(Mwin == 0) {
      if(windowAttributes.width == DOCK_WIDTH && windowAttributes.height == DOCK_HEIGHT && Mgr.getDock()->isSaved(mre.window)) {
	 Mgr.getDock()->insertDockAppAtSavedPosition(mre.window);
      } else {
	 
	 Mgr.increaseNumOfMwins();
	 Mwin = Mgr.getNumOfMwins();
	 
	 Mgr.createMwindow(Mwin);
	 Mgr.getMwindow(Mwin)->setWindow(9, mre.window);
	 Mgr.getMwindow(Mwin)->decorate();
	 Mgr.getMwindow(Mwin)->setup();
	 Mgr.getMwindow(Mwin)->placeOnScreen();
      }
   }
   
   if(Mwin) {
      Mgr.getMwindow(Mwin)->map();
      Mgr.getMwindow(Mwin)->raise();
   }
   
   XUngrabServer(Mgr.scr.disp);
}

void Eventhandler::mapNotifyHandler(XMapEvent me) {
      
   int Mwin;
   
   if((Mwin = Mgr.winToMwin(me.event))) {
      Mgr.getMwindow(Mwin)->map();
   }/* else {
      XMapWindow(Mgr.scr.disp, me.window);
   }*/
}

void Eventhandler::unmapNotifyHandler(XUnmapEvent ue) {
   
   int Mwin;
     
   if((Mwin = Mgr.winToMwin(ue.event))) {
      Mgr.getMwindow(Mwin)->unmap();
      XSync(Mgr.scr.disp, False);
   } else {
      if((Mwin = Mgr.winToMwin(ue.window))) {
	 if((Mgr.getMwindow(Mwin)->getState() & S_SHAPED)) {
	    Mgr.getMwindow(Mwin)->unmap();
	    //Mgr.printErr("Unmapped %d\n", Mwin);
	    XSync(Mgr.scr.disp, False);
	 }
      }
   }
}

void Eventhandler::destroyNotifyHandler(XDestroyWindowEvent de) {
   
   int Mwin;
      
   XGrabServer(Mgr.scr.disp);
   
   if((Mwin = Mgr.winToMwin(de.window))) {
      
      // procedure is: remove the requested item from stack, pack the stack
      //               and delete the last item from the stack
      
      Mgr.getMwindow(Mwin)->unmap();
      
      Mgr.getMwindow(Mwin)->destroy();  
      
      Mgr.packMwinStack(Mwin);
      
      delete Mgr.getMwindow(Mgr.getNumOfMwins());
      
      Mgr.decreaseNumOfMwins();
   } else {
      Mgr.getDock()->removeDockApp(de.window);
   }
   
   XUngrabServer(Mgr.scr.disp);
}

void Eventhandler::motionNotifyHandler(XMotionEvent me) {
}

void Eventhandler::clientMessageHandler(XClientMessageEvent cme) {      
   
   int Mwin;
   
   if(cme.message_type == Mgr.getAtom("WM_CHANGE_STATE")) {
      if(cme.format == 32 && cme.data.l[0] == IconicState) {
	 if((Mwin = Mgr.winToMwin(cme.window))) {
	    Mgr.getMwindow(Mwin)->minimize(False);
	 }
      }
   }
}

void Eventhandler::propertyNotifyHandler(XPropertyEvent pe) {      
   
   int Mwin;
   
   switch(pe.atom) {
   
    case XA_WM_NAME:
      if((Mwin = Mgr.winToMwin(pe.window))) {
	 Mgr.getMwindow(Mwin)->drawTitlebarText();
      }
      break;
    case XA_WM_NORMAL_HINTS:
      if((Mwin = Mgr.winToMwin(pe.window))) {
	 Mgr.getMwindow(Mwin)->fixSizeHints();
      }
      break;
   }
}
