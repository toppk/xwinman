#ifndef _MISC_H_
#define _MISC_H_

#include "Mosquito.h"

// Used by XCheckIfEvent
Bool checkForRelease(Display *disp, XEvent *e, XPointer arg);
Bool checkForPress(Display *disp, XEvent *e, XPointer arg);

Bool checkForKeyRelease(Display *disp, XEvent *e, XPointer arg);
Bool checkForKeyPress(Display *disp, XEvent *e, XPointer arg);

Bool isDoubleClick(XButtonEvent *be);

//Just had to put it somewhere
void trekkify(Window window);

//this is fun ;)
time_t uptime(void);
void setRecordTime(time_t recordTime);
time_t getRecordTime(void);

//Error handlers
XErrorHandler errorHandler(Display *disp, XErrorEvent *ee); 
XIOErrorHandler IOerrorHandler(Display *disp);

#endif

