#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <X11/Xproto.h>
#include <X11/Xutil.h>
#include "Popupmenu.h"
#include "Fonts.h"
#include "Colors.h"
#include "Iconpopupmenu.h"
#include "Mwindow.h"
#include "Mosquito.h"
#include "Misc.h"
#include "Manager.h"

extern Manager Mgr;

static void deiconify(const char *Mwindow) {
   
   if(atoi(Mwindow)) {
      Mgr.getMwindow(atoi(Mwindow))->setWS(Mgr.getVscreen()->getActiveWS());
      Mgr.getMwindow(atoi(Mwindow))->normalize();
      Mgr.getMwindow(atoi(Mwindow))->raise();
   }
}

Iconpopupmenu::Iconpopupmenu(void) {
   
   int i, j;
   int numOfMenus, numOfItems;
   int itemWidth, itemHeight, menuBorderWidth, menuBorderHeight;
   Bool gotOne;
   char *label;
   char *command;
   
   itemWidth = 100;
   itemHeight = 20;
   menuBorderWidth = 50;
   menuBorderHeight = 50;
   
   numOfMenus = 1;
   numOfItems = getNumOfIcons();
   command = new char[4];

   menu = new Popupmenu(trekkify, deiconify, numOfItems, itemWidth + menuBorderWidth, numOfItems * itemHeight + menuBorderHeight, itemWidth, itemHeight, XLoadFont(Mgr.scr.disp, Mgr.getFont(ICONPOPUPMENUFONT)));
   
   for(i = 0, j = 1;i < numOfItems;i++) {
      
      gotOne = False;
      
      for(;j <= Mgr.getNumOfMwins() && gotOne != True;j++) {
	 
	 if(Mgr.getStickyIcons() == 1 || Mgr.getMwindow(j)->getWS() == Mgr.getVscreen()->getActiveWS()) {
	    if((Mgr.getMwindow(j)->getState() & S_MINIMIZED)) {
	       
	       gotOne = True;
	       label = Mgr.getMwindow(j)->getIconName();
	       snprintf(command, 4, "%d", j);
	       
	       menu->createItem(label, command);
	       
	       delete [] label;
	    }
	 }
      }
   }
   
   delete [] command;
}

Iconpopupmenu::~Iconpopupmenu(void) {
      
   delete menu;
}

int Iconpopupmenu::getNumOfIcons(void) {
   
   int i;
   int numOfIcons;
   
   numOfIcons = 0;
   
   for(i = 1;i <= Mgr.getNumOfMwins();i++) {
      if(((Mgr.getMwindow(i)->getState() & S_MINIMIZED) && (Mgr.getStickyIcons() || Mgr.getMwindow(i)->getWS() == Mgr.getVscreen()->getActiveWS()))) {
	 numOfIcons++;
      }
   }
   
   return(numOfIcons);
}

void Iconpopupmenu::pop(void) {
   
   menu->pop();
}
