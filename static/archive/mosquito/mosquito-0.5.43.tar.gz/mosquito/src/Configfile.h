#ifndef _CONFIGFILE_H_
#define _CONFIGFILE_H_

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <X11/Xproto.h>
#include <X11/Xutil.h>
#include "Mosquito.h"

class Configfile {
 private:
   FILE *cf;
   
 public:
   
   Configfile(void);
   ~Configfile(void);
   
   char *readNextLine(void);
   
   //Popup
   int getPopupTotalNumOfItems(void);
   int getPopupTotalNumOfSubmenus(void);
   
   int getPopupNumOfSubmenuItems(int subMenu);
   
   char *getPopupLabel(int subMenu, int item);
   char *getPopupCommand(int subMenu, int item);
   
   //Fonts
   char *getFontFont(int font);      //arg: POPUPFONT gives the popupfont
   
   //Color
   int getColorColor(int color);
   
   //Keybindings
   int getKeybindingsNumOfItems(void);
   int getKeybindingsKey(int line);
   int getKeybindingsModifiers(int line);
   int getKeybindingsFunction(int line);
   char *getKeybindingsCommand(int line);
   
   //Dock
   char *getDockPixmapPath(void);
   int getDockPosition(void);
   int getDockGrowDirection(void);
   
   int getByCharToInt(const char *section, const char *variableName);
   char *getByCharToChar(const char *section, const char *variableName);
   
   void runAutostart(void);
};

#endif
