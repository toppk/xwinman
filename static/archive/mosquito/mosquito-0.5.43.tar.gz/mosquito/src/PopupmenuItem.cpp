#include <stdio.h>
#include <string.h>
#include "Popupmenu.h"
#include "Manager.h"

extern Manager Mgr;

PopupmenuItem::PopupmenuItem(Window window, Font font, void *subMenu, char *label, char *command) {
   
   XGCValues gcValues;
   
   this->window = window;
   this->font = font;
   this->subMenu = subMenu;
   this->label = label;
   this->command = command;
   
   gcValues.function = GXcopy;
   gc = XCreateGC(Mgr.scr.disp, window, GCFunction, &gcValues);
   
   XMapWindow(Mgr.scr.disp, window);   
}

PopupmenuItem::~PopupmenuItem(void) {
  
   delete [] label;
   delete [] command;
   if(subMenu) {
      delete subMenu;
   }
   XFreeGC(Mgr.scr.disp, gc);
   XDestroyWindow(Mgr.scr.disp, window);
}

Window PopupmenuItem::getWindow(void) {
   
   return(window);
}

const char *PopupmenuItem::getCommand(void) {

   return(command);
}

void *PopupmenuItem::getSubMenu(void) {
   
   return(subMenu);
}

void PopupmenuItem::turnOn(void) {
   
   XSetWindowBackground(Mgr.scr.disp, window, Mgr.adaptToDepth(0.537, 0.082, 0.686));
   XClearWindow(Mgr.scr.disp, window);
   drawLabel(0x000000);
}

void PopupmenuItem::turnOff(void) {
   
   XSetWindowBackground(Mgr.scr.disp, window, 0x000000);
   XClearWindow(Mgr.scr.disp, window);
   drawLabel(Mgr.adaptToDepth(0.537, 0.082, 0.686));
}

void PopupmenuItem::drawLabel(int color) {
   
   XTextItem textItem;
   
   textItem.chars = label;
   textItem.nchars = strlen(label);
   textItem.delta = 5;
   textItem.font = font;
   
   XSetForeground(Mgr.scr.disp, gc, color);
   
   XDrawText(Mgr.scr.disp, window, gc, 0, 15, &textItem, 1); //fixa
   XSync(Mgr.scr.disp, False);                               //is this needed?
}
