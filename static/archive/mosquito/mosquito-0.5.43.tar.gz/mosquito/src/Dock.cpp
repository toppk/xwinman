#include <stdio.h>
#include <X11/Xlib.h>
#include <X11/xpm.h>
#include <X11/extensions/shape.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "Dock.h"
#include "Fonts.h"
#include "Colors.h"
#include "Configfile.h"
#include "Eventhandler.h"
#include "Misc.h"
#include "Mosquito.h"
#include "Manager.h"

extern Manager Mgr;

Dock::Dock(void) {
   
   int i;
   int x, y;
   char path[255];
   char *pixmapPath;
   char *cmd;
   
   Configfile cf;
   Pixmap shapeReturn;
   XpmAttributes xpmAttributes;      
   XSetWindowAttributes dockWindowAttributes;
   
   numOfDockWins = 0;
   xpmAttributes.colormap = XDefaultColormap(Mgr.scr.disp, Mgr.scr.screen);
   xpmAttributes.closeness = 40000;
   xpmAttributes.valuemask = XpmReturnPixels | XpmColormap | XpmCloseness;
   
   growDirection = cf.getDockGrowDirection();
      
   pixmapPath = cf.getDockPixmapPath();
   snprintf(path, strlen(pixmapPath), "%s", pixmapPath);
   delete [] pixmapPath;
   XpmReadFileToPixmap(Mgr.scr.disp, Mgr.scr.rootwin, path, &tilePixmap, &shapeReturn, &xpmAttributes);
   
   dockWindowAttributes.background_pixmap = tilePixmap;
   dockWindowAttributes.override_redirect = False;
   
   switch((position = cf.getDockPosition())) {
    case UPPERLEFT:
      x = 0;
      y = 0;
      break;
    default:
    case UPPERRIGHT:
      x = Mgr.scr.width - DOCK_WIDTH;
      y = 0;
      break;
    case LOWERRIGHT:
      x = Mgr.scr.width - DOCK_WIDTH;
      y = Mgr.scr.height - DOCK_HEIGHT;
      break;
    case LOWERLEFT:
      x = 0;
      y = Mgr.scr.height - DOCK_HEIGHT;
      break;
   }
   
   dockItem = new struct DockItem;
   dockItem->next = NULL;
   dockItem->window = None;
   dockItem->programWindow = None;
 
   restoreDockWinPositions();
   dockParentWindow = XCreateWindow(Mgr.scr.disp, Mgr.scr.rootwin, x, y, DOCK_WIDTH, DOCK_HEIGHT, 0, CopyFromParent, InputOutput, CopyFromParent, CWBackPixmap, &dockWindowAttributes);
}

Dock::~Dock(void) {

}

int Dock::getPosition(void) {
   return(position);
}

int Dock::getGrowDirection(void) {
   return(growDirection);
}

int Dock::getNumOfDockWins(void) {
   return(numOfDockWins);
}

void Dock::insertDockAppAtSavedPosition(Window w) {
   
   int i, j;
   char *appName;
   char tmp[255];
   struct DockItem *list, *object;
   
   if(XFetchName(Mgr.scr.disp, w, &appName)) {
      if(strrchr(appName, '/')) {
	 snprintf(tmp, 255, "%s", strrchr(appName, '/') + 1);
      } else {
	 snprintf(tmp, 255, "%s", appName);
      }
      
      for(i = 0;dockPositions[i].appName;i++) {
	 if(!strncmp(dockPositions[i].appName, tmp, strlen(dockPositions[i].appName) - 1) && dockPositions[i].filled == None) {

	    object = new struct DockItem;
	    object->programWindow = w;
	    object->window = addDockWin();
	    
	    list = dockItem;
	    
	    for(j = 0;list->next && j != i;j++) {
	       list = list->next;
	    }
	    object->next = list->next;
	    list->next = object;
	    	    
	    dockPositions[i].filled = w;
	    
	    XReparentWindow(Mgr.scr.disp, object->programWindow, object->window, 0, 0);
	    XMapWindow(Mgr.scr.disp, object->programWindow);
	    XMapWindow(Mgr.scr.disp, object->window);

	    updateDockWinPositions();	    
	    
	    delete [] appName;
	    return;
	 }
      }
      delete [] appName;
   }
}

void Dock::addDockApp(Window w) {
   
   DockItem *list, *object;
   
   list = dockItem;
   
   while(list->next) {
      list = list->next;
   }
   
   object = new struct DockItem;
   object->next = NULL;
   object->programWindow = w;
   object->window = addDockWin();
   
   list->next = object;
   
   XReparentWindow(Mgr.scr.disp, object->programWindow, object->window, 0, 0);
   XMapWindow(Mgr.scr.disp, object->programWindow);
   XMapWindow(Mgr.scr.disp, object->window);   
}
   

void Dock::removeDockApp(Window w) {
   
   int i;
   struct DockItem *list, *ptrToNext;
   
   list = dockItem;
   
   while(list->next) {
      if(list->next->programWindow == w) {
	 break;
      }
      list = list->next;
   }
   
   if(list->next == NULL) {
      return;
   }
   
   ptrToNext = list->next->next;
   XUnmapWindow(Mgr.scr.disp, list->next->programWindow);
   XUnmapWindow(Mgr.scr.disp, list->next->window);
   XDestroyWindow(Mgr.scr.disp, list->next->programWindow);
   XDestroyWindow(Mgr.scr.disp, list->next->window);
   
   delete list->next;
   list->next = ptrToNext;
   
   for(i = 0;dockPositions[i].appName;i++) {
      if(dockPositions[i].filled == w) {
	 dockPositions[i].filled = None;
      }
   }
   
   decreaseParentWindowSize();
   decreaseNumOfDockWins();
   updateDockWinPositions();
}

Window Dock::addDockWin(void) {
   
   Window window;
   XSetWindowAttributes dockWindowAttributes;
   XWindowAttributes windowAttributes;
   
   XGetWindowAttributes(Mgr.scr.disp, dockParentWindow, &windowAttributes);
   dockWindowAttributes.override_redirect = False;
   dockWindowAttributes.background_pixmap = tilePixmap;
   
   increaseParentWindowSize();
   
   if(growDirection == RIGHT) {
      window = XCreateWindow(Mgr.scr.disp, dockParentWindow, (numOfDockWins * DOCK_WIDTH), 0, DOCK_WIDTH, DOCK_HEIGHT, 0, CopyFromParent, InputOutput, CopyFromParent, CWBackPixmap, &dockWindowAttributes);
   } else if(growDirection == DOWN) {
      window = XCreateWindow(Mgr.scr.disp, dockParentWindow, 0, (numOfDockWins * DOCK_HEIGHT), DOCK_WIDTH, DOCK_HEIGHT, 0, CopyFromParent, InputOutput, CopyFromParent, CWBackPixmap, &dockWindowAttributes);
   } else if(growDirection == LEFT) {
      updateDockWinPositions();
      window = XCreateWindow(Mgr.scr.disp, dockParentWindow, 0, 0, DOCK_WIDTH, DOCK_HEIGHT, 0, CopyFromParent, InputOutput, CopyFromParent, CWBackPixmap, &dockWindowAttributes);
   } else if(growDirection == UP) {
      updateDockWinPositions();
      window = XCreateWindow(Mgr.scr.disp, dockParentWindow, 0, 0, DOCK_WIDTH, DOCK_HEIGHT, 0, CopyFromParent, InputOutput, CopyFromParent, CWBackPixmap, &dockWindowAttributes);
   }
   
   XSelectInput(Mgr.scr.disp, window, VisibilityChangeMask | SubstructureNotifyMask);
   
   increaseNumOfDockWins();
   
   return(window);
}

void Dock::increaseParentWindowSize(void) {
   
   XWindowAttributes windowAttributes;
   
   XGetWindowAttributes(Mgr.scr.disp, dockParentWindow, &windowAttributes);
   
   if(numOfDockWins == 0) {
      XMapWindow(Mgr.scr.disp, dockParentWindow);    //an exception has to be made
   } else if(growDirection == RIGHT) {
      XResizeWindow(Mgr.scr.disp, dockParentWindow, DOCK_WIDTH * (numOfDockWins + 1), DOCK_HEIGHT);
   } else if(growDirection == DOWN) {
      XResizeWindow(Mgr.scr.disp, dockParentWindow, DOCK_WIDTH, DOCK_HEIGHT * (numOfDockWins + 1));
   } else if(growDirection == LEFT) {
      XMoveResizeWindow(Mgr.scr.disp, dockParentWindow, windowAttributes.x - (DOCK_WIDTH * (numOfDockWins + 1)), windowAttributes.y, DOCK_WIDTH * (numOfDockWins + 1), DOCK_HEIGHT);
   } else if(growDirection == UP) {
      XMoveResizeWindow(Mgr.scr.disp, dockParentWindow, windowAttributes.x, windowAttributes.y - (DOCK_HEIGHT * (numOfDockWins + 1)), DOCK_WIDTH, DOCK_HEIGHT * (numOfDockWins + 1));
   }
}

void Dock::decreaseParentWindowSize(void) {
   
   XWindowAttributes windowAttributes;
   
   XGetWindowAttributes(Mgr.scr.disp, dockParentWindow, &windowAttributes);
   
   if(numOfDockWins == 1) {
      XUnmapWindow(Mgr.scr.disp, dockParentWindow);
   } else if(growDirection == RIGHT) {
      XResizeWindow(Mgr.scr.disp, dockParentWindow, DOCK_WIDTH * (numOfDockWins - 1), DOCK_HEIGHT);
   } else if(growDirection == DOWN) {
      XResizeWindow(Mgr.scr.disp, dockParentWindow, DOCK_WIDTH, DOCK_HEIGHT * (numOfDockWins - 1));
   } else if(growDirection == LEFT) {
      XMoveResizeWindow(Mgr.scr.disp, dockParentWindow, windowAttributes.x - (DOCK_WIDTH * (numOfDockWins - 1)), windowAttributes.y, DOCK_WIDTH * (numOfDockWins - 1), DOCK_HEIGHT);
   } else if(growDirection == UP) {
      XMoveResizeWindow(Mgr.scr.disp, dockParentWindow, windowAttributes.x, windowAttributes.y - (DOCK_HEIGHT * (numOfDockWins - 1)), DOCK_WIDTH, DOCK_HEIGHT * (numOfDockWins - 1));
   }
}

void Dock::updateDockWinPositions(void) {

   int i;
   struct DockItem *list;
   
   for(i = 0, list = dockItem->next;list;list = list->next, i++) {
      
      if(growDirection == RIGHT) {
	 XMoveWindow(Mgr.scr.disp, list->window, DOCK_WIDTH * i, 0);
      } else if(growDirection == DOWN) {
     	 XMoveWindow(Mgr.scr.disp, list->window, 0, DOCK_HEIGHT * i);
      } else if(growDirection == UP) {
	 XMoveWindow(Mgr.scr.disp, list->window, 0, (DOCK_HEIGHT * (numOfDockWins - 1)) - (i * DOCK_HEIGHT));
      } else if(growDirection == LEFT) {
	 XMoveWindow(Mgr.scr.disp, list->window, (DOCK_WIDTH * (numOfDockWins - 1)) - (i * DOCK_WIDTH), 0);
      }
   }
}

void Dock::increaseNumOfDockWins(void) {
   numOfDockWins++;
}

void Dock::decreaseNumOfDockWins(void) {
   numOfDockWins--;
}

Bool Dock::isParentWindow(Window w) {
   
   if(w == dockParentWindow) {
      return(True);
   } else {
      return(False);
   }
}

Bool Dock::isMember(Window w) {
   
   struct DockItem *list;

   list = dockItem->next;
   
   while(list) {
      if(list->window == w || list->programWindow == w) {
	 return(True);
      }
      list = list->next;
   }
   return(False);
}

Bool Dock::isSaved(Window w) {
   
   int i;
   char *appName;
   char tmp[255];
   
   if(XFetchName(Mgr.scr.disp, w, &appName)) {   
      if(strrchr(appName, '/')) {
	 snprintf(tmp, 255, "%s", strrchr(appName, '/') + 1); //WARNING
      } else {
	 snprintf(tmp, 255, "%s", appName);
      }
      
      for(i = 0;dockPositions[i].appName;i++) {
	 if(!strncmp(tmp, dockPositions[i].appName, strlen(dockPositions[i].appName) - 1) && dockPositions[i].filled == None) {
	    delete [] appName;
	    return(True);
	 }
      }
      delete [] appName;
   }
   
   return(False);
}

void Dock::raise(void) {
   
   XRaiseWindow(Mgr.scr.disp, dockParentWindow);
}

Window Dock::getAppWindow(int app) {  //no checks whatsoever in this function
   
   int i;
   struct DockItem *list;
   
   list = dockItem->next;
   
   for(i = 0;i < app;i++) {
      list = list->next;
   }
   return(list->programWindow);
}

void Dock::saveDockWinPositions(void) {
   
   FILE *fp;
   int i;
   char path[255];
   char *appName;
   struct DockItem *list;
   
   snprintf(path, 255, "%s/.mosquito/dock-win-positions", getenv("HOME"));
   
   fp = fopen(path, "w");
   if(fp == NULL) {
      Mgr.printErr("Couldn't open %s\nAborting dock-win-positions-save...\n", path);
      return;
   }

   list = dockItem->next;
   
   while(list) {
      if(XFetchName(Mgr.scr.disp, list->programWindow, &appName)) {
	 if(strrchr(appName, '/')) {
	    fprintf(fp, "%s\n", strrchr(appName, '/') + 1);     //WARNING!!!
	 } else {
	    fprintf(fp, "%s\n", appName);
	 }
	 delete [] appName;
      }
      list = list->next;
   }
   
   fclose(fp);
}

void Dock::restoreDockWinPositions(void) {
   
   FILE *fp;
   int i;
   char path[255];
   char appName[255];
   
   snprintf(path, 255, "%s/.mosquito/dock-win-positions", getenv("HOME"));
   
   fp = fopen(path, "r");
   if(fp == NULL) {
      Mgr.printErr("Couldn't open %s\nAborting dock-win-positions-restore...\n", path);
      return;
   }
   
   for(i = 0;i < MAX_NUM_OF_DOCKWINS;i++) {
      if(fgets(appName, 255, fp)) {
	 dockPositions[i].appName = new char[strlen(appName) + 1];
	 strcpy(dockPositions[i].appName, appName);
      } else {
	 dockPositions[i].appName = NULL;
      }
      dockPositions[i].filled = None;
   }
   
   fclose(fp);
}

void Dock::destroy(void) {
   
   int i;
   long int mask;
   XEvent event;
   struct DockItem *list, *object;
   
   memset(&event, 0, sizeof (event));
   event.xclient.type = ClientMessage;
   event.xclient.message_type = Mgr.getAtom("WM_PROTOCOLS");
   event.xclient.format = 32;
   event.xclient.data.l[0] = Mgr.getAtom("WM_DELETE_WINDOW");
   event.xclient.data.l[1] = CurrentTime;
   mask = 0L;

   list = dockItem->next;
   
   while(list) {
      event.xclient.window = list->programWindow;
      XSendEvent(Mgr.scr.disp, list->programWindow, False, mask, &event);
      XDestroyWindow(Mgr.scr.disp, list->window);
      object = list;
      list = list->next;
      delete object;
   }
   delete dockItem;
   
   XDestroyWindow(Mgr.scr.disp, dockParentWindow);
}

int Dock::getParentWindow(void) {
   
   return(dockParentWindow);
}
