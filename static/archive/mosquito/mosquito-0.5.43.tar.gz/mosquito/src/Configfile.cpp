#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <X11/Xproto.h>
#include <X11/Xutil.h>
#include "Mosquito.h"
#include "Fonts.h"
#include "Configfile.h"
#include "Manager.h"

extern Manager Mgr;

Configfile::Configfile(void) {
   
   char path[512];
   
   snprintf(path, 512, "%s/.mosquito/mosquitorc", getenv("HOME"));
   cf = fopen(path, "r");
   if(cf == NULL) {
      snprintf(path, 512, "%s/mosquitorc", MOSQUITOHOME);
      cf = fopen(path, "r");
      if(cf == NULL) {
	 Mgr.printErr("Couldn't open configfile in either %s/.mosquito/mosquitorc or %s/mosquitorc\n", getenv("HOME"), MOSQUITOHOME);
	 Mgr.quit(-20);
      }
   }
   
}

Configfile::~Configfile(void) {
   
   fclose(cf);
}

char *Configfile::readNextLine(void) {
   
   int i, j;
   static char tmp[255];
   
   if(!fgets(tmp, 255, cf)) {
      Mgr.printErr("Unsuspected EOF in configfile\n");
      Mgr.quit(-20);
   }
   //Do a little processing with our string. check for comments and such
      
   i = strspn(tmp, "\t\n ");
      
   for(;i > 0;i--) {
      for(j = 0;(unsigned int)j < strlen(tmp);j++) {
	 tmp[j] = tmp[j + 1];
      }
   }
   
   if(tmp[0] == '\n') {
      tmp[0] = '\0';
   }
   
   for(i = 0;tmp[i] != '\0';i++) {
      if(tmp[i] == '\\') {
	 switch(tmp[i + 1]) {
	  case '#':
	  case '\\':
	    tmp[i] = tmp[i + 1];
	    i++;
	    for(j = i;tmp[j];j++)
	      tmp[j] = tmp[j + 1];
	    continue;
	 }
      }
      if(tmp[i] == '#') {
	 tmp[i] = '\0';
	 break;
      }
   }
   
   return(tmp);
}


int Configfile::getByCharToInt(const char *section, const char *variableName) {
   
   char *tmp;
   char *ptr;
   
   rewind(cf);
   
   do {
      tmp = readNextLine();
   } while((strstr(tmp, section)) == NULL);
   
   do {
      tmp = readNextLine();
   } while((strstr(tmp, variableName)) == NULL);
   
   ptr = strchr(tmp, '=') + 1;
   
   return(atoi(ptr));
}

char *Configfile::getByCharToChar(const char *section, const char *variableName) {
   
   char *tmp;
   char *string;
   char *ptr;
   
   rewind(cf);
   
   do {
      tmp = readNextLine();
   } while((strstr(tmp, section)) == NULL);
   
   do {
      tmp = readNextLine();
   } while((strstr(tmp, variableName)) == NULL);
   
   ptr = strchr(tmp, '=') + 1;
   
   string = new char[strlen(ptr) + 1];
   sprintf(string, "%s", ptr);
   
   return(string);
}

int Configfile::getPopupTotalNumOfItems(void) {
   
   int totalNumOfItems;
   char *tmp;
   
   rewind(cf);
   
   totalNumOfItems = 0;
   
   do {
      tmp = readNextLine();
   } while((strstr(tmp, "[Popupmenu begin]")) == NULL);
   
   do {
      
      tmp = readNextLine();
      if((strstr(tmp, "[Sub end")) == NULL) {
	 totalNumOfItems++;
      }
      
   } while((strstr(tmp, "[Popupmenu end]")) == NULL);
   
   return(totalNumOfItems - 1);
}

int Configfile::getPopupTotalNumOfSubmenus(void) {
   
   int totalNumOfSubmenus;
   char *tmp;
   
   rewind(cf);
   
   totalNumOfSubmenus = 0;
   
   do {
      
      tmp = readNextLine();
      
   } while((strstr(tmp, "[Popupmenu begin]")) == NULL);
   
   do {
      tmp = readNextLine();
      if((strstr(tmp, "[Sub end")) != NULL) {
	 totalNumOfSubmenus++;
      }
      
   } while((strstr(tmp, "[Popupmenu end]")) == NULL);
   
   return(totalNumOfSubmenus);
}

int Configfile::getPopupNumOfSubmenuItems(int subMenu) {
   
   int numOfSubmenus, numOfItems;
   char *tmp;
   
   rewind(cf);
   
   numOfSubmenus = -1;
   numOfItems = 0;
   
   do {
      
      tmp = readNextLine();
   
   } while((strstr(tmp, "[Popupmenu begin]")) == NULL);
   
   do {
      
      tmp = readNextLine();
      if((strstr(tmp, "[Sub start")) != NULL) {
	 numOfSubmenus++;
      }
      
      if(numOfSubmenus == subMenu) {
	 numOfSubmenus = 0;
	 
	 do {
	    
	    tmp = readNextLine();
	    
	    if(numOfSubmenus == 0) {
	       if((strstr(tmp, "[Sub end")) == NULL) {
		  numOfItems++;
	       } else {
		  return(numOfItems);
	       }
	    }
	    
	    if((strstr(tmp, "[Sub start")) != NULL) {
	       numOfSubmenus++;
	    } else if((strstr(tmp, "[Sub end")) != NULL) {
	       numOfSubmenus--;
	    }
	    	    
	 } while((strstr(tmp, "[Popupmenu end]")) == NULL);
	 
      }
      
   } while((strstr(tmp, "[Popupmenu end]")) == NULL);

   return(-1);
}

char *Configfile::getPopupLabel(int subMenu, int item) {
   
   int i;
   int numOfSubmenus, numOfItems;
   char *tmp;
   char *label, *ptr;
   
   rewind(cf);
   
   numOfSubmenus = -1;
   numOfItems = 0;
   label = new char[64];
      
   do {
      
      tmp = readNextLine();
      
   } while((strstr(tmp, "[Popupmenu begin]")) == NULL);
   
   do {
      
      tmp = readNextLine();
      if((strstr(tmp, "[Sub start")) != NULL) {
	 numOfSubmenus++;
      }
      
      if(numOfSubmenus == subMenu) {
	 
	 numOfSubmenus = 0;
	 
	 do {
	    
	    tmp = readNextLine();
	    
	    if(numOfSubmenus == 0) {
	       if((strstr(tmp, "[Sub end")) == NULL) {
		  numOfItems++;
	       } 
	    }
	    
	    if((strstr(tmp, "[Sub start")) != NULL) {
	       numOfSubmenus++;
	    } else if((strstr(tmp, "[Sub end")) != NULL) {
	       numOfSubmenus--;
	    }
	    
	    if(numOfItems == item + 1) {
	       for(i = 0; i < 63; i++) {
		  if(tmp[i] == '=') {
		     i--;                              //Bugfix
		     break;                            //Just to get out of the loop
		  } else if(tmp[i] == ']') {
		     label[i] = ']';
		     break;
		  } else {
		     label[i] = tmp[i];
		  }
	       }
	       label[i + 1] = '\0';
	       
	       //Some serious stringhandling here...
	       if((ptr = strstr(label, "[Sub start"))) {
		  ptr += 12;
		  snprintf(tmp, 64, "%s", ptr);
		  ptr = strchr(tmp, '\"');
		  *ptr = '\0';
		  //snprintf(tmp, 256, "[%s]", ptr + 11);
		  //tmp[0] = '[';
		  //tmp[strlen(tmp)-2] = ']';
		  //tmp[strlen(tmp)-1] = '\0';
		  snprintf(label, 64, "%s", tmp);
	       }
			       
	   /*    while(label[0] == ' ') {                //Stripping spaces in the beginning if any
		  for(i = 0; i < (signed int)strlen(label);i++) {
		     label[i] = label[i + 1];
		  }
	       }*/
	       return(label);
	    }
	    
	 } while((strstr(tmp, "[Popupmenu end]")) == NULL);
	 
      }
      
   } while((strstr(tmp, "[Popupmenu end]")) == NULL);
   
   return(NULL);
}

char *Configfile::getPopupCommand(int subMenu, int item) {
   
   int i;
   int numOfSubmenus, numOfItems, countedMenus;
   char *tmp;
   char *command, *ptr;
   
   rewind(cf);
   
   numOfSubmenus = -1;
   numOfItems = 0;
   countedMenus = 0;
   command = new char[256];
      
   do {
      
      tmp = readNextLine();
      
   } while((strstr(tmp, "[Popupmenu begin]")) == NULL);
   
   do {
      
      tmp = readNextLine();
      if((strstr(tmp, "[Sub start")) != NULL) {
	 numOfSubmenus++;
      }
      
      if(numOfSubmenus == subMenu) {
	 
	 countedMenus = subMenu;
	 numOfSubmenus = 0;
	 
	 do {
	    
	    tmp = readNextLine();
	    
	    if(numOfSubmenus == 0) {
	       if((strstr(tmp, "[Sub end")) == NULL) {
		  numOfItems++;
	       } 
	    }
	    
	    if((strstr(tmp, "[Sub start")) != NULL) {
	       numOfSubmenus++;
	       countedMenus++;
	    } else if((strstr(tmp, "[Sub end")) != NULL) {
	       numOfSubmenus--;
	    }
	    
	    if(numOfItems == item + 1) {
	       ptr = strchr(tmp, '=');
	       if(ptr == NULL) {
		  if((strstr(tmp, "[Sub start")) != NULL) {
		     snprintf(command, 256, "%d", countedMenus);
		  } else if((strstr(tmp, "[Separator]")) != NULL) {
		     snprintf(command, 256, "[Separator]");
		  } else {
		     Mgr.printErr("Config file error\n");
		     if(strlen(tmp) < 256) {               //Bounds checking needed here
			snprintf(command, strlen(tmp), "%s", tmp);
			Mgr.printErr("\"%s\" - Not understood\n", command);
		     }
		     Mgr.quit(-10);
		  }
		     
		  return(command);  
	       }
	       
	       ptr++;
	       
	       for(i = 0; i < 255;i++) {
		  if(ptr[i] == '\n') {
		     i--;
		     break;                    //Just to get out of the loop
		  } else {
		     command[i] = ptr[i];
		  }
	       }
	       command[i + 1] = '\0';
	       return(command);
	    }
	    
	 } while((strstr(tmp, "[Popupmenu end]")) == NULL);
	 
      }
      
   } while((strstr(tmp, "[Popupmenu end]")) == NULL);
   
   return(NULL);
   
}

char *Configfile::getFontFont(int font) {
   
   char *tmp, wantedFont[80];
   char *theFont, *ptr;
   
   rewind(cf);
   
   do {
      tmp = readNextLine();
   } while((strstr(tmp, "[Fonts begin]")) == NULL);
   
   switch(font) {
    case TITLEBARFONT:
      snprintf(wantedFont, 80, "TitlebarFont");
      break;
    case ROOTPOPUPMENUFONT:
      snprintf(wantedFont, 80, "RootPopupMenuFont");
      break;
    case MWINDOWPOPUPMENUFONT:
      snprintf(wantedFont, 80, "MwindowPopupMenuFont");
      break;
    case ICONPOPUPMENUFONT:
      snprintf(wantedFont, 80, "IconPopupMenuFont");
      break;
    case WSCHANGEWINDOWFONT:
      snprintf(wantedFont, 80, "WSChangeWindowFont");
      break;
    case WSSENDTOWSWINDOWFONT:
      snprintf(wantedFont, 80, "WSSendToWSWindowFont");
      break;
   case DOCKPOPUPMENUFONT:
      snprintf(wantedFont, 80, "DockPopupMenuFont");
      break;
    default:
      Mgr.printErr("We dont have that font!\n");
      Mgr.quit(-25);
      break;
   }
   
   do {
      tmp = readNextLine();
   } while((strstr(tmp, wantedFont)) == NULL);
   
   theFont = new char[100];
   
   ptr = strchr(tmp, '=') + 1;
   snprintf(theFont, strlen(ptr), "%s", ptr);     // Gets rid of annoying NL
   
   return(theFont);
}

int Configfile::getColorColor(int color) {
   
   int i, j;
   float frgb[3];
   char *tmp, wantedColor[25], crgb[10];
   char *ptr;
   
   rewind(cf);
   
   switch(color) {
    case MWINDOWTITLEBARCOLOR:
      sprintf(wantedColor, "MwindowTitlebar");
      break;
    case MWINDOWTITLEBARFADETOCOLOR:
      sprintf(wantedColor, "MwindowTitlebarFadeTo");
      break;
    case MWINDOWBORDERCOLOR:
      sprintf(wantedColor, "MwindowBorder");
      break;
    case MWINDOWRESIZERCOLOR:
      sprintf(wantedColor, "MwindowResizer");
      break;
    case MWINDOWTEXTCOLOR:
      sprintf(wantedColor, "MwindowText");
      break;
    case HILIGHTEDMWINDOWTITLEBARCOLOR:
      sprintf(wantedColor, "HilightedMwindowTitlebar");
      break;
    case HILIGHTEDMWINDOWBORDERCOLOR:
      sprintf(wantedColor, "HilightedMwindowBorder");
      break;
    case HILIGHTEDMWINDOWRESIZERCOLOR:
      sprintf(wantedColor, "HilightedMwindowResizer");
      break;
    case HILIGHTEDMWINDOWTEXTCOLOR:
      sprintf(wantedColor, "HilightedMwindowText");
      break;
    case MWINDOWPOPUPBACKGROUNDCOLOR:
      sprintf(wantedColor, "MwindowPopupBackground");
      break;
    case MWINDOWPOPUPBORDERCOLOR:
      sprintf(wantedColor, "MwindowPopupBorder");
      break;
    case MWINDOWPOPUPTEXTCOLOR:
      sprintf(wantedColor, "MwindowPopupText");
      break;
    case ROOTPOPUPBACKGROUNDCOLOR:
      sprintf(wantedColor, "RootPopupBackground");
      break;
    case ROOTPOPUPBORDERCOLOR:
      sprintf(wantedColor, "RootPopupBorder");
      break;
    case ROOTPOPUPTEXTCOLOR:
      sprintf(wantedColor, "RootPopupText");
      break;
    case ICONPOPUPBACKGROUNDCOLOR:
      sprintf(wantedColor, "IconPopupBackground");
      break;
    case ICONPOPUPBORDERCOLOR:
      sprintf(wantedColor, "IconPopupBorder");
      break;
    case ICONPOPUPTEXTCOLOR:
      sprintf(wantedColor, "IconPopupText");
      break;
/*    case DOCKBACKGROUNDCOLOR:
      sprintf(wantedColor, "DockBackground");
      break;*/
    default:
      Mgr.printErr("%s - No such color. Exiting...\n", color);
      Mgr.quit(-45);
      break;
   }
   
   do {
      tmp = readNextLine();
   } while((strstr(tmp, "[Colors begin]")) == NULL);
   
   do {
      tmp = readNextLine();
   } while((strstr(tmp, wantedColor)) == NULL);
   
   ptr = strchr(tmp, '=');
   
   for(i = 0;i < 3;i++) {
      ptr++;
      for(j = 0;j < 10 && ptr[0] != '-' && ptr[0] != '\n'; j++) {
	 crgb[j] = ptr[0];
	 ptr++;
      }
      crgb[j] = '\0';
      frgb[i] = atof(crgb);
   }
   
   return(Mgr.adaptToDepth(frgb[0], frgb[1], frgb[2]));
}

void Configfile::runAutostart(void) {
   
   char *tmp;
   
   rewind(cf);
   
   do {
      tmp = readNextLine();
   } while((strstr(tmp, "[Autostart begin]")) == NULL);
   
   tmp = readNextLine();
   
   while((strstr(tmp, "[Autostart end]")) == NULL) {
      
      Mgr.runCommand(tmp);
      tmp = readNextLine();
   } 
   
}

int Configfile::getKeybindingsKey(int line) {
   
   int i;
   unsigned int key;
   char *tmp, skey[255];
   
   rewind(cf);
   
   do {
      
      tmp = readNextLine();
   
   } while((strstr(tmp, "[Keybindings begin]")) == NULL);
   
   for(i = 0;i <= line;i++) {
      tmp = readNextLine();
      if((strcmp(tmp, "")) == 0) {
	 i--;
      }
   }
   
   for(i = 0;(unsigned int)i < strlen(tmp);i++) {
      if(tmp[i] == '+') {
	 break;
      } else {
	 skey[i] = tmp[i];
      }
   }
   skey[i] = '\0';  
   
   key = atoi(skey);
   
   return(key);
}

int Configfile::getKeybindingsModifiers(int line) {
   
   int i;
   unsigned int mods;
   char *tmp, smods[255];
   char *pmods;
   
   rewind(cf);
   mods = 0;
   
   do {
      
      tmp = readNextLine();
      
   } while((strstr(tmp, "[Keybindings begin]")) == NULL);
   
   for(i = 0;i <= line;i++) {
      tmp = readNextLine();
      if((strcmp(tmp, "")) == 0) {
	 i--;
      }
   }
   
   pmods = strchr(tmp, '\"') + 1;
   if(pmods == NULL) {
      Mgr.quit(-20);
   }
   
   for(i = 0;(unsigned int)i < strlen(tmp);i++) {
      if(pmods[i] == '\"') {
	 break;
      } else {
	 smods[i] = pmods[i];
      }
   }          
   smods[i] = '\0';
   
   if((strstr(smods, "ShiftMask")) != NULL) {
      mods |= (1 << 0);
   } 
   if((strstr(smods, "LockMask")) != NULL) {
      mods |= (1 << 1);
   } 
   if((strstr(smods, "ControlMask")) != NULL) {
      mods |= (1 << 2);
   } 
   if((strstr(smods, "Mod1Mask")) != NULL) {
      mods |= (1 << 3);
   }
   if((strstr(smods, "Mod2Mask")) != NULL) {
      mods |= (1 << 4);
   }
   if((strstr(smods, "Mod3Mask")) != NULL) {
      mods |= (1 << 5);
   }
   if((strstr(smods, "Mod4Mask")) != NULL) {
      mods |= (1 << 6);
   }
   if((strstr(smods, "Mod5Mask")) != NULL) {
      mods |= (1 << 7);
   }
   
   return(mods);
}

int Configfile::getKeybindingsFunction(int line) {
   
   int i;
   unsigned int function;
   char *tmp, sfunction[255];
   char *pfunction;
   
   rewind(cf);
   
   do {
      
      tmp = readNextLine();
      
   } while((strstr(tmp, "[Keybindings begin]")) == NULL);
   
   for(i = 0;i <= line;i++) {
      tmp = readNextLine();
      if((strcmp(tmp, "")) == 0) {
	 i--;
      }
   }
   
   pfunction = strchr(tmp, '=') + 1;
   
   for(i = 0;(unsigned int)i < strlen(tmp);i++) {
      if(pfunction[i] == '\"' || pfunction[i] == '\n') {
	 break;
      } else {
	 sfunction[i] = pfunction[i];
      }
   }          
   sfunction[i] = '\0';
   
   //Convert our string to int format 
   if((strstr(sfunction, "EXEC")) != NULL) {
      function = 1;
   } else if((strstr(sfunction, "RESTART")) != NULL) { 
      function = 2;
   } else if((strstr(sfunction, "EXIT")) != NULL) {
      function = 3;
   } else if((strstr(sfunction, "ROOTPOPUPMENU")) != NULL) {
      function = 4;
   } else if((strstr(sfunction, "WINDOWPOPUPMENU")) != NULL) {
      function = 5;
   } else if((strstr(sfunction, "DEICONIFY")) != NULL) {
      function = 6;
   } else if((strstr(sfunction, "ICONIFY")) != NULL) {
      function = 7;
   } else if((strstr(sfunction, "MAXIMIZE")) != NULL) {
      function = 8;
   } else if((strstr(sfunction, "CLOSE")) != NULL) {
      function = 9;
   } else if((strstr(sfunction, "RAISE")) != NULL) {
      function = 10;
   } else if((strstr(sfunction, "LOWER")) != NULL) {
      function = 11;
   } else if((strstr(sfunction, "CIRCULATEWINDOWSUP")) != NULL) {
      function = 12;
   } else if((strstr(sfunction, "CIRCULATEWINDOWSDOWN")) != NULL) {
      function = 13;
   } else if((strstr(sfunction, "NEXTWS")) != NULL) {
      function = 14;
   } else if((strstr(sfunction, "PREVIOUSWS")) != NULL) {
      function = 15;
   } else if((strstr(sfunction, "SWITCHTOWS")) != NULL) {
      function = 16;
   } else if((strstr(sfunction, "MOVEONKLICK")) != NULL) {
      function = 17;
   } else {
      function = 0;
   }
   
   return(function);
}

char *Configfile::getKeybindingsCommand(int line) {
   
   int i;
   char *tmp, scommand[255];
   char *pcommand;
   
   rewind(cf);
   
   do {
      
      tmp = readNextLine();
      
   } while((strstr(tmp, "[Keybindings begin]")) == NULL);
   
   for(i = 0;i <= line;i++) {
      tmp = readNextLine();
      if((strcmp(tmp, "")) == 0) {
	 i--;
      }
   }
   
   pcommand = strstr(tmp, "=");   //we have to set the pointer after the modifiers \"
   pcommand = strchr(pcommand, '\"') + 1;
   
   for(i = 0;(unsigned int)i < strlen(tmp);i++) {
      if(pcommand[i] == '\"') {
	 break;
      } else {
	 scommand[i] = pcommand[i];
      }
   }          
   scommand[i] = '\0';
   
   //Recycling is good! ^_^
   pcommand = new char[strlen(scommand) + 1];
   snprintf(pcommand, (strlen(scommand) + 1), "%s", scommand);
   
   return(pcommand);
}

int Configfile::getKeybindingsNumOfItems(void) {
   
   int i;
   char *tmp;
   
   rewind(cf);
   i = 0;
   
   do {
      
      tmp = readNextLine();
      
   } while((strstr(tmp, "[Keybindings begin]")) == NULL);
   
   do {
      
      i++;
      tmp = readNextLine();
      if((strcmp(tmp, "")) == 0) {
	 i--;
      }
       
   } while((strstr(tmp, "[Keybindings end]")) == NULL);
   
   return(i - 1);
} 

char *Configfile::getDockPixmapPath(void) {
   
   char *path;
   
   path = getByCharToChar("[Dock begin]", "BackgroundPixmap");
   return(path);
}

int Configfile::getDockPosition(void) {
   
   return(getByCharToInt("[Dock begin]", "Position"));
}

int Configfile::getDockGrowDirection(void) {
   
   return(getByCharToInt("[Dock begin]", "GrowDirection"));
}
