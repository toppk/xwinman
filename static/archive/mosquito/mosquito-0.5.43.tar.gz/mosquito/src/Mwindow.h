#ifndef _MWINDOW_H_
#define _MWINDOW_H_

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <X11/Xproto.h>
#include <X11/Xutil.h>  

// Ripped from FVWM which had ripped from MWM

typedef struct {
   CARD32      flags;
   CARD32      functions;
   CARD32      decorations;
   INT32       inputMode;
} PropMotifWmHints;

typedef PropMotifWmHints		PropMwmHints;

#define MWM_HINTS_FUNCTIONS		(1L << 0)
#define MWM_HINTS_DECORATIONS		(1L << 1)

#define MWM_FUNC_ALL			(1L << 0)
#define MWM_FUNC_RESIZE			(1L << 1)
#define MWM_FUNC_MOVE			(1L << 2)
#define MWM_FUNC_MINIMIZE		(1L << 3)
#define MWM_FUNC_MAXIMIZE		(1L << 4)

#define MWM_DECOR_ALL			(1L << 0)
#define MWM_DECOR_BORDER		(1L << 1)
#define MWM_DECOR_HANDLES		(1L << 2)
#define MWM_DECOR_TITLE			(1L << 3)
#define MWM_DECOR_MENU			(1L << 4)
#define MWM_DECOR_MINIMIZE		(1L << 5)
#define MWM_DECOR_MAXIMIZE		(1L << 6)

#define PROP_MOTIF_WM_HINTS_ELEMENTS	4
#define PROP_MWM_HINTS_ELEMENTS		PROP_MOTIF_WM_HINTS_ELEMENTS

#define S_STICKY			(1L << 0)
#define S_SHADED			(1L << 1)
#define S_MINIMIZED			(1L << 2)
#define S_UNMAPPED			(1L << 3)
#define S_SHAPED			(1L << 4)
#define S_MAXIMIZED			(1L << 5)
#define S_ALWAYSONTOP			(1L << 6)

#define W_BORDER_NORTH			1
#define W_BORDER_EAST			2
#define W_BORDER_SOUTH			3
#define W_BORDER_WEST			4
#define W_RESIZE			5
#define W_TITLEBAR			6
#define W_MINIMIZE			7
#define W_KILL				8
#define W_APP				9
#define W_PARENT			10

class Mwindow {
 
 private:
   int x, y;                                       // The X/Y coordinates
   int width, height;                              // the width/height of our window
   int nx, ny, nwidth, nheight;                    // normal X,Y,Width,Height if maximized
   int decorSet;                                   // Windows decore set
   int homeWS;                                     // The Workspace this window belongs to
   Window parentWindow, appWindow;                 // The parent and our app-window
   Window titlebarWindow, killWindow, iconWindow;  // The buttons + the titlebar
   Window borderWindow[4];                         // The surrounding border to the window
   Window resizeWindow;                            // The resizer window
   XSizeHints *sizeHints;                          // info about resize and stuff 
   Bool sticky, shaded, unMapped;                  // If window is sticky/shaded/iconified
   Bool maximized, minimized;
   Bool shaped;
   Bool alwaysOnTop;
   
 public:
   Mwindow(); 
   ~Mwindow();
   
   void setup(void);
   
   int getX(void);
   void setX(int x);
   int getY(void);
   void setY(int y);
   
   int getWidth(void);
   void setWidth(int widht);
   int getHeight(void);
   void setHeight(int height);
   
   char *getName(void);
   void setName(const char *name);
   
   char *getIconName(void);
   void setIconName(const char *name);
   
   void setSticky(Bool removeSticky);
   void removeSticky(Bool setSticky);
   
   void setAlwaysOnTop(Bool removeAlwaysOnTop);
   void removeAlwaysOnTop(Bool setAlwaysOnTop);
   
   int getWS(void);
   void setWS(int ws);
   
   
   int getState(void);                   //Returns the state of the window
   void setState(int state);             // sticky = 1, shaded = 2, iconified = 4
                                         //Use setState with extreme caution
   
   void setWindow(int which, Window w);
   unsigned int getWindow(int which);
   
   Bool isMember(Window w);
   
   void setFocus(void);
   void removeFocus(void);
   
   void decorate(void);
   int selectDecorations(void);
   int getMWMHints(void);
   
   void placeOnScreen(void);
   void placeByPointer(void);
   void placeByApp(void);
   void placeSmart(void);
   
   void drawTitlebarText(void);
   void drawTitlebarGradient(void);
   
   void addToDock(void);
   
   void map(void);
   void unmap(void);
   
   void raise(void);
   void lower(void);
   
   void iconifyEffect(void);
   void minimize(Bool normalize);
   void maximize(Bool normalize);
   void normalize(void);
   
   void shade(Bool unShade);
   void unShade(Bool shade);
   
   void move(int x, int y);
   void move(void);
   void moveOpaque(void);
   void moveInteractive(void);
   void moveOnClick(void);
   
   void resize(int widht, int height);
   void resize(int widht, int height, Bool overrideSizeHints);
   void resize(void);
   
   Bool isTitlebar(Window w);
   Bool isParent(Window w);
   Bool isIcon(Window w);
   Bool isKill(Window w);
   Bool isApp(Window w);
   Bool isResize(Window w);
   int  isBorder(Window w);
   
   void sendConfigureNotify(void);
   
   void repaint();
   
   void kill(void);
   void fadeEffect(void);
   
   void destroy(void);
   
   Mwindow &copyMwin(const Mwindow *MwinArg);
   void fixSizeHints(void);
   //int getID(void);
   //int setID(int id);
};

#endif
