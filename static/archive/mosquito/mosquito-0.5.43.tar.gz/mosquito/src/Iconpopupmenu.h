#ifndef _ICONPOPUPMENU_H_
#define _ICONPOPUPMENU_H_

#include "Popupmenu.h"

class Iconpopupmenu {
 private:
   Popupmenu *menu;   
   
 public:
   Iconpopupmenu(void);
   ~Iconpopupmenu(void);
   
   int getNumOfIcons(void);
   
   void pop(void);
};

#endif

