#ifndef _VSCREEN_H_
#define _VSCREEN_H_

#include "Mosquito.h"

struct wsData {
   int x, y;
   Window focus;
};

class Vscreen {
 private:
   int activeWS;
   int numOfWSs;
   struct wsData *wsData;
   
 public:
   
   Vscreen(void);
   
   int getActiveWS(void);
   
   void setNumOfWSs(int numOfWSs);
   int getNumOfWSs(void);
   
   void switchWS(int ws);
   
   void nextWS(void);
   void previousWS(void);
   
   void moveMwindowFromScreen(int Mwin);
   void moveMwindowToScreen(int Mwin);
   
   void sendToWS(int Mwin, int ws);
   void sendToWS(int Mwin);
   
   void saveWSData(void);
   void restoreWSData(void);
   
   void drawActiveWS(void);
   
};

#endif

