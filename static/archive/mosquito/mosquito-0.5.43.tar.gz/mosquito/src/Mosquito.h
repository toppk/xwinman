#ifndef _MOSQUITO_H_
#define _MOSQUITO_H_

#include "Mwindow.h"

/****************************************************************************
 *   Definitions
 ***************************************************************************/ 
#define MOSQUITOVERSION "0.5.40"

#define MAX_WINDOW_HEIGHT 3000
#define MAX_WINDOW_WIDTH 3000

#define MAX_NUM_OF_DOCKWINS 50

/* DO NOT change this, i'll put it in another file sometime */
#define RIGHT		0
#define LEFT		1
#define UP		2
#define DOWN		3

#define UPPERLEFT	0
#define UPPERRIGHT	1
#define LOWERRIGHT	2
#define LOWERLEFT	3

#endif

