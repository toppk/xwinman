#include <time.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include "Mosquito.h"
#include "Manager.h"

extern Manager Mgr;

Bool checkForRelease(Display *disp, XEvent *e, XPointer arg) {
   
   if(e->type == ButtonRelease) {
      return(True);
   } else {
      return(False);
   }
}

Bool checkForPress(Display *disp, XEvent *e, XPointer arg) {
   
   if(e->type == ButtonPress) {
      if(arg == NULL) {
	 return(True);
      }
      else if((unsigned int)*arg == e->xbutton.button) {
	 return(True);
      }
      else {
	 return(False);
      }
   } else {
      return(False);
   }
}

Bool isDoubleClick(XButtonEvent *be) {
   
   static unsigned int lastClickTime = 0;
   static unsigned int lastClickButton = 0;
   static Window lastClickWindow = None;
   
   if(lastClickTime &&
      (be->button == lastClickButton) &&
      (be->window == lastClickWindow) &&
      ((be->time - lastClickTime) <= Mgr.getDoubleClickDelay())) {

      lastClickTime = 0;
      lastClickWindow = None;
      return(True);
   }
   
   lastClickWindow = be->window;
   lastClickTime = be->time;
   lastClickButton = be->button;
   
   return(False);
}  

Bool checkForKeyPress(Display *disp, XEvent *e, XPointer arg) {
   
   if(e->type == KeyPress) {
      return(True);
   } else {
      return(False);
   }
}

Bool checkForKeyRelease(Display *disp, XEvent *e, XPointer arg) {
   
   if(e->type == KeyRelease) {
      return(True);
   } else {
      return(False);
   }
}

void trekkify(Window window) {
   
   GC gc;
   XGCValues gcValues;
   XWindowAttributes windowAttributes;
   
   gcValues.function = GXcopy;
   gcValues.foreground = Mgr.adaptToDepth(0.537, 0.082, 0.686); //0x8915af;
   gcValues.line_width = 10;
   gcValues.cap_style = CapRound;
   gcValues.join_style = JoinMiter;
   gc = XCreateGC(Mgr.scr.disp, window, GCForeground | GCFunction | GCLineWidth | GCCapStyle | GCJoinStyle, &gcValues);
   
   XGetWindowAttributes(Mgr.scr.disp, window, &windowAttributes);
   
   // 255 123 0
   XSetWindowBackground(Mgr.scr.disp, window, 0x000000);
   XClearWindow(Mgr.scr.disp, window);
   
   XDrawLine(Mgr.scr.disp, window, gc, 6, 6, windowAttributes.width - 6, 6);
   XDrawLine(Mgr.scr.disp, window, gc, windowAttributes.width - 6, 6, windowAttributes.width - 6, windowAttributes.height - 6);
   XDrawLine(Mgr.scr.disp, window, gc, 6, windowAttributes.height - 6, windowAttributes.width - 6, windowAttributes.height - 6);
   XDrawLine(Mgr.scr.disp, window, gc, 6, 6, 6, windowAttributes.height - 6);

   XSetForeground(Mgr.scr.disp, gc, Mgr.adaptToDepth(1, 0.478, 0)); //0xff7a00);
   XDrawLine(Mgr.scr.disp, window, gc, 18, 18, windowAttributes.width - 18, 18);
   XDrawLine(Mgr.scr.disp, window, gc, windowAttributes.width - 18, 18, windowAttributes.width - 18, windowAttributes.height - 18);
   XDrawLine(Mgr.scr.disp, window, gc, 18, windowAttributes.height - 18, windowAttributes.width - 18, windowAttributes.height - 18);
   XDrawLine(Mgr.scr.disp, window, gc, 18, 18, 18, windowAttributes.height - 18);
/*
   XSetForeground(disp, gc, 0x000000);
   XSetLineAttributes(disp, gc, 2, LineSolid, CapRound, JoinRound);
   XDrawLine(disp, window, gc, 26, 0, 26, windowAttributes.height);
   XDrawLine(disp, window, gc, windowAttributes.width - 26, 0, windowAttributes.width - 26, windowAttributes.height);
   XDrawLine(disp, window, gc, 0, 26, windowAttributes.width, 26);
   XDrawLine(disp, window, gc, 0, windowAttributes.height - 26, windowAttributes.width, windowAttributes.height - 26);
  */ 
      
   XFreeGC(Mgr.scr.disp, gc);
}

time_t uptime(void) {
   
   static int put = 1;
   static time_t initTime;
   time_t totalTime;
   
   if(put) {
      initTime = time(NULL);
      put = 0;
   } else {
      totalTime = time(NULL) - initTime;
      Mgr.printErr("Mosquito has been running for:\n"
		   "%d days, %d hours, %d minutes and %d seconds\n",
		   totalTime / 86400,
		   (totalTime % 86400) / 3600,
		   ((totalTime % 86400) % 3600) / 60,
		   (((totalTime % 86400) % 3600) % 60));
   
      return(totalTime);
   }
   
   return(0);
}

time_t getRecordTime(void) {
   
   FILE *fp;
   char buffer[255];
   
   snprintf(buffer, 255, "%s/.mosquito/uptime-highscore", getenv("HOME"));
   
   fp = fopen(buffer, "r");
   if(fp) {
      fgets(buffer, 255, fp);
      fclose(fp);
      
      if(atoi(buffer)) {
	 return(atoi(buffer));
      }
   }
   
   return(0);
}

void setRecordTime(time_t recordTime) {
      
   FILE *fp;
   char file[255];
   
   snprintf(file, 255, "%s/.mosquito/uptime-highscore", getenv("HOME"));

   fp = fopen(file, "w");
   if(fp) {
      fprintf(fp, "%ld", recordTime);
      fclose(fp);
   }
}

XErrorHandler errorHandler(Display *disp, XErrorEvent *ee) {
   
   if(ee->error_code == BadWindow) {
      Mgr.printErr("Caught BadWindow error\n");
   } else {
      Mgr.printErr("Caught error no. %d\n", ee->error_code);
   }
   
   return(0);
}

XIOErrorHandler IOerrorHandler(Display *disp) {
   
   Mgr.printErr("Lost connection to X-Server\n");
   Mgr.quit(-10);
   
   return(0);
}
  
  
