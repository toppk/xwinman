#include <stdio.h>
#include <X11/Xlib.h>
#include <X11/xpm.h>
#include <X11/cursorfont.h>
#include <X11/extensions/shape.h>
#include <X11/Xatom.h>
#include <X11/Xproto.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <math.h>
#include "Mwindow.h"    
#include "Fonts.h"
#include "Colors.h"
#include "Misc.h"
#include "Mosquito.h"
#include "Manager.h"
#include "Eventhandler.h"

extern Manager Mgr;

Mwindow::Mwindow(void) {
   
}

Mwindow::~Mwindow(void) {
 //  defragMwindows();
}

int Mwindow::getX(void) {
   
   return(x);
}

void Mwindow::setX(int x) {
   
   this->x = x;
}

int Mwindow::getY(void) {
   
   return(y);
}

void Mwindow::setY(int y) {
   
   this->y = y;
}

int Mwindow::getHeight(void) {
   
   return(height);
}

void Mwindow::setHeight(int height) {
   
   this->height = height;
}

int Mwindow::getWidth(void) {
   
   return(width);
}

void Mwindow::setWidth(int width) {
   
   this->width = width;
}

int Mwindow::getWS(void) {
   
   return(homeWS);
}

void Mwindow::setWS(int ws) {
   
   homeWS = ws;
}

int Mwindow::getState(void) {
   
   int state;
   
   state = 0;
   
   if(sticky)
     state |= S_STICKY;
   if(shaded)
     state |= S_SHADED;
   if(minimized)
     state |= S_MINIMIZED;
   if(unMapped)
     state |= S_UNMAPPED;
   if(shaped)
     state |= S_SHAPED;
   if(maximized)
     state |= S_MAXIMIZED;
   if(alwaysOnTop)
     state |= S_ALWAYSONTOP;
      
   return(state);
}

void Mwindow::setState(int state) {
      
   (state & S_STICKY) ? sticky = True : sticky = False;

   (state & S_SHADED) ? shaded = True : shaded = False;

   (state & S_MINIMIZED) ? minimized = True : minimized = False;

   (state & S_UNMAPPED) ? unMapped = True : unMapped = False;

   (state & S_SHAPED) ? shaped = True : shaped = False;

   (state & S_MAXIMIZED) ? maximized = True : maximized = False;
   
   (state & S_ALWAYSONTOP) ? alwaysOnTop = True : alwaysOnTop = False;
   
}

void Mwindow::decorate(void) {
  
   int i;
   int pheight, pwidth;
   char path[512];

   //XSetWindowAttributes winSAttributes;
   XSetWindowAttributes parentSAttributes;
   XSetWindowAttributes titlebarSAttributes, killSAttributes, iconSAttributes;
   XSetWindowAttributes borderSAttributes, resizeSAttributes;
   XWindowAttributes winAttributes;
   XpmAttributes xpmAttributes;
   Pixmap resizePixmap;
   Pixmap shapeReturn;
   Pixmap killPixmap;
   Pixmap iconPixmap;

   decorSet = selectDecorations();
   sizeHints = NULL;
   fixSizeHints();

   XSetWindowBorderWidth(Mgr.scr.disp, appWindow, 0);

   XGetWindowAttributes(Mgr.scr.disp, appWindow, &winAttributes);
   
//   winAttributes.x = x;  //borde fan fixas!
//   winAttributes.y = y;
//   winAttributes.width = width;
//   winAttributes.height = height;
   
   xpmAttributes.colormap = XDefaultColormap(Mgr.scr.disp, Mgr.scr.screen);
   xpmAttributes.closeness = 40000;
   xpmAttributes.valuemask = XpmReturnPixels | XpmColormap | XpmCloseness;

   
   if(winAttributes.x > Mgr.scr.width)
     winAttributes.x = Mgr.scr.width - winAttributes.width;
   if(winAttributes.y > Mgr.scr.height)
     winAttributes.y = Mgr.scr.height - winAttributes.height;

   XMoveResizeWindow(Mgr.scr.disp, appWindow, winAttributes.x, winAttributes.y, winAttributes.width, winAttributes.height);
   
   /* Our window:
    * - has a titlebar with 23 height
    * - has 2 buttons, both 20x20 pixels
    * - has horizantal borders that are 3 pixels high
    * - has vertical borders that are 3 pixels wide
    * - has a resizer at the bottom right corner
    */
   
   if(shaped == False) { 
      pheight = winAttributes.height;
      pwidth = winAttributes.width;
      
      if((decorSet & MWM_DECOR_BORDER)) {
	 pheight += 6;
	 pwidth += 6;
      }
      if((decorSet & MWM_DECOR_TITLE))
	pheight += 23;
      
      
      parentSAttributes.bit_gravity = NorthWestGravity;
      parentSAttributes.background_pixel = 0;
      parentWindow = XCreateWindow(Mgr.scr.disp, Mgr.scr.rootwin, winAttributes.x, winAttributes.y, pwidth, pheight, 0, CopyFromParent, InputOutput, CopyFromParent, CWBitGravity | CWBackPixel, &parentSAttributes);
      XSelectInput(Mgr.scr.disp, parentWindow, EnterWindowMask | SubstructureNotifyMask | SubstructureRedirectMask | VisibilityChangeMask);
      XSelectInput(Mgr.scr.disp, appWindow, PropertyChangeMask);
      
      //Put the childwindow on our parentwindow
      XReparentWindow(Mgr.scr.disp, appWindow, parentWindow, 3, 3 + 23);
           
      if((decorSet & MWM_DECOR_TITLE)) {

	 titlebarSAttributes.background_pixel = Mgr.getColor(MWINDOWTITLEBARCOLOR);
	 titlebarSAttributes.win_gravity = NorthWestGravity;
	 titlebarSAttributes.bit_gravity = NorthWestGravity;
	 titlebarWindow = XCreateWindow(Mgr.scr.disp, parentWindow, 3, 3, winAttributes.width, 23, 0, CopyFromParent, InputOutput, CopyFromParent, CWBackPixel | CWBitGravity | CWWinGravity, &titlebarSAttributes);
	 XSelectInput(Mgr.scr.disp, titlebarWindow, ButtonPressMask | ButtonReleaseMask | ExposureMask | Button1MotionMask);
	 
	 snprintf(path, 512, "%s/pics/iconify.xpm", MOSQUITOHOME);
	 XpmReadFileToPixmap(Mgr.scr.disp, parentWindow, path, &iconPixmap, &shapeReturn, &xpmAttributes);
	 iconSAttributes.background_pixmap  = iconPixmap;
	 iconSAttributes.win_gravity  = NorthEastGravity;
	 iconWindow = XCreateWindow(Mgr.scr.disp, parentWindow, winAttributes.width+6-40-5, 3+1, 20, 20, 0, CopyFromParent, InputOutput, CopyFromParent, CWBackPixmap | CWWinGravity, &iconSAttributes);
	 XSelectInput(Mgr.scr.disp, iconWindow, ButtonPressMask | ButtonReleaseMask);
	 
	 snprintf(path, 512, "%s/pics/kill.xpm", MOSQUITOHOME);
	 XpmReadFileToPixmap(Mgr.scr.disp, parentWindow, path, &killPixmap, &shapeReturn, &xpmAttributes);
	 killSAttributes.background_pixmap  = killPixmap;
	 killSAttributes.win_gravity  = NorthEastGravity;
	 killWindow = XCreateWindow(Mgr.scr.disp, parentWindow, winAttributes.width+6-20-4, 3+1, 20, 20, 0, CopyFromParent, InputOutput, CopyFromParent, CWBackPixmap | CWWinGravity, &killSAttributes);
	 XSelectInput(Mgr.scr.disp, killWindow, ButtonPressMask | ButtonReleaseMask);
	 
      } else {
	 titlebarWindow = killWindow = iconWindow = 0;
      }

      if((decorSet & MWM_DECOR_BORDER)) {
	 borderSAttributes.background_pixel = Mgr.getColor(MWINDOWBORDERCOLOR);
	 borderSAttributes.do_not_propagate_mask = ButtonPressMask | ButtonReleaseMask;
	 borderSAttributes.win_gravity = NorthWestGravity;
	 borderWindow[0] = XCreateWindow(Mgr.scr.disp, parentWindow, 0, 0, winAttributes.width+6, 3, 0, CopyFromParent, InputOutput, CopyFromParent, CWBackPixel | CWDontPropagate | CWWinGravity, &borderSAttributes);
	 
	 borderSAttributes.win_gravity = NorthEastGravity;
	 borderWindow[1] = XCreateWindow(Mgr.scr.disp, parentWindow, winAttributes.width+3, 0, 3, winAttributes.height+6+23, 0, CopyFromParent, InputOutput, CopyFromParent, CWBackPixel | CWDontPropagate | CWWinGravity, &borderSAttributes);
	
	 borderSAttributes.win_gravity = SouthWestGravity;
	 borderWindow[2] = XCreateWindow(Mgr.scr.disp, parentWindow, 0, winAttributes.height+3+23, winAttributes.width+6, 3, 0, CopyFromParent, InputOutput, CopyFromParent, CWBackPixel | CWDontPropagate | CWWinGravity, &borderSAttributes);
	 
	 borderSAttributes.win_gravity = NorthWestGravity;
	 borderWindow[3] = XCreateWindow(Mgr.scr.disp, parentWindow, 0, 0, 3, winAttributes.height+6+23, 0, CopyFromParent, InputOutput, CopyFromParent, CWBackPixel | CWDontPropagate | CWWinGravity, &borderSAttributes);
	 
	 if(decorSet & MWM_DECOR_HANDLES) {
	    snprintf(path, 512, "%s/pics/resize.xpm", MOSQUITOHOME);
	    XpmReadFileToPixmap(Mgr.scr.disp, parentWindow, path, &resizePixmap, &shapeReturn,&xpmAttributes);
	    resizeSAttributes.background_pixmap = resizePixmap;
	    resizeSAttributes.win_gravity = SouthEastGravity;
	    //This should also be configurable
	    resizeSAttributes.background_pixel = Mgr.getColor(MWINDOWRESIZERCOLOR);
	    resizeWindow = XCreateWindow(Mgr.scr.disp, parentWindow, winAttributes.width+6-20, winAttributes.height+6+23-20, 20, 20, 0, CopyFromParent, InputOutput, CopyFromParent, CWBackPixmap | CWBackPixel | CWWinGravity, &resizeSAttributes);
	    XSelectInput(Mgr.scr.disp, resizeWindow, ButtonPressMask | ButtonReleaseMask | Button1MotionMask);
	    XShapeSelectInput(Mgr.scr.disp, resizeWindow, ShapeNotifyMask);
	    XShapeCombineMask(Mgr.scr.disp, resizeWindow, ShapeBounding, 0, 0, shapeReturn, ShapeSet);
	    XShapeCombineMask(Mgr.scr.disp, resizeWindow, ShapeClip, 0, 0, shapeReturn, ShapeSet);
	 } else {
	    resizeWindow = 0;
	 }
      } else {
	 for(i = 0; i < 4;i++) {
	    borderWindow[i] = 0;
	 }            
	 resizeWindow = 0;
      }      
      
   } else { //This means we have a shaped window!
//      Mgr.printErr("Shaped Window\n");
      XSelectInput(Mgr.scr.disp, appWindow, EnterWindowMask | SubstructureNotifyMask | SubstructureRedirectMask | VisibilityChangeMask | PropertyChangeMask);
      
      parentWindow = 0;                          //We have no parent
      resizeWindow = 0;
      for(i = 0;i < 4;i++)
	borderWindow[i] = 0;
      
      
      if((decorSet & MWM_DECOR_TITLE)) {
	 
	 if(winAttributes.y > 23)
	   winAttributes.y -= 23;
	 
	 titlebarSAttributes.background_pixel = Mgr.getColor(MWINDOWTITLEBARCOLOR);
	 titlebarSAttributes.bit_gravity = NorthWestGravity;
	 titlebarWindow = XCreateWindow(Mgr.scr.disp, Mgr.scr.rootwin, winAttributes.x, winAttributes.y, winAttributes.width, 23, 0, CopyFromParent, InputOutput, CopyFromParent, CWBackPixel | CWBitGravity, &titlebarSAttributes);

	 XSelectInput(Mgr.scr.disp, titlebarWindow, ButtonPressMask | ButtonReleaseMask | ExposureMask | Button1MotionMask);

	 snprintf(path, 512, "%s/pics/iconify.xpm", MOSQUITOHOME);
	 XpmReadFileToPixmap(Mgr.scr.disp, Mgr.scr.rootwin, path, &iconPixmap, &shapeReturn, &xpmAttributes);
	 iconSAttributes.background_pixmap = iconPixmap;
	 iconWindow = XCreateWindow(Mgr.scr.disp, Mgr.scr.rootwin, winAttributes.x + winAttributes.width-40-5, winAttributes.y+1, 20, 20, 0, CopyFromParent, InputOutput, CopyFromParent, CWBackPixmap, &iconSAttributes);
	 XSelectInput(Mgr.scr.disp, iconWindow, ButtonPressMask | ButtonReleaseMask);
	 
	 snprintf(path, 512, "%s/pics/kill.xpm", MOSQUITOHOME);
	 XpmReadFileToPixmap(Mgr.scr.disp, Mgr.scr.rootwin, path, &killPixmap, &shapeReturn, &xpmAttributes);
	 killSAttributes.background_pixmap = killPixmap;
	 killWindow = XCreateWindow(Mgr.scr.disp, Mgr.scr.rootwin, winAttributes.x + winAttributes.width-20-4, winAttributes.y+1, 20, 20, 0, CopyFromParent, InputOutput, CopyFromParent, CWBackPixmap, &killSAttributes);
	 XSelectInput(Mgr.scr.disp, killWindow, ButtonPressMask | ButtonReleaseMask);
	 
	 drawTitlebarText();
	 
      } else {
	 titlebarWindow = killWindow = iconWindow = 0;
      }
   }
   
   move(winAttributes.x, winAttributes.y);     

}

//Stolen
int Mwindow::selectDecorations(void) { 
   
   int decor, junk, shape;
   unsigned int ujunk;
   Window propReturn;
   PropMwmHints *prop;
   
   decor = MWM_DECOR_ALL;
   if(getMWMHints()) {
      prop = (PropMwmHints *)getMWMHints();
      if(prop->flags & MWM_HINTS_DECORATIONS) {
	 decor = prop->decorations;
      }
   }

   if(decor & MWM_DECOR_ALL) {
      decor &= ~MWM_DECOR_ALL;
      decor = (MWM_DECOR_BORDER | MWM_DECOR_HANDLES | MWM_DECOR_TITLE | MWM_DECOR_MENU | MWM_DECOR_MINIMIZE | MWM_DECOR_MAXIMIZE) & (~decor);
   }
   
   if(decor & (MWM_DECOR_MENU| MWM_DECOR_MINIMIZE | MWM_DECOR_MAXIMIZE)) {
      decor |= MWM_DECOR_TITLE;
   }
   
   XShapeQueryExtents(Mgr.scr.disp, appWindow, &shape, &junk, &junk, &ujunk, &ujunk, &junk, &junk, &junk, &ujunk, &ujunk);
   if(shape) {
      this->shaped = True;
      decor &= ~(MWM_DECOR_BORDER|MWM_DECOR_HANDLES);
   } else {
      this->shaped = False;
   }
   
   if(XGetTransientForHint(Mgr.scr.disp, appWindow, &propReturn)) {
      decor &= ~MWM_DECOR_HANDLES;   
   }
   
   return(decor);
}

int Mwindow::getMWMHints(void) {
   
   int actualFormat, mwmHints;
   Atom actualType, mwmAtom;
   unsigned long nItems, bytesAfter;
   
   mwmAtom = Mgr.getAtom("_MOTIF_WM_HINTS");
   if(XGetWindowProperty(Mgr.scr.disp, appWindow, mwmAtom, 0L, 20L, False, mwmAtom, &actualType, &actualFormat, &nItems, &bytesAfter, (unsigned char **)&mwmHints) == Success) {
      if(nItems >= PROP_MOTIF_WM_HINTS_ELEMENTS) {
	 return(mwmHints);
      }
   }
   return(0);
}

void Mwindow::setup(void) {
   
   XWindowAttributes windowAttributes;
   
   if(shaped == False) {
      XGetWindowAttributes(Mgr.scr.disp, parentWindow, &windowAttributes);
      
      x = windowAttributes.x;
      y = windowAttributes.y;
      width = windowAttributes.width;
      height = windowAttributes.height;
      
      nx = windowAttributes.x;
      ny = windowAttributes.y;
      nwidth = windowAttributes.width;
      nheight = windowAttributes.height;
      
      homeWS = Mgr.getVscreen()->getActiveWS();
      
      //shaped = False;
      alwaysOnTop = False;
      sticky = False;
      shaded = False;  
      minimized = False;
      maximized = False;
      unMapped = True;
   } else {

      XGetWindowAttributes(Mgr.scr.disp, appWindow, &windowAttributes);
      
      x = windowAttributes.x;
      y = windowAttributes.y;
      width = windowAttributes.width;
      height = windowAttributes.height;
      
      nx = windowAttributes.x;
      ny = windowAttributes.y;
      nwidth = windowAttributes.width;
      nheight = windowAttributes.height;
      
      homeWS = Mgr.getVscreen()->getActiveWS();
      
      //shaped = True;
      alwaysOnTop = False;
      sticky = False;
      shaded = False;  
      minimized = False;
      maximized = False;
      unMapped = True;
      
   }
   
}

void Mwindow::drawTitlebarText(void) {
   
   XTextItem xti;
   char *name;
   
   xti.font = XLoadFont(Mgr.scr.disp, Mgr.getFont(TITLEBARFONT));
   xti.delta = 0;
   
   name = getName();
   
   XSetForeground(Mgr.scr.disp, Mgr.scr.gc, Mgr.getColor(MWINDOWTEXTCOLOR));
     
   drawTitlebarGradient();

   xti.chars = new char[strlen(name) + 13];
   sprintf(xti.chars, "%s (0x%lX)", name, appWindow);
   xti.nchars = strlen(xti.chars);
   
   if(xti.nchars > 255)
     xti.nchars = 255;
         
   XDrawText(Mgr.scr.disp, titlebarWindow, Mgr.scr.gc, 5, 16, &xti, 1);

   XUnloadFont(Mgr.scr.disp, xti.font);
   delete [] name;
   delete [] xti.chars;
}
/*
void Mwindow::drawTitlebarGradient(void) {
   
   int i;
   int left, right;
   int colorRight, colorLeft;
   int width;
   
   GC gradientGC;
   XGCValues gcValues;
   
   width = getWidth();
   left = Mgr.getColor(MWINDOWTITLEBARCOLOR);
   right = Mgr.getColor(MWINDOWTITLEBARFADETOCOLOR);
   
   gcValues.function = GXcopy;
   gradientGC = XCreateGC(Mgr.scr.disp, titlebarWindow, GCFunction, &gcValues);
   
   for(i = 0;i < width;i++) {
      colorLeft = ((int)rint(((left & 0xff0000) >> 16) * ((float)(width - i) / (float)width)) << 16) | ((int)rint(((left & 0x00ff00) >> 8) * ((float)(width - i) / (float)width)) << 8) | (int)rint((left & 0x0000ff) * ((float)(width - i) / (float)width));
      colorRight = ((int)rint(((right & 0xff0000) >> 16) * ((float)(i) / (float)width)) << 16) | ((int)rint(((right & 0x00ff00) >> 8) * ((float)(i) / (float)width)) << 8) | (int)rint((right & 0x0000ff) * ((float)(i) / (float)width));
      
      XSetForeground(Mgr.scr.disp, gradientGC, colorLeft + colorRight);
      XDrawLine(Mgr.scr.disp, titlebarWindow, gradientGC, i, 0, i, 23);

   }
   XSync(Mgr.scr.disp, False);
   
   XFreeGC(Mgr.scr.disp, gradientGC);

}
*/
void Mwindow::drawTitlebarGradient(void) {
   
   int i;
   int left, right;
   int redMask, greenMask, blueMask;
   int redShift, greenShift, blueShift;
   int colorRight, colorLeft;
   int width;
   
   GC gradientGC;
   XGCValues gcValues;
   
   width = getWidth();
   left = Mgr.getColor(MWINDOWTITLEBARCOLOR);
   right = Mgr.getColor(MWINDOWTITLEBARFADETOCOLOR);
   
   switch(XDefaultDepth(Mgr.scr.disp, Mgr.scr.screen)) {
    case 16:
      redShift = 11;
      greenShift = 5;
      blueShift = 0;
      
      redMask = 0x1f; 
      greenMask = 0x3f;
      blueMask = 0x1f;
      break;
    case 24:
      redShift = 16;
      greenShift = 8;
      blueShift = 0;
      
      redMask = 0xff;
      greenMask = 0xff;
      blueMask = 0xff;
      break;
    default:
      Mgr.printErr("Cannot understand the depth\n");
      Mgr.quit(-1);
   }
   redMask <<= redShift;
   greenMask <<= greenShift;
   blueMask <<= blueShift;
   
   gcValues.function = GXcopy;
   gradientGC = XCreateGC(Mgr.scr.disp, titlebarWindow, GCFunction, &gcValues);
   
   for(i = 0;i < width;i++) {
      colorLeft = ((int)rint(((left & redMask) >> redShift) * ((float)(width - i) / (float)width)) << redShift) | ((int)rint(((left & greenMask) >> greenShift) * ((float)(width - i) / (float)width)) << greenShift) | (int)rint((left & blueMask) * ((float)(width - i) / (float)width));
      colorRight = ((int)rint(((right & redMask) >> redShift) * ((float)(i) / (float)width)) << redShift) | ((int)rint(((right & greenMask) >> greenShift) * ((float)(i) / (float)width)) << greenShift) | (int)rint((right & blueMask) * ((float)(i) / (float)width));
      
      XSetForeground(Mgr.scr.disp, gradientGC, colorLeft + colorRight);
      XDrawLine(Mgr.scr.disp, titlebarWindow, gradientGC, i, 0, i, 23);

   }
   XSync(Mgr.scr.disp, False);
   
   XFreeGC(Mgr.scr.disp, gradientGC);

}

void Mwindow::move(int x, int y) {

   XWindowAttributes windowAttributes;
   XWindowChanges windowChanges;
   
   if(x > Mgr.scr.width)
     x = Mgr.scr.width - 4;
   if(x < (0 - width))
     x = 3; 
   if(y > Mgr.scr.height)
     y = Mgr.scr.height - 4;
   if(y < (0 - height))
     y = 3;
   
   windowChanges.x = x; 
   windowChanges.y = y;
   
   
   if(shaped == False) {
               
      XConfigureWindow(Mgr.scr.disp, parentWindow, CWX | CWY, &windowChanges);

   } else { //shaped window!

      XGetWindowAttributes(Mgr.scr.disp, appWindow, &windowAttributes);
      
      if(titlebarWindow) {
	 
	 XConfigureWindow(Mgr.scr.disp, titlebarWindow, CWX | CWY, &windowChanges);

	 windowChanges.x = x + (windowAttributes.width - 40 - 5);
	 windowChanges.y = y + 1;
	 XConfigureWindow(Mgr.scr.disp, iconWindow, CWX | CWY, &windowChanges);
	 
	 windowChanges.x = x + (windowAttributes.width - 20 - 4);
	 windowChanges.y = y + 1;
	 XConfigureWindow(Mgr.scr.disp, killWindow, CWX | CWY, &windowChanges);

	 windowChanges.x = x;
	 windowChanges.y = y + 23;
	 XConfigureWindow(Mgr.scr.disp, appWindow, CWX | CWY, &windowChanges);
    
      } else {
	 
	 XConfigureWindow(Mgr.scr.disp, appWindow, CWX | CWY, &windowChanges);
      }
   }
   
   setX(x);
   setY(y);
      
   sendConfigureNotify();
}

void Mwindow::move(void) {
   
   if(Mgr.getMoveModel() == MOVEMODEL_OPAQUE) {
      moveOpaque();
   } else if(Mgr.getMoveModel() == MOVEMODEL_INTERACTIVE) {
      moveInteractive();
   }
}

void Mwindow::moveOpaque(void) {
   
   int x, y;
   int wRootX, wRootY, wChildX, wChildY;
   unsigned int maskReturn;
   
   Window *win;
   Window wRootReturn, wChildReturn;
   XEvent event;
   
   Eventhandler eventHandler;
   
   if(shaped == False) {
      win = &parentWindow;
   } else {
      win = &titlebarWindow;
   }
   
   memset(&event, 0, sizeof (XEvent));
   XQueryPointer(Mgr.scr.disp, *win, &wRootReturn, &wChildReturn, &wRootX, &wRootY, &wChildX, &wChildY, &maskReturn);
   XDefineCursor(Mgr.scr.disp, *win, XCreateFontCursor(Mgr.scr.disp, XC_fleur));
      
   while(1) {

      XMaskEvent(Mgr.scr.disp, (ExposureMask | PointerMotionMask | ButtonReleaseMask), &event);
      
      if(event.type == MotionNotify) {
	 x = event.xmotion.x_root - wChildX;
	 y = event.xmotion.y_root - wChildY;
	 
	 move(x, y);
      } else if(event.type == ButtonRelease) { 
	 break;
      } else {
	 eventHandler.handleEvent(event);
      }
   }
   
   XDefineCursor(Mgr.scr.disp, *win, None);
}

void Mwindow::moveInteractive(void) {
   
   int *newX, *newY;
   int oldX, oldY;
   int offsetX, offsetY;
   Bool firstTime;   
   XEvent event;
   XGCValues gcValues;
   GC xorGC;
   
   memset(&event, 0, sizeof (XEvent));
   
   gcValues.function = GXxor;
   gcValues.foreground = WhitePixel(Mgr.scr.disp, Mgr.scr.screen);
   gcValues.subwindow_mode = IncludeInferiors;
   xorGC = XCreateGC(Mgr.scr.disp, Mgr.scr.rootwin, GCFunction | GCForeground | GCSubwindowMode, &gcValues);
      
   firstTime = True;
   newX = &(event.xmotion.x_root);
   newY = &(event.xmotion.y_root);
   
   XGrabPointer(Mgr.scr.disp, Mgr.scr.rootwin, False, (ButtonReleaseMask | PointerMotionMask), GrabModeAsync, GrabModeAsync, None, XCreateFontCursor(Mgr.scr.disp, XC_fleur), CurrentTime);
   XGrabServer(Mgr.scr.disp);
      
   while(1) {
      
      XMaskEvent(Mgr.scr.disp, (ButtonReleaseMask | PointerMotionMask), &event);
      
      if(event.type == ButtonRelease) {
	 break;
      } else {
	     
	 if(firstTime) {
	    firstTime = !firstTime;
	    offsetX = *newX - getX();
	    offsetY = *newY - getY();
	 } else {
	    XDrawRectangle(Mgr.scr.disp, Mgr.scr.rootwin, xorGC, oldX - offsetX, oldY - offsetY, getWidth(), getHeight());
	 }
	 
	 XDrawRectangle(Mgr.scr.disp, Mgr.scr.rootwin, xorGC, *newX - offsetX, *newY - offsetY, getWidth(), getHeight());
	 oldX = *newX;
	 oldY = *newY;
      }
   }
   
   if(firstTime == False) {
      XDrawRectangle(Mgr.scr.disp, Mgr.scr.rootwin, xorGC, *newX - offsetX, *newY - offsetY, getWidth(), getHeight());
      move(*newX - offsetX, *newY - offsetY);
   }
   
   XFreeGC(Mgr.scr.disp, xorGC);
   XUngrabPointer(Mgr.scr.disp, CurrentTime);
   XUngrabServer(Mgr.scr.disp);
}

void Mwindow::resize(int width, int height) {

   resize(width, height, False);
}

void Mwindow::resize(int width, int height, Bool overrideSizeHints) {
   
   XWindowChanges windowChanges;
   
   if(overrideSizeHints == False) {
      //We have to se if the requested size is allowed 


      if(width > sizeHints->max_width)
	width = sizeHints->max_width;
      if(height > sizeHints->max_height)
        height = sizeHints->max_height;
      
      if(width < sizeHints->min_width)
	width = sizeHints->min_width;
      if(height < sizeHints->min_height)
	height = sizeHints->min_height;
           
      while(width % (sizeHints->width_inc) != sizeHints->base_width % sizeHints->width_inc)
	width--;
      while(height % (sizeHints->height_inc) != sizeHints->base_height % sizeHints->height_inc)
	height--;
      //wierd bug... but lets go with it for a while
      height++;
         
   }

   if(shaped == False) {
	 
      //Get the X and Y coordinates, which we wont change...
//      XGetWindowAttributes(Mgr.scr.disp, parentWindow, &windowAttributes);
      
  //    windowChanges.x = windowAttributes.x;
   //   windowChanges.y = windowAttributes.y;
      windowChanges.width = width;
      windowChanges.height = height;
         
      //Resize the parent window
      XConfigureWindow(Mgr.scr.disp, parentWindow, CWWidth | CWHeight, &windowChanges);
   
      //Resize the borders
      if(titlebarWindow && borderWindow[0]) {
	 windowChanges.width = width;
	 windowChanges.height = height;

	 XConfigureWindow(Mgr.scr.disp, borderWindow[0], CWWidth, &windowChanges);
	 XConfigureWindow(Mgr.scr.disp, borderWindow[1], CWHeight, &windowChanges);
	 XConfigureWindow(Mgr.scr.disp, borderWindow[2], CWWidth, &windowChanges);
	 XConfigureWindow(Mgr.scr.disp, borderWindow[3], CWHeight, &windowChanges);
	 	 
	 //Resize the app window
	 windowChanges.width = width - 6;
	 windowChanges.height = height - 23 - 6;
	 XConfigureWindow(Mgr.scr.disp, appWindow, CWWidth | CWHeight, &windowChanges);
	 
	 //TitlebarWindow
	 XConfigureWindow(Mgr.scr.disp, titlebarWindow, CWWidth, &windowChanges);
	    
      } else if(borderWindow[0]) {
	 
	 windowChanges.width = width;
	 windowChanges.height = height;
	 XConfigureWindow(Mgr.scr.disp, borderWindow[3], CWHeight, &windowChanges);
	 XConfigureWindow(Mgr.scr.disp, borderWindow[0], CWWidth, &windowChanges);
	 XConfigureWindow(Mgr.scr.disp, borderWindow[2], CWWidth, &windowChanges);
	 XConfigureWindow(Mgr.scr.disp, borderWindow[1], CWHeight, &windowChanges);
	 
	 //Resize the app window
	 windowChanges.width = width - 6;
	 windowChanges.height = height - 6;
	 XConfigureWindow(Mgr.scr.disp, appWindow, CWWidth | CWHeight, &windowChanges);

	 
      } else if(titlebarWindow) {
	 	 
	 //Resize the app window
	 windowChanges.width = width;
	 windowChanges.height = height - 23;
	 XConfigureWindow(Mgr.scr.disp, appWindow, CWWidth | CWHeight, &windowChanges);
	 
	 //TitlebarWindow
	 XConfigureWindow(Mgr.scr.disp, titlebarWindow, CWWidth , &windowChanges);
	    
      } else {
	 
	 windowChanges.width = width;
	 windowChanges.height = height;
	 XConfigureWindow(Mgr.scr.disp, appWindow, CWWidth | CWHeight, &windowChanges);
	 	 
      }
      
      setWidth(width);
      setHeight(height);
      if(borderWindow[0]) {
	 drawTitlebarText();
      }

   } else { //Shaped
      
      windowChanges.width = width;
      windowChanges.height = height;
      
    //  if(windowChanges.width < 50)
//	windowChanges.width = 50;
  //    if(windowChanges.height < 23 + 6)
//	windowChanges.height = 23 + 6;
      
      if(appWindow)
	XConfigureWindow(Mgr.scr.disp, appWindow, CWWidth | CWHeight, &windowChanges);
      
      //Resize the titlebar
      if(titlebarWindow) {
	 XConfigureWindow(Mgr.scr.disp, titlebarWindow, CWWidth, &windowChanges);
	 
	 //to fix the gradient
	 //drawTitlebarGradient();
	 drawTitlebarText();
      }
      
      //Resize the iconify button
      windowChanges.x = width - 40 - 5;
      if(iconWindow)
	XConfigureWindow(Mgr.scr.disp, iconWindow, CWX, &windowChanges);
      
      //Resize the kill button
      windowChanges.x = width - 20 - 4;
      if(killWindow)
	XConfigureWindow(Mgr.scr.disp, killWindow, CWX, &windowChanges);
   }

}

void Mwindow::resize(void) {
   
   int width, height;
   int wRootX, wRootY;
   int resizeX, resizeY;
   unsigned int maskReturn;
   
   Window wRootReturn, wChildReturn;
   XWindowAttributes windowAttributes;
   XEvent releaseEvent;
   GC xorGC;
   XGCValues gcValues;
      
   Eventhandler eventHandler;
   
      
   memset(&releaseEvent, 0, sizeof (XEvent));
   width = 0;
   height = 0;
   
   gcValues.function = GXxor;
   gcValues.foreground = WhitePixel(Mgr.scr.disp, Mgr.scr.screen);
   gcValues.subwindow_mode = IncludeInferiors;
   xorGC = XCreateGC(Mgr.scr.disp, Mgr.scr.rootwin, GCFunction | GCForeground | GCSubwindowMode, &gcValues);

   
   //Fix the pointerlocation in the little resizerwindow
   XQueryPointer(Mgr.scr.disp, resizeWindow, &wRootReturn, &wChildReturn, &wRootX, &wRootY, &resizeX, &resizeY, &maskReturn);
   resizeX = 20 - resizeX;
   resizeY = 20 - resizeY;
   
   //Get the X and Y coordinates, which we wont change...
   XGetWindowAttributes(Mgr.scr.disp, parentWindow, &windowAttributes);
      
   XDefineCursor(Mgr.scr.disp, parentWindow, XCreateFontCursor(Mgr.scr.disp, XC_bottom_right_corner));
      
   while(releaseEvent.type != ButtonRelease) {
      
      XNextEvent(Mgr.scr.disp, &releaseEvent);
      
      if(releaseEvent.type == MotionNotify) {
	 
	 if(width && height)
	   XDrawRectangle(Mgr.scr.disp, Mgr.scr.rootwin, xorGC, windowAttributes.x, windowAttributes.y, width, height);
	 
	 width = (releaseEvent.xmotion.x_root - windowAttributes.x) + resizeX;
	 height = (releaseEvent.xmotion.y_root - windowAttributes.y) + resizeY;
	 
	 //resize(width, height);
	 //
	 XDrawRectangle(Mgr.scr.disp, Mgr.scr.rootwin, xorGC, windowAttributes.x, windowAttributes.y, width, height);
   
	 
      } else {
	 eventHandler.handleEvent(releaseEvent);
      }
   }
   
   if(width && height) {
      XDrawRectangle(Mgr.scr.disp, Mgr.scr.rootwin, xorGC, windowAttributes.x, windowAttributes.y, width, height);
      resize(width, height);
   }
   XDefineCursor(Mgr.scr.disp, parentWindow, None);
   XFreeGC(Mgr.scr.disp, xorGC);
   
   XSync(Mgr.scr.disp, False);
   
}

//border 0 = 1
//       1 = 2
//       2 = 3
//       3 = 4
//resize   = 5
//titlebar = 6
//icon     = 7
//kill     = 8
//app      = 9
//parent   = 10

void Mwindow::setWindow(int which, Window w) {
   
   switch(which) {
    case 1:
      borderWindow[0] = w;
      break;
    case 2:
      borderWindow[1] = w;
      break;
    case 3:
      borderWindow[2] = w;
      break;
    case 4:
      borderWindow[3] = w;
      break;
    case 5:
      resizeWindow = w;
      break;
    case 6:
      titlebarWindow = w;
      break;
    case 7:
      iconWindow = w;
      break;
    case 8:
      killWindow = w;
      break;
    case 9:
      appWindow = w;
      break;
    case 10:
      parentWindow = w;
      break;
   }
}

unsigned int Mwindow::getWindow(int which) {
   
   unsigned int windowReturn;
   
   switch(which) {
    case 1:
      windowReturn = borderWindow[0];
      break;
    case 2:
      windowReturn = borderWindow[1];
      break;
    case 3:
      windowReturn = borderWindow[2];
      break;
    case 4:
      windowReturn = borderWindow[3];
      break;
    case 5:
      windowReturn = resizeWindow;
      break;
    case 6:
      windowReturn = titlebarWindow;
      break;
    case 7:
      windowReturn = iconWindow;
      break;
    case 8:
      windowReturn = killWindow;
      break;
    case 9:
      windowReturn = appWindow;
      break;
    default:    // Do we really want this?
    case 10:
      windowReturn = parentWindow;
      break;
   }
   
   return(windowReturn);
}

Bool Mwindow::isTitlebar(Window w) {
   
   if(w == titlebarWindow)
     return(True);
   return(False);
}

Bool Mwindow::isApp(Window w) {
   
   if(w == appWindow)
     return(True);
   return(False);
}

Bool Mwindow::isParent(Window w) {
   
   if(w == parentWindow)
     return(True);
   return(False);
}

Bool Mwindow::isResize(Window w) {

   if(w == resizeWindow)
     return(True);
   return(False);
}

Bool Mwindow::isIcon(Window w) {

   if(w == iconWindow)
     return(True);
   return(False);
}

Bool Mwindow::isKill(Window w) {
   
   if(w == killWindow)
     return(True);
   return(False);
}

// note that we add 1 to the actual borderwindow to make it return 0 on nomatch
int Mwindow::isBorder(Window w) {
                                         
   int i;                                //   ____1_____   
                                         //  |          |  
   for(i = 0; i < 4; i++) {              //  |          |  
      if(w == borderWindow[i])           // 4|          |2 
	return(i + 1);                   //  |          |  
   }                                     //  |__________|  
                                         //       3        
   return(0);
}

void Mwindow::setFocus(void) {
   
   int i;

   if(borderWindow[0]) {
      //Hilighigt borders 
      for(i = 0;i < 4;i++) {
	 XSetWindowBackground(Mgr.scr.disp, borderWindow[i], Mgr.getColor(HILIGHTEDMWINDOWBORDERCOLOR));
	 XClearWindow(Mgr.scr.disp, borderWindow[i]);
      }
   }
   
   if(resizeWindow) {
      //hiligt resizer
      XSetWindowBackground(Mgr.scr.disp, resizeWindow, Mgr.getColor(HILIGHTEDMWINDOWRESIZERCOLOR));
      XClearWindow(Mgr.scr.disp, resizeWindow);
   }
   
   if(appWindow)
     XSetInputFocus(Mgr.scr.disp, appWindow, RevertToPointerRoot, CurrentTime);
      
   XSync(Mgr.scr.disp, False);      
}

void Mwindow::removeFocus(void) {   // doesnt actually remove focus but unhilights the window
   
   int i;
   
   if(borderWindow[0]) {
      //Hilighigt borders 
      for(i = 0;i < 4;i++) {
	 XSetWindowBackground(Mgr.scr.disp, borderWindow[i], Mgr.getColor(MWINDOWBORDERCOLOR));
	 XClearWindow(Mgr.scr.disp, borderWindow[i]);
      }
      
      if(resizeWindow) {
	 //hiligt resizer
	 XSetWindowBackground(Mgr.scr.disp, resizeWindow, Mgr.getColor(MWINDOWRESIZERCOLOR));
	 XClearWindow(Mgr.scr.disp, borderWindow[i]);
      }
   }      
}

void Mwindow::setSticky(Bool removeSticky) {

   if(sticky == True) {
      if(removeSticky == True) {
	 this->removeSticky(False);
      }
   } else {
      sticky = True;
   }
}

void Mwindow::removeSticky(Bool setSticky) {
   
   if(sticky == False) {
      if(setSticky == True) {
	 this->setSticky(False);
      }
   } else {
      sticky = False;
   }
}

void Mwindow::setAlwaysOnTop(Bool removeAlwaysOnTop) {

   if(alwaysOnTop == True) {
      if(removeAlwaysOnTop == True) {
	 this->removeAlwaysOnTop(False);
      }
   } else {
      alwaysOnTop = True;
      raise();        //we want to raise the window too
   }
}

void Mwindow::removeAlwaysOnTop(Bool setAlwaysOnTop) {

   if(alwaysOnTop == False) {
      if(setAlwaysOnTop == True) {
	 this->setAlwaysOnTop(False);
      }
   } else {
      alwaysOnTop = False;
   }
}

char *Mwindow::getName(void) {
   
   char *name;
  
   if(!XFetchName(Mgr.scr.disp, appWindow, &name)) {
      name = new char[12];   
      strcpy(name, "Untitled");
   }
   
   return(name);
}

void Mwindow::setName(const char *name) {
   
   XStoreName(Mgr.scr.disp, appWindow, name);
}

char *Mwindow::getIconName(void) {
   
   char *name;
         
   if(!XGetIconName(Mgr.scr.disp, appWindow, &name)) {
      name = new char[12];   
      strcpy(name, "Untitled");
   }
      
   return(name);
}



Bool Mwindow::isMember(Window w) {
   
   if(appWindow == w || resizeWindow == w || titlebarWindow == w || killWindow == w || iconWindow == w || parentWindow == w) {
      return(True);
   } else if(borderWindow[0] == w || borderWindow[1] == w || borderWindow[2] == w || borderWindow[3] == w) {
      return(True);
   } else {
      return(False);
   }
}

void Mwindow::minimize(Bool normalize) {
   
   if(minimized == True) {
      if(normalize == True) {
	 this->normalize();
      }
   } else {
      unmap();
      removeFocus();
      minimized = True;
      iconifyEffect();
   }
}

void Mwindow::placeOnScreen(void) {
   
   switch(Mgr.getPlacementModel()) {
    case PLACEMENTMODEL_SMART:
      placeSmart();
      break;
    case PLACEMENTMODEL_POINTER:
      placeByPointer();
      break;
    case PLACEMENTMODEL_APP:
      placeByApp();
      break;
   }
}

void Mwindow::placeSmart(void) {
   
   
}

void Mwindow::placeByPointer(void) {
   
   int *newX, *newY;
   int oldX, oldY;
   int junkInt;
   unsigned int uJunkInt;
   Bool firstTime;
   Window junkWin;
   GC xorGC;
   XGCValues gcValues;
   XEvent event;
   
   memset(&event, 0, sizeof (XEvent));
   firstTime = True;
   
   gcValues.function = GXxor;
   gcValues.foreground = WhitePixel(Mgr.scr.disp, Mgr.scr.screen);
   gcValues.subwindow_mode = IncludeInferiors;
   xorGC = XCreateGC(Mgr.scr.disp, Mgr.scr.rootwin, GCFunction | GCForeground | GCSubwindowMode, &gcValues);
   
   newX = &(event.xmotion.x_root);
   newY = &(event.xmotion.y_root);
   
   XQueryPointer(Mgr.scr.disp, Mgr.scr.rootwin, &junkWin, &junkWin, newX, newY, &junkInt, &junkInt, &uJunkInt);
   XGrabPointer(Mgr.scr.disp, Mgr.scr.rootwin, False, (ButtonPressMask | PointerMotionMask), GrabModeAsync, GrabModeAsync, None, None, CurrentTime);
   XGrabServer(Mgr.scr.disp);

   do {
      
      if(event.type == ButtonPress) {
	 break;
      } else {
	 
	 if(firstTime) {
	    firstTime = !firstTime;
	 } else {
	    XDrawRectangle(Mgr.scr.disp, Mgr.scr.rootwin, xorGC, oldX, oldY, getWidth(), getHeight());
	 }
	 
	 XDrawRectangle(Mgr.scr.disp, Mgr.scr.rootwin, xorGC, *newX, *newY, getWidth(), getHeight());
	 
	 oldX = *newX;
	 oldY = *newY;
      }
      
      XMaskEvent(Mgr.scr.disp, PointerMotionMask | ButtonPressMask, &event);

   } while(1);

   if(firstTime == False) {
      XDrawRectangle(Mgr.scr.disp, Mgr.scr.rootwin, xorGC, *newX, *newY, getWidth(), getHeight());
      move(*newX, *newY);
   }

   XFreeGC(Mgr.scr.disp, xorGC);
   XUngrabPointer(Mgr.scr.disp, CurrentTime);
   XUngrabServer(Mgr.scr.disp);
}


void Mwindow::placeByApp(void) {
   
}

   
void Mwindow::iconifyEffect(void) {
   
   int i, MAX;
   int tw, th, tx, ty;
   XGCValues gcValues;
   GC xorGC;
   
   gcValues.foreground = WhitePixel(Mgr.scr.disp, Mgr.scr.screen);
   gcValues.function = GXxor;
   gcValues.subwindow_mode = IncludeInferiors;
   xorGC = XCreateGC(Mgr.scr.disp, Mgr.scr.rootwin, GCFunction | GCSubwindowMode | GCForeground, &gcValues);
   
   tw = width;
   th = height;
   tx = x;
   ty = y;
   MAX = 3;
   XSync(Mgr.scr.disp, False);
   
   XGrabServer(Mgr.scr.disp);
   
   for(i = 0;i < MAX;i++) {
      
      tw /= 2;
      th /= 2;
      tx += (int)rint(0.25 * tw);
      ty += (int)rint(0.25 * th);
      
      XDrawRectangle(Mgr.scr.disp, Mgr.scr.rootwin, xorGC, tx, ty, tw, th);
      XSync(Mgr.scr.disp, False);
      usleep(100000);
      XDrawRectangle(Mgr.scr.disp, Mgr.scr.rootwin, xorGC, tx, ty, tw, th);
      XSync(Mgr.scr.disp, False);
   }
   
   XFreeGC(Mgr.scr.disp, xorGC);
   XUngrabServer(Mgr.scr.disp);
}

void Mwindow::raise(void) {
   
   if(shaped == False) {
      XRaiseWindow(Mgr.scr.disp, parentWindow);
   } else {
      if(titlebarWindow) {
	 XRaiseWindow(Mgr.scr.disp, titlebarWindow);
	 XRaiseWindow(Mgr.scr.disp, iconWindow);
	 XRaiseWindow(Mgr.scr.disp, killWindow);
      }
      XRaiseWindow(Mgr.scr.disp, appWindow);
   }
   
}

void Mwindow::lower(void) {
   
   if(shaped == False) {
      XLowerWindow(Mgr.scr.disp, parentWindow);
   } else {
      if(titlebarWindow) {
	 XLowerWindow(Mgr.scr.disp, titlebarWindow);
	 XLowerWindow(Mgr.scr.disp, iconWindow);
	 XLowerWindow(Mgr.scr.disp, killWindow);
      }
      XLowerWindow(Mgr.scr.disp, appWindow);
   }
   
}

void Mwindow::addToDock(void) {
   
   int Mwin;
   
   Mwin = Mgr.winToMwin(appWindow);
   
   Mgr.getDock()->addDockApp(appWindow);
   
   appWindow = 0;
   destroy();
   
   Mgr.packMwinStack(Mwin);
   delete Mgr.getMwindow(Mgr.getNumOfMwins());
   Mgr.decreaseNumOfMwins();
}

void Mwindow::map(void) {
   
   int i;
   
   if(shaded == True) {
      if(titlebarWindow) {
	 XMapWindow(Mgr.scr.disp, titlebarWindow);
      }
      if(killWindow) {
	 XMapWindow(Mgr.scr.disp, killWindow);
	 XMapWindow(Mgr.scr.disp, iconWindow);
      }
      if(parentWindow) {
	 XMapWindow(Mgr.scr.disp, parentWindow); 
      }
   } else {
      if(titlebarWindow) {
	 XMapWindow(Mgr.scr.disp, titlebarWindow);
      }
      if(killWindow) {
	 XMapWindow(Mgr.scr.disp, killWindow);
	 XMapWindow(Mgr.scr.disp, iconWindow);
      }
      if(borderWindow[0]) {
	 for(i = 0;i < 4;i++) {
	    XMapWindow(Mgr.scr.disp, borderWindow[i]); 
	 }
      }
      if(resizeWindow) {
	 XMapWindow(Mgr.scr.disp, resizeWindow); 
      }
      if(appWindow) {
	 XMapWindow(Mgr.scr.disp, appWindow); 
      }
      if(parentWindow) {
	 XMapWindow(Mgr.scr.disp, parentWindow); 
      }
   }
   unMapped = False;
}

void Mwindow::unmap(void) {
   
   if(shaped == False) {
      XUnmapWindow(Mgr.scr.disp, parentWindow);
   } else {
      if(titlebarWindow) {
	 XUnmapWindow(Mgr.scr.disp, titlebarWindow);
	 XUnmapWindow(Mgr.scr.disp, iconWindow);
	 XUnmapWindow(Mgr.scr.disp, killWindow);
      }
      XUnmapWindow(Mgr.scr.disp, appWindow);
   }
   unMapped = True;
}

void Mwindow::shade(Bool unShade) {

   if(shaded == False) {
      if(titlebarWindow && borderWindow[0]) {
	 nheight = height;
	 nwidth = width;
	 resize(width, 23 + 6, True);
	 shaded = True;
      } else if(titlebarWindow) {
      	 nheight = height;
	 nwidth = width;
	 resize(width, 23, True);
	 shaded = True;
      }
   } else if(unShade) {
      this->unShade(False);
   }
}

void Mwindow::unShade(Bool shade) {

   if(shaded == True) {
      height = nheight;
      width = nwidth;
      resize(width, height, True);
      nheight = nwidth = 0;
      shaded = False;
   } else if(shade) {
      this->shade(False);
   }
}

void Mwindow::maximize(Bool normalize) {
   
   int x, y;
   int width, height;
   
   x = 0;
   y = 0;
   
   if(maximized == False) { 
      
      nx = getX();
      ny = getY();
      nwidth = getWidth();
      nheight = getHeight();
      maximized = True;
      
      if((Mgr.getDock()->getNumOfDockWins())) {
	 switch((Mgr.getDock()->getPosition())) {
	  case UPPERLEFT:
	    if(Mgr.getDock()->getGrowDirection() == RIGHT) {
	       x = 0;
	       y = 64;
	    } else if(Mgr.getDock()->getGrowDirection() == DOWN) {
	       x = 64;
	       y = 0;
	    }
	    width = Mgr.scr.width - x;
	    height = Mgr.scr.height - y;
	    break;
	  default:
	  case UPPERRIGHT:
	    if(Mgr.getDock()->getGrowDirection() == LEFT) {
	       y = 64;
	       width = Mgr.scr.width;
	    } else if(Mgr.getDock()->getGrowDirection() == DOWN) {
	       width = Mgr.scr.width - 64;
	    }
	    height = Mgr.scr.height - y;
	    break;
	  case LOWERRIGHT:
	    if(Mgr.getDock()->getGrowDirection() == LEFT) {
	       width = Mgr.scr.width;
	       height = Mgr.scr.height - 64;
	    } else if(Mgr.getDock()->getGrowDirection() == UP) {
	       width = Mgr.scr.width - 64;
	       height = Mgr.scr.height;
	    }
	    break;
	  case LOWERLEFT:
	    if(Mgr.getDock()->getGrowDirection() == RIGHT) {
	       width = Mgr.scr.width;
	       height = Mgr.scr.height - 64;
	    } else if(Mgr.getDock()->getGrowDirection() == UP) {
	       x = 64;
	       height = Mgr.scr.height;
	    }
	    width = Mgr.scr.width - x;
	    break;
	 }
      } else {
	 width = Mgr.scr.width;
	 height = Mgr.scr.height;
      }
      
      move(x, y);
      resize(width, height);
   
   } else if(normalize){
      this->normalize();
   }
   
}

void Mwindow::normalize(void) {
   
   if(maximized) {
      move(nx, ny);
      resize(nwidth, nheight);
      
      nx = 0;
      ny = 0;
      nwidth = 0;
      nheight = 0;
      maximized = False;
   }
   if(minimized) {
      map();
      minimized = False;
   }
   
}

void Mwindow::destroy(void) {
   
   if(shaped == False) {
      XDestroyWindow(Mgr.scr.disp, parentWindow);
   } else {
      if(titlebarWindow) {
	 XDestroyWindow(Mgr.scr.disp, titlebarWindow);
	 XDestroyWindow(Mgr.scr.disp, iconWindow);
	 XDestroyWindow(Mgr.scr.disp, killWindow);
      }
      XDestroyWindow(Mgr.scr.disp, appWindow);
   }
      
   sticky = False;
   shaped = False;
   titlebarWindow = 0;
   killWindow = 0;
   iconWindow = 0;
   parentWindow = 0;
   appWindow = 0;
   resizeWindow = 0;
   borderWindow[0] = 0;
   XFree(sizeHints);
   
}

Mwindow &Mwindow::copyMwin(const Mwindow *MwinArg) {
   
   int i;
   
   x = MwinArg->x;
   y = MwinArg->y;
   width = MwinArg->width;
   height = MwinArg->height;
   
   nx = MwinArg->nx;
   ny = MwinArg->ny;
   nwidth = MwinArg->nwidth;
   nheight = MwinArg->nheight;          
   
   appWindow = MwinArg->appWindow;
   parentWindow = MwinArg->parentWindow;
   titlebarWindow = MwinArg->titlebarWindow;
   killWindow = MwinArg->killWindow;
   iconWindow = MwinArg->iconWindow;  
   for(i = 0;i < 4; i++)
     borderWindow[i] = MwinArg->borderWindow[i];
   resizeWindow = MwinArg->resizeWindow;
   
   alwaysOnTop = MwinArg->alwaysOnTop;
   sticky = MwinArg->sticky;
   shaded = MwinArg->shaded;   
   minimized = MwinArg->minimized;
   maximized = MwinArg->maximized;
   homeWS = MwinArg->homeWS;    
   decorSet = MwinArg->decorSet;
   unMapped = MwinArg->unMapped;
   shaped = MwinArg->shaped;
   sizeHints = MwinArg->sizeHints;
   
   return(*this);
}

void Mwindow::kill(void) {
   
   XEvent e;
   long mask;
   
   memset(&e, 0, sizeof(e));
   
   e.xclient.type = ClientMessage;
   e.xclient.message_type = Mgr.getAtom("WM_PROTOCOLS");
   e.xclient.format = 32;
   e.xclient.data.l[0] = Mgr.getAtom("WM_DELETE_WINDOW");
   e.xclient.data.l[1] = CurrentTime;
   mask = 0L;
   
   //fadeEffect();
   if(appWindow) {
      e.xclient.window = appWindow;
      XSendEvent(Mgr.scr.disp, appWindow, False, mask, &e);
   } else {
      e.xclient.window = parentWindow;
      XSendEvent(Mgr.scr.disp, parentWindow, False, mask, &e);
   }
}

void Mwindow::fadeEffect(void) {
   
   Window fadeWindow;
   
   fadeWindow = XCreateSimpleWindow(Mgr.scr.disp, Mgr.scr.rootwin, x, y, width, height, 0, 0, 0);
   
   XCopyArea(Mgr.scr.disp, Mgr.scr.rootwin, fadeWindow, Mgr.scr.gc, 0, 0, width, height, 0, 0);
   XSync(Mgr.scr.disp, False);
   XMapWindow(Mgr.scr.disp, fadeWindow);
   
   
}

void Mwindow::repaint(void) {
   
   drawTitlebarText();
}

void Mwindow::sendConfigureNotify(void) {
   
   int x, y;
   unsigned int depthReturn;
   
   Window junkWindow;
   XConfigureEvent configureEvent;
   
   configureEvent.type = ConfigureNotify;
   configureEvent.event = appWindow;
   configureEvent.window = appWindow;
   
   XGetGeometry(Mgr.scr.disp, appWindow, &junkWindow, &x, &y, (unsigned int *)&configureEvent.width, (unsigned int *)&configureEvent.height, (unsigned int *)&configureEvent.border_width, &depthReturn);
   
   if(shaped == False) {  // we have a parent and must adapt our coordinates
      XTranslateCoordinates(Mgr.scr.disp, parentWindow, Mgr.scr.rootwin, x, y, &x, &y, &junkWindow);
   }
   
   configureEvent.x = x;
   configureEvent.y = y;
   configureEvent.above = None;
   configureEvent.override_redirect = 0;
   
   XSendEvent(Mgr.scr.disp, appWindow, False, StructureNotifyMask, (XEvent*)&configureEvent);
}

void Mwindow::fixSizeHints(void) {
   
   long suppliedReturn;
   XWindowAttributes windowAttributes;

   
   if(sizeHints)
     XFree(sizeHints);
   sizeHints = XAllocSizeHints();
   
   
   if((XGetWMNormalHints(Mgr.scr.disp, appWindow, sizeHints, &suppliedReturn)) == 0) {
      sizeHints->flags = 0;
   }
   
//   Mgr.printErr("SizeHint flags: %d\n", sizeHints->flags);
   
   if(sizeHints->flags & PResizeInc) {
      if(sizeHints->width_inc == 0)
	sizeHints->width_inc = 1;
      if(sizeHints->height_inc == 0)
	sizeHints->height_inc = 1;
   } else {
      sizeHints->width_inc = 1;
      sizeHints->height_inc = 1;
   }
   
   if(sizeHints->flags & (USPosition | PPosition)) {
      x = sizeHints->x;
      y = sizeHints->y;
      /*Mgr.printErr("user specified position: %d %d\n", sizeHints->x, sizeHints->y);
      Mgr.printErr("minimum aspect: %d %d\n", sizeHints->min_aspect.x, sizeHints->min_aspect.y);
      Mgr.printErr("maximum aspect: %d %d\n", sizeHints->max_aspect.x, sizeHints->max_aspect.y);*/
   } else {
/*      Mgr.printErr("default position: 0 0\n");
      Mgr.printErr("minimum aspect: %d %d\n", sizeHints->min_aspect.x, sizeHints->min_aspect.y);
      Mgr.printErr("maximum aspect: %d %d\n", sizeHints->max_aspect.x, sizeHints->max_aspect.y);*/

      x = 0;
      y = 0;
   }
  
   if((sizeHints->flags & PBaseSize) == 0) {
      if(sizeHints->flags & PMinSize) {
	 sizeHints->base_width = sizeHints->min_width;
	 sizeHints->base_height = sizeHints->min_height;
      } else {
	 sizeHints->base_width = 1;
	 sizeHints->base_height = 1;
      }
   }
   
   if(sizeHints->flags & (USSize | PSize)) {
      width = sizeHints->width;
      height = sizeHints->height;
   //   Mgr.printErr("Userspecified size is: %d x %d\n", width, height);
   } else {
     
      XGetWindowAttributes(Mgr.scr.disp, appWindow, &windowAttributes);
      width = windowAttributes.width;
      height = windowAttributes.height;
      
//      Mgr.printErr("Defaulting size to basesize: %d x %d\n", width, height);
   }
      
   if((sizeHints->flags & PMinSize) == 0) {
      sizeHints->min_width = sizeHints->base_width;
      sizeHints->min_height = sizeHints->base_height;
   }
   
   if((sizeHints->flags & PMaxSize) == 0) {
      sizeHints->max_width = MAX_WINDOW_WIDTH;
      sizeHints->max_height = MAX_WINDOW_HEIGHT;
   }
   
//   Mgr.printErr("flags: %d\n", sizeHints->flags);
//   Mgr.printErr("basesize: %d %d\n", sizeHints->base_width, sizeHints->base_height);
//   Mgr.printErr("minsize: %d %d\n", sizeHints->min_width, sizeHints->min_height);
   
   if(sizeHints->min_height <= 0) {
      Mgr.printErr("minimum height is negative, this should never happen!\n");
      sizeHints->min_height = 1;
   }
   if(sizeHints->min_width <= 0) {
      Mgr.printErr("minimum width is negative, this should never happen!\n");
      sizeHints->min_width = 1;
   }
   if(sizeHints->max_height < sizeHints->min_height) {
      Mgr.printErr("maximum height is larger than allowed, this should never happen!\n");
      sizeHints->max_height = MAX_WINDOW_HEIGHT;
   }
   if(sizeHints->max_width < sizeHints->min_width) {
      Mgr.printErr("maximum width is larger than allowed, this should never happen!\n");
      sizeHints->max_width = MAX_WINDOW_WIDTH;
   }
   
   if(sizeHints->min_height > sizeHints->max_height) {
      Mgr.printErr("minimum height is larger than maximum height, this should never happen!\n");
      sizeHints->min_height = 1;
   }
   if(sizeHints->min_width > sizeHints->max_width) {
      Mgr.printErr("minimum width is larger than maximum width, this should never happen!\n");
      sizeHints->min_width = 1;
   }
   
   if(shaped == False) {
      if((decorSet & MWM_DECOR_TITLE) && (decorSet & MWM_DECOR_BORDER)) {
	 sizeHints->max_width += 6;
	 sizeHints->max_height += (6 + 23);
	 sizeHints->min_width += 6;
	 sizeHints->min_height += (6 + 23);
	 	 
      } else if(decorSet & MWM_DECOR_BORDER) {
	 sizeHints->max_width += 6;
	 sizeHints->max_height += 6;
	 sizeHints->min_width += 6;
	 sizeHints->min_height += 6;
	 
      } else if(decorSet & MWM_DECOR_TITLE) {
	 sizeHints->max_height += 23;
	 sizeHints->min_height += 23;
      }
   } else {
      if(decorSet & MWM_DECOR_TITLE) {
	 sizeHints->max_height += 23;
	 sizeHints->min_height += 23;
      }
   }
}
