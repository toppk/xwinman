#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <X11/Xproto.h>
#include <X11/Xutil.h>
#include "Dockpopupmenu.h"
#include "Dock.h"
#include "Fonts.h"
#include "Colors.h"
#include "Mosquito.h"
#include "Manager.h"
#include "Misc.h"
#include "Configfile.h"

extern Manager Mgr;

static void dockOperation(const char *command) {
   
   Window appWindow;
   
   if(!strcmp("save", command)) {
      Mgr.getDock()->saveDockWinPositions();
   } else if(!strcmp("add-NotYet", command)) {
   
   } else {
      appWindow = strtoul(command, NULL, 10);
      Mgr.getDock()->removeDockApp(appWindow);
   }
}

Dockpopupmenu::Dockpopupmenu(void) {
   
   int i;
   int numOfItems;
   int itemWidth, itemHeight, menuBorderWidth, menuBorderHeight;
   char command[255];
   char *appName;
   Window tmpWin;
   Dock *dock;
   
   itemWidth = 100;
   itemHeight = 20;
   menuBorderWidth = 50;
   menuBorderHeight = 50;
   menu[1] = NULL;
      
   dock = Mgr.getDock();
   numOfItems = dock->getNumOfDockWins();
   
   menu[1] = new Popupmenu(trekkify, dockOperation, numOfItems, itemWidth + menuBorderWidth, numOfItems * itemHeight + menuBorderHeight, itemWidth, itemHeight, XLoadFont(Mgr.scr.disp, Mgr.getFont(DOCKPOPUPMENUFONT)));
   
   for(i = 0;i < numOfItems;i++) {
      tmpWin = dock->getAppWindow(i);
      snprintf(command, 255, "%ul", tmpWin);

      if((XFetchName(Mgr.scr.disp, tmpWin, &appName)) == 0) {
	 appName = new char[12];
	 strcpy(appName, "Untitled");
      }

      if(strrchr(appName, '/')) {
	 menu[1]->createItem(strrchr(appName, '/') + 1, command); //WARNING!!
      } else {
	 menu[1]->createItem(appName, command);
      }
      delete [] appName;
   }
   
   numOfItems = 3;
   menu[0] = new Popupmenu(trekkify, dockOperation, numOfItems, itemWidth + menuBorderWidth, numOfItems * itemHeight + menuBorderHeight, itemWidth, itemHeight, XLoadFont(Mgr.scr.disp, Mgr.getFont(DOCKPOPUPMENUFONT)));
   menu[0]->createItem("Add app", "add");
   menu[0]->createItem("Delete app", menu[1]);
   menu[0]->createItem("Save dock", "save");
}

Dockpopupmenu::~Dockpopupmenu(void) {
   
   delete menu[0];
}

void Dockpopupmenu::pop(void) {
   
   menu[0]->pop();
}


