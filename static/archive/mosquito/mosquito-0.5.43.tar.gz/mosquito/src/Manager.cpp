#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdarg.h>
#include <math.h>
#include <sys/param.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <X11/Xproto.h>
#include <X11/Xutil.h>
#include "Manager.h"
#include "Mosquito.h"
#include "Fonts.h"
#include "Colors.h"
#include "Iconpopupmenu.h"
#include "Mwindowpopupmenu.h"
#include "Configfile.h"
#include "Eventhandler.h"
#include "Vscreen.h"
#include "Mwindow.h"
#include "Dock.h"
#include "Misc.h"

Manager::Manager(void) {

}

Manager::~Manager(void) {

}

int Manager::getNumOfMwins(void) {
   
   return(numOfMwins);
}

void Manager::setNumOfMwins(int num) {
   
   numOfMwins = num;
}

void Manager::increaseNumOfMwins(void) {
   
   numOfMwins++;
}

void Manager::decreaseNumOfMwins(void) {
   
   numOfMwins--;
}

Mwindow *Manager::getMwindow(int Mwin) {
   return(this->Mwin[Mwin]);
}

void Manager::createMwindow(int Mwin) {
   
   this->Mwin[Mwin] = new Mwindow();
}

void Manager::listMwins(void) {
   
   int i;
   
   printErr("numOfMwins: %d\n", getNumOfMwins());
   for(i = 1;i < 15; i++)
     printErr("mwin: %d, X: %d, Y: %d, state: %d\n", i, Mwin[i]->getX(), Mwin[i]->getY(), Mwin[i]->getState());
}

//direction can be either 0 = down or 1 = up
void Manager::circulateMwins(int direction) {
   
   int counter, revertTo; 
   static int lastRaisedMwin = 0;
   Bool gotOne;
   Window currentFocus;
   
   gotOne = False;
   counter = getNumOfMwins();
   
   //First see if we have an active window, if so circulate around that
   XGetInputFocus(scr.disp, &currentFocus, &revertTo);
   if(winToMwin(currentFocus)) {
      lastRaisedMwin = winToMwin(currentFocus);
   }
   
   while(gotOne != True && counter) {
      if(direction == UP) {
	 if(lastRaisedMwin < getNumOfMwins()) {
	    
	    lastRaisedMwin++;
	    
	    if(Mwin[lastRaisedMwin]->getWS() == getVscreen()->getActiveWS() && (Mwin[lastRaisedMwin]->getState() & (S_SHADED | S_MINIMIZED | S_UNMAPPED)) == 0)
	      gotOne = True;
	    else 
	      counter--;
	    
	 } else if(lastRaisedMwin >= getNumOfMwins()) {
	    
	    lastRaisedMwin = 0;
	 
	 }
      } else if(direction == DOWN) {
	 if(lastRaisedMwin > 1) {
	 
	    lastRaisedMwin--;
	    if(Mwin[lastRaisedMwin]->getWS() == getVscreen()->getActiveWS() && (Mwin[lastRaisedMwin]->getState() & (S_SHADED | S_MINIMIZED | S_UNMAPPED)) == 0)
	      gotOne = True;
	    else
	      counter--;
	    
	 } else if(lastRaisedMwin <= 1) {
	 
	    lastRaisedMwin = getNumOfMwins() + 1;
	 
	 }
      } else {
	 // If wrong argument is given... 
	 return;
      }
   }
   
   if(lastRaisedMwin && gotOne == True) {
      Mwin[lastRaisedMwin]->raise();
      
      if(winToMwin(currentFocus))
	Mwin[winToMwin(currentFocus)]->removeFocus();
      
      Mwin[lastRaisedMwin]->setFocus();
   }
}

Bool Manager::getDebugMode(void) {
   
   return(debugMode);
}

void Manager::setDebugMode(Bool mode) {
   
   debugMode = mode;
}

int Manager::getFocusModel(void) {
   
   return(focusModel);
}

void Manager::setFocusModel(int model) {

   focusModel = model;
}

int Manager::getMoveModel(void) {
   
   return(moveModel);
}

void Manager::setMoveModel(int model) {

   moveModel = model;
}

int Manager::getPlacementModel(void) {
   
   return(placementModel);
}

void Manager::setPlacementModel(int model) {

   placementModel = model;
}

int Manager::getStickyIcons(void) {
  
   return(stickyIcons);
}

char *Manager::getFont(int name) {
   
   //printErr("%d <%s>\n", name, fonts[name]);
   return(fonts[name]);
   
}

int Manager::getDoubleClickDelay(void) {
   
   return(doubleClickDelay);
}

void Manager::generalSetup(void) {
   
   char *ptr;
   Configfile cf;
   
   if((ptr = cf.getByCharToChar("[LookAndFeel begin]", "DebugMode"))) {   //THIS IS WRONG!!! SHOULD BE SET FIRST THING!!!!
      if(strstr(ptr, "Off") != NULL) {
	 debugMode = 0;
      } else if(strstr(ptr, "On") != NULL) {
	 debugMode = 1;
      }   
      delete [] ptr;
   }
   
   if((ptr = cf.getByCharToChar("[LookAndFeel begin]", "FocusModel"))) {
      if(strstr(ptr, "SloppyFocus") != NULL) {
	 focusModel = FOCUSMODEL_SLOPPY;
      } else if(strstr(ptr, "ClickToFocus") != NULL) {
	 focusModel = FOCUSMODEL_CLICKTOFOCUS;
      } else if(strstr(ptr, "FocusFollowsMouse") != NULL) {
	 focusModel = FOCUSMODEL_FOCUSFOLLOWSMOUSE;
      }
      delete [] ptr;
   } else {
      focusModel = FOCUSMODEL_SLOPPY;     //default
   }
   
   if((ptr = cf.getByCharToChar("[LookAndFeel begin]", "PlacementModel"))) {
      if(strstr(ptr, "SmartPlacement") != NULL) {
	 placementModel = PLACEMENTMODEL_SMART;
      } else if(strstr(ptr, "AppPlacement") != NULL) {
	 placementModel = PLACEMENTMODEL_APP;
      } else if(strstr(ptr, "PointerPlacement") != NULL) {
	 placementModel = PLACEMENTMODEL_POINTER;
      }
      delete [] ptr;
   } else {
      placementModel = PLACEMENTMODEL_APP;
   }

   if((ptr = cf.getByCharToChar("[LookAndFeel begin]", "NumberOfWorkspaces"))) {

      if(atoi(ptr)) {
	 getVscreen()->setNumOfWSs(atoi(ptr));
      } else {
	 getVscreen()->setNumOfWSs(4);
      }
      delete [] ptr;        
   } else {
      printErr("No number of workspaces specified, quitting...\n");
      quit(-123);
   }
   
   if((ptr = cf.getByCharToChar("[LookAndFeel begin]", "MoveModel"))) {
      if(strstr(ptr, "OpaqueMove") != NULL) {
	 moveModel = 0;
      } else if(strstr(ptr, "InteractiveMove") != NULL) {
	 moveModel = 1;
      }
      delete [] ptr;
   }
   
   doubleClickDelay = cf.getByCharToInt("[LookAndFeel begin]", "DoubleClickDelay");
   
   if((ptr = cf.getByCharToChar("[LookAndFeel begin]", "StickyIcons"))) {
      if(strstr(ptr, "Off") != NULL) {
	 stickyIcons = 0;
      } else if(strstr(ptr, "On") != NULL) {
	 stickyIcons = 1;
      }
      delete [] ptr;
   }
   
}

void Manager::vscreenSetup(void) {
   
   vscreen = new Vscreen();
}

void Manager::vscreenSetdown(void) {
   
   delete vscreen;
}

Vscreen *Manager::getVscreen(void) {
   
   return(vscreen);
}

void Manager::rootPopupMenuSetup(void) {
   
   rootPopupMenu = new Rootpopupmenu();
}

void Manager::rootPopupMenuSetdown(void) {
   
//   delete rootPopupMenu;
}

Rootpopupmenu *Manager::getRootPopupMenu(void) {
   
   return(rootPopupMenu);
}

void Manager::dockSetup(void) {
   
   dock = new Dock();
   dock->raise();
}

void Manager::dockSetdown(void) {
   
   getDock()->destroy();
   delete dock;
}

Dock *Manager::getDock(void) {

   return(dock);
}

int Manager::winToMwin(Window w) {
   
   int i;
   
   if(w) {
      for(i = 1;i <= numOfMwins;i++) {
	 if(Mwin[i]->isMember(w))
	   return(i);
      }
   }
   return(0);
}

void Manager::packMwinStack(void) {
   
   int i;
   for(i = 1;i <= numOfMwins;i++) {
      if(i);
   }
}

void Manager::packMwinStack(int startWith) {
   
   int i;
   for(i = startWith;i < numOfMwins;i++) {
      Mwin[i]->copyMwin(Mwin[i+1]);
   }
}

void Manager::printOut(const char *msg, ...) {
   
   va_list vl;
      
   va_start(vl, msg);
   vfprintf(stdout, msg, vl);
   va_end(vl);
   
}


void Manager::printErr(const char *msg, ...) {
  
   va_list vl;

   if(debugMode) {
      va_start(vl, msg);
      vfprintf(stderr, msg, vl);
      va_end(vl);
   }
}

Atom Manager::getAtom(const char *atomName) {
   
   Atom atomReturn;
   
   if((strcmp("WM_CHANGE_STATE", atomName)) == 0) {
      atomReturn = XInternAtom(scr.disp, "WM_CHANGE_STATE", False);
   } else if((strcmp("WM_DELETE_WINDOW", atomName)) == 0) {
      atomReturn = XInternAtom(scr.disp, "WM_DELETE_WINDOW", False);
   } else if((strcmp("_MOTIF_WM_HINTS", atomName)) == 0) {
      atomReturn = XInternAtom(scr.disp, "_MOTIF_WM_HINTS", False);
   } else if((strcmp("WM_PROTOCOLS", atomName)) == 0) {
      atomReturn = XInternAtom(scr.disp, "WM_PROTOCOLS", False);
   } else if((strcmp("WM_SIZE_HINTS", atomName)) == 0) {
      atomReturn = XInternAtom(scr.disp, "WM_SIZE_HINTS", False);
   } else if((strcmp("XA_WM_NORMAL_HINTS", atomName)) == 0) {
      atomReturn = XInternAtom(scr.disp, "XA_WM_NORMAL_HINTS", False);
   } else if((strcmp("XA_WM_NAME", atomName)) == 0) {
      atomReturn = XInternAtom(scr.disp, "XA_WM_NAME", False);
   } else if((strcmp("XA_WM_ICON_NAME", atomName)) == 0) {
      atomReturn = XInternAtom(scr.disp, "XA_WM_ICON_NAME", False);
   } else {
      atomReturn = 0;
   }
   
   return(atomReturn);
}

int Manager::adaptToDepth(float r, float g, float b) {

   int depth, red, green, blue;
   int result;

   depth = XDefaultDepth(scr.disp, scr.screen);

   switch(depth) {
    case 8:
      red = (int)rint(3 * r);
      green = (int)rint(7 * g);
      blue = (int)rint(7 * b);
      
      result = (red << 6) | (green << 3) | (blue);
      break;
    case 16:
      red = (int)rint(31 * r);
      green = (int)rint(63 * g);
      blue = (int)rint(31 * b);
      
      result = (red << 11) | (green << 5) | (blue);
      break;
    default:
    case 24:
      red = (int)rint(255 * r);
      green = (int)rint(255 * g);
      blue = (int)rint(255 * b);
      
      result = (red << 16) | (green << 8) | (blue);
      break;
    case 32:
      red = (int)rint(1023 * r);
      green = (int)rint(2047 * g);
      blue = (int)rint(2047 * b);
      
      result = (red << 22) | (green << 11) | (blue);
      break;
   }

   return(result);
}

void Manager::autoStartSetup(void) {
   
   Configfile cf;
   
   cf.runAutostart();
   
}

void Manager::colorSetup(void) {
  
   int i;
   Configfile cf;
   
   for(i = 0;i < NUMBEROFCOLORS;i++) {
      colors[i] = cf.getColorColor(i);
   }
}

int Manager::getColor(int color) {
   
   return(colors[color]);
}

void Manager::fontSetup(void) {
   
   int i;
   char *tmp;
   
   Configfile cf;
   
   
   for(i = 0;i < NUMBEROFFONTS;i++) {
      
      tmp = cf.getFontFont(i);
      fonts[i] = new char[strlen(tmp) + 1];
      snprintf(fonts[i], strlen(tmp) + 1, "%s", tmp);
      
      delete [] tmp;
   }
   
}

void Manager::fontSetdown(void) {
   
   int i;
   for(i = 0;i < NUMBEROFFONTS;i++) {
      delete [] fonts[i]; 
   }
}

void Manager::keyBindingsSetup(void) {
   
   int i;
   Configfile cf;
   
   keyBinding.numOfItems = cf.getKeybindingsNumOfItems();
   
   //Allocate memory
   keyBinding.key = new int[keyBinding.numOfItems];
   keyBinding.modifiers = new int[keyBinding.numOfItems];     
   keyBinding.function = new int[keyBinding.numOfItems];     
   keyBinding.command = new (char *)[keyBinding.numOfItems];     
      
   for(i = 0;i < keyBinding.numOfItems;i++) {
      keyBinding.key[i] = cf.getKeybindingsKey(i);
      keyBinding.modifiers[i] = cf.getKeybindingsModifiers(i); 
      keyBinding.function[i] = cf.getKeybindingsFunction(i); 
      if(keyBinding.function[i] == 0x01 || keyBinding.function[i] == 0x10) {
	 keyBinding.command[i] = cf.getKeybindingsCommand(i); 
      } else {
	 keyBinding.command[i] = NULL;
      }
   }
   
   //Set our grabs
   for(i = 0;i < keyBinding.numOfItems;i++) {
      //printErr("Setting grab on key: %d, Modifiers: %d. Functionnum -> %d\n",keyBinding.key[i], keyBinding.modifiers[i], keyBinding.function[i]);
      XGrabKey(scr.disp, keyBinding.key[i], keyBinding.modifiers[i], scr.rootwin, True, GrabModeAsync, GrabModeAsync);
   }
   
}

void Manager::keyBindingsSetdown(void) {
   
   int i;
         
   for(i = 0;i < keyBinding.numOfItems;i++) {
      
      if(keyBinding.function[i] == 1 || keyBinding.function[i] == 16) {
	 delete [] keyBinding.command[i];
      } 
   }
   
   for(i = 0;i < keyBinding.numOfItems;i++) {
      XUngrabKey(scr.disp, keyBinding.key[i], keyBinding.modifiers[i], scr.rootwin);
   }
   
   delete [] keyBinding.key;
   delete [] keyBinding.modifiers;
   delete [] keyBinding.function;
   delete [] keyBinding.command;
   
}

void Manager::keyParseFunction(int function, const char *command, XKeyEvent *keyEvent) {
   
   //Ugly and shouldnt be here
   int i, revertTo;
   Window activeWindow;
   Mwindowpopupmenu *MwindowPopupMenu;
   Iconpopupmenu *IconPopupMenu;
   
   XGetInputFocus(scr.disp, &activeWindow, &revertTo);
      
   switch(function) {
    case 1:
      runCommand(command);
      break;
    case 2:
      restart();
      break;
    case 3:
      quit(0);
      break;
    case 4:
      //Rootpopup
      rootPopupMenu->pop();
      break;
    case 5:
      //winpopup
      if((i = winToMwin(activeWindow))) {
	 
	 MwindowPopupMenu = new Mwindowpopupmenu(i);
	 
	 MwindowPopupMenu->pop(Mwin[i]->getX(), Mwin[i]->getY());
	 
	 delete MwindowPopupMenu;
      }
      break;
    case 6:
      //Deiconify
      for(i = 1;i <= numOfMwins;i++) {
	 if((Mwin[i]->getState() & S_MINIMIZED)) {
	    
	    IconPopupMenu = new Iconpopupmenu();
	    IconPopupMenu->pop();
	    delete IconPopupMenu;
	    
	    return;
	 }
      }
      break;
    case 7:
      //Minimize
      if((i = winToMwin(activeWindow))) {
	 Mwin[i]->minimize(False);
      }
      break;
    case 8:
      //Maximise
      if((i = winToMwin(activeWindow))) {
	 Mwin[i]->maximize(True);
      }
      break;
    case 9:
      //close
      if((i = winToMwin(activeWindow))) {
	 Mwin[i]->kill();
      }
      break;
    case 10:
      //raise
      if((i = winToMwin(activeWindow))) {
	 Mwin[i]->raise();
      }
      break;
    case 11:
      //lower
      if((i = winToMwin(activeWindow))) {
	 Mwin[i]->lower();
      }
      break;
    case 12:
      //circulate up
      circulateMwins(UP);
      break;
    case 13:
      //circulate down
      circulateMwins(DOWN);
      break;
    case 14:
      //NEXT WS
      getVscreen()->nextWS();
      break;
    case 15:
      // prev ws
      getVscreen()->previousWS();
      break;
    case 16:
      //switch to ws
      i = atoi(command);
      if(i > 0 && i <= getVscreen()->getNumOfWSs()) {
	 getVscreen()->switchWS(i);
      }
      break;
    case 17:
      //Move on klick 
      int Mwin;
      XEvent e;

      memset(&e, 0, sizeof (XEvent));
      
      XGrabButton(scr.disp, 1, AnyModifier, scr.rootwin, False, NoEventMask, GrabModeAsync, GrabModeAsync, None, None);
      while(1) {

	 XMaskEvent(scr.disp, (ButtonPressMask | KeyReleaseMask), &e);
	 if(e.type == KeyRelease) {
	    if(e.xkey.keycode == keyEvent->keycode) {
	       break;
	    }
	 } else {
	    
	    if((Mwin = winToMwin(e.xbutton.subwindow))) {
	       getMwindow(Mwin)->moveInteractive();
	    }
	    break;
	 }
      }
      XUngrabButton(scr.disp, 1, AnyModifier, scr.rootwin);
      break;
   }
}

void Manager::restart(void) {
   
   generalSetup();

   fontSetdown();
   fontSetup();

   colorSetup();

   //   rootPopupMenuSetdown();
   rootPopupMenuSetup();

   keyBindingsSetdown();
   keyBindingsSetup();
   /*
   dockSetdown();
   dockSetup();
   */
   autoStartSetup();

   printErr("Config reloaded\n");
}

void Manager::quit(int signal) {
   
   int i;
   time_t currentUptime;
   
   for(i = 1; i <= numOfMwins; i++) {
      Mwin[i]->kill();
   }
   
   for(i = 0; i < NUMBEROFFONTS; i++) {
      delete fonts[i];
   }
   
   rootPopupMenuSetdown();
   keyBindingsSetdown();
   
   getDock()->destroy();
   
   XCloseDisplay(scr.disp);
   
   currentUptime = uptime();
   
   if(currentUptime > getRecordTime()) {
      printErr("Hoooray! You have just set a new mosquito uptime record for this user!\n");
      setRecordTime(currentUptime);
   }
   
   exit(signal);
}

//Does this one belong here ?
void Manager::noFocus(void) {
   
   int Mwin;
   int revertTo;
   Window currentFocus;
   
   XGetInputFocus(scr.disp, &currentFocus, &revertTo);
   
   if((Mwin = winToMwin(currentFocus))) {
      this->Mwin[Mwin]->removeFocus();
   }
   
   XSetInputFocus(scr.disp, PointerRoot, RevertToPointerRoot, CurrentTime);
   
}

void Manager::runCommand(const char *command) {
   
   unsigned int i, j;
   unsigned int argc;
   short int argLen[ARG_MAX], len;
   char **argv;
   char *cmd, *ptr;
   Bool hasStrofe;
   
   hasStrofe = False;
   argc = 0;
   len = 0;
   
   if(!strcmp("", command))  // sweet ;)
     return;
     
   cmd = new char[strlen(command) + 1];
   strcpy(cmd, command);
   
   i = strspn(cmd, " ");
   for(;i > 0;i--) {
      for(j = 0;j < strlen(cmd);j++) {
	 cmd[j] = cmd[j + 1];
      }
   }
   for(i = 0;i < strlen(cmd);i++) {
      while(cmd[i] == ' ' && cmd[i + 1] == ' ') {
	 for(j = (i + 1);j < strlen(cmd);j++) {
	    cmd[j] = cmd[j + 1];
	 }
      }
   }
   for(ptr = &cmd[0];(ptr = strchr(ptr, '\n'));) {
      *ptr = '\0';
      break;
   }
   
   for(i = 0;i <= strlen(cmd);i++) {
      
      len++;
      
      if((cmd[i] == '\'' || cmd[i] == '\"') && hasStrofe == False) {
	 hasStrofe = True;
      } else if((cmd[i] == '\'' || cmd[i] == '\"') && hasStrofe == True) {
	 hasStrofe = False;
      } 
      if((cmd[i] == ' ' || cmd[i] == '\0') && hasStrofe == False) {
	 argLen[argc] = len;
	 argc++;
	 len = 0;
      }
   }
   if(hasStrofe) {
      printErr("Odd number of quotation marks: %s\n", command);
      quit(-1);
   }
     
   argv = new (char *)[argc + 1];
   for(i = 0;i < argc;i++) {
      argv[i] = new char[argLen[i]];
   }

   ptr = &cmd[0];
   for(i = 0;i < argc;i++) {
      snprintf(argv[i], argLen[i], "%s", ptr);
      ptr += argLen[i];
   }
   argv[argc] = NULL;
    
   switch(fork()) {
    case 0:
      if((execvp(argv[0], argv)) == -1) {
	 printErr("Couldn't execute command...\n");
	 exit(-1);
      }
      break;
    case -1:
      printErr("Unable to fork...\n");
      break;
   }
  
   for(i = 0;argv[i];i++)
     delete [] argv[i];
   
   delete [] argv;
   delete [] cmd;
}
