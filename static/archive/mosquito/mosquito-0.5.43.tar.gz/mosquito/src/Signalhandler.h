class Signalhandler {
 
 private:
   
 public:
   Signalhandler(void);
   ~Signalhandler(void);
   
   
   static void abortHandler(int signal);
   static void childHandler(int signal);
   
};
