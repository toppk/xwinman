#ifndef _DOCK_H_
#define _DOCK_H_

#include "Mosquito.h"

#define DOCK_WIDTH 64
#define DOCK_HEIGHT 64

struct DockItem {
   struct DockItem *next;
   Window window;
   Window programWindow;
};

struct DockPositions {
   char *appName;
   Window filled;
};

class Dock {
 private:
   int numOfDockWins;
   int growDirection;
   int position;
     
   Window dockParentWindow;
   Pixmap tilePixmap;
   struct DockItem *dockItem;
   struct DockPositions dockPositions[MAX_NUM_OF_DOCKWINS]; //this is fun!
   
 public:
   Dock(void);
   ~Dock(void);
   
   Bool isParentWindow(Window w);
   Bool isMember(Window w);
   Bool isSaved(Window w);
   
   void increaseNumOfDockWins(void);
   void decreaseNumOfDockWins(void);
   
   void increaseParentWindowSize(void);
   void decreaseParentWindowSize(void);
   
   
   int getParentWindow(void);
   
   int getPosition(void);
   int getGrowDirection(void);
   int getNumOfDockWins(void);

   
   Window addDockWin(void);
   void copyDockWin(int src, int dst);
   
   void updateDockWinPositions(void);
   void saveDockWinPositions(void);
   void restoreDockWinPositions(void);
   
   void insertDockAppAtSavedPosition(Window w);
   void addDockApp(Window w);
   void removeDockApp(Window w);
   
   Window getAppWindow(int app);
   void destroy(void);
   
   
   void raise(void);
      
};

#endif
