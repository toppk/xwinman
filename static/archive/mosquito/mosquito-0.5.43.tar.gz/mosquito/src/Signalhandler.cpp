#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "Manager.h"
#include "Signalhandler.h"

extern Manager Mgr;

Signalhandler::Signalhandler(void) {
   
   signal(SIGABRT, Signalhandler::abortHandler);
   signal(SIGCHLD, Signalhandler::childHandler);
   
}

Signalhandler::~Signalhandler(void) {
   
}

void Signalhandler::abortHandler(int signal) {
   
   Mgr.printErr("Got SIGABRT, exiting...\n");
   Mgr.quit(0);
}

void Signalhandler::childHandler(int signal) {
   
   while((waitpid(-1, NULL, WNOHANG)) > 0);
}


