#ifndef _ROOTPOPUPMENU_H_
#define _ROOTPOPUPMENU_H_

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <X11/Xproto.h>
#include <X11/Xutil.h>
#include "Mosquito.h"
#include "Popupmenu.h"

class Rootpopupmenu {
 private:
   Popupmenu **menu;
   
 public:
   Rootpopupmenu(void);
   ~Rootpopupmenu(void);
   
   void pop(void);
};

#endif
