#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <X11/Xproto.h>
#include <X11/Xutil.h>
#include "Rootpopupmenu.h"
#include "Fonts.h"
#include "Mosquito.h"
#include "Manager.h"
#include "Configfile.h"
#include "Misc.h"

extern Manager Mgr;

static void runCommand(const char *command) {
   
   if(!strcmp(command, "[Quit]")) {
      Mgr.quit(0);
   } else if(!strcmp(command, "[Restart]")) {
      Mgr.restart();
   } else if(!strcmp(command, "[Uptime]")) {
      uptime();
   } else {
      Mgr.runCommand(command);
   }
}

Rootpopupmenu::Rootpopupmenu(void) {
   
   int i, j;
   int numOfMenus, *numOfItems;
   int itemWidth, itemHeight, menuBorderWidth, menuBorderHeight;
   char *command, *label;
   Configfile *configFile;
   
   itemWidth = 100;
   itemHeight = 20;
   menuBorderWidth = 50;
   menuBorderHeight = 50;
   
   configFile = new Configfile();
   numOfMenus = configFile->getPopupTotalNumOfSubmenus();
   numOfItems = new int[numOfMenus];
   menu = new (Popupmenu *)[numOfMenus];
   
   for(i = 0;i < numOfMenus;i++) {
      numOfItems[i] = configFile->getPopupNumOfSubmenuItems(i);
      menu[i] = new Popupmenu(trekkify, runCommand, numOfItems[i], itemWidth + menuBorderWidth, numOfItems[i] * itemHeight + menuBorderHeight, itemWidth, itemHeight, XLoadFont(Mgr.scr.disp, Mgr.getFont(ROOTPOPUPMENUFONT)));
   }

   for(i = 0;i < numOfMenus;i++) {
      for(j = 0;j < numOfItems[i];j++) {
	 
	 command = configFile->getPopupCommand(i, j);
	 label = configFile->getPopupLabel(i, j);

	 if(atoi(command)) {
	    menu[i]->createItem(label, menu[atoi(command)]);
	 } else {
	    menu[i]->createItem(label, command);
	 }
	 
	 delete [] command;
	 delete [] label;
      }
   }
   
   delete [] numOfItems;
   delete configFile;
}

Rootpopupmenu::~Rootpopupmenu(void) {
   
   int i;
   
   for(i = 0;menu[i];i++)
     delete menu[i];
}

void Rootpopupmenu::pop(void) {
   
   menu[0]->pop();
}
