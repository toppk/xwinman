/*
static char sccs_id[] = "@(#)uwinoptS.h	5.6  9/1/88";
*/

/*
 * Copyright 1988 by Siemens Research and Technology Laboratories, Princeton, NJ
 *
 *                         All Rights Reserved
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose and without fee is hereby granted,
 * provided that the above copyright notice appear in all copies and that
 * both that copyright notice and this permission notice appear in
 * supporting documentation, and that the name of Siemens Research and Technology
 * Laboratories not be used in advertising or publicity pertaining to
 * distribution of the software without specific, written prior permission.
 *
 *
 * SIEMENS DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
 * ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
 * SIEMENS BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
 * ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
 * WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
 * ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
 * SOFTWARE.
 */



char *(user_window_strs[(int)LENGTH_USER_WINDOW_OPTIONS]) = {

    "acceptButtonInBody",
    "acceptButtonInHeader",
    "acceptButtonInIcon",

    "acceptKeyInBody",
    "acceptKeyInHeader",
    "acceptKeyInGadget",
    "acceptKeyInBorder", 
    "acceptKeyInIcon",

    "aggressivelyRepopulate",

    "allowShrinkOnUnzoom", 
    "allowShrinkOnAutoUnzoom", 

    "allowZoomClose",

    "autoOpenOnCreate", 
    "autoOpenOnWrite", 

    "autoPlaceOnClientOpen",

    "autoResatisfyOnResetMinmax",

    "clientDrawsIcon",
    "clientProvidesHeader",

    "considerForRepopulation",

    "enforceClientMinimums",
    "enforceClientMaximums",

    "listenerTiedToZoom",

    "forceShrinkOnUnzoom", 
    "forceShrinkOnAutoUnzoom", 

    "glassClient",

    "iconDrawnByClient",

    "ignoreInitialPositionHints",
    "ignoreInitialSizeHints",
    "ignorePositionHints",
    "ignoreSizeHints",

    "includeResClassInTitle",
    "includeResClassInIconTitle",
    "includeResNameInTitle",
    "includeResNameInIconTitle",
    "includeNameInTitle",
    "includeNameInIconTitle",
    "includeHostInTitle",
    "includeHostInIconTitle",

    "includeTitleInHeader",
    "includeTitleInPixmapIcon",
    "includeTitleInClientIcon",

    "invertIconWhenPending",

    "noteListener",
    "noteListenerInput",
    "noteClosedInput",
    "noteOpenInput",
    "noteClosedOutput",
    "noteOpenOutput",

    "preferPreviousIconPosition",
    "preferPreviousPosition",
    "requirePreviousIconPosition",
    "requirePreviousPosition",

    "saveInLayout",

    "showIcon",

    "useBorders",
    "useGadgets",
    "useHeader",
    "useMoveGadget",

    "zoomFullExplicit",
    "zoomFullHeight",
    "zoomFullWidth",

    "zoomOnOpen",
    
    "zoomTiedToDesire" };


