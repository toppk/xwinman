rtl.focusFollowsPointer: off
