#include <stdio.h>

int main () {
#   if defined(sun)
#       if defined(mc68020)
	    puts("SUN3");
#       endif
#       if defined(sparc)
	    puts("SUN4");
#       endif
#   endif
#   if defined(vax)
	puts("VAX");
#   endif
    return 0;
}
