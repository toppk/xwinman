/*
 * Implementation of Adjuster and derived classes.
 */

#include <InterViews/adjuster.h>
#include <InterViews/bitmap.h>
#include <InterViews/painter.h>
#include <InterViews/perspective.h>
#include <InterViews/sensor.h>
#include <InterViews/shape.h>

Adjuster::Adjuster (Interactor* i, Bitmap* b, int d) {
    Init(i, b, d);
}

Adjuster::Adjuster (const char* name, Interactor* i, Bitmap* b, int d) {
    SetInstance(name);
    Init(i, b, d);
}

Adjuster::Adjuster (Interactor* i, Bitmap* b, int d, Painter* p) : (nil, p) {
    Init(i, b, d);
}

void Adjuster::Init (Interactor* i, Bitmap* b, int d) {
    SetClassName("Adjuster");
    view = i;
    highlighted = false;
    delay = d;
    shown = new Perspective;
    bitmap = b;
    bitmap->Reference();
    input = new Sensor(onoffEvents);
    input->Catch(UpEvent);
    input->Catch(DownEvent);
}    

void Adjuster::Reconfig () {
    Painter* tmp = new Painter(output);
    delete output;
    output = tmp;
    bitmap->SetColors(output->GetFgColor(), output->GetBgColor());
    shape->width = bitmap->Width();
    shape->height = bitmap->Height();
}

void Adjuster::Invert () {
    Color* fg, *bg;

    fg = bitmap->GetFgColor();
    bg = bitmap->GetBgColor();
    bitmap->SetColors(bg, fg);
    Draw();
}

void Adjuster::AutoRepeat () {
    Event e;
    
    Poll(e);	// initialize event
    do {
	if (Check()) {
	    Read(e);
	    if (e.target == this) {
		switch (e.eventType) {
		    case OnEvent:
			Highlight();
			break;
		    case OffEvent:
			UnHighlight();
			break;
		    default:
			break;
		}
	    }		    
	} else if (highlighted) {
	    Flash();
	    AdjustView(e);
	    Sync();
	}
    } while (e.eventType != UpEvent);
}

void Adjuster::HandlePress () {
    Event e;
    
    do {
	Read(e);
	if (e.target == this) {
	    switch (e.eventType) {
		case OnEvent:
		    TimerOn();
		    Highlight();
		    break;
		case OffEvent:
		    TimerOff();
		    UnHighlight();
		    break;
		case UpEvent:
		    if (highlighted) {
			AdjustView(e);
		    }
		    break;
		case TimerEvent:
		    AutoRepeat();
		    return;
		default:
		    break;
	    }
	}
    } while (e.eventType != UpEvent);
}

void Adjuster::Flash () {
    UnHighlight();
    Highlight();
}

static const int USEC_PER_DELAY_UNIT = 100000;	    // delay unit = 1/10 secs

void Adjuster::TimerOn () {
    if (delay >= 0) {
	input->CatchTimer(0, delay * USEC_PER_DELAY_UNIT);
    }
}

void Adjuster::TimerOff () {
    input->Ignore(TimerEvent);
}

void Adjuster::Delete () {
    delete bitmap;
    delete shown;
    Interactor::Delete();
}

void Adjuster::Handle (Event& e) {
    if (e.eventType == DownEvent) {
	Highlight();
	TimerOn();
	if (delay == 0) {
	    AutoRepeat();
	} else {
	    HandlePress();
	}
	UnHighlight();
	TimerOff();
    }
}

void Adjuster::Draw () {
    bitmap->Draw(canvas);
}

void Adjuster::Redraw (Coord l, Coord b, Coord r, Coord t) {
    output->Clip(canvas, l, b, r, t);
    bitmap->Draw(canvas);
    output->NoClip();
}

void Adjuster::Resize () {
    Coord ox, oy;
    
    ox = (xmax + 1 - shape->width) / 2;
    oy = (ymax + 1 - shape->height) / 2;
    bitmap->SetOrigin(ox, oy);
}

void Adjuster::Reshape (Shape& s) {
    shape->Rigid(s.hshrink, s.hstretch, s.vshrink, s.vstretch);
}

void Adjuster::Highlight () {
    if (!highlighted) {
	Invert();
	highlighted = true;
    }
}

void Adjuster::UnHighlight () {
    if (highlighted) {
	Invert();
	highlighted = false;
    }
}

void Adjuster::AdjustView (Event&) {
    // nop default
}

Zoomer::Zoomer (Interactor* i, Bitmap* b, float f) : (i, b, NO_AUTOREPEAT) {
    Init(f);
}

Zoomer::Zoomer (
    const char* name, Interactor* i, Bitmap* b, float f
) : (name, i, b, NO_AUTOREPEAT) {
    Init(f);
}

Zoomer::Zoomer (
    Interactor* i, Bitmap* b, float f, Painter* p
) : (i, b, NO_AUTOREPEAT, p) {
    Init(f);
}

void Zoomer::Init (float f) {
    SetClassName("Zoomer");
    factor = f;
}

void Zoomer::AdjustView (Event&) {
    register Perspective* s = shown;
    Coord cx, cy;

    *s = *view->GetPerspective();
    cx = s->curx + s->curwidth/2;
    cy = s->cury + s->curheight/2;
    s->curwidth = round(float(s->curwidth) / factor);
    s->curheight = round(float(s->curheight) / factor);
    s->curx = cx - s->curwidth/2;
    s->cury = cy - s->curheight/2;
    view->Adjust(*s);    
}

static const int enlw = 25;
static const int enlh = 15;
static unsigned char enl[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x10, 0x00, 0x00, 0x00, 0x6c, 0x00, 0x00,
    0x00, 0x83, 0x01, 0x00, 0xc0, 0x00, 0x06, 0x00,
    0x30, 0x00, 0x18, 0x00, 0x0c, 0x00, 0x60, 0x00,
    0xfc, 0x00, 0x7e, 0x00, 0x44, 0x00, 0x44, 0x00,
    0x3c, 0x00, 0x78, 0x00, 0xe0, 0xff, 0x0f, 0x00,
    0x20, 0x00, 0x08, 0x00, 0xe0, 0xff, 0x0f, 0x00,
    0x00, 0x00, 0x00, 0x00
};

Enlarger::Enlarger (Interactor* i) : (i, new Bitmap(enl, enlw, enlh), 2.0) {
    Init();
}

Enlarger::Enlarger (
    const char* name, Interactor* i
) : (name, i, new Bitmap(enl, enlw, enlh), 2.0) {
    Init();
}

Enlarger::Enlarger (
    Interactor* i, Painter* p
) : (i, new Bitmap(enl, enlw, enlh), 2.0, p) {
    Init();
}

void Enlarger::Init () {
    SetClassName("Enlarger");
}

static const int redw = 25;
static const int redh = 15;
static unsigned char red[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0xfe, 0x00, 0x00, 0x00, 0x01, 0x01, 0x00,
    0x80, 0x00, 0x02, 0x00, 0x7c, 0x00, 0x7c, 0x00,
    0x1c, 0x00, 0x70, 0x00, 0x64, 0x00, 0x4c, 0x00,
    0x84, 0x01, 0x43, 0x00, 0x18, 0xc6, 0x30, 0x00,
    0x60, 0x38, 0x0c, 0x00, 0x80, 0x11, 0x03, 0x00,
    0x00, 0xd6, 0x00, 0x00, 0x00, 0x38, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00
};

Reducer::Reducer (Interactor* i) : (i, new Bitmap(red, redw, redh), 0.5) {
    Init();
}

Reducer::Reducer (
    const char* name, Interactor* i
) : (name, i, new Bitmap(red, redw, redh), 0.5) {
    Init();
}

Reducer::Reducer (
    Interactor* i, Painter* p
) : (i, new Bitmap(red, redw, redh), 0.5, p) {
    Init();
}

void Reducer::Init () {
    SetClassName("Reducer");
}

static typedef enum MoveType { 
    MOVE_LEFT, MOVE_RIGHT, MOVE_UP, MOVE_DOWN, MOVE_UNDEF
};

Mover::Mover (
    Interactor* i, Bitmap* b, int delay, int mt
) : (i, b, delay) {
    Init(mt);
}

Mover::Mover (
    const char* name, Interactor* i, Bitmap* b, int delay, int mt
) : (name, i, b, delay) {
    Init(mt);
}

Mover::Mover (
    Interactor* i, Bitmap* b, int delay, int mt, Painter* p
) : (i, b, delay, p) {
    Init(mt);
}

void Mover::Init (int mt) {
    SetClassName("Mover");
    moveType = mt;
}

void Mover::AdjustView (Event& e) {
    register Perspective* s = shown;
    int amtx, amty;

    *s = *view->GetPerspective();
    amtx = e.shift ? s->sx : s->lx;
    amty = e.shift ? s->sy : s->ly;

    switch (moveType) {
	case MOVE_LEFT:	    s->curx -= amtx; break;
	case MOVE_RIGHT:    s->curx += amtx; break;
	case MOVE_UP:	    s->cury += amty; break;
	case MOVE_DOWN:	    s->cury -= amty; break;
	default:	    break;
    }
    view->Adjust(*s);    
}

static const int lmoverw = 11;
static const int lmoverh = 11;
static unsigned char lmover[] = {
    0x00, 0x00, 0x60, 0x00, 0x70, 0x00, 0xf8, 0x03,
    0xfc, 0x03, 0xfe, 0x03, 0xfc, 0x03, 0xf8, 0x03,
    0x70, 0x00, 0x60, 0x00, 0x00, 0x00
};

LeftMover::LeftMover (
    Interactor* i, int delay
) : (i, new Bitmap(lmover, lmoverw, lmoverh), delay, MOVE_LEFT) {
    Init();
}

LeftMover::LeftMover (
    const char* name, Interactor* i, int delay
) : (name, i, new Bitmap(lmover, lmoverw, lmoverh), delay, MOVE_LEFT) {
    Init();
}

LeftMover::LeftMover (
    Interactor* i, int delay, Painter* p
) : (i, new Bitmap(lmover, lmoverw, lmoverh), delay, MOVE_LEFT, p) {
    Init();
};

void LeftMover::Init () {
    SetClassName("LeftMover");
}

static const int rmoverw = 11;
static const int rmoverh = 11;
static unsigned char rmover[] = {
    0x00, 0x00, 0x30, 0x00, 0x70, 0x00, 0xfe, 0x00,
    0xfe, 0x01, 0xfe, 0x03, 0xfe, 0x01, 0xfe, 0x00,
    0x70, 0x00, 0x30, 0x00, 0x00, 0x00
};

RightMover::RightMover (
    Interactor* i, int delay
) : (i, new Bitmap(rmover, rmoverw, rmoverh), delay, MOVE_RIGHT) {
    Init();
}

RightMover::RightMover (
    const char* name, Interactor* i, int delay
) : (name, i, new Bitmap(rmover, rmoverw, rmoverh), delay, MOVE_RIGHT) {
    Init();
}

RightMover::RightMover (
    Interactor* i, int delay, Painter* p
) : (i, new Bitmap(rmover, rmoverw, rmoverh), delay, MOVE_RIGHT, p) {
    Init();
};

void RightMover::Init () {
    SetClassName("RightMover");
}

static const int umoverw = 11;
static const int umoverh = 11;
static unsigned char umover[] = {
    0x00, 0x00, 0x20, 0x00, 0x70, 0x00, 0xf8, 0x00,
    0xfc, 0x01, 0xfe, 0x03, 0xfe, 0x03, 0xf8, 0x00,
    0xf8, 0x00, 0xf8, 0x00, 0x00, 0x00
};

UpMover::UpMover (
    Interactor* i, int delay
) : (i, new Bitmap(umover, umoverw, umoverh), delay, MOVE_UP) {
    Init();
}

UpMover::UpMover (
    const char* name, Interactor* i, int delay
) : (name, i, new Bitmap(umover, umoverw, umoverh), delay, MOVE_UP) {
    Init();
}

UpMover::UpMover (
    Interactor* i, int delay, Painter* p
) : (i, new Bitmap(umover, umoverw, umoverh), delay, MOVE_UP, p) {
    Init();
};

void UpMover::Init () {
    SetClassName("UpMover");
}

static const int dmoverw = 11;
static const int dmoverh = 11;
static unsigned char dmover[] = {
    0x00, 0x00, 0xf8, 0x00, 0xf8, 0x00, 0xf8, 0x00,
    0xfe, 0x03, 0xfe, 0x03, 0xfc, 0x01, 0xf8, 0x00,
    0x70, 0x00, 0x20, 0x00, 0x00, 0x00
};

DownMover::DownMover (
    Interactor* i, int delay
) : (i, new Bitmap(dmover, dmoverw, dmoverh), delay, MOVE_DOWN) {
    Init();
}

DownMover::DownMover (
    Interactor* i, int delay, Painter* p
) : (i, new Bitmap(dmover, dmoverw, dmoverh), delay, MOVE_DOWN, p) {
    Init();
};

void DownMover::Init () {
    SetClassName("DownMover");
}
