/*
 * A world is the root scene for a display.
 */

#include <InterViews/canvas.h>
#include <InterViews/event.h>
#include <InterViews/painter.h>
#include <InterViews/propsheet.h>
#include <InterViews/shape.h>
#include <InterViews/strtable.h>
#include <InterViews/world.h>
#include <libc.h>
#include <stdio.h>
#include <string.h>

extern StringTable* nameTable;

double inch, inches, cm, point, points;

static OptionDesc defoptions[] = {
    { "-background", "*background", OptionValueNext },
    { "-bg", "*background", OptionValueNext },
    { "-display", "display", OptionValueNext },
    { "-fg", "*foreground", OptionValueNext },
    { "-fn", "*font", OptionValueNext },
    { "-font", "*font", OptionValueNext },
    { "-foregound", "*foreground", OptionValueNext },
    { "-geometry", ".geometry", OptionValueNext },
    { "-name", ".name", OptionValueNext },
    { "-reverse", "*reverseVideo", OptionValueImplicit, "on" },
    { "-rv", "*reverseVideo", OptionValueImplicit, "on" },
    { nil, nil, nil }
};

static PropDir* appdir;

static void PutProp (
    const char* path, const char* value, const char* type = nil
) {
    if (path[0] == '.' || path[0] == '*') {
	properties->PutLocal(appdir, path, value, type);
    } else {
	properties->Put(path, value, type);
    }
}

static void PutPropLower (
    const char* path, const char* value, const char* type = nil
) {
    if (path[0] == '.' || path[0] == '*') {
	properties->PutLocalLower(appdir, path, value, type);
    } else {
	properties->PutLower(path, value, type);
    }
}

World::World (const char* s, int& argc, char* argv[]) {
    Setup(s);
    ParseArgs(argc, argv, defoptions);
    Init(GetAttribute("display"));
    LoadUserDefaults();
    FinishInit(s);
}

World::World (const char* s, OptionDesc* opts, int& argc, char* argv[]) {
    Setup(s);
    ParseArgs(argc, argv, opts);
    ParseArgs(argc, argv, defoptions);
    Init(GetAttribute("display"));
    LoadUserDefaults();
    FinishInit(s);
}

World::World (
    const char* s, PropertyData* initprops,
    OptionDesc* opts, int& argc, char* argv[]
) {
    register PropertyData* p;

    Setup(s);
    ParseArgs(argc, argv, opts);
    ParseArgs(argc, argv, defoptions);
    Init(GetAttribute("display"));
    LoadUserDefaults();
    for (p = &initprops[0]; p->path != nil; p++) {
	PutPropLower(p->path, p->value, p->type);
    }
    FinishInit(s);
}

World::World (const char* s, const char* device) {
    Setup(s);
    Init(device);
    LoadUserDefaults();
    FinishInit(s);
}

void World::Setup (const char* name) {
    if (properties == nil) {
	properties = new PropertySheet;
    }
    if (nameTable == nil) {
	nameTable = new StringTable(1024);
    }
    appdir = (name == nil) ? properties->Root() : properties->MakeDir(name);
}

void World::FinishInit (const char* name) {
    extern void InitSensors(), InitCursors(Color*, Color*);

    RootConfig("World", name);
    InitSensors();
    InitCursors(output->GetFgColor(), output->GetBgColor());
}

void World::LoadUserDefaults () {
    const char* defaults = UserDefaults();
    if (defaults != nil) {
	properties->LoadList(defaults);
    } else {
	char* filename = getenv("XENVIRONMENT");
	if (filename == nil) {
	    filename = getenv("HOME");
	    if (filename != nil) {
		char buf[1024];

		sprintf(buf, "%s/.Xdefaults", filename);
		properties->LoadFile(buf);
	    }
	} else {
	    properties->LoadFile(filename);
	}
    }
}

static void BadArg (const char* fmt, const char* arg) {
    fflush(stdout);
    fprintf(stderr, fmt, arg);
    putc('\n', stderr);
    exit(1);
}

void World::ParseArgs (int& argc, char* argv[], OptionDesc opts[]) {
    register int i;
    register OptionDesc* o;
    int newargc;
    char* newargv[1024];
    boolean match;

    newargc = 1;
    newargv[0] = argv[0];
    for (i = 1; i < argc; i++) {
	match = false;
	char* arg = argv[i];
	for (o = &opts[0]; o->name != nil; o++) {
	    if (strcmp(o->name, arg) == 0) {
		match = true;
		switch (o->style) {
		    case OptionValueNext:
			++i;
			if (i == argc) {
			    BadArg("missing value after '%s'", arg);
			}
			PutProp(o->path, argv[i]);
			break;
		    case OptionValueImplicit:
			PutProp(o->path, o->value);
			break;
		    case OptionValueIsArg:
			PutProp(o->path, arg);
			break;
		    case OptionValueAfter:
			BadArg("missing value in '%s'", arg);
		}
	    } else if (o->style == OptionValueAfter) {
		int len = strlen(o->name);
		if (strncmp(o->name, arg, len) == 0) {
		    match = true;
		    PutProp(o->path, &arg[len]);
		}
	    }
	}
	if (!match && opts == defoptions) {
	    if (arg[0] == '=') {
		match = true;
		PutProp(".geometry", &arg[1]);
	    } else if (strchr(arg, ':') != nil) {
		match = true;
		PutProp("display", arg);
	    } else if (strcmp(arg, "-xrm") == 0) {
		match = true;
		++i;
		if (i == argc) {
		    BadArg("missing value after '%s'", arg);
		}
		arg = argv[i];
		char* value = strchr(arg, ':');
		if (value == nil) {
		    BadArg("missing ':' in '%s'", arg);
		}
		*value = '\0';
		PutProp(arg, value+1);
	    }
	}
	if (!match) {
	    newargv[newargc] = arg;
	    ++newargc;
	}
    }
    if (newargc < argc) {
	for (i = 1; i < newargc; i++) {
	    argv[i] = newargv[i];
	}
	argc = newargc;
    }
}

void World::DoInsert (Interactor* i, boolean b, Coord& x, Coord& y) {
    register Shape* s = i->GetShape();
    if (b && s->width > 0 && s->height > 0) {
	Place(i, x, y, x + s->width - 1, y + s->height - 1);
    } else {
	unsigned int u = GetGeometry(i, x, y, s->width, s->height);
	if ((u & (GeomXValue|GeomYValue)) != 0 &&
	    s->width > 0 && s->height > 0
	) {
	    Place(i, x, y, x + s->width - 1, y + s->height - 1);
	} else {
	    UserPlace(i);
	}
    }
    const char* name = i->GetName();
    if (name == nil) {
	name = GetAttribute("name");
	if (name == nil) {
	    name = GetInstance();
	}
    }
    if (name != nil) {
	i->SetName(name);
    }
    FinishInsert(i);
}

/*
 * For now, we only return the geometry specification
 * for the first inserted interactor.  We should really check
 * to see if the interactor has a local geometry attribute specified.
 */

unsigned int World::GetGeometry (
    Interactor*, Coord& x, Coord& y, int& w, int& h
) {
    static boolean firsttime = true;
    unsigned int r = GeomNoValue;

    if (firsttime) {
	firsttime = false;
	const char* g = GetAttribute("geometry");
	if (g != nil) {
	    r = ParseGeometry((char*)g, x, y, w, h);
	    if ((r & GeomXValue) != 0) {
		if ((r & GeomXNegative) != 0) {
		    x = xmax + 1 + x - w;
		}
	    } else {
		x = 0;
	    }
	    if ((r & GeomYValue) != 0) {
		if ((r & GeomYNegative) != 0) {
		    y = -y;
		} else {
		    y = ymax + 1 - y - h;
		}
	    } else {
		y = ymax + 1 - h;
	    }
	}
    }
    return r;
}

int World::Width () {
    return canvas->width;
}

int World::Height () {
    return canvas->height;
}

Coord World::InvMapX (Coord x) {
    return x;
}

Coord World::InvMapY (Coord y) {
    return canvas->height - 1 - y;
}
