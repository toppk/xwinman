/*
 * Graphics implementation on top of X
 */

#include <InterViews/paint.h>
#include <InterViews/strtable.h>
#include <InterViews/table.h>
#include <string.h>

Painter* stdpaint;

static void MakeSubString (char* tmp, const char* s, int n) {
    strncpy(tmp, s, n);
    tmp[n] = '\0';
}

/*
 * class Brush
 */

Brush* single;

/*
 * class Color
 */

Color* black;
Color* white;

Color::Color (const char* name) {
    GetColorByName(name);
}

Color::Color (const char* name, int len) {
    char tmp[100];

    MakeSubString(tmp, name, len);
    GetColorByName(tmp);
}

boolean Color::Valid () {
    return pixel != -1;
}

/*
 * class Font
 */

Font* stdfont;

static Table* fontTable;
static StringTable* fontnameTable;

Font::Font (const char* name) {
    if (!Lookup(name, strlen(name))) {
	GetFontByName(name);
    }
}

Font::Font (const char* name, int len) {
    if (!Lookup(name, len)) {
	if (name[len] == '\0') {
	    GetFontByName(name);
	} else {
	    char tmp[256];

	    MakeSubString(tmp, name, len);
	    GetFontByName(tmp);
	}
    }
}

boolean Font::Lookup (const char* name, int len) {
    StringId* s;

    if (fontTable == nil) {
	fontTable = new Table(32);
	fontnameTable = new StringTable(32);
    }
    s = fontnameTable->Id(name, len);
    if (fontTable->Find(rep, s)) {
	rep->Reference();
	return true;
    }
    rep = new FontRep;
    fontTable->Insert(s, rep);
    return false;
}

int Font::Height () {
    return rep->height;
}

int Font::Index (const char* s, int offset, boolean between) {
    return Index(s, strlen(s), offset, between);
}

boolean Font::Valid () {
    return rep->height != -1;
}

/*
 * class Pattern
 */

Pattern* solid;
Pattern* clear;
Pattern* lightgray;
Pattern* gray;
Pattern* darkgray;
