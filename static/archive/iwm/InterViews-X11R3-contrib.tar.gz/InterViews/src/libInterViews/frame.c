/*
 * A frame surrounds another interactor, providing borders, title banners, etc.
 */

#include <InterViews/banner.h>
#include <InterViews/border.h>
#include <InterViews/box.h>
#include <InterViews/canvas.h>
#include <InterViews/frame.h>
#include <InterViews/painter.h>
#include <InterViews/pattern.h>
#include <InterViews/shape.h>
#include <InterViews/sensor.h>

Frame::Frame (Interactor* i, int w) {
    Init(i, w, w, w, w);
}

Frame::Frame (const char* name, Interactor* i, int w) {
    SetInstance(name);
    Init(i, w, w, w, w);
}

Frame::Frame (Interactor* i, int l, int b, int r, int t) {
    Init(i, l, b, r, t);
}

Frame::Frame (const char* name, Interactor* i, int l, int b, int r, int t) {
    SetInstance(name);
    Init(i, l, b, r, t);
}

Frame::Frame (
    Painter* p, Interactor* i, int l, int b, int r, int t
) : (nil, p) {
    Init(i, l, b, r, t);
}

Frame::Frame (Painter* p, Interactor* i, int w) : (nil, p) {
    Init(i, w, w, w, w);
}

void Frame::Init (Interactor* i, int l, int b, int r, int t) {
    SetClassName("Frame");
    left = l;
    bottom = b;
    right = r;
    top = t;
    if (i != nil) {
	Insert(i);
    }
    input = onoffEvents;
    input->Reference();
}

void Frame::Reconfig () {
    MonoScene::Reconfig();
    shape->width += left + right;
    shape->height += bottom + top;
}

void Frame::Resize () {
    canvas->SetBackground(output->GetBgColor());
    Place(component, left, bottom, xmax - right, ymax - top);
}

void Frame::Redraw (Coord x1, Coord y1, Coord x2, Coord y2) {
    register Coord r = xmax - right;
    register Coord t = ymax - top;

    if (x1 < left || y1 < bottom || x2 > r || y2 > t) {
        /* top strip */
        output->FillRect(canvas, 0, t+1, xmax, ymax);
        /* bottom strip */
        output->FillRect(canvas, 0, 0, xmax, bottom-1);
        /* left strip */
        output->FillRect(canvas, 0, bottom, left-1, t);
        /* right strip */
        output->FillRect(canvas, r+1, bottom, xmax, t);
    }
}

void Frame::Handle (Event& e) {
    if (e.eventType == OnEvent) {
        Highlight(true);
    } else if (e.eventType == OffEvent) {
        Highlight(false);
    } else {
	HandleInput(e);
    }
}

void Frame::HandleInput (Event& e) {
    component->Handle(e);
}

void Frame::Highlight (boolean) {
    /* default is to do nothing */
}

/*
 * A title frame is a frame around a box containing
 * a banner, border, and the component.
 */

TitleFrame::TitleFrame (Banner* b, Interactor* i, int w) : (nil, w) {
    Init(b, i);
}

TitleFrame::TitleFrame (
    const char* name, Banner* b, Interactor* i, int w
) : (name, nil, w) {
    Init(b, i);
}

TitleFrame::TitleFrame (
    Painter* out, Banner* b, Interactor* i, int width
) : (out, nil, width) {
    Init(b, i);
}

void TitleFrame::Init (Banner* b, Interactor* i) {
    SetClassName("TitleFrame");
    banner = b;
    if (i != nil) {
	Insert(i);
    }
}

Interactor* TitleFrame::Wrap (Interactor* i) {
    Scene* p = banner->Parent();
    if (p != nil) {
	p->Remove(banner);
    }
    return new VBox(banner, new HBorder, i);
}

void TitleFrame::Highlight (boolean b) {
    banner->highlight = b;
    banner->Draw();
}

BorderFrame::BorderFrame (Interactor* i, int w) : (i, w) {
    Init();
}

BorderFrame::BorderFrame (
    const char* name, Interactor* i, int w
) : (name, i, w) {
    Init();
}

BorderFrame::BorderFrame (Painter* out, Interactor* i, int w) : (out, i, w) {
    Init();
}

void BorderFrame::Init () {
    SetClassName("BorderFrame");
    grayout = nil;
    normal = false;
}

void BorderFrame::Reconfig () {
    Frame::Reconfig();
    delete grayout;
    grayout = new Painter(output);
    grayout->SetPattern(gray);
}

void BorderFrame::Delete () {
    delete grayout;
}

void BorderFrame::Highlight (boolean b) {
    normal = b;
    Redraw(0, 0, xmax, ymax);
}

void BorderFrame::Redraw (Coord x1, Coord y1, Coord x2, Coord y2) {
    if (normal) {
	Frame::Redraw(x1, y1, x2, y2);
    } else {
	Painter* tmp = output;
	output = grayout;
	Frame::Redraw(x1, y1, x2, y2);
	output = tmp;
    }
}

/*
 * A shadow frame is a frame with a drop shadow.
 */

ShadowFrame::ShadowFrame (Interactor* i, int h, int v) {
    Init(i, h, v);
}

ShadowFrame::ShadowFrame (
    const char* name, Interactor* i, int h, int v
) : (name) {
    Init(i, h, v);
}

ShadowFrame::ShadowFrame (Painter* p, Interactor* i, int h, int v) : (p) {
    Init(i, h, v);
}

void ShadowFrame::Init (Interactor* i, int h, int v) {
    if (h > 0) {
	bottom += h;
    } else {
	top += -h;
    }
    if (v > 0) {
	right += v;
    } else {
	left += -v;
    }
    if (i != nil) {
	Insert(i);
    }
}

void ShadowFrame::Redraw (Coord x1, Coord y1, Coord x2, Coord y2) {
    register Coord r = xmax - right + 1;
    register Coord t = ymax - top + 1;
    Coord hsl, hsb, hsr, hst, vsl, vsb, vsr, vst;  // horiz & vert shadow rects

    if (x1 < left || y1 < bottom || x2 > r || y2 > t) {
        /* top strip */
        output->FillRect(canvas, left-1, t, r, t);
        /* bottom strip */
        output->FillRect(canvas, left-1, bottom-1, r, bottom-1);
        /* left strip */
        output->FillRect(canvas, left-1, bottom-1, left-1, t);
        /* right strip */
        output->FillRect(canvas, r, bottom-1, r, t);

	if (right > 1) {
	    hsl = 2*left - 1;
	    hsr = xmax;
	    vsl = r + 1;
	    vsr = xmax;
	} else if (left > 1) {
	    hsl = 0;
	    hsr = r - right;
	    vsl = 0;
	    vsr = left - 1;
	}
	if (bottom > 1) {
	    hsb = 0;
	    hst = bottom - 1;
	    vsb = 0;
	    vst = t - top;
	} else if (top > 1) {
	    hsb = t + 1;
	    hst = ymax;
	    vsb = 2*bottom - 1;
	    vst = ymax;
	}
	output->FillRect(canvas, hsl, hsb, hsr, hst);
	output->FillRect(canvas, vsl, vsb, vsr, vst);
    }
}
