/*
 * X10-dependent methods for window management.
 */

#include <InterViews/canvas.h>
#include <InterViews/color.h>
#include <InterViews/cursor.h>
#include <InterViews/font.h>
#include <InterViews/interactor.h>
#include <InterViews/painter.h>
#include <InterViews/reqerr.h>
#include <InterViews/rubrect.h>
#include <InterViews/scene.h>
#include <InterViews/sensor.h>
#include <InterViews/shape.h>
#include <InterViews/table.h>
#include <InterViews/world.h>
#include <InterViews/worldview.h>
#include <InterViews/X10/Xinput.h>
#include <InterViews/X10/Xoutput.h>
#include <InterViews/X10/Xutil.h>
#include <InterViews/X10/Xwindow.h>
#include <stdio.h>
#include <string.h>
#include <osfcn.h>

Table* assocTable;
XDisplay* _World_dpy;
int _World_nplanes;
int _Workstation_planemask;

/*
 * class Canvas
 */

/*
 * In X10, we implement clipping with a transparent window.
 * The window and (x,y) offset are stored in the associated CanvasRep.
 */

class CanvasRep {
    friend class Canvas;

    boolean active;
    Coord left, bottom;
    Canvas* unclipped;

    CanvasRep();
    ~CanvasRep();
};

CanvasRep::CanvasRep () {
    active = false;
    left = 0;
    bottom = 0;
    unclipped = nil;
}

CanvasRep::~CanvasRep () {
    delete unclipped;
}

Canvas::Canvas (void* c) {
    id = c;
    width = 0;
    height = 0;
    status = CanvasUnmapped;
    rep = nil;
}

Canvas::Canvas (int w, int h) {
    id = nil;
    width = w;
    height = h;
    status = CanvasOffscreen;
    rep = nil;
}

Canvas::~Canvas () {
    if (id != nil) {
	if (status == CanvasOffscreen) {
	    XFreePixmap(id);
	} else {
	    XDestroyWindow(id);
	    assocTable->Remove(id);
	}
	id = nil;
    }
    delete rep;
}

void Canvas::WaitForCopy () {
    XEvent xe;
    register XExposeEvent* r = (XExposeEvent*)&xe;
    Interactor* i;

    for (;;) {
	XWindowEvent(id, ExposeCopy|ExposeRegion, xe);
	if (xe.type == ExposeCopy) {
	    break;
	}
	/* must be ExposeRegion */
	if (assocTable->Find(i, r->window)) {
	    i->Redraw(
		r->x, height - r->y - r->height,
		r->x + r->width - 1, height - 1 - r->y
	    );
	}
    }
}

void Canvas::SetBackground (Color* c) {
    XPixmap p;
    
    void* w = (rep != nil && rep->active) ? rep->unclipped->id : id;
    if (id != nil && status != CanvasOffscreen) {
	if (c == white) {
	    XChangeBackground(w, XWhitePixmap);
	} else if (c == black) {
	    XChangeBackground(w, XBlackPixmap);
	} else {
	    p = XMakeTile(c->PixelValue());
	    XChangeBackground(w, p);
	    XFreePixmap(p);
	}
    }
}

void Canvas::Clip (Coord x1, Coord y1, Coord x2, Coord y2) {
    Coord left, bottom, right, top;
    int w, h;

    if (x1 <= x2) {
	left = x1; right = x2;
    } else {
	left = x2; right = x1;
    }
    if (y1 <= y2) {
	bottom = y1; top = y2;
    } else {
	bottom = y2; top = y1;
    }
    w = right - left + 1;
    h = top - bottom + 1;
    if (rep != nil) {
	top = rep->unclipped->height - 1 - top;
	XConfigureWindow(id, x1, top, w, h);
    } else {
	top = height - 1 - top;
	rep = new CanvasRep;
	rep->unclipped = new Canvas(XCreateTransparency(id, x1, top, w, h));
	ClipOn();
	XSelectInput(id, EnterWindow|LeaveWindow);
	XMapWindow(id);
    }
    rep->left = x1;
    rep->bottom = y1;
    width = w;
    height = h;
}

void Canvas::NoClip () {
    ClipOff();
    delete rep;
    rep = nil;
}

/*
 * Temporarily turn clipping on/off.
 */

void Canvas::ClipOn () {
    if (rep != nil && !rep->active) {
	rep->active = true;
	register Canvas* c = rep->unclipped;
	void* tmp = id; id = c->id; c->id = tmp;
	int itmp = width; width = c->width; c->width = itmp;
	itmp = height; height = c->height; c->height = itmp;
    }
}

void Canvas::ClipOff () {
    if (rep != nil && rep->active) {
	rep->active = false;
	register Canvas* c = rep->unclipped;
	void* tmp = id; id = c->id; c->id = tmp;
	int itmp = width; width = c->width; c->width = itmp;
	itmp = height; height = c->height; c->height = itmp;
    }
}

boolean Canvas::IsClipped () {
    return rep != nil && rep->active;
}

void Canvas::Map (register Coord& x, register Coord& y) {
    if (rep != nil && rep->active) {
	x -= rep->left;
	y -= rep->bottom;
    }
    y = height - 1 - y;
}

/*
 * class Interactor
 */

int Interactor::Fileno () {
    return Xdpyno();
}

void Interactor::Listen (Sensor* s) {
    unsigned mask;

    cursensor = s;
    if (canvas != nil) {
	if (s == nil && Parent() != nil) {
	    XSelectInput(canvas->id, ExposeRegion|ExposeCopy);
	} else {
	    if (Parent() == nil) {
		if (s->mask & (ExposeRegion|ExposeCopy)) {
		    mask = s->mask & ~(ExposeRegion|ExposeCopy);
		} else {
		    mask = s->mask;
		}
	    } else {
		mask = s->mask;
	    }
	    XSelectInput(canvas->id, mask);
	}
    }
}

void Interactor::DoSetCursor (Cursor* c) {
    XDefineCursor(canvas->id, c->Id());
    Flush();
}

boolean Interactor::GetEvent (Event& e, boolean) {
    XEvent xe;
    register XExposeEvent* r = (XExposeEvent*)&xe;
    Interactor* i;

    XNextEvent(xe);
    if (assocTable->Find(i, xe.window)) {
	if (i->cursensor != nil && i->cursensor->Interesting(&xe, e)) {
	    e.target = i;
	    e.y = i->ymax - e.y;
	    return true;
	} else if (xe.type == ExposeRegion) {
	    i->SendRedraw(r->x, r->y, r->width, r->height, 0);
	} else if (xe.type == ExposeWindow && i->parent->parent == nil) {
	    i->SendResize(0, 0, r->width, r->height);
	}
    }
    return false;
}

/*
 * Check to see if any input events of interest are pending.
 * This routine will return true even if the event is for another interactor.
 */

boolean Interactor::Check () {
    XEvent xe;
    Event e;
    register XExposeEvent* r = (XExposeEvent*) &xe;
    Interactor* i;

    while (XPending()) {
	XNextEvent(xe);
	if (assocTable->Find(i, xe.window)) {
	    if (i->cursensor != nil && i->cursensor->Interesting(&xe, e)) {
		XPutBackEvent(xe);
		return true;
	    } else if (xe.type == ExposeRegion) {
		i->SendRedraw(r->x, r->y, r->width, r->height, 0);
	    } else if (xe.type == ExposeWindow && i->parent->parent == nil) {
		i->SendResize(0, 0, r->width, r->height);
	    }
	}
    }
    return false;
}

int Interactor::CheckQueue () {
    return XQLength();
}

/*
 * Translate an ExposeRegion into the appropriate Redraw call.
 */

void Interactor::SendRedraw (Coord x, Coord iy, int w, int h, int) {
    register Coord y;

    y = ymax-iy;
    if (canvas->IsClipped()) {
	canvas->ClipOff();
	Redraw(x, y-h+1, x+w-1, y);
	canvas->ClipOn();
    } else {
	Redraw(x, y-h+1, x+w-1, y);
    }
}

/*
 * Translate an ExposeWindow event to the appropriate call.
 * ExposeWindow can imply either a full redraw
 * (as in the window moved) or a resize, so we check for a size change
 * explicitly.
 */

void Interactor::SendResize (Coord, Coord, int w, int h) {
    register Canvas* c;
    XWindowInfo info;

    c = canvas;
    if (canvas->IsClipped()) {
	canvas->ClipOff();
    }
    XQueryWindow(canvas->id, info);
    left = info.x;
    bottom = parent->ymax - info.y - h + 1;
    if (w != c->width || h != c->height) {
	c->width = w;
	c->height = h;
	/*
	 * Since Canvas::Clip can't rely on Interactor::ymax to calculate
	 * top, it must instead use height - 1.  So we have to update
	 * height here (potentially twice if there's no clipping, but
	 * it's really not worth a conditional).
	 */
	canvas->height = h;
	xmax = w - 1;
	ymax = h - 1;
	XUnmapSubwindows(c->id);
	Resize();
    }
    Draw();
    if (canvas->IsClipped()) {
	canvas->ClipOn();
    }
}

void Interactor::Poll (Event& e) {
    int x, y;
    short state;
    register short s;
    XWindow dummy;
    register Interactor* i;
    int offx, offy;

    offx = 0;
    offy = 0;
    for (i = this; i->parent != nil; i = i->parent) {
	offx += i->left;
	offy += i->bottom;
    }
    XQueryMouseButtons(i->canvas->id, x, y, dummy, state);
    e.x = x - offx;
    e.y = (i->ymax - y) - offy;
    e.w = (World*)i;
    e.wx = x;
    e.wy = y;
    s = state;
    e.control = (s&ControlMask) != 0;
    e.meta = (s&MetaMask) != 0;
    e.shift = (s&ShiftMask) != 0;
    e.shiftlock = (s&ShiftLockMask) != 0;
    e.leftmouse = (s&LeftMask) != 0;
    e.middlemouse = (s&MiddleMask) != 0;
    e.rightmouse = (s&RightMask) != 0;
}

void Interactor::Flush () {
    XFlush();
}

void Interactor::Sync () {
    XSync(0);
}

void Interactor::GetRelative (Coord& x, Coord& y, Interactor* rel) {
    register Interactor* t, * r;
    Coord tx, ty, rx, ry;

    if (parent == nil) {
	if (rel == nil || rel->parent == nil) {
	    /* world relative to world -- nop */
	    return;
	}
	/* world relative to interactor is relative to interactor's l, b */
	rx = 0; ry = 0;
	rel->GetRelative(rx, ry);
	x = x - rx;
	y = y - ry;
	return;
    }
    tx = x; ty = y;
    for (t = this; t->parent->parent != nil; t = t->parent) {
	tx += t->left;
	ty += t->bottom;
    }
    if (rel == nil || rel->parent == nil) {
	r = nil;
    } else {
	rx = 0; ry = 0;
	for (r = rel; r->parent->parent != nil; r = r->parent) {
	    rx += r->left;
	    ry += r->bottom;
	}
    }
    if (r == t) {
	/* this and rel are within same top-level interactor */
	x = tx - rx;
	y = ty - ry;
    } else {
	XWindowInfo info;

	XQueryWindow(t->canvas->id, info);
	x = tx + info.x;
	y = ty + t->parent->ymax - (info.y + info.height - 1);
	if (r != nil) {
	    XQueryWindow(r->canvas->id, info);
	    x -= rx + info.x;
	    y -= ry + t->parent->ymax - (info.y + info.height - 1);
	}
    }
}

void Interactor::DoSetName (const char* s) {
    XStoreName(canvas->id, s);
}

void Interactor::DoSetIcon (Interactor* i) {
    if (i == nil) {
	XClearIconWindow(canvas->id);
    } else if (i->canvas != nil) {
	XSetIconWindow(canvas->id, i->canvas->id);
    }
}

static XWindow FindIcon (XWindow w) {
    XWindowInfo info;
    XQueryWindow(w, info);
    return info.assoc_wind;
}

void Interactor::Iconify () {
    XWindow w = nil;
    Interactor* i = GetIcon();
    if (i != nil && i->canvas != nil) {
	w = i->canvas->id;
	i->canvas->status = CanvasMapped;
    }
    if (w == nil && canvas != nil) {
	w = FindIcon(canvas->id);
    }
    if (w != nil) {
	XMapWindow(w);
	if (canvas != nil && canvas->id != nil) {
	    XUnmapWindow(canvas->id);
	    canvas->status = CanvasUnmapped;
	}
    }
}

void Interactor::DeIconify () {
    if (canvas != nil && canvas->id != nil) {
	XMapWindow(canvas->id);
	canvas->status = CanvasMapped;
	XWindow w = nil;
	Interactor* i = GetIcon();
	if (i != nil && i->canvas != nil) {
	    w = i->canvas->id;
	    i->canvas->status = CanvasUnmapped;
	}
	if (w == nil && canvas != nil) {
	    w = FindIcon(canvas->id);
	}
	if (w != nil) {
	    XUnmapWindow(w);
	}
    }
}

/*
 * class ReqErr
 */

static ReqErr* errhandler;

ReqErr::ReqErr () {
    /* no constructor code currently necessary */
}

ReqErr::~ReqErr () {
    if (errhandler == this) {
	errhandler = nil;
    }
}

void ReqErr::Error () {
    /* default is to do nothing */
}

static void DoXError (XDisplay*, register XErrorEvent* e) {
    extern const char* XErrDescrip(int);
    register ReqErr* r = errhandler;
    if (r != nil) {
	r->msgid = e->serial;
	r->code = e->error_code;
	r->request = e->request_code;
	r->detail = e->func;
	r->id = e->window;
	strncpy(r->message, XErrDescrip(r->code), sizeof(r->message));
	r->Error();
    }
}

ReqErr* ReqErr::Install () {
    typedef void XHandler(void*, XErrorEvent*);
    extern void XErrorHandler(XHandler*);

    if (errhandler == nil) {
	XErrorHandler(DoXError);
    }
    ReqErr* r = errhandler;
    errhandler = this;
    return r;
}

/*
 * class Scene
 */

typedef struct ExposeList {
    XEvent* event;
    ExposeList* next;
};

void Scene::UserPlace (Interactor* i) {
    Event e;
    Coord x1, y1, x2, y2, tmp;
    RubberRect* r;
    const int mask = ButtonPressed|ButtonReleased|MouseMoved;
    register XEvent* xe;
    register ExposeList* list = nil;
    register ExposeList* el;

    do {
	Poll(e);
    } while (e.leftmouse || e.middlemouse || e.rightmouse);
    while (!XGrabMouse(canvas->id, upperleft->Id(), mask)) {
	sleep(1);
    }
    do {
	Poll(e);
    } while (!e.leftmouse && !e.middlemouse && !e.rightmouse);
    e.target = this;
    e.GetAbsolute(x1, y1);
    if (e.leftmouse && i->shape->width != 0) {
	x2 = x1 + i->shape->width - 1;
	y2 = y1 + i->shape->height - 1;
	r = new SlidingRect(output, canvas, x1, y1, x2, y2, x1, y2);
	r->Track(x1, y1);
    } else {
	do {
	    Poll(e);
	    e.target = this;
	    e.GetAbsolute(x2, y2);
	    x2 = e.x; y2 = e.y;
	} while (x2 == x1 && y2 == y1 &&
	     (e.leftmouse || e.middlemouse || e.rightmouse)
	);
	r = new RubberRect(output, canvas, x1, y1, x2, y1);
	r->Track(x2, y1);
	XGrabMouse(canvas->id, lowerright->Id(), mask);
    }
    XGrabServer();
    while (e.leftmouse || e.middlemouse || e.rightmouse) {
	Poll(e);
	e.target = this;
	e.GetAbsolute(x1, y1);
	x1 = e.x; y1 = e.y;
	r->Track(x1, y1);
    }

    xe = new XEvent;
    while (XPending()) {
	XNextEvent(*xe);
	if (xe->type == ExposeRegion || xe->type == ExposeWindow ||
	    xe->type == ExposeCopy
	) {
	    el = new ExposeList;
	    el->event = xe;
	    el->next = list;
	    list = el;
	    xe = new XEvent;
	}
    }
    while (list != nil) {
	XPutBackEvent(*list->event);
	delete(list->event);
	list = list->next;
    }

    XUngrabServer();
    XUngrabMouse();
    r->GetCurrent(x1, y1, x2, y2);
    delete r;

    if (x1 > x2) {
	tmp = x1; x1 = x2; x2 = tmp;
    } else if (x1 == x2) {
	x2 = x1 + 10;
    }
    if (y1 > y2) {
	tmp = y1; y1 = y2; y2 = tmp;
    } else if (y1 == y2) {
	y2 = y1 + 10;
    }
    Place(i, x1, y1, x2, y2);
}

void Scene::Place (
    Interactor* i, Coord x1, Coord y1, Coord x2, Coord y2, boolean map
) {
    register XWindow id;
    register int w, h;
    Coord top;
    static boolean traversing = false;

    if (i->parent != nil && i->parent != this) {
	i->parent->Remove(i);
    }
    if (parent == nil) {
	traversing = true;
    }
    i->parent = this;
    top = ymax - y2;
    w = x2 - x1 + 1;
    h = y2 - y1 + 1;
    if (i->canvas == nil) {
	id = XCreateWindow(canvas->id, x1, top, w, h, 0, 0, 0);
	i->canvas = new Canvas(id);
	Assign(i, x1, y1, w, h);
	InitCanvas(i);
    } else {
	id = i->canvas->id;
	XUnmapSubwindows(id);
	XConfigureWindow(id, x1, top, w, h);
	Assign(i, x1, y1, w, h);
    }
    if (map) {
	XMapWindow(id);
	i->canvas->status = CanvasMapped;
    }
    if (!traversing) {
	i->Redraw(0, 0, i->xmax, i->ymax);
    }
    if (parent == nil) {
	traversing = false;
    }
}

void Scene::Map (register Interactor* i, boolean) {
    XMapWindow(i->canvas->id);
    i->canvas->status = CanvasMapped;
    if (parent != nil) {
	i->Draw();
    }
}

void Scene::Unmap (register Interactor* i) {
    XUnmapWindow(i->canvas->id);
    i->canvas->status = CanvasUnmapped;
}

void Scene::InitCanvas (register Interactor* i) {
    register XWindow id = i->canvas->id;
    Coord x, y;

    const char* s = i->GetName();
    if (s != nil) {
	i->DoSetName(s);
    }
    Interactor* ic = i->GetIcon();
    if (ic != nil) {
	if (ic->canvas == nil) {
	    ic->parent = this;
	    x = i->left + ((i->xmax - ic->shape->width) >> 1) + 1;
	    y = i->bottom + ((i->ymax - ic->shape->height) >> 1) + 1;
	    ic->canvas = new Canvas(
		XCreateWindow(
		    canvas->id,
		    x, ymax - (y + ic->shape->height - 1),
		    ic->shape->width, ic->shape->height,
		    0, 0, 0
		)
	    );
	    Assign(ic, x, y, ic->shape->width, ic->shape->height);
	    InitCanvas(ic);
	    i->DoSetIcon(ic);
	} else {
	    i->DoSetIcon(ic);
	}
    }
    if (i->cursensor == nil) {
	if (i->input == nil) {
	    XSelectInput(id, ExposeRegion|ExposeCopy);
	} else {
	    i->cursensor = i->input;
	    XSelectInput(id, i->cursensor->mask);
	}
    } else {
	XSelectInput(id, i->cursensor->mask);
    }
    Cursor* c = i->GetCursor();
    if (c != nil) {
	XDefineCursor(id, c->Id());
    } else if (parent == nil) {
	XDefineCursor(id, defaultCursor->Id());
    }
    assocTable->Insert(id, i);
}

void Scene::Raise (Interactor* i) {
    if (i->canvas != nil && i->canvas->status != CanvasOffscreen) {
	XRaiseWindow(i->canvas->id);
    }
}

void Scene::Lower (Interactor* i) {
    if (i->canvas != nil && i->canvas->status != CanvasOffscreen) {
	XLowerWindow(i->canvas->id);
    }
}

void Scene::Change (Interactor* i) {
    if (propagate) {
	DoChange(i);
	if (parent != nil) {
	    parent->Change(this);
	}
    } else if (canvas != nil) {
	Resize();
	Draw();
    }
}

void Scene::DoMove (Interactor* i, Coord& x, Coord& y) {
    XMoveWindow(i->canvas->id, x, ymax - y);
}

/*
 * class Sensor
 */

int motionmask = MouseMoved;
int keymask = KeyPressed;
int entermask = EnterWindow;
int leavemask = LeaveWindow;
int focusmask = FocusChange;
int substructmask = 0;
int upmask = ButtonPressed|ButtonReleased;
int downmask = ButtonPressed|ButtonReleased;
int initmask = ExposeRegion|ExposeCopy;

static XWindow focus;
static Sensor* grabber;

boolean Sensor::Interesting (void* raw, Event& e) {
    boolean b;
    XEvent* x = (XEvent*) raw;
    register XMouseEvent* m = (XMouseEvent*)x;
    XFocusChangeEvent* f = (XFocusChangeEvent*)x;

    b = false;
    switch (x->type) {
	case MouseMoved:
	    e.eventType = MotionEvent;
	    e.x = m->x;
	    e.y = m->y;
	    e.w = nil;
	    e.wx = (m->location >> 16) & 0xffff;
	    e.wy = m->location & 0xffff;
	    b = true;
	    break;
	case KeyPressed:
	    e.eventType = KeyEvent;
	    e.GetButtonInfo(x);
	    b = ButtonIsSet(down, e.button);
	    break;
	case ButtonPressed:
	    e.eventType = DownEvent;
	    e.GetButtonInfo(x);
	    b = ButtonIsSet(down, e.button);
	    if (b && ButtonIsSet(up, e.button)) {
		grabber = this;
	    } else {
		grabber = nil;
	    }
	    break;
	case ButtonReleased:
	    e.eventType = UpEvent;
	    e.GetButtonInfo(x);
	    b = ButtonIsSet(up, e.button) || (grabber != nil);
	    break;
	case FocusChange:
	    if (f->subwindow == nil) {
		if (f->detail == EnterWindow) {
		    focus = f->window;
		    e.eventType = OnEvent;
		} else {
		    focus = nil;
		    e.eventType = OffEvent;
		}
		b = true;
	    }
	    break;
	case EnterWindow:
	    if (f->subwindow == nil && f->detail != 1 && f->window != focus) {
		e.eventType = OnEvent;
		b = true;
	    }
	    break;
	case LeaveWindow:
	    if (f->subwindow == nil && f->detail != 1 && f->window != focus) {
		e.eventType = OffEvent;
		b = true;
	    }
	    break;
	default:
	    /* ignore */;
    }
    return b;
}

void Event::GetButtonInfo (void* xe) {
    register XKeyOrButtonEvent* k = (XKeyOrButtonEvent*)xe;
    register int state;
    int n;

    timestamp = 10 * k->time;
    x = k->x;
    y = k->y;
    w = nil;
    wx = (k->location >> 16) & 0xffff;
    wy = k->location & 0xffff;
    state = k->detail;
    shift = (state & ShiftMask) != 0;
    control = (state & ControlMask) != 0;
    meta = (state & MetaMask) != 0;
    shiftlock = (state & ShiftLockMask) != 0;
    leftmouse = (state & LeftMask) != 0;
    middlemouse = (state & MiddleMask) != 0;
    rightmouse = (state & RightMask) != 0;
    button = state & 0xff;
    if (k->type == KeyPressed) {
	keystring = XLookupMapping(*k, n);
	len = n;
    } else {
	button = 2 - button;
	len = 0;
    }
    if (len == 0) {
	keystring = keydata;
	keydata[0] = '\0';
    }
}

/*
 * class World
 */

class WorldRep {
    friend class World;

    XDisplay* display;
    XWindow root;
};

void World::Init (const char* device) {
    rep = new WorldRep;
    rep->display = XOpenDisplay(device);
    if (rep->display == nil) {
	fprintf(stderr, "fatal error: can't open display\n");
	exit(1);
    }
    rep->root = XRootWindow;
    SetCurrent();
    if (assocTable == nil) {
	assocTable = new Table(4096);
    }
    canvas = new Canvas(rep->root);
    canvas->width = DisplayWidth();
    canvas->height = DisplayHeight();
    canvas->status = CanvasMapped;
    _Workstation_planemask = AllPlanes;
    _World_nplanes = XDisplayPlanes();
    inch = 78.0; /* what X11 tells me for a VAXstation */
    inches = inch;
    cm = inch/2.54;
    point = 1;
    points = 1;
    assocTable->Insert(rep->root, this);
    xmax = canvas->width - 1;
    ymax = canvas->height - 1;
    black = new Color(0);
    white = new Color(1);
    stdfont = new Font("6x13p");
    stdpaint = new Painter;
}

void World::Delete () {
    assocTable->Remove(rep->root);
    XCloseDisplay(rep->display);
    delete rep;
    Scene::Delete();
}

const char* World::UserDefaults () {
    return nil;
}

void World::FinishInsert (Interactor* i) {
    XEvent xevent;

    XWindowEvent(i->canvas->id, ExposeWindow, xevent);
    i->Draw();
}

void World::DoChange (Interactor* i) {
    XEvent xevent;

    Coord x = 0;
    Coord y = 0;
    i->GetRelative(x, y, this);
    Shape* s = i->GetShape();
    Place(i, x, y, x + s->width - 1, y + s->height - 1);
    XWindowEvent(i->canvas->id, ExposeWindow, xevent);
    i->Draw();
}

void World::DoRemove (Interactor*) {
    XFlush();
}

int World::Fileno () {
    return Xdpyno();
}

void World::SetCurrent () {
    XSetDisplay(rep->display);
    _Workstation_planemask = AllPlanes;
    _World_nplanes = XDisplayPlanes();
}

void World::SetRoot (void*) {}
void World::SetScreen (int) {}

int World::NPlanes () {
    return XDisplayPlanes();
}

int World::NButtons () {
    return 3;
}

int World::PixelSize () {
    return XYPixmapSize(32, 1, XDisplayPlanes()) >> 2;
}

const char* World::GetDefault (const char* name) {
    return GetAttribute(name);
}

const char* World::GetGlobalDefault (const char* name) {
    return GetAttribute(name);
}

unsigned World::ParseGeometry (
    char* spec, Coord& x, Coord& y, int& w, int &h
) {
    extern unsigned XParseGeometry(char*, Coord&, Coord&, int&, int&);

    return XParseGeometry(spec, x, y, w, h);
}

void World::RingBell (int v) {
    if (v > 7) {
	XFeep(7);
    } else if (v >= 0) {
	XFeep(v);
    }
}

void World::SetKeyClick (int v) {
    XKeyClickControl(v);
}

void World::SetAutoRepeat (boolean b) {
    if (b) {
	XAutoRepeatOn();
    } else {
	XAutoRepeatOff();
    }
}

void World::SetFeedback (int thresh, int scale) {
    XMouseControl(scale, thresh);
}

/*
 * class WorldView
 */

void WorldView::Init (World*) {
    canvas = new Canvas(XRootWindow);
    canvas->width = DisplayWidth();
    canvas->height = DisplayHeight();
    canvas->status = CanvasMapped;
    xmax = canvas->width - 1;
    ymax = canvas->height - 1;
}

const int bmask = ButtonPressed|ButtonReleased;

void WorldView::GrabMouse (Cursor* c) {
    while (!XGrabMouse(world->canvas->id, c->Id(), bmask)) {
	sleep(1);
    }
}

void WorldView::UngrabMouse () {
    XUngrabMouse();
}

boolean WorldView::GrabButton (unsigned b, unsigned m, Cursor* c) {
    return XGrabButton(world->canvas->id, c->Id(), b | m, bmask);
}

void WorldView::UngrabButton (unsigned b, unsigned m) {
    XUngrabButton(b | m);
}

void WorldView::Lock () {
    XGrabServer();
}

void WorldView::Unlock () {
    XUngrabServer();
    Sync();
}

void WorldView::ClearInput () {
    XSync(1);
}

void WorldView::MoveMouse (Coord x, Coord y) {
    XWarpMouse(canvas->id, x, ymax - y);
}

void WorldView::Map (RemoteInteractor i) {
    XMapWindow(i);
}

void WorldView::MapRaised (RemoteInteractor i) {
    XMapWindow(i);
}

void WorldView::Unmap (RemoteInteractor i) {
    XUnmapWindow(i);
}

RemoteInteractor WorldView::Find (Coord x, Coord y) {
    RemoteInteractor i;
    Coord rx, ry;

    XInterpretLocator(world->canvas->id, rx, ry, i, (x << 16) | (ymax - y));
    return i;
}

void WorldView::Move (RemoteInteractor i, Coord left, Coord top) {
    XMoveWindow(i, left, ymax - top);
}

void WorldView::Change (
    RemoteInteractor i, Coord left, Coord top, int w, int h
) {
    XConfigureWindow(i, left, ymax - top, w, h);
}

void WorldView::Raise (RemoteInteractor i) {
    XRaiseWindow(i);
}

void WorldView::Lower (RemoteInteractor i) {
    XLowerWindow(i);
}

void WorldView::Focus (RemoteInteractor i) {
    if (i != curfocus) {
	curfocus = i;
	XFocusKeyboard(i == nil ? world->canvas->id : i);
    }
}

void WorldView::GetList (RemoteInteractor*& ilist, int& n) {
    XWindow parent;

    XQueryTree(canvas->id, parent, n, ilist);
}

void WorldView::GetInfo (
    RemoteInteractor i, Coord& x1, Coord& y1, Coord& x2, Coord& y2
) {
    XWindowInfo info;

    XQueryWindow(i, info);
    x1 = info.x;
    y2 = ymax - info.y;
    x2 = info.x + info.width + 2*info.bdrwidth - 1;
    y1 = y2 - info.height - 2*info.bdrwidth + 1;
}

boolean WorldView::GetHints (
    RemoteInteractor, Coord&, Coord&, Shape& s
) {
    s.width = 0;
    s.height = 0;
    return false;
}

void WorldView::SetHints (RemoteInteractor i, Coord x, Coord y, Shape& s) {
    /* unimplemented on X10 */
}

RemoteInteractor WorldView::GetIcon (RemoteInteractor i) {
    XWindowInfo info;

    XQueryWindow(i, info);
    return info.assoc_wind;
}

void WorldView::AssignIcon (RemoteInteractor i, RemoteInteractor icon) {
    XSetIconWindow(i, icon);
}

void WorldView::UnassignIcon (RemoteInteractor i) {
    XClearIconWindow(i);
}

RemoteInteractor WorldView::TransientOwner (RemoteInteractor) {
    return nil;
}

char* WorldView::GetName (RemoteInteractor i) {
    char* name;

    XFetchName(i, name);
    return name;
}
