/*
 * X11-dependent methods for graphics output.
 */

#include <InterViews/bitmap.h>
#include <InterViews/brush.h>
#include <InterViews/canvas.h>
#include <InterViews/color.h>
#include <InterViews/cursor.h>
#include <InterViews/font.h>
#include <InterViews/painter.h>
#include <InterViews/pattern.h>
#include <InterViews/shape.h>
#include <InterViews/transformer.h>
#include <InterViews/world.h>
#include <InterViews/X11/Xlib.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>

/*
 * These global variables are a botch that I would like to remove
 * some time in the future.
 */

extern Display* _World_dpy;
extern int _World_screen;
extern Window _World_root;
extern XColormap _World_cmap;

/*
 * class Bitmap
 */

int Bitmap::Size (int w, int h) {
    return (w*h*BitmapUnit(_World_dpy) + BitmapPad(_World_dpy) - 1) >> 3;
}

int Bitmap::Index (int x, int y) {
    return (width+7)/8 * (height-y-1) + x/8;
}

int Bitmap::Bit (int x, int) {
    return 1 << (x%8);
}

void Bitmap::SetBit (int x, int y) {
    data[Index(x, y)] |= Bit(x, y);
}

void Bitmap::ClearBit (int x, int y) {
    data[Index(x, y)] &= ~Bit(x, y);
}

boolean Bitmap::BitIsSet (int x, int y) {
    return (data[Index(x, y)] & Bit(x, y)) != 0;
}

Bitmap::Bitmap (const char* filename) {
    extern int XReadBitmapFile(
	Display*, Drawable, const char*,
	int& width, int& height, Pixmap&,
	int* x_hot, int* y_hot
    );

    Init();
    XReadBitmapFile(
	_World_dpy, _World_root, filename, width, height,
	(Pixmap)pixmap, nil, nil
    );
}

void Bitmap::FreePixmap () {
    if (pixmap != nil) {
	XFreePixmap(_World_dpy, (Pixmap)pixmap);
	pixmap = nil;
    }
}

void Bitmap::FreeMaps () {
    FreePixmap();
}

void Bitmap::Draw (Canvas* c) {
    if (pixmap == nil && data != nil) {
	pixmap = (void*)XCreateBitmapFromData(
	    _World_dpy, _World_root, data, width, height
	);
    }
    if (pixmap != nil) {
	int xx = x0;
	int yy = (c->Height() - 1) - (height - 1) - y0;
	GC gc = XCreateGC(_World_dpy, _World_root, 0, nil);
	XSetForeground(_World_dpy, gc, foreground->PixelValue());
	XSetBackground(_World_dpy, gc, background->PixelValue());
	XSetGraphicsExposures(_World_dpy, gc, False);
	XCopyPlane(
	    _World_dpy, (Pixmap)pixmap, (Drawable)c->Id(), gc,
	    0, 0, width, height, xx, yy, 1
	);
	XFreeGC(_World_dpy, gc);
    }
}

/*
 * class Brush
 */

static Pixmap MakeStipple(int[patternHeight]);

Brush::Brush (int p, int w) {
    int r[patternHeight];
    register int i;

    width = w;
    for (i = 0; i < patternHeight; i++) {
	r[i] = p;
    }
    info = (void*)MakeStipple(r);
}

Brush::~Brush () {
    if (LastRef()) {
	XFreePixmap(_World_dpy, (Pixmap)info);
    }
}

/*
 * class Color
 */

Color::Color (int r, int g, int b) {
    XColor c;

    c.red = r;
    c.green = g;
    c.blue = b;
    if (XAllocColor(_World_dpy, _World_cmap, &c)) {
	pixel = c.pixel;
	red = c.red;
	green = c.green;
	blue = c.blue;
	allocated = true;
    } else {
	pixel = -1;
	allocated = false;
    }
}

Color::Color (int index, int r, int g, int b) {
    pixel = index;
    red = r;
    green = g;
    blue = b;
    allocated = false;
}

Color::Color (int index) {
    XColor def;

    def.pixel = index;
    XQueryColor(_World_dpy, _World_cmap, def);
    pixel = index;
    red = def.red;
    green = def.green;
    blue = def.blue;
    allocated = false;
}

/*
 * For some reason, X requires special casing for black and white
 * (at least this is true on one-plane systems).
 */

void Color::GetColorByName (const char* name) {
    XColor c, exact;
    char colorname[50];
    register const char* src;
    register char* dst;

    for (
	src = name, dst = colorname;
	*src != '\0' && dst < &colorname[sizeof(colorname) - 1];
	src++, dst++
    ) {
	if (isupper(*src)) {
	    *dst = _tolower(*src);
	} else {
	    *dst = *src;
	}
    }
    *dst = '\0';
    allocated = false;
    if (strcmp(colorname, "black") == 0) {
	c.pixel = BlackPixel(_World_dpy, _World_screen);
	XQueryColor(_World_dpy, _World_cmap, c);
    } else if (strcmp(colorname, "white") == 0) {
	c.pixel = WhitePixel(_World_dpy, _World_screen);
	XQueryColor(_World_dpy, _World_cmap, c);
    } else if (!XLookupColor(_World_dpy, _World_cmap, name, c, exact)) {
	pixel = -1;
	return;
    }
    pixel = c.pixel;
    red = c.red;
    green = c.green;
    blue = c.blue;
}

Color::~Color () {
    if (LastRef()) {
	if (allocated) {
	    unsigned long p[1];

	    p[0] = pixel;
	    XFreeColors(_World_dpy, _World_cmap, p, 1, 0);
	}
    }
}

/*
 * class Cursor
 */

/*
 * Create the pixmap for a cursor.  These are always 16x16, unlike
 * fill patterns, which are 32x32.
 */

static Pixmap MakeCursorPixmap (int* scanline) {
#if vax
    /*
     * Cursor bitmaps work fine on the VAX; I suspect because
     * XPutImage doesn't have to do (misbehaving) swapping on a VAX.
     * The #else code fills the cursor pixmap explicitly because
     * cursor bitmaps don't seem to work right on other machines.
     */
    char data[2*cursorHeight];
    char* p;
    register int i, j;
    register unsigned int s1, s2;
    register unsigned int src, dst;
    union {
	char c[sizeof(short)];
	short s;
    } u;

    p = data;
    for (i = 0; i < cursorHeight; i++) {
	dst = 0;
	src = scanline[i];
	s1 = 1;
	s2 = 1 << (cursorWidth - 1);
	for (j = 0; j < cursorWidth; j++) {
	    if ((s1 & src) != 0) {
		dst |= s2;
	    }
	    s1 <<= 1;
	    s2 >>= 1;
	}
	u.s = dst;
	*p++ = u.c[0];
	*p++ = u.c[1];
    }
    return XCreateBitmapFromData(
	_World_dpy, _World_root, data, cursorWidth, cursorHeight
    );
#else
    /*
     * As best as I can tell, cursors created with a bitmap
     * don't work right.  The problem must be in the X11R2 library,
     * because the cursor has a slight glitch when running either
     * local on the Sun or remote to a VAX X server.
     *
     * I don't have the stomach to try to track down the problem,
     * so the simple solution is to draw into an off-screen pixmap.
     */

    Pixmap dst;
    GC g;
    register int i, j;
    register unsigned s1, s2;

    dst = XCreatePixmap(_World_dpy, _World_root, cursorWidth, cursorHeight, 1);
    g = XCreateGC(_World_dpy, dst, 0, nil);
    XSetForeground(_World_dpy, g, 0);
    XSetFillStyle(_World_dpy, g, FillSolid);
    XFillRectangle(_World_dpy, dst, g, 0, 0, cursorWidth, cursorHeight);
    XSetForeground(_World_dpy, g, 1);
    for (i = 0; i < cursorHeight; i++) {
	s1 = scanline[i];
	s2 = 1;
	for (j = 0; j < cursorWidth; j++) {
	    if ((s1 & s2) != 0) {
		XDrawPoint(_World_dpy, dst, g, cursorWidth - 1 - j, i);
	    }
	    s2 <<= 1;
	}
    }
    XFreeGC(_World_dpy, g);
    return dst;
#endif
}

/*
 * Convert a Color object to the X representation.
 */

static void MakeColor (Color* c, XColor& xc) {
    int r, g, b;

    xc.pixel = c->PixelValue();
    c->Intensities(r, g, b);
    xc.red = r;
    xc.green = g;
    xc.blue = b;
}

void* Cursor::Id () {
    if (id == nil) {
	Pixmap p, m;
	XColor f, b;

	p = MakeCursorPixmap(pat);
	m = MakeCursorPixmap(mask);
	MakeColor(foreground, f);
	MakeColor(background, b);
	id = (void*)XCreatePixmapCursor(
	    _World_dpy, p, m, f, b, x, cursorHeight - 1 - y
	);
	XFreePixmap(_World_dpy, p);
	XFreePixmap(_World_dpy, m);
    }
    return id;
}

Cursor::~Cursor () {
    if (id != nil) {
	XFreeCursor(_World_dpy, (Pixmap)id);
    }
}

/*
 * class Font
 */

void Font::GetFontByName (const char* name) {
    rep->info = XLoadQueryFont(_World_dpy, name);
    Init();
}

inline boolean IsFixedWidth (XFontStruct* i) {
    return i->min_bounds.width == i->max_bounds.width;
}

void Font::Init () {
    register XFontStruct* i = (XFontStruct*)rep->info;
    if (i != nil) {
	rep->id = (void*)i->fid;
	rep->height = i->max_bounds.ascent + i->max_bounds.descent;
    } else {
	rep->height = -1;
    }
}

Font::~Font () {
    if (LastRef()) {
	delete rep;
    }
}

FontRep::~FontRep () {
    if (info != nil && LastRef()) {
	XFreeFont(_World_dpy, (XFontStruct*)info);
    }
}

int Font::Baseline () {
    return 0;
}

int Font::Width (const char* s) {
    return XTextWidth((XFontStruct*)rep->info, s, strlen(s));
}

int Font::Width (const char* s, int len) {
    register const char* p, * q;

    q = &s[len];
    for (p = s; *p != '\0' && p < q; p++);
    return XTextWidth((XFontStruct*)rep->info, s, p - s);
}

int Font::Index (const char* s, int len, int offset, boolean between) {
    register XFontStruct* i = (XFontStruct*)rep->info;
    register const char* p;
    register int n, w;
    int coff, cw;

    if (offset < 0 || *s == '\0' || len == 0) {
	return 0;
    }
    if (IsFixedWidth(i)) {
	cw = i->min_bounds.width;
	n = offset / cw;
	coff = offset % cw;
    } else {
	w = 0;
	for (p = s, n = 0; *p != '\0' && n < len; ++p, ++n) {
	    cw = XTextWidth(i, p, 1);
	    w += cw;
	    if (w > offset) {
		break;
	    }
	}
	coff = offset - w + cw;
    }
    if (between && coff > cw/2) {
	++n;
    }
    return min(n, len);
}

boolean Font::FixedWidth () {
    register XFontStruct* i = (XFontStruct*)rep->info;
    return IsFixedWidth(i);
}

/*
 * class Painter
 */

typedef enum { PaintInvalid, PaintLines, PaintFill } PaintStatus;

class PainterRep {
    friend class Painter;

    int raster;
    GC gc;
    int fillstyle;
    boolean overwrite;
    PaintStatus status;

    PainterRep();
    ~PainterRep();
    void DoPrepare(PaintStatus, void*, void*);
    void Prepare (PaintStatus s, void* pixmap, void* solid) {
	if (status != s) {
	    DoPrepare(s, pixmap, solid);
	}
    }
};

PainterRep::PainterRep () {
    raster = GXcopy;
    gc = XCreateGC(_World_dpy, _World_root, 0, nil);
    XSetFunction(_World_dpy, gc, GXcopy);
    XSetPlaneMask(_World_dpy, gc, AllPlanes);
    fillstyle = 0;
    overwrite = false;
    status = PaintInvalid;
}

PainterRep::~PainterRep () {
    XFreeGC(_World_dpy, gc);
}

void PainterRep::DoPrepare (PaintStatus s, void* pixmap, void* solid) {
    if (pixmap == solid) {
	XSetFillStyle(_World_dpy, gc, FillSolid);
    } else {
	XSetStipple(_World_dpy, gc, (Pixmap)pixmap);
	XSetFillStyle(_World_dpy, gc, fillstyle);
    }
    status = s;
}

/*
 * Short-hand for allocating a vector of X points.
 * The idea is to use a static array if possible; otherwise
 * allocate/deallocate off the heap.
 */

static const XPointListSize = 200;
static XPoint xpoints[XPointListSize];

inline XPoint* AllocPts (int n) {
    return (n <= XPointListSize) ? xpoints : new XPoint[n];
}

inline void FreePts (XPoint* v) {
    if (v != xpoints) {
	delete v;
    }
}

Painter::Painter () {
    rep = new PainterRep;
    Init();
}

Painter::Painter (Painter* copy) {
    rep = new PainterRep;
    rep->raster = copy->rep->raster;
    rep->fillstyle = copy->rep->fillstyle;
    rep->overwrite = copy->rep->overwrite;
    Copy(copy);
    if (rep->overwrite) {
	XSetSubwindowMode(_World_dpy, rep->gc, IncludeInferiors);
    }
    rep->status = PaintInvalid;
}

Painter::~Painter () {
    if (LastRef()) {
	delete matrix;
	delete rep;
    }
}

void Painter::FillBg (boolean b) {
    if (rep->raster == GXxor) {
	End_xor();
    }
    rep->fillstyle = b ? FillOpaqueStippled : FillStippled;
    rep->status = PaintInvalid;
}

boolean Painter::BgFilled () {
    return rep->fillstyle == FillOpaqueStippled;
}

void Painter::SetColors (Color* f, Color* b) {
    if (f != nil && foreground != f) {
	foreground = f;
	if (rep->raster != GXxor) {
	    XSetForeground(_World_dpy, rep->gc, f->PixelValue());
	}
    }
    if (b != nil && background != b) {
	background = b;
	XSetBackground(_World_dpy, rep->gc, b->PixelValue());
    }
}

void Painter::SetPattern (Pattern* pat) {
    if (pattern != pat) {
	pattern = pat;
	rep->status = PaintInvalid;
    }
}

void Painter::SetBrush (Brush* b) {
    if (br != b) {
	br = b;
	if (b != nil) {
	    XSetLineAttributes(
		_World_dpy, rep->gc, b->width, LineSolid, CapButt, JoinMiter
	    );
	}
	rep->status = PaintInvalid;
    }
}

void Painter::SetFont (Font* f) {
    font = f;
    if (f != nil) {
	XSetFont(_World_dpy, rep->gc, (XFont)f->rep->id);
    }
}

void Painter::Clip (
    Canvas* c, Coord left, Coord bottom, Coord right, Coord top
) {
    XRectangle r[1];
    Coord x, y;

    if (left > right) {
	x = right; r[0].width = left - right + 1;
    } else {
	x = left; r[0].width = right - left + 1;
    }
    if (bottom > top) {
	y = bottom; r[0].height = bottom - top + 1;
    } else {
	y = top; r[0].height = top - bottom + 1;
    }
    r[0].x = x;
    r[0].y = c->height - 1 - y;
    if (r[0].x == 0 && r[0].y == 0 &&
	r[0].width == c->width && r[0].height == c->height
    ) {
	/* clipping to entire canvas is equivalent to no clipping at all */
	XSetClipMask(_World_dpy, rep->gc, None);
    } else {
	XSetClipRectangles(_World_dpy, rep->gc, 0, 0, r, 1, Unsorted);
    }
}

void Painter::NoClip () {
    XSetClipMask(_World_dpy, rep->gc, None);
}

void Painter::SetOverwrite (boolean children) {
    if (rep->overwrite != children) {
	rep->overwrite = children;
	XSetSubwindowMode(
	    _World_dpy, rep->gc, children ? IncludeInferiors : ClipByChildren
	);
    }
}

void Painter::SetPlaneMask (int m) {
    XSetPlaneMask(_World_dpy, rep->gc, m);
}

void Painter::Map (Canvas* c, Coord x, Coord y, Coord& mx, Coord& my) {
    if (matrix == nil) {
	mx = x; my = y;
    } else {
	matrix->Transform(x, y, mx, my);
    }
    mx += xoff;
    my = c->height - 1 - (my + yoff);
}

void Painter::MapList (
    Canvas* c, Coord x[], Coord y[], int n, Coord mx[], Coord my[]
) {
    register Coord* xp, * yp, * mxp, * myp;
    Coord* lim;

    xp = x; yp = y;
    mxp = mx; myp = my;
    lim = &x[n];
    if (matrix == nil) {
	for (; xp < lim; xp++, yp++, mxp++, myp++) {
	    *mxp = *xp + xoff;
	    *myp = c->height - 1 - (*yp + yoff);
	}
    } else {
	for (; xp < lim; xp++, yp++, mxp++, myp++) {
	    matrix->Transform(*xp, *yp, *mxp, *myp);
	    *mxp += xoff;
	    *myp = c->height - 1 - (*myp + yoff);
	}
    }
}

void Painter::Begin_xor () {
    if (rep->raster != GXxor) {
	rep->raster = GXxor;
	XSetFunction(_World_dpy, rep->gc, GXxor);
	XSetForeground(_World_dpy, rep->gc, 1);
	XSetFillStyle(_World_dpy, rep->gc, FillSolid);
    }
}

void Painter::End_xor () {
    if (rep->raster != GXcopy) {
	rep->raster = GXcopy;
	XSetFunction(_World_dpy, rep->gc, GXcopy);
	XSetForeground(_World_dpy, rep->gc, foreground->PixelValue());
	XSetFillStyle(_World_dpy, rep->gc, rep->fillstyle);
	rep->status = PaintInvalid;
    }
}

/*
 * InvertArea is only here for the Modula-2 idraw and will be removed
 * as soon as possible.
 */

void Painter::InvertArea (Canvas* c, Coord x1, Coord y1, Coord x2, Coord y2) {
    Coord left, bottom, right, top, tmp;

    Map(c, x1, y1, left, bottom);
    Map(c, x2, y2, right, top);
    if (left > right) {
	tmp = left; left = right; right = tmp;
    }
    if (top > bottom) {
	tmp = bottom; bottom = top; top = tmp;
    }
    if (rep->raster == GXxor) {
	XFillRectangle(
	    _World_dpy, (Drawable)c->id, rep->gc,
	    left, top, right-left+1, bottom-top+1
	);
    } else {
	XSetFunction(_World_dpy, rep->gc, GXxor);
	XSetForeground(_World_dpy, rep->gc, 1);
	XSetFillStyle(_World_dpy, rep->gc, FillSolid);
	XFillRectangle(
	    _World_dpy, (Drawable)c->id, rep->gc,
	    left, top, right-left+1, bottom-top+1
	);
	XSetFunction(_World_dpy, rep->gc, GXcopy);
	XSetForeground(_World_dpy, rep->gc, foreground->PixelValue());
	XSetFillStyle(_World_dpy, rep->gc, rep->fillstyle);
    }
}

void Painter::Text (Canvas* c, const char* s, int len, Coord x, Coord y) {
    register XFontStruct* f = (XFontStruct*)(font->rep->info);
    Coord x0, y0;

    Map(c, x, y + f->descent - 1, x0, y0);
    rep->Prepare(PaintFill, pattern->info, solid->info);
    if (rep->fillstyle == FillStippled) {
	XDrawString(_World_dpy, (Drawable)c->id, rep->gc, x0, y0, s, len);
    } else {
	XDrawImageString(_World_dpy, (Drawable)c->id, rep->gc, x0, y0, s, len);
    }
}

void Painter::Point (Canvas* c, Coord x, Coord y) {
    Coord mx, my;

    Map(c, x, y, mx, my);
    XDrawPoint(_World_dpy, (Drawable)c->id, rep->gc, mx, my);
}

void Painter::MultiPoint (Canvas* c, Coord x[], Coord y[], int n) {
    register XPoint* v;
    register int i;

    v = AllocPts(n);
    for (i = 0; i < n; i++) {
	Map(c, x[i], y[i], v[i].x, v[i].y);
    }
    XDrawPoints(_World_dpy, (Drawable)c->id, rep->gc, v, n, CoordModeOrigin);
    FreePts(v);
}

void Painter::Line (Canvas* c, Coord x1, Coord y1, Coord x2, Coord y2) {
    Coord mx1, my1, mx2, my2;

    Map(c, x1, y1, mx1, my1);
    Map(c, x2, y2, mx2, my2);
    rep->Prepare(PaintLines, br->info, single->info);
    XDrawLine(_World_dpy, (Drawable)c->id, rep->gc, mx1, my1, mx2, my2);
}

void Painter::Rect (Canvas* c, Coord x1, Coord y1, Coord x2, Coord y2) {
    if (matrix != nil && matrix->Rotated() && !matrix->Rotated90()) {
	Coord x[4], y[4];

	x[0] = x[3] = x1;
	x[1] = x[2] = x2;
	y[0] = y[1] = y1;
	y[2] = y[3] = y2;
	Polygon(c, x, y, 4);
    } else {
	Coord left, bottom, right, top, tmp;
	int w, h;

	Map(c, x1, y1, left, bottom);
	Map(c, x2, y2, right, top);
	if (left > right) {
	    tmp = left; left = right; right = tmp;
	}
	if (top > bottom) {
	    tmp = bottom; bottom = top; top = tmp;
	}
	w = right - left;
	h = bottom - top;
	rep->Prepare(PaintLines, br->info, single->info);
	XDrawRectangle(_World_dpy, (Drawable)c->id, rep->gc, left, top, w, h);
    }
}

void Painter::FillRect (Canvas* c, Coord x1, Coord y1, Coord x2, Coord y2) {
    if (matrix != nil && matrix->Rotated() && !matrix->Rotated90()) {
	Coord x[4], y[4];

	x[0] = x[3] = x1;
	x[1] = x[2] = x2;
	y[0] = y[1] = y1;
	y[2] = y[3] = y2;
	FillPolygon(c, x, y, 4);
    } else {
	Coord left, bottom, right, top, tmp;
	int w, h;

	Map(c, x1, y1, left, bottom);
	Map(c, x2, y2, right, top);
	if (left > right) {
	    tmp = left; left = right; right = tmp;
	}
	if (top > bottom) {
	    tmp = bottom; bottom = top; top = tmp;
	}
	w = right - left + 1;
	h = bottom - top + 1;
	rep->Prepare(PaintFill, pattern->info, solid->info);
	XFillRectangle(_World_dpy, (Drawable)c->id, rep->gc, left, top, w, h);
    }
}

void Painter::ClearRect (Canvas* c, Coord x1, Coord y1, Coord x2, Coord y2) {
    XSetForeground(_World_dpy, rep->gc, background->PixelValue());
    Pattern* curpat = pattern;
    SetPattern(solid);
    FillRect(c, x1, y1, x2, y2);
    XSetForeground(_World_dpy, rep->gc, foreground->PixelValue());
    SetPattern(curpat);
}

void Painter::Circle (Canvas* c, Coord x, Coord y, int r) {
    if (matrix != nil && matrix->Stretched()) {
	Ellipse(c, x, y, r, r);
    } else {
	Coord left, top;

	Map(c, x-r, y+r, left, top);
	int d = r+r;
	rep->Prepare(PaintLines, br->info, single->info);
	XDrawArc(
	    _World_dpy, (Drawable)c->id, rep->gc, left, top, d, d, 0, 360*64
	);
    }
}

void Painter::FillCircle (Canvas* c, Coord x, Coord y, int r) {
    if (matrix != nil && matrix->Stretched()) {
	FillEllipse(c, x, y, r, r);
    } else {
	Coord left, top;

	Map(c, x-r, y+r, left, top);
	int d = r+r;
	rep->Prepare(PaintFill, pattern->info, solid->info);
	XFillArc(
	    _World_dpy, (Drawable)c->id, rep->gc, left, top, d, d, 0, 360*64
	);
    }
}

void Painter::MultiLine (Canvas* c, Coord x[], Coord y[], int n) {
    register XPoint* v;
    register int i;

    v = AllocPts(n);
    for (i = 0; i < n; i++) {
	Map(c, x[i], y[i], v[i].x, v[i].y);
    }
    rep->Prepare(PaintLines, br->info, single->info);
    XDrawLines(_World_dpy, (Drawable)c->id, rep->gc, v, n, CoordModeOrigin);
    FreePts(v);
}

void Painter::MultiLineNoMap (Canvas* c, Coord x[], Coord y[], int n) {
    register XPoint* v;
    register int i;

    v = AllocPts(n);
    for (i = 0; i < n; i++) {
	v[i].x = x[i];
	v[i].y = y[i];
    }
    rep->Prepare(PaintLines, br->info, single->info);
    XDrawLines(_World_dpy, (Drawable)c->id, rep->gc, v, n, CoordModeOrigin);
    FreePts(v);
}

void Painter::Polygon (Canvas* c, Coord x[], Coord y[], int n) {
    register XPoint* v;
    register int i;

    v = AllocPts(n+1);
    for (i = 0; i < n; i++) {
	Map(c, x[i], y[i], v[i].x, v[i].y);
    }
    if (x[i-1] != x[0] || y[i-1] != y[0]) {
	v[i] = v[0];
	++i;
    }
    rep->Prepare(PaintLines, br->info, single->info);
    XDrawLines(_World_dpy, (Drawable)c->id, rep->gc, v, i, CoordModeOrigin);
    FreePts(v);
}

void Painter::FillPolygonNoMap (Canvas* c, Coord x[], Coord y[], int n) {
    register XPoint* v;
    register int i;

    v = AllocPts(n);
    for (i = 0; i < n; i++) {
	v[i].x = x[i];
	v[i].y = y[i];
    }
    rep->Prepare(PaintFill, pattern->info, solid->info);
    XFillPolygon(
	_World_dpy, (Drawable)c->id, rep->gc, v, n, Complex, CoordModeOrigin
    );
    FreePts(v);
}

void Painter::FillPolygon (Canvas* c, Coord x[], Coord y[], int n) {
    register XPoint* v;
    register int i;

    v = AllocPts(n+1);
    for (i = 0; i < n; i++) {
	Map(c, x[i], y[i], v[i].x, v[i].y);
    }
    rep->Prepare(PaintFill, pattern->info, solid->info);
    XFillPolygon(
	_World_dpy, (Drawable)c->id, rep->gc, v, n, Complex, CoordModeOrigin
    );
    FreePts(v);
}

void Painter::Copy (
    Canvas* src, Coord x1, Coord y1, Coord x2, Coord y2,
    Canvas* dst, Coord x0, Coord y0
) {
    register int w, h;
    Coord sx1, sy1, dx1, dy1;

    w = x2 - x1 + 1;
    h = y2 - y1 + 1;
    Map(src, x1, y2, sx1, sy1);
    Map(dst, x0, y0+h-1, dx1, dy1);
    if (src->status == CanvasOffscreen) {
	XSetGraphicsExposures(_World_dpy, rep->gc, False);
	XCopyArea(
	    _World_dpy, (Drawable)src->id, (Drawable)dst->id, rep->gc,
	    sx1, sy1, w, h, dx1, dy1
	);
	XSetGraphicsExposures(_World_dpy, rep->gc, True);
    } else {
	XCopyArea(
	    _World_dpy, (Drawable)src->id, (Drawable)dst->id, rep->gc,
	    sx1, sy1, w, h, dx1, dy1
	);
	dst->WaitForCopy();
    }
}

void Painter::Read (
    Canvas* c, void* dst, Coord x1, Coord y1, Coord x2, Coord y2
) {
    /* unimplemented */
}

void Painter::Write (
    Canvas* c, const void* src, Coord x1, Coord y1, Coord x2, Coord y2
) {
    /* unimplemented */
}

/*
 * class Pattern
 */

/*
 * Create a Pixmap for stippling from the given array of data.
 * The assumption is that the data is 16x16 and should be expanded to 32x32.
 */

static Pixmap MakeStipple (int* p) {
    int data[32];
    register int i, j;
    register unsigned int s1, s2;
    register unsigned int src, dst;

    for (i = 0; i < patternHeight; i++) {
	dst = 0;
	src = p[i];
	s1 = 1;
	s2 = 1 << (patternWidth - 1);
	for (j = 0; j < patternWidth; j++) {
	    if ((s1 & src) != 0) {
		dst |= s2;
	    }
	    s1 <<= 1;
	    s2 >>= 1;
	}
	dst = (dst << 16) | dst;
	data[i] = dst;
	data[i+16] = dst;
    }
    return XCreateBitmapFromData(_World_dpy, _World_root, data, 32, 32);
}

Pattern::Pattern (int p[patternHeight]) {
    info = (void*)MakeStipple(p);
}

Pattern::Pattern (int dither) {
    register int i, seed;
    int r[16];

    seed = dither;
    for (i = 0; i < 4; i++) {
	r[i] = (seed & 0xf000) >> 12;
	r[i] |= r[i] << 4;
	r[i] |= r[i] << 8;
	seed <<= 4;
	r[i+4] = r[i];
	r[i+8] = r[i];
	r[i+12] = r[i];
    }
    info = (void*)MakeStipple(r);
}

Pattern::~Pattern () {
    if (LastRef()) {
	XFreePixmap(_World_dpy, (Pixmap)info);
    }
}
