/*
 * Bitmap - Bit map for InterViews
 */

#include <InterViews/bitmap.h>
#include <InterViews/color.h>
#include <InterViews/transformer.h>
#include <bstring.h>

inline boolean Bitmap::Valid (int x, int y) {
    return (x >= 0 && x < width && y >= 0 && y < height);
}

Bitmap::Bitmap (void* d, int w, int h) {
    Init();
    width = w;
    height = h;
    int size = Size(w, h);
    data = new char[size];
    if (d != nil) {
	bcopy(d, data, size);
    } else {
	bzero(data, size);
    }
}

Bitmap::Bitmap (Bitmap* b) {
    Init();
    width = b->width;
    height = b->height;
    if (b->data != nil) {
	int size = Size(width, height);
	data = new char[size];
	bcopy(b->data, data, size);
    }
}

void Bitmap::Init () {
    x0 = 0;
    y0 = 0;
    width = 0;
    height = 0;
    data = nil;
    bitmap = nil;
    pixmap = nil;
    foreground = black;
    background = white;
}

Bitmap::~Bitmap () {
    if (LastRef()) {
	FreeMaps();
	delete data;
    }
}

void Bitmap::SetColors (Color* fg, Color* bg) {
    if (fg != foreground) {
	FreePixmap();
	foreground = fg;
    }
    if (bg != background) {
	FreePixmap();
	background = bg;
    }
}

void Bitmap::Transform (Transformer* t) {
    int x1 = 0, y1 = 0;
    int x2 = 0, y2 = height-1;
    int x3 = width-1, y3 = height-1;
    int x4 = width-1, y4 = 0;

    t->Transform(x1, y1);
    t->Transform(x2, y2);
    t->Transform(x3, y3);
    t->Transform(x4, y4);

    t->Invert();

    int xmax = max(x1,max(x2,max(x3,x4)));
    int xmin = min(x1,min(x2,min(x3,x4)));
    int ymax = max(y1,max(y2,max(y3,y4)));
    int ymin = min(y1,min(y2,min(y3,y4)));

    Bitmap* b = new Bitmap(nil, xmax-xmin+1, ymax-ymin+1);
    for (int x = xmin; x <= xmax; ++x) {
	for (int y = ymin; y <= ymax; ++y) {
	    int xx = x;
	    int yy = y;
	    t->Transform(xx, yy);
	    b->Poke(Peek(xx,yy), x-xmin, y-ymin);
	}
    }
    delete data;
    data = b->data;
    width = b->width;
    height = b->height;
    b->data = nil;
    delete b;
    FreeMaps();
}

void Bitmap::Scale (float sx, float sy) {
    Transformer* t = new Transformer;
    t->Scale(sx,sy);
    Transform(t);
    delete t;
}

void Bitmap::Rotate (float angle) {
    Transformer* t = new Transformer;
    t->Rotate(angle);
    Transform(t);
    delete t;
}

void Bitmap::SetOrigin (int x, int y) {
    x0 = x;
    y0 = y;
}

void Bitmap::GetOrigin (int &x, int &y) {
    x = x0;
    y = y0;
}

void Bitmap::FlipHorizontal () {
    for (int x = 0; x < width/2; ++x) {
	for (int y = 0; y < height; ++y) {
	    boolean bit = Peek(x, y);
	    Poke(Peek(width-x-1, y), x, y);
	    Poke(bit, width-x-1, y);
	}
    }
    FreeMaps();
}

void Bitmap::FlipVertical () {
    for (int x = 0; x < width; ++x) {
	for (int y = 0; y < height/2; ++y) {
	    boolean bit = Peek(x, y);
	    Poke(Peek(x, height-y-1), x, y);
	    Poke(bit, x, height-y-1);
	}
    }
    FreeMaps();
}

void Bitmap::Invert () {
    for (int x = 0; x < width; ++x) {
	for (int y = 0; y < height; ++y) {
	    Poke(!Peek(x,y), x, y);
	}
    }
    FreeMaps();
}

void Bitmap::Rotate90 () {
    Bitmap* b = new Bitmap(nil, height, width);
    for (int x = 0; x < width; ++x) {
	for (int y = 0; y < height; ++y) {
	    b->Poke(Peek(x,y), width-y-1, x);
	}
    }
    delete data;
    data = b->data;
    b->data = nil;
    width = b->width;
    height = b->height;
    delete b;
    FreeMaps();
}

boolean Bitmap::Peek (int x, int y) {
    if (Valid(x,y)) {
	return BitIsSet(x, y);
    } else {
	return false;
    }
}

void Bitmap::Poke (boolean bit, int x, int y) {
    if (Valid(x,y)) {
	if (bit) {
	    SetBit(x, y);
	} else {
	    ClearBit(x, y);
	}
    }
}
