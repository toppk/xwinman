/*
 * Support for window managers.
 */

#include <InterViews/sensor.h>
#include <InterViews/shape.h>
#include <InterViews/world.h>
#include <InterViews/worldview.h>

WorldView* _WorldView_this;

WorldView::WorldView (World* w, Sensor* s, Painter* p) : (s, p) {
    world = w;
    curfocus = nil;
    Init(w);
    if (input == nil) {
	input = new Sensor;
	input->Catch(DownEvent);
	input->Catch(UpEvent);
	input->CatchRemote();
    }
    w->Listen(input);
    _WorldView_this = this;
}

void WorldView::Delete () {
    /* nothing to do currently */
}

void WorldView::InsertRemote (RemoteInteractor i) {
    Map(i);
}

void WorldView::ChangeRemote (
    RemoteInteractor i, Coord left, Coord top, int w, int h
) {
    Change(i, left, top, w, h);
}

RemoteInteractor WorldView::Choose (Cursor* c, boolean waitforup) {
    Event e;

    GrabMouse(c);
    do {
	Read(e);
    } while (e.eventType != DownEvent);
    if (waitforup) {
	do {
	    Read(e);
	} while (e.eventType != UpEvent);
    }
    UngrabMouse();
    return Find(e.x, e.y);
}

void WorldView::FreeList (RemoteInteractor* i) {
    delete i;
}

void WorldView::RedrawAll () {
    Interactor dummy;

    dummy.shape->Rect(xmax+1, ymax+1);
    world->Insert(&dummy, 0, 0);
    world->Remove(&dummy);
    Sync();
}
