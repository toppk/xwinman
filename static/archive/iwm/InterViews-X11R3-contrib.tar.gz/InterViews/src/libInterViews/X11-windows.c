/*
 * X11-dependent methods for window manipulation.
 */

#include <InterViews/canvas.h>
#include <InterViews/color.h>
#include <InterViews/cursor.h>
#include <InterViews/interactor.h>
#include <InterViews/font.h>
#include <InterViews/painter.h>
#include <InterViews/reqerr.h>
#include <InterViews/sensor.h>
#include <InterViews/shape.h>
#include <InterViews/table.h>
#include <InterViews/world.h>
#include <InterViews/worldview.h>
#include <InterViews/X11/Xlib.h>
#include <InterViews/X11/Xutil.h>
#include <X11/Xatom.h>
#include <osfcn.h>
#include <stdio.h>
#include <string.h>

Table* assocTable;
Display* _World_dpy;
int _World_screen;
Window _World_root;
XColormap _World_cmap;

extern WorldView* _WorldView_this;

/*
 * class Canvas
 */

class CanvasRep {
    friend class Canvas;

    /* nothing needed for X11 */
    int unused;
};

Canvas::Canvas (void* c) {
    id = c;
    width = 0;
    height = 0;
    status = CanvasUnmapped;
}

Canvas::Canvas (int w, int h) {
    id = (void*)XCreatePixmap(
	_World_dpy, _World_root, w, h, DefaultDepth(_World_dpy, _World_screen)
    );
    width = w;
    height = h;
    status = CanvasOffscreen;
}

Canvas::~Canvas () {
    if (id != nil) {
	if (status == CanvasOffscreen) {
	    XFreePixmap(_World_dpy, (Pixmap)id);
	} else {
	    XDestroyWindow(_World_dpy, (Window)id);
	    assocTable->Remove(id);
	}
	id = nil;
    }
}

void Canvas::WaitForCopy () {
    XEvent xe;
    Interactor* i;

    for (;;) {
	XWindowEvent(_World_dpy, (Window)id, ExposureMask, xe);
	switch (xe.type) {
	    case NoExpose:
		return;
	    case Expose:
		if (assocTable->Find(i, xe.xexpose.window)) {
		    i->Redraw(
			xe.xexpose.x,
			height - xe.xexpose.y - xe.xexpose.height,
			xe.xexpose.x + xe.xexpose.width - 1,
			height - 1 - xe.xexpose.y
		    );
		}
		break;
	    case GraphicsExpose:
		if (assocTable->Find(i, xe.xgraphicsexpose.drawable)) {
		    i->Redraw(
			xe.xgraphicsexpose.x,
			height - xe.xgraphicsexpose.y -
			    xe.xgraphicsexpose.height,
			xe.xgraphicsexpose.x + xe.xgraphicsexpose.width - 1,
			height - 1 - xe.xgraphicsexpose.y
		    );
		    if (xe.xgraphicsexpose.count == 0) {
			return;
		    }
		}
		break;
	}
    }
}

void Canvas::SetBackground (Color* c) {
    if (status != CanvasOffscreen) {
	XSetWindowBackground(_World_dpy, (Window)id, c->PixelValue());
    }
}

void Canvas::Clip (Coord, Coord, Coord, Coord) {
    /* Canvas clipping unimplemented for X11. */
}

void Canvas::NoClip () {
    /* Canvas clipping unimplemented for X11. */
}

void Canvas::ClipOn () {
    /* Canvas clipping unimplemented for X11. */
}

void Canvas::ClipOff () {
    /* Canvas clipping unimplemented for X11. */
}

boolean Canvas::IsClipped () {
    return false;
}

void Canvas::Map (Coord& x, Coord& y) {
    /* nothing to do */
}

/*
 * class Interactor
 */

void Interactor::Listen (Sensor* s) {
    unsigned int m;

    cursensor = s;
    if (canvas == nil) {
	/* can't set input interest without window */
	return;
    }
    m = (s == nil) ? 0 : s->mask;
    if (parent != nil) {
	/* exposure on everyone but root window */
	m |= ExposureMask;
	if (parent->parent == nil) {
	    /* configure events to top-level windows only */
	    m |= StructureNotifyMask;
	}
    }
    XSelectInput(_World_dpy, (Window)canvas->id, m);
}

void Interactor::DoSetCursor (Cursor* c) {
    XDefineCursor(_World_dpy, (Window)canvas->id, (XCursor)c->Id());
    Flush();
}

int Interactor::Fileno () {
    return ConnectionNumber(_World_dpy);
}

/*
 * Read a single event from the event stream.  If it is an input event,
 * is associated with an interactor, and the interactor is interested in it,
 * then return true.  In all other cases, return false.
 */

boolean Interactor::GetEvent (Event& e, boolean remove) {
    XEvent xe;
    Window w;
    Interactor* i;
    WorldView* wv;

    XNextEvent(_World_dpy, xe);
    switch (xe.type) {
	case Expose:
	    if (assocTable->Find(i, xe.xexpose.window)) {
		i->SendRedraw(
		    xe.xexpose.x, xe.xexpose.y,
		    xe.xexpose.width, xe.xexpose.height, xe.xexpose.count
		);
	    }
	    return false;
	case ConfigureNotify:
	    if (assocTable->Find(i, xe.xconfigure.window)) {
		i->SendResize(
		    xe.xconfigure.x, xe.xconfigure.y,
		    xe.xconfigure.width, xe.xconfigure.height
		);
	    }
	    return false;
	case MotionNotify:
	    w = xe.xmotion.window;
	    break;
	case KeyPress:
	    w = xe.xkey.window;
	    break;
	case ButtonPress:
	case ButtonRelease:
	    w = xe.xbutton.window;
	    break;
	case FocusIn:
	case FocusOut:
	    w = xe.xfocus.window;
	    break;
	case EnterNotify:
	case LeaveNotify:
	    w = xe.xcrossing.window;
	    break;
	case MapRequest:
	    wv = _WorldView_this;
	    if (wv != nil &&
		wv->canvas->id == (void*)xe.xmaprequest.parent
	    ) {
		wv->InsertRemote((void*)xe.xmaprequest.window);
	    }
	    return false;
	case ConfigureRequest:
	    wv = _WorldView_this;
	    if (wv != nil &&
		wv->canvas->id == (void*)xe.xconfigurerequest.parent
	    ) {
		wv->ChangeRemote(
		    (void*)xe.xconfigurerequest.window,
		    xe.xconfigurerequest.x, ymax - xe.xconfigurerequest.y,
		    xe.xconfigurerequest.width, xe.xconfigurerequest.height
		);
	    }
	    return false;
	default:
	    /* ignore */
	    return false;
    }
    /* only input events should get here */
    if (!assocTable->Find(i, w) ||
	i->cursensor == nil || !i->cursensor->Interesting(&xe, e)
    ) {
	return false;
    }
    e.target = i;

    /*
     * Can't do the QueryPointer before checking to make sure the window
     * is valid because a motion event might have been sent just before
     * we destroyed the target window.
     */
    if (xe.type == MotionNotify) {
	Window dummy;
	int x, y, wx, wy;
	unsigned int state;

	XQueryPointer(_World_dpy, w, dummy, dummy, x, y, wx, wy, state);
	e.x = wx;
	e.y = wy;
    }
    e.y = i->ymax - e.y;
    if (!remove) {
	XPutBackEvent(_World_dpy, xe);
    }
    return true;
}

/*
 * Check to see if any input events of interest are pending.
 * This routine will return true even if the event is for another interactor.
 */

boolean Interactor::Check () {
    Event e;

    while (XPending(_World_dpy)) {
	if (GetEvent(e, false)) {
	    return true;
	}
    }
    return false;
}

int Interactor::CheckQueue () {
    return QLength(_World_dpy);
}

void Interactor::SendRedraw (Coord x, Coord y, int w, int h, int count) {
    if (count == 0) {
	Coord top = ymax - y;
	Redraw(x, top - h + 1, x + w - 1, top);
    } else {
	register int i;
	XEvent xe;
	Coord buf[40];
	Coord* left, * bottom, * right, * top;

	i = count + 1;
	if (i <= 10) {
	    left = buf;
	} else {
	    left = new Coord[4*i];
	}
	bottom = &left[i];
	right = &bottom[i];
	top = &right[i];

	left[0] = x;
	top[0] = ymax - y;
	right[0] = x + w - 1;
	bottom[0] = top[0] - h + 1;
	for (i = 1; i <= count; i++) {
	    /*
	     * This should be XNextEvent(_World_dpy, xe), but that
	     * didn't work.  I think that implies an X server bug,
	     * but I have to live with what I've got for now.
	     */
	    XWindowEvent(_World_dpy, (Window)canvas->id, ExposureMask, xe);
	    left[i] = xe.xexpose.x;
	    top[i] = ymax - xe.xexpose.y;
	    right[i] = left[i] + xe.xexpose.width - 1;
	    bottom[i] = top[i] - xe.xexpose.height + 1;
	}
	RedrawList(count+1, left, bottom, right, top);
	if (left != buf) {
	    delete left;
	}
    }
}

void Interactor::SendResize (Coord x, Coord y, int w, int h) {
    left = x;
    bottom = parent->ymax - y - h + 1;
    canvas->width = w;
    canvas->height = h;
    xmax = w - 1;
    ymax = h - 1;
    Resize();
}

void Interactor::Poll (Event& e) {
    Window root, child;
    int x, y, root_x, root_y;
    unsigned int state;
    register unsigned int s;

    XQueryPointer(
	_World_dpy, (Window)canvas->id, root, child,
	root_x, root_y, x, y, state
    );
    e.x = x;
    e.y = ymax - y;
    if (!assocTable->Find(e.w, root)) {
	e.w = nil;
    }
    e.wx = root_x;
    e.wy = root_y;
    s = state;
    e.control = (s&ControlMask) != 0;
    e.meta = (s&Mod1Mask) != 0;
    e.shift = (s&ShiftMask) != 0;
    e.shiftlock = (s&LockMask) != 0;
    e.leftmouse = (s&Button1Mask) != 0;
    e.middlemouse = (s&Button2Mask) != 0;
    e.rightmouse = (s&Button3Mask) != 0;
}

void Interactor::Flush () {
    XFlush(_World_dpy);
}

void Interactor::Sync () {
    XSync(_World_dpy, 0);
}

void Interactor::GetRelative (Coord& x, Coord& y, Interactor* rel) {
    register Interactor* t, * r;
    Coord tx, ty, rx, ry;

    if (parent == nil) {
	if (rel == nil || rel->parent == nil) {
	    /* world relative to world -- nop */
	    return;
	}
	/* world relative to interactor is relative to interactor's l, b */
	rx = 0; ry = 0;
	rel->GetRelative(rx, ry);
	x = x - rx;
	y = y - ry;
	return;
    }
    tx = x; ty = y;
    t = this;
    for (t = this; t->parent->parent != nil; t = t->parent) {
	tx += t->left;
	ty += t->bottom;
    }
    if (rel == nil || rel->parent == nil) {
	r = nil;
    } else {
	rx = 0; ry = 0;
	for (r = rel; r->parent->parent != nil; r = r->parent) {
	    rx += r->left;
	    ry += r->bottom;
	}
    }
    if (r == t) {
	/* this and rel are within same top-level interactor */
	x = tx - rx;
	y = ty - ry;
    } else {
	Interactor* w;
	Window child;

	w = (rel == nil) ? t->parent : rel;
	XTranslateCoordinates(
	    _World_dpy, (Window)canvas->id, (Window)w->canvas->id,
	    x, ymax - y, rx, ry, child
	);
	x = rx;
	y = w->ymax - ry;
    }
}

void Interactor::DoSetName (const char* s) {
    XStoreName(_World_dpy, (Window)canvas->id, s);
}

void Interactor::DoSetIcon (Interactor* i) {
    XWMHints h;

    if (i->canvas->id != nil) {
	h.flags = IconWindowHint;
	h.icon_window = (Window)i->canvas->id;
	XSetWMHints(_World_dpy, (Window)canvas->id, h);
    }
}

static Window FindIcon (void* w) {
    Window r = nil;
    XWMHints* h = XGetWMHints(_World_dpy, (Window)w);
    if (h != nil && (h->flags&IconWindowHint) != 0) {
	r = h->icon_window;
    }
    delete h;
    return r;
}

void Interactor::Iconify () {
    Window w = nil;
    Interactor* i = GetIcon();
    if (i != nil && i->canvas != nil) {
	w = (Window)i->canvas->id;
	i->canvas->status = CanvasMapped;
    } else if (IsMapped()) {
	w = FindIcon(canvas->id);
    }
    if (w != nil) {
	XMapWindow(_World_dpy, w);
	if (IsMapped()) {
	    XUnmapWindow(_World_dpy, (Window)canvas->id);
	    canvas->status = CanvasUnmapped;
	}
    }
}

void Interactor::DeIconify () {
    if (canvas != nil) {
	XMapWindow(_World_dpy, (Window)canvas->id);
	canvas->status = CanvasMapped;
	Window w = nil;
	Interactor* i = GetIcon();
	if (i != nil && i->IsMapped()) {
	    w = (Window)i->canvas->id;
	    i->canvas->status = CanvasUnmapped;
	}
	if (w == nil && canvas != nil) {
	    w = FindIcon(canvas->id);
	}
	if (w != nil) {
	    XUnmapWindow(_World_dpy, w);
	}
    }
}

/*
 * class ReqErr
 */

static ReqErr* errhandler;

ReqErr::ReqErr () {
    /* no constructor code currently necessary */
}

ReqErr::~ReqErr () {
    if (errhandler == this) {
	errhandler = nil;
    }
}

void ReqErr::Error () {
    /* default is to do nothing */
}

static void DoXError (Display* errdisplay, XErrorEvent* e) {
    extern void XGetErrorText(Display*, int, char*, int);

    register ReqErr* r = errhandler;
    if (r != nil) {
	r->msgid = e->serial;
	r->code = e->error_code;
	r->request = e->request_code;
	r->detail = e->minor_code;
	r->id = (void*)e->resourceid;
	XGetErrorText(errdisplay, r->code, r->message, sizeof(r->message));
	r->Error();
    }
}

ReqErr* ReqErr::Install () {
    typedef void XHandler(Display*, XErrorEvent*);
    extern void XSetErrorHandler(XHandler*);

    if (errhandler == nil) {
	XSetErrorHandler(DoXError);
    }
    ReqErr* r = errhandler;
    errhandler = this;
    return r;
}

/*
 * class Scene
 */

/*
 * Place an interactor according to user preferences.
 */

void Scene::UserPlace (Interactor* i) {
    if (i->parent != nil && i->parent != this) {
	i->parent->Remove(i);
    }
    i->parent = this;
    MakeWindow(i, 0, 0, i->shape->width, i->shape->height, false);
    DoMap(i);
}

/*
 * Place an interactor at a particular position.
 */

void Scene::Place (
    Interactor* i, Coord x1, Coord y1, Coord x2, Coord y2, boolean map
) {
    register Canvas* c;
    int width, height;
    Coord newtop;

    /* for debugging purposes only ... */
    if (i->parent == nil || i->parent != this) {
	fprintf(stderr, "internal error: bad parent in Scene::Place\n");
	exit(1);
    }
    width = x2 - x1 + 1;
    height = y2 - y1 + 1;
    newtop = ymax - y2;
    c = i->canvas;
    if (c == nil) {
	MakeWindow(i, x1, newtop, width, height, true);
	c = i->canvas;
    } else {
	boolean newsize = (width != c->width || height != c->height);
	/* need to know if parent's size has changed to compute newpos */
	boolean newpos = true;
	if (newsize && newpos) {
	    XMoveResizeWindow(
		_World_dpy, (Window)c->id, x1, newtop, width, height
	    );
	} else if (newsize) {
	    XResizeWindow(_World_dpy, (Window)c->id, width, height);
	} else if (newpos) {
	    XMoveWindow(_World_dpy, (Window)c->id, x1, newtop);
	}
    }
    Assign(i, x1, y2 - height + 1, width, height);
    if (map) {
	XMapRaised(_World_dpy, (Window)c->id);
	c->status = CanvasMapped;
    }
}

/*
 * Adjust window dimensions to avoid 0 width or height error.
 */

static void DefaultShape (int w, int h, int& nw, int& nh) {
    nw = (w == 0) ? round(2*inch) : w;
    nh = (h == 0) ? round(2*inch) : h;
}

/*
 * Create and map a window for an interactor and initialize
 * the interactor's canvas appropriately.  If the "force" parameter
 * is true, then give the window the position and size requested.
 * If "force" is false, then potentially let the user place and size
 * the window.
 */

void Scene::MakeWindow (
    Interactor* i, Coord x, Coord y, int width, int height, boolean force
) {
    Window w;
    register unsigned int m;
    XSetWindowAttributes a;
    int rwidth, rheight;
    int wtype;
    Cursor* c;

    m = CWDontPropagate;
    if (force) {
	m |= CWOverrideRedirect;
	a.override_redirect = True;
    }
    if (parent != nil) {
	m |= CWBackPixmap|CWWinGravity;
	a.background_pixmap = ParentRelative;
	a.win_gravity = UnmapGravity;
    }
    a.do_not_propagate_mask = (
	FocusChangeMask | EnterWindowMask | LeaveWindowMask
    );
    DefaultShape(width, height, rwidth, rheight);
    switch (i->GetCanvasType()) {
	case CanvasShapeOnly:
	    /*
	     * This is intended for "light-weight" interactors that
	     * do nothing more than take space as far as X is concerned.
	     * One obvious use is glue, but I haven't had time to test it.
	     */
	    return;
	case CanvasInputOnly:
	    wtype = InputOnly;
	    break;
	case CanvasInputOutput:
	    wtype = InputOutput;
	    break;
	case CanvasSaveUnder:
	    wtype = InputOutput;
	    m |= CWSaveUnder;
	    a.save_under = True;
	    break;
	case CanvasSaveContents:
	    wtype = InputOutput;
	    m |= CWBackingStore;
	    a.backing_store = WhenMapped;
	    break;
	case CanvasSaveBoth:
	    wtype = InputOutput;
	    m |= (CWSaveUnder|CWBackingStore);
	    a.save_under = True;
	    a.backing_store = WhenMapped;
	    break;
    }
    w = XCreateWindow(
	_World_dpy, (Window)canvas->id, x, y, rwidth, rheight, 0, 0,
	wtype, CopyFromParent, m, &a
    );
    i->canvas = new Canvas((void*)w);
    assocTable->Insert(w, i);
    c = i->GetCursor();
    if (c != nil) {
	XDefineCursor(_World_dpy, w, (XCursor)c->Id());
    } else if (parent == nil) {
	XDefineCursor(_World_dpy, w, (XCursor)defaultCursor->Id());
    }
    i->Listen(i->cursensor == nil ? i->input : i->cursensor);
}

/*
 * Map an interactor and wait for confirmation of its position.
 * The interactor is either being placed by the user or inserted
 * in the world (in which case a window manager might choose to allocate
 * it a different size and placement).
 */

struct EventInfo {
    Window w;
    Interactor* i;
};

static Bool MapOrRedraw (Display*, XEvent& xe, char* w) {
    EventInfo* x = (EventInfo*)w;

    return (
	(xe.type == MapNotify && xe.xmap.window == x->w) ||
	(xe.type == ConfigureNotify && xe.xconfigure.window == x->w) ||
	(xe.type == Expose && assocTable->Find(x->i, xe.xexpose.window))
    );
}

void Scene::DoMap (Interactor* i) {
    EventInfo info;
    XEvent xe;
    boolean assigned;

    info.w = (Window)i->canvas->id;
    XMapRaised(_World_dpy, info.w);
    assigned = false;
    for (;;) {
	XIfEvent(_World_dpy, xe, MapOrRedraw, (char*)&info);
	if (xe.type == MapNotify) {
	    if (!assigned) {
		int w, h;

		DefaultShape(i->shape->width, i->shape->height, w, h);
		Assign(i, 0, 0, w, h);
	    }
	    break;
	} else if (xe.type == ConfigureNotify) {
	    Assign(
		i, xe.xconfigure.x,
		ymax - xe.xconfigure.y - xe.xconfigure.height + 1,
		xe.xconfigure.width, xe.xconfigure.height
	    );
	    assigned = true;
	} else if (xe.type == Expose) {
	    info.i->SendRedraw(
		xe.xexpose.x, xe.xexpose.y,
		xe.xexpose.width, xe.xexpose.height, xe.xexpose.count
	    );
	}
    }
    i->canvas->status = CanvasMapped;
}

void Scene::Map (Interactor* i, boolean raised) {
    if (raised) {
	XMapRaised(_World_dpy, (Window)i->canvas->id);
    } else {
	XMapWindow(_World_dpy, (Window)i->canvas->id);
    }
    i->canvas->status = CanvasMapped;
}

void Scene::Unmap (Interactor* i) {
    XUnmapWindow(_World_dpy, (Window)i->canvas->id);
    i->canvas->status = CanvasUnmapped;
}

void Scene::Raise (Interactor* i) {
    XRaiseWindow(_World_dpy, (Window)i->canvas->id);
}

void Scene::Lower (Interactor* i) {
    XLowerWindow(_World_dpy, (Window)i->canvas->id);
}

void Scene::Change (Interactor* i) {
    if (propagate) {
	DoChange(i);
	if (parent != nil) {
	    parent->Change(this);
	}
    } else if (canvas != nil) {
	Resize();
    }
}

void Scene::DoMove (Interactor* i, Coord& x, Coord& y) {
    XMoveWindow(_World_dpy, (Window)i->canvas->id, x, ymax - y);
}

/*
 * class Sensor
 */

int motionmask = PointerMotionMask;
int keymask = KeyPressMask;
int entermask = EnterWindowMask;
int leavemask = LeaveWindowMask;
int focusmask = FocusChangeMask;
int substructmask = SubstructureRedirectMask;
int upmask = ButtonPressMask|ButtonReleaseMask|OwnerGrabButtonMask;
int downmask = ButtonPressMask|ButtonReleaseMask|OwnerGrabButtonMask;
int initmask = PointerMotionHintMask;

static Window focus;
static Sensor* grabber;

boolean Sensor::Interesting (void* raw, Event& e) {
    boolean b;
    register XEvent* x = (XEvent*)raw;

    b = false;
    switch (x->type) {
	case MotionNotify:
	    e.eventType = MotionEvent;
	    e.x = x->xmotion.x;
	    e.y = x->xmotion.y;
	    if (!assocTable->Find(e.w, x->xmotion.root)) {
		e.w = nil;
	    }
	    e.wx = x->xmotion.x_root;
	    e.wy = x->xmotion.y_root;
	    b = true;
	    break;
	case KeyPress:
	    e.eventType = KeyEvent;
	    e.GetButtonInfo(x);
	    b = ButtonIsSet(down, e.button);
	    break;
	case ButtonPress:
	    e.eventType = DownEvent;
	    e.GetButtonInfo(x);
	    b = ButtonIsSet(down, e.button);
	    if (b && ButtonIsSet(up, e.button)) {
		grabber = this;
	    } else {
		grabber = nil;
	    }
	    break;
	case ButtonRelease:
	    e.eventType = UpEvent;
	    e.GetButtonInfo(x);
	    b = ButtonIsSet(up, e.button) || (grabber != nil);
	    break;
	case FocusIn:
	    focus = x->xfocus.window;
	    e.eventType = OnEvent;
	    b = true;
	    break;
	case FocusOut:
	    focus = nil;
	    e.eventType = OffEvent;
	    b = true;
	    break;
	case EnterNotify:
	case LeaveNotify:
	    if (x->xcrossing.detail != NotifyInferior &&
		x->xcrossing.window != focus
	    ) {
		e.eventType = x->type == EnterNotify ? OnEvent : OffEvent;
		b = true;
	    }
	    break;
	default:
	    /* ignore */;
    }
    return b;
}

void Event::GetButtonInfo (void* xe) {
    register XKeyEvent* k = &(((XEvent*)xe)->xkey);
    register int state;
    XComposeStatus status;
    char buf[4096];

    timestamp = k->time;
    x = k->x;
    y = k->y;
    if (!assocTable->Find(w, k->root)) {
	w = nil;
    }
    wx = k->x_root;
    wy = k->y_root;
    state = k->state;
    shift = (state & ShiftMask) != 0;
    control = (state & ControlMask) != 0;
    meta = (state & Mod1Mask) != 0;
    shiftlock = (state & LockMask) != 0;
    leftmouse = (state & Button1Mask) != 0;
    middlemouse = (state & Button2Mask) != 0;
    rightmouse = (state & Button3Mask) != 0;
    button = k->keycode;
    if (k->type == KeyPress) {
	len = XLookupString(*k, buf, sizeof(buf), nil, &status);
	if (len > 0) {
	    if (len <= sizeof(int)) {
		keystring = keydata;
	    } else {
		keystring = new char[len+1];
	    }
	    strncpy(keystring, buf, len);
	    keystring[len] = '\0';
	}
    } else {
	button -= 1;
	len = 0;
    }
    if (len == 0) {
	keystring = keydata;
	keydata[0] = '\0';
    }
}

/*
 * class World
 */

class WorldRep {
    friend class World;

    Display* display;
    int screen;
    Window root;
};

void World::Init (const char* device) {
    rep = new WorldRep;
    rep->display = XOpenDisplay(device);
    if (rep->display == nil) {
	fprintf(stderr, "fatal error: can't open display\n");
	exit(1);
    }
    rep->screen = DefaultScreen(rep->display);
    rep->root = RootWindow(rep->display, rep->screen);
    SetCurrent();
    if (assocTable == nil) {
	assocTable = new Table(2048);
    }
    canvas = new Canvas((void*)rep->root);
    canvas->width = DisplayWidth(rep->display, rep->screen);
    canvas->height = DisplayHeight(rep->display, rep->screen);
    canvas->status = CanvasMapped;
    double pixmm = (
	double(canvas->width) /
	double(DisplayWidthMM(rep->display, rep->screen))
    );
    cm = round(10*pixmm);
    inch = round(25.4*pixmm);
    inches = inch;
    point = 72.07/inch;
    points = point;
    assocTable->Insert(rep->root, this);
    xmax = canvas->width - 1;
    ymax = canvas->height - 1;

    black = new Color("black");
    white = new Color("white");
    stdfont = new Font("fixed");
    stdpaint = new Painter;
}

void World::Delete () {
    assocTable->Remove(rep->root);
    XCloseDisplay(rep->display);
    delete rep;
    Scene::Delete();
}

const char* World::UserDefaults () {
    return rep->display->xdefaults;
}

void World::FinishInsert (Interactor*) {
    /* nothing else to do */
}

void World::DoChange (Interactor* i) {
    Canvas* c = i->canvas;
    if (c != nil && c->status == CanvasMapped) {
	Shape* s = i->GetShape();
	if (c->width != s->width || c->height != s->height) {
	    XResizeWindow(rep->display, (Window)c->id, s->width, s->height);
	} else {
	    i->Resize();
	}
    }
}

void World::DoRemove (Interactor*) {
    XFlush(rep->display);
}

int World::Fileno () {
    return ConnectionNumber(rep->display);
}

void World::SetCurrent () {
    _World_dpy = rep->display;
    _World_root = rep->root;
    _World_screen = rep->screen;
    _World_cmap = DefaultColormap(rep->display, rep->screen);
}

void World::SetRoot (void* r) {
    rep->root = (Window)r;
    if (_World_dpy == rep->display) {
	_World_root = rep->root;
    }
}

void World::SetScreen (int n) {
    rep->screen = n;
    if (_World_dpy == rep->display) {
	_World_screen = n;
    }
}

int World::NPlanes () {
    return DisplayPlanes(rep->display, rep->screen);
}

int World::NButtons () {
    return 3;
}

int World::PixelSize () {
    return BitmapPad(rep->display);
}

const char* World::GetDefault (const char* name) {
    return GetAttribute(name);
}

const char* World::GetGlobalDefault (const char* name) {
    return GetAttribute(name);
}

unsigned World::ParseGeometry (
    char* spec, Coord& x, Coord& y, int& w, int &h
) {
    return XParseGeometry(spec, x, y, w, h);
}

void World::RingBell (int v) {
    if (v > 100) {
	XBell(rep->display, 100);
    } else if (v >= 0) {
	XBell(rep->display, v);
    }
}

void World::SetKeyClick (int v) {
    XKeyboardControl k;

    k.key_click_percent = v;
    XChangeKeyboardControl(rep->display, KBKeyClickPercent, k);
}

void World::SetAutoRepeat (boolean b) {
    if (b) {
	XAutoRepeatOn(rep->display);
    } else {
	XAutoRepeatOff(rep->display);
    }
}

void World::SetFeedback (int t, int s) {
    XChangePointerControl(rep->display, True, True, s, 1, t);
}

/*
 * class WorldView
 */

void WorldView::Init (World*) {
    Window w;

    w = RootWindow(_World_dpy, _World_screen);
    canvas = new Canvas((void*)w);
    canvas->width = DisplayWidth(_World_dpy, _World_screen);
    canvas->height = DisplayHeight(_World_dpy, _World_screen);
    canvas->status = CanvasMapped;
    xmax = canvas->width - 1;
    ymax = canvas->height - 1;
    output->SetOverwrite(true);
}

static const int bmask =
    ButtonPressMask|ButtonReleaseMask|OwnerGrabButtonMask|
    PointerMotionMask|PointerMotionHintMask;

void WorldView::GrabMouse (Cursor* c) {
    while (
	XGrabPointer(
	    _World_dpy, (Window)canvas->id, True, bmask,
	    GrabModeAsync, GrabModeAsync, None, (XCursor)c->Id(),
	    CurrentTime
	) != GrabSuccess
    ) {
	sleep(1);
    }
}

void WorldView::UngrabMouse () {
    XUngrabPointer(_World_dpy, CurrentTime);
}

boolean WorldView::GrabButton (unsigned b, unsigned m, Cursor* c) {
    XGrabButton(
	_World_dpy, b, m, (Window)canvas->id, True, bmask,
	GrabModeAsync, GrabModeAsync, None, (XCursor)c->Id()
    );
    return true;
}

void WorldView::UngrabButton (unsigned b, unsigned m) {
    XUngrabButton(_World_dpy, b, m, (Window)canvas->id);
}

void WorldView::Lock () {
/*
 * Grabbing doesn't work right on X11?
 *
    XGrabServer(_World_dpy);
 */
}

void WorldView::Unlock () {
/*
 * See Lock()
 *
    XUngrabServer(_World_dpy);
    Sync();
 */
}

void WorldView::ClearInput () {
    XSync(_World_dpy, 1);
}

void WorldView::MoveMouse (Coord x, Coord y) {
    XWarpPointer(
	_World_dpy, (Window)canvas->id, (Window)canvas->id,
	0, 0, xmax, ymax, x, ymax - y
    );
}

void WorldView::Map (RemoteInteractor i) {
    XMapWindow(_World_dpy, (Window)i);
}

void WorldView::MapRaised (RemoteInteractor i) {
    XMapRaised(_World_dpy, (Window)i);
}

void WorldView::Unmap (RemoteInteractor i) {
    XUnmapWindow(_World_dpy, (Window)i);
}

RemoteInteractor WorldView::Find (Coord x, Coord y) {
    Window w;
    Coord rx, ry;

    XTranslateCoordinates(
	_World_dpy, (Window)canvas->id, (Window)canvas->id,
	x, ymax - y, rx, ry, w
    );
    return (void*)w;
}

void WorldView::Move (RemoteInteractor i, Coord left, Coord top) {
    XMoveWindow(_World_dpy, (Window)i, left, ymax - top);
}

void WorldView::Change (
    RemoteInteractor i, Coord left, Coord top, int w, int h
) {
    XMoveResizeWindow(_World_dpy, (Window)i, left, ymax - top, w, h);
}

void WorldView::Raise (RemoteInteractor i) {
    XRaiseWindow(_World_dpy, (Window)i);
}

void WorldView::Lower (RemoteInteractor i) {
    XLowerWindow(_World_dpy, (Window)i);
}

void WorldView::Focus (RemoteInteractor i) {
    if (i != curfocus) {
	curfocus = i;
	XSetInputFocus(
	    _World_dpy, i == nil ? PointerRoot : (Window)i,
	    RevertToPointerRoot, CurrentTime
	);
    }
}

void WorldView::GetList (RemoteInteractor*& ilist, int& n) {
    Window parent;

    XQueryTree(
	_World_dpy, (Window)canvas->id, parent, parent, (Window*)ilist, n
    );
}

void WorldView::GetInfo (
    RemoteInteractor i, Coord& x1, Coord& y1, Coord& x2, Coord& y2
) {
    Window root;
    int x, y, w, h, bw, d;

    XGetGeometry(_World_dpy, (Window)i, root, x, y, w, h, bw, d);
    x1 = x;
    y2 = ymax - y;
    x2 = x + w + 2*bw - 1;
    y1 = y2 - h - 2*bw + 1;
}

boolean WorldView::GetHints (
    RemoteInteractor i, Coord& x, Coord& y, Shape& s
) {
    XSizeHints sizehints;

    sizehints.flags = 0;
    XGetSizeHints(_World_dpy, (Window)i, sizehints, XA_WM_NORMAL_HINTS);
    if ((sizehints.flags & USSize) != 0) {
	s.width = sizehints.width;
	s.height = sizehints.height;
	s.hstretch = sizehints.max_width - sizehints.width;
	s.hshrink = sizehints.width - sizehints.min_width;
	s.vstretch = sizehints.max_height - sizehints.height;
	s.vshrink = sizehints.height - sizehints.min_height;
	s.hunits = sizehints.width_inc;
	s.vunits = sizehints.height_inc;
    } else {
	s.width = 0;
	s.height = 0;
    }
    if ((sizehints.flags & USPosition) != 0) {
	x = sizehints.x;
	y = ymax - sizehints.y;
	return true;
    }
    return false;
}

void WorldView::SetHints (RemoteInteractor i, Coord x, Coord y, Shape& s) {
    XSizeHints sizehints;

    sizehints.flags = (USPosition | USSize);
    sizehints.x = x;
    sizehints.y = ymax - y;
    sizehints.width = s.width;
    sizehints.height = s.height;
    XSetSizeHints(_World_dpy, (Window)i, sizehints, XA_WM_NORMAL_HINTS);
}

RemoteInteractor WorldView::GetIcon (RemoteInteractor i) {
    XWMHints* h;
    RemoteInteractor r;

    h = XGetWMHints(_World_dpy, (Window)i);
    if (h == nil || (h->flags&IconWindowHint) == 0) {
	r = nil;
    } else {
	r = (void*)h->icon_window;
    }
    delete h;
    return r;
}

void WorldView::AssignIcon (RemoteInteractor i, RemoteInteractor icon) {
    XWMHints h;

    h.flags = IconWindowHint;
    h.icon_window = (Window)i;
    XSetWMHints(_World_dpy, (Window)icon, h);
    h.icon_window = (Window)icon;
    XSetWMHints(_World_dpy, (Window)i, h);
}

void WorldView::UnassignIcon (RemoteInteractor i) {
    XWMHints h;

    h.flags = IconWindowHint;
    h.icon_window = None;
    XSetWMHints(_World_dpy, (Window)i, h);
}

RemoteInteractor WorldView::TransientOwner (RemoteInteractor i) {
    Window w;

    return XGetTransientForHint(_World_dpy, (Window)i, w) ? (void*)w : nil;
}

char* WorldView::GetName (RemoteInteractor i) {
    char* name;

    XFetchName(_World_dpy, (Window)i, name);
    return name;
}
