/*
 * X10-dependent methods for graphics output.
 */

#include <InterViews/bitmap.h>
#include <InterViews/brush.h>
#include <InterViews/canvas.h>
#include <InterViews/color.h>
#include <InterViews/cursor.h>
#include <InterViews/font.h>
#include <InterViews/painter.h>
#include <InterViews/pattern.h>
#include <InterViews/transformer.h>
#include <InterViews/shape.h>
#include <InterViews/world.h>
#include <InterViews/X10/Xinput.h>
#include <InterViews/X10/Xoutput.h>
#include <InterViews/X10/Xutil.h>
#include <InterViews/X10/Xwindow.h>
#include <stdio.h>
#include <string.h>

extern XDisplay* _World_dpy;
extern int _World_nplanes;
extern int _Workstation_planemask;

/*
 * class Bitmap
 */

int Bitmap::Size (int w, int h) {
    return BitmapSize(w, h);
}

int Bitmap::Index (int x, int y) {
    return (width+15)/16 * (height-y-1) + x/16;
}

int Bitmap::Bit (int x, int) {
    return 1 << (x%16);
}

void Bitmap::SetBit (int x, int y) {
    *((short*)data + Index(x, y)) |= Bit(x, y);
}

void Bitmap::ClearBit (int x, int y) {
    *((short*)data + Index(x, y)) &= ~Bit(x, y);
}

boolean Bitmap::BitIsSet (int x, int y) {
    return (*((short*)data + Index(x, y)) & Bit(x, y)) != 0;
}

Bitmap::Bitmap (const char* filename) {
    extern int XReadBitmapFile(
	const char* filename,
	int& width, int& height, void*& data,
	int* x_hot, int* y_hot
    );

    Init();
    XReadBitmapFile(filename, width, height, data, nil, nil);
}

void Bitmap::FreePixmap () {
    if (pixmap != nil) {
	XFreePixmap(pixmap);
	pixmap = nil;
    }
}

void Bitmap::FreeMaps () {
    if (bitmap != nil) {
	XFreeBitmap(bitmap);
	bitmap = nil;
    }
    FreePixmap();
}

void Bitmap::Draw (Canvas* c) {
    if (bitmap == nil && data != nil) {
	bitmap = XStoreBitmap(width, height, data);
    }
    if (pixmap == nil && bitmap != nil) {
	pixmap = XMakePixmap(bitmap,
	    foreground->PixelValue(), background->PixelValue()
	);
    }
    Coord xx = x0;
    Coord yy = y0 + height - 1;
    c->Map(xx, yy);
    if (pixmap != nil) {
	XPixmapPut(c->Id(),
	    0, 0, xx, yy, width, height,
	    pixmap, GXcopy, AllPlanes
	);
    } else {
	XPixSet(c->Id(), xx, yy, width, height, background->PixelValue());
	if (bitmap != nil) {
	    XPixFill(c->Id(),
		xx, yy, width, height, foreground->PixelValue(),
		bitmap, GXcopy, AllPlanes
	    );
	}
    }
}

/*
 * class Brush
 */

Brush::Brush (int p, int w) {
    width = (w > 0) ? w : 1;
    info = (void*)(XMakePattern(p, 16, 1));
}

Brush::~Brush () {
    /* nothing to do */
}

/*
 * class Color
 */

Color::Color (int r, int g, int b) {
    XColor c;

    c.red = r;
    c.green = g;
    c.blue = b;
    if (XGetHardwareColor(&c)) {
	pixel = c.pixel;
	red = c.red;
	green = c.green;
	blue = c.blue;
    } else {
	pixel = -1;
    }
}

Color::Color (int index, int r, int g, int b) {
    red = r;
    green = g;
    blue = b;
    pixel = index;
}

Color::Color (int index) {
    pixel = index;
}

void Color::GetColorByName (const char* name) {
    XColor closest, exact;

    if (_World_nplanes == 1) {
	if (strcmp(name, "white") == 0) {
	    pixel = white->pixel;
	    red = 65535; blue = 65535; green = 65535;
	} else {
	    pixel = black->pixel;
	    red = 0; green = 0; blue = 0;
	}
    } else if (XGetColor(name, &closest, &exact)) {
	pixel = closest.pixel;
	red = closest.red;
	green = closest.green;
	blue = closest.blue;
    } else {
	pixel = -1;
    }
}

Color::~Color () {
    /* nothing to do */
}

/*
 * class Cursor
 */

void* Cursor::Id () {
    if (id == nil) {
	register int i;
	short pattern[cursorHeight], patmask[cursorHeight];
	register int* srcpat, * srcmask;
	register short* dstpat, * dstmask;

	srcpat = pat;
	dstpat = pattern;
	srcmask = mask;
	dstmask = patmask;
	for (i = 0; i < cursorHeight; i++) {
	    /* swap bits because X expects (backwards) VAX order */
	    register int j;
	    register unsigned s1, s2;

	    *dstpat = 0;
	    *dstmask = 0;
	    s1 = 1;
	    s2 = (1 << 15);
	    for (j = 0; j < 16; j++) {
		if ((s1 & *srcpat) != 0) {
		    *dstpat |= s2;
		}
		if ((s1 & *srcmask) != 0) {
		    *dstmask |= s2;
		}
		s1 <<= 1;
		s2 >>= 1;
	    }
	    ++srcpat;
	    ++dstpat;
	    ++srcmask;
	    ++dstmask;
	}
	id = XCreateCursor(
	    cursorWidth, cursorHeight, pattern, patmask,
	    x, cursorHeight - 1 - y,
	    foreground->PixelValue(), background->PixelValue(), GXcopy
	);
    }
    return id;
}

Cursor::~Cursor () {
    if (id != nil) {
	XFreeCursor(id);
    }
}

/*
 * class Font
 */

void Font::GetFontByName (const char* name) {
    rep->id = XGetFont(name);
    Init();
}

void Font::Init () {
    if (rep->id != nil) {
	register XFontInfo* i = new XFontInfo;

	XQueryFont(rep->id, *i);
	rep->height = i->height;
	if (i->fixedwidth) {
	    i->widths = nil;
	} else {
	    i->widths = XFontWidths(rep->id);
	}
	rep->info = i;
    } else {
	rep->height = -1;
    }
}

Font::~Font () {
    if (LastRef()) {
	delete rep;
    }
}

FontRep::~FontRep () {
    if (LastRef() && id != nil) {
	register XFontInfo* i;

	XFreeFont(id);
	i = (XFontInfo*)info;
	if (i->widths != nil) {
	    delete i->widths;
	}
	delete i;
    }
}

int Font::Baseline () {
    register XFontInfo* i = (XFontInfo*)rep->info;
    return i->baseline;
}

inline int CharWidth (register XFontInfo* info, char c) {
    register int i;

    i = c;
    if (i >= info->firstchar && i <= info->lastchar) {
#	if vax
	    if (_World_nplanes == 1) {
		/* X10 QVSS bug -- widths are 1 off */
		--i;
	    }
#	endif
	i = info->widths[i - info->firstchar];
    } else {
	i = 0;
    }
    return i;
}

int Font::Width (const char* s) {
    register XFontInfo* i = (XFontInfo*)rep->info;
    register char* p;
    register int w;

    if (i->fixedwidth) {
	return strlen(s) * i->width;
    } else {
	w = 0;
	for (p = (char*) s; *p != '\0'; p++) {
	    w += CharWidth(i, *p);
	}
	return w;
    }
}

int Font::Width (const char* s, int len) {
    register XFontInfo* i = (XFontInfo*)rep->info;
    register char* p;
    register int w, n;

    if (i->fixedwidth) {
	return len * i->width;
    } else {
	w = 0;
	for (p = (char*) s, n = len; *p != '\0' && n > 0; p++, n--) {
	    w += CharWidth(i, *p);
	}
	return w;
    }
}

int Font::Index (const char* s, int len, int offset, boolean between) {
    register XFontInfo* i = (XFontInfo*)rep->info;
    register int n, cw, coff;

    if (offset < 0 || *s == '\0' || len == 0) {
	return 0;
    }
    if (i->fixedwidth) {
	cw = i->width;
	n = offset / cw;
	coff = offset % cw;
    } else {
	register int w = 0;
	register const char* p;
	for (p = s, n = 0; *p != '\0' && n < len; ++p, ++n) {
	    cw = CharWidth(i, *p);
	    w += cw;
	    if (w > offset) {
		break;
	    }
	}
	coff = offset - w + cw;
    }
    if (between && coff > cw/2) {
	++n;
    }
    return min(n, len);
}

boolean Font::FixedWidth () {
    register XFontInfo* i = (XFontInfo*)rep->info;
    return i->fixedwidth;
}

/*
 * class Painter
 */

typedef XVertex XPoint;

static const XPointListSize = 200;
static XPoint xpoints[XPointListSize];

class PainterRep {
    friend class Painter;

    int raster;
    int fg, bg;
    boolean fillbg;
    XBitmap pat;
    XPixmap tile;
    XPixmap clearhi, clearlo, stipple;
    Canvas* curcanvas;

    PainterRep();
    XPoint* AllocPts (int n) {
	return (n <= XPointListSize) ? xpoints : new XPoint[n];
    }
    void FreePts (XPoint* v) {
	if (v != xpoints) {
	    delete v;
	}
    }
    void DoDraw(XWindow, Brush*, XPoint v[], int);
    void Update(Color* fg, Color* bg);
    void MakeNoBgPixmaps();
    void FreeNoBgPixmaps();
    void DrawTiled(void*, XPoint*, int);
};

PainterRep::PainterRep () {
    raster = GXcopy;
    fg = 0;
    bg = 0;
    fillbg = true;
    pat = nil;
    tile = XWhitePixmap;
    clearhi = nil;
    clearlo = nil;
    stipple = nil;
    curcanvas = nil;
}

inline void PainterRep::DoDraw (XWindow w, Brush* br, XPoint v[], int n) {
    if (br == single) {
	XDraw(w, v, n, br->width, br->width, fg,
	    raster, _Workstation_planemask
	);
    } else if (fillbg) {
	XDrawPatterned(
	    w, v, n, br->width, br->width, fg, bg,
	    (int)(br->info), raster, _Workstation_planemask
	);
    } else {
	XDrawDashed(
	    w, v, n, br->width, br->width, fg,
	    (int)(br->info), raster, _Workstation_planemask
	);
    }
}

void PainterRep::Update (Color* f, Color* b) {
    if (raster == GXxor) {
	tile = XWhitePixmap;
	fg = 1;
	bg = 0;
	fillbg = true;
    } else {
	fg = f->PixelValue();
	bg = b->PixelValue();
	if (tile != XWhitePixmap) {
	    XFreePixmap(tile);
	}
	tile = XMakePixmap(pat, fg, bg);
	if (!fillbg && stipple == nil) {
	    MakeNoBgPixmaps();
	}
    }
}

void PainterRep::MakeNoBgPixmaps () {
    if (_World_nplanes == 1) {
	/* first turn off fg bits, leave bg as is */
	clearhi = XMakePixmap(pat, 0, 1);
    } else {
	int mask = 1 << _World_nplanes - 1;
	clearhi = XMakePixmap(pat, mask-1, mask);
	clearlo = XMakePixmap(pat, mask, mask-1);
    }
    /* set fg bits to foreground color */
    stipple = XMakePixmap(pat, fg, 0);
}

void PainterRep::FreeNoBgPixmaps () {
    if (stipple != nil) {
	XFreePixmap(stipple);
	XFreePixmap(clearhi);
	if (_World_nplanes > 1) {
	    XFreePixmap(clearlo);
	}
	stipple = nil;
    }
}

void PainterRep::DrawTiled (void* id, XPoint* v, int n) {
    if (fillbg) {
	XDrawTiled(id, v, n, tile, raster, _Workstation_planemask);
    } else if (_World_nplanes == 1) {
	/* erase fg bits */
	XDrawTiled(id, v, n, clearhi, GXand, _Workstation_planemask);
	/* fill in fg bits */
	XDrawTiled(id, v, n, stipple, GXor, _Workstation_planemask);
    } else {
	/*
	 * First turn off fg bits, leave bg as is.  Then set fg
	 * bits to foreground color.
	 * To avoid using bogus colors, we'll erase the bits in
	 * two passes with two legal colors.
	 */
	int mask = 1 << _World_nplanes - 1;
	XDrawTiled(id, v, n, clearhi, GXand, mask);
	XDrawTiled(id, v, n, clearlo, GXand, mask-1);
	XDrawTiled(id, v, n, stipple, GXor, _Workstation_planemask);
    }
}

Painter::Painter () {
    rep = new PainterRep;
    Init();
}

Painter::Painter (Painter* copy) {
    rep = new PainterRep;
    Copy(copy);
    FillBg(copy->rep->fillbg);
}

Painter::~Painter () {
    if (LastRef()) {
	rep->FreeNoBgPixmaps();
	delete matrix;
	delete rep;
    }
}

void Painter::FillBg (boolean b) {
    if (rep->raster != GXcopy) {
	rep->fillbg = b;
	rep->raster = GXcopy;
	rep->Update(foreground, background);
    } else if (b != rep->fillbg) {
	rep->fillbg = b;
	if (!b && rep->stipple == nil) {
	    rep->MakeNoBgPixmaps();
	}
    }
}

boolean Painter::BgFilled () {
    return rep->fillbg;
}

void Painter::SetColors (Color* f, Color* b) {
    boolean changed = false;
    if (f != nil && foreground != f) {
	foreground = f;
	changed = true;
    }
    if (b != nil && background != b) {
	background = b;
	changed = true;
    }
    if (changed) {
	rep->FreeNoBgPixmaps();
	rep->Update(foreground, background);
    }
}

void Painter::SetPattern (Pattern* pat) {
    if (pattern != pat) {
	pattern = pat;
	if (pat != nil) {
	    rep->pat = pat->info;
	    rep->FreeNoBgPixmaps();
	    rep->Update(foreground, background);
	}
    }
}

void Painter::SetBrush (Brush* b) {
    br = b;
}

void Painter::SetFont (Font* f) {
    font = f;
}

void Painter::Clip (
    Canvas* c, Coord left, Coord bottom, Coord right, Coord top
) {
    c->Clip(left, bottom, right, top);
    rep->curcanvas = c;
}

void Painter::NoClip () {
    if (rep->curcanvas != nil) {
	rep->curcanvas->NoClip();
	rep->curcanvas = nil;
    }
}

void Painter::SetPlaneMask (int m) {
    _Workstation_planemask = m;
}

void Painter::SetOverwrite (boolean) {
    /* always true in X10 */
}

void Painter::Map (Canvas* c, Coord x, Coord y, Coord& mx, Coord& my) {
    if (matrix == nil) {
	mx = x; my = y;
    } else {
	matrix->Transform(x, y, mx, my);
    }
    mx += xoff;
    my += yoff;
    c->Map(mx, my);
}

void Painter::MapList (
    Canvas* c, Coord x[], Coord y[], int n, Coord mx[], Coord my[]
) {
    register Coord* xp, * yp, * mxp, * myp;
    Coord* lim;

    xp = x; yp = y;
    mxp = mx; myp = my;
    lim = &x[n];
    if (matrix == nil) {
	for (; xp < lim; xp++, yp++, mxp++, myp++) {
	    *mxp = *xp + xoff;
	    *myp = *yp + yoff;
	    c->Map(*mxp, *myp);
	}
    } else {
	for (; xp < lim; xp++, yp++, mxp++, myp++) {
	    matrix->Transform(*xp, *yp, *mxp, *myp);
	    *mxp += xoff;
	    *myp += yoff;
	    c->Map(*mxp, *myp);
	}
    }
}

void Painter::Begin_xor () {
    if (rep->raster != GXxor) {
	rep->raster = GXxor;
	rep->Update(foreground, background);
    }
}

void Painter::End_xor () {
    if (rep->raster != GXcopy) {
	rep->raster = GXcopy;
	rep->Update(foreground, background);
    }
}

void Painter::InvertArea (Canvas* c, Coord x1, Coord y1, Coord x2, Coord y2) {
    Coord left, bottom, right, top, tmp;

    Map(c, x1, y1, left, bottom);
    Map(c, x2, y2, right, top);
    if (left > right) {
	tmp = left; left = right; right = tmp;
    }
    if (top > bottom) {
	tmp = bottom; bottom = top; top = tmp;
    }
    XPixFill(
	c->Id(), left, top, right - left + 1, bottom - top + 1, 1, 0,
	GXxor, _Workstation_planemask
    );
}

void Painter::Text (Canvas* c, const char* s, int len, Coord x, Coord y) {
    Coord x0, y0;

    Map(c, x, y + font->rep->height - 1, x0, y0);
    if (rep->fillbg) {
	XTextPad(
	    c->Id(), x0, y0, s, len, font->rep->id, 0, 0,
	    rep->fg, rep->bg, rep->raster, _Workstation_planemask
	);
    } else {
	XTextMaskPad(
	    c->Id(), x0, y0, s, len, font->rep->id, 0, 0,
	    rep->fg, GXcopy, _Workstation_planemask
	);
    }
}

void Painter::Point (Canvas* c, Coord x, Coord y) {
    Coord mx, my;

    Map(c, x, y, mx, my);
    XLine(
	c->Id(), mx, my, mx, my,
	br->width, br->width, rep->fg, rep->raster, _Workstation_planemask
    );
}

void Painter::MultiPoint (Canvas* c, Coord x[], Coord y[], int n) {
    register XPoint* v;
    register int i;
    int nn;

    nn = 2*n;
    v = rep->AllocPts(nn);
    for (i = 0; i < nn; i += 2) {
	Map(c, x[i], y[i], v[i].x, v[i].y);
	v[i].flags = VertexDontDraw;
	v[i+1] = v[i];
	v[i+1].flags = 0;
    }
    rep->DoDraw(c->Id(), br, v, nn);
    rep->FreePts(v);
}

/*
 * X behaves anomalously, at best, for single lines (in other words,
 * VertexDrawLastPoint doesn't seem to work right), so we simply add
 * the end point on twice.
 */

void Painter::Line (Canvas* c, Coord x1, Coord y1, Coord x2, Coord y2) {
    XPoint v[3];

    Map(c, x1, y1, v[0].x, v[0].y);
    v[0].flags = 0;
    Map(c, x2, y2, v[1].x, v[1].y);
    v[1].flags = 0;
    v[2] = v[1];
    v[2].flags = VertexDrawLastPoint;
    rep->DoDraw(c->Id(), br, v, 3);
}

void Painter::Rect (Canvas* c, Coord x1, Coord y1, Coord x2, Coord y2) {
    XPoint v[5];

    Map(c, x1, y1, v[0].x, v[0].y);  v[0].flags = 0;
    Map(c, x2, y1, v[1].x, v[1].y);  v[1].flags = 0;
    Map(c, x2, y2, v[2].x, v[2].y);  v[2].flags = 0;
    Map(c, x1, y2, v[3].x, v[3].y);  v[3].flags = 0;
    Map(c, x1, y1, v[4].x, v[4].y);  v[4].flags = 0;
    rep->DoDraw(c->Id(), br, v, 5);
}

void Painter::FillRect (Canvas* c, Coord x1, Coord y1, Coord x2, Coord y2) {
    Coord left, bottom, right, top, tmp, x[4], y[4];
    int w, h;

    if (matrix != nil && matrix->Rotated() && !matrix->Rotated90()) {
	x[0] = x[3] = x1;
	x[1] = x[2] = x2;
	y[0] = y[1] = y1;
	y[2] = y[3] = y2;
	FillPolygon(c, x, y, 4);
    } else {
	Map(c, x1, y1, left, bottom); 
	Map(c, x2, y2, right, top);
	if (left > right) {
	    tmp = left; left = right; right = tmp;
	}
	if (top > bottom) {
	    tmp = bottom; bottom = top; top = tmp;
	}
	w = right - left + 1;
	h = bottom - top + 1;
	if (rep->fillbg) {
	    XTileFill(
		c->Id(), left, top, w, h,
		rep->tile, 0, rep->raster, _Workstation_planemask
	    );
	} else if (_World_nplanes == 1) {
	    /* erase fg bits */
	    XTileFill(
		c->Id(), left, top, w, h, rep->clearhi, 0, 
		GXand, _Workstation_planemask
	    );
	    /* fill in fg bits */
	    XTileFill(
		c->Id(), left, top, w, h, rep->stipple, 0, 
		GXor, _Workstation_planemask
	    );
	} else {
	    /*
	     * First turn off fg bits, leave bg as is.  Then set fg
	     * bits to foreground color.
	     * To avoid using bogus colors, we'll erase the bits in
	     * two passes with two legal colors.
	     */
	    int mask = 1 << _World_nplanes - 1;
	    XTileFill(c->Id(), left, top, w, h, rep->clearhi, 0, GXand, mask);
	    XTileFill(
		c->Id(), left, top, w, h, rep->clearlo, 0, GXand, mask-1
	    );
	    XTileFill(c->Id(), left, top, w, h, rep->stipple, 0, GXor, mask-1);
	}
    }
}

void Painter::ClearRect (Canvas* c, Coord x1, Coord y1, Coord x2, Coord y2) {
    Coord left, bottom, right, top, tmp;

    Map(c, x1, y1, left, bottom);
    Map(c, x2, y2, right, top);
    if (left > right) {
	tmp = left; left = right; right = tmp;
    }
    if (top > bottom) {
	tmp = bottom; bottom = top; top = tmp;
    }
    XPixFill(
	c->Id(), left, top, right - left + 1, bottom - top + 1,
	rep->bg, 0, rep->raster, _Workstation_planemask
    );
}

void Painter::Circle (Canvas* c, Coord x, Coord y, int r) {
    XPoint v[5];

    if (matrix != nil && matrix->Stretched()) {
	Ellipse(c, x, y, r, r);
    } else {
	Map(c, x-r, y, v[0].x, v[0].y);
	v[0].flags = VertexStartClosed+VertexCurved;
	Map(c, x, y+r, v[1].x, v[1].y);
	v[1].flags = VertexCurved;
	Map(c, x+r, y, v[2].x, v[2].y);
	v[2].flags = VertexCurved;
	Map(c, x, y-r, v[3].x, v[3].y);
	v[3].flags = VertexCurved;
	Map(c, x-r, y, v[4].x, v[4].y);
	v[4].flags = VertexEndClosed+VertexCurved;
	rep->DoDraw(c->Id(), br, v, 5);
    }
}

void Painter::FillCircle (Canvas* c, Coord x, Coord y, int r) {
    XPoint v[5];

    if (matrix != nil && matrix->Stretched()) {
	FillEllipse(c, x, y, r, r);
    } else {
	Map(c, x-r, y, v[0].x, v[0].y);
	v[0].flags = VertexStartClosed+VertexCurved;
	Map(c, x, y+r, v[1].x, v[1].y);
	v[1].flags = VertexCurved;
	Map(c, x+r, y, v[2].x, v[2].y);
	v[2].flags = VertexCurved;
	Map(c, x, y-r, v[3].x, v[3].y);
	v[3].flags = VertexCurved;
	Map(c, x-r, y, v[4].x, v[4].y);
	v[4].flags = VertexEndClosed+VertexCurved;
	rep->DrawTiled(c->Id(), v, 5);
    }
}

void Painter::MultiLine (Canvas* c, Coord x[], Coord y[], int n) {
    register XPoint* v;
    register int i;

    v = rep->AllocPts(n);
    for (i = 0; i < n; i++) {
	Map(c, x[i], y[i], v[i].x, v[i].y);
	v[i].flags = 0;
    }
    rep->DoDraw(c->Id(), br, v, n);
    rep->FreePts(v);
}

void Painter::MultiLineNoMap (Canvas* c, Coord x[], Coord y[], int n) {
    register XPoint* v;
    register int i;

    v = rep->AllocPts(n);
    for (i = 0; i < n; i++) {
	v[i].x = x[i];
	v[i].y = y[i];
	v[i].flags = 0;
    }
    rep->DoDraw(c->Id(), br, v, n);
    rep->FreePts(v);
}

void Painter::Polygon (Canvas* c, Coord x[], Coord y[], int n) {
    register XPoint* v;
    register int i;

    v = rep->AllocPts(n+1);
    for (i = 0; i < n; i++) {
	Map(c, x[i], y[i], v[i].x, v[i].y);
	v[i].flags = 0;
    }
    if (x[i-1] != x[0] || y[i-1] != y[0]) {
	v[i] = v[0];
	++i;
    }
    v[0].flags |= VertexStartClosed;
    v[i-1].flags |= VertexEndClosed;
    rep->DoDraw(c->Id(), br, v, i);
    rep->FreePts(v);
}

void Painter::FillPolygonNoMap (Canvas* c, Coord x[], Coord y[], int n) {
    register XPoint* v;
    register int i;

    v = rep->AllocPts(n);
    for (i = 0; i < n; i++) {
	v[i].x = x[i];
	v[i].y = y[i];
	v[i].flags = 0;
    }
    if (x[i-1] != x[0] || y[i-1] != y[0]) {
	v[i] = v[0];
	++i;
    }
    v[0].flags |= VertexStartClosed;
    v[i-1].flags |= VertexEndClosed;
    rep->DrawTiled(c->Id(), v, i);
    rep->FreePts(v);
}

void Painter::FillPolygon (Canvas* c, Coord x[], Coord y[], int n) {
    register XPoint* v;
    register int i;

    v = rep->AllocPts(n+1);
    for (i = 0; i < n; i++) {
	Map(c, x[i], y[i], v[i].x, v[i].y);
	v[i].flags = 0;
    }
    if (x[i-1] != x[0] || y[i-1] != y[0]) {
	v[i] = v[0];
	++i;
    }
    v[0].flags |= VertexStartClosed;
    v[i-1].flags |= VertexEndClosed;
    rep->DrawTiled(c->Id(), v, i);
    rep->FreePts(v);
}

void Painter::Copy (
    Canvas* src, Coord x1, Coord y1, Coord x2, Coord y2,
    Canvas* dst, Coord x0, Coord y0
) {
    register int w, h;
    Coord sx1, sy1, dx1, dy1;

    w = x2 - x1 + 1;
    h = y2 - y1 + 1;
    Map(src, x1, y2, sx1, sy1);
    Map(dst, x0, y0+h-1, dx1, dy1);
    if (src->status == CanvasOffscreen) {
	if (dst->status == CanvasOffscreen) {
	    /* offscreen-to-offscreen unimplemented */
	} else {
	    XPixmapPut(
		dst->id, sx1, sy1, dx1, dy1, w, h,
		src->id, rep->raster, _Workstation_planemask
	    );
	}
    } else {
	if (dst->status == CanvasOffscreen) {
	    if (dst->id != nil) {
		XFreePixmap(dst->id);
	    }
	    dst->id = XPixmapSave(src->id, sx1, sy1, w, h);
	    dst->width = w;
	    dst->height = h;
	} else {
	    if (src->id == dst->id) {
		XCopyArea(
		    src->id, sx1, sy1, dx1, dy1, w, h,
		    rep->raster, _Workstation_planemask
		);
		src->WaitForCopy();
	    } else {
		/* cross-window unimplemented */
	    }
	}
    }
}

void Painter::Read (
    Canvas* c, void* dst, Coord x1, Coord y1, Coord x2, Coord y2
) {
    XPixmapGetXY(c->id, x1, c->height-y2-1, x2-x1+1, y2-y1+1, dst);
}

void Painter::Write (
    Canvas* c, const void* src, Coord x1, Coord y1, Coord x2, Coord y2
) {
    XPixmapBitsPutXY(
	c->id, x1, c->height - y2 - 1, x2 - x1 + 1, y2 - y1 + 1,
	(short*)src, nil, rep->raster, _Workstation_planemask
    );
}

/*
 * class Pattern
 */

Pattern::Pattern (int p[patternHeight]) {
    short bp[patternHeight];
    register int* src;
    register short* dst;
    register int i;

    src = p;
    dst = bp;
    for (i = 0; i < patternHeight; i++) {
	/*
	 * Swap bits in patterns for X, which expects them in VAX order.
	 */
	register int j;
	register unsigned s1, s2;

	*dst = 0;
	s1 = 1;
	s2 = 1 << (patternWidth-1);
	for (j = 0; j < patternWidth; j++) {
	    if ((s1 & *src) != 0) {
		*dst |= s2;
	    }
	    s1 <<= 1;
	    s2 >>= 1;
	}
	++src;
	++dst;
    }
    info = XStoreBitmap(patternWidth, patternHeight, bp);
}

Pattern::Pattern (int dither) {
    register int i, seed;
    int r[4];
    short p[patternHeight];

    register unsigned s1, s2;

    s1 = 1;
    s2 = 1 << (patternHeight-1);
    seed = 0;
    for (i = 0; i < patternWidth; i++) {
	if ((s1 & dither) != 0) {
	    seed |= s2;
	}
	s1 <<= 1;
	s2 >>= 1;
    }
    for (i = 0; i < 4; i++) {
	r[i] = (seed & 0xf000) >> 12;
	r[i] |= r[i] << 4;
	r[i] |= r[i] << 8;
	seed <<= 4;
    }
    for (i = 0; i < patternHeight; i++) {
	p[i] = r[i%4];
    }
    info = XStoreBitmap(patternWidth, patternHeight, p);
}

Pattern::Pattern (Bitmap*) {
    /* unimplemented */
}

Pattern::~Pattern () {
    if (LastRef()) {
	XFreeBitmap(info);
    }
}
