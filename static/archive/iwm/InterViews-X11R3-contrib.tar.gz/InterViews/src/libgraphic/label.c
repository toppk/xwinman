/*
 * Implementation of Label, an object derived from Graphic.
 */

#include <InterViews/transformer.h>
#include <InterViews/Graphic/grclasses.h>
#include <InterViews/Graphic/label.h>

extern int strlen(const char*);
extern char* strncpy(char*, const char*, int);

void Label::draw (Canvas *c, Graphic* gs) {
    update(gs);
    pText(c, string, count, 0, 0);
}

ClassId Label::GetClassId () { 
    return LABEL;
}

boolean Label::IsA (ClassId id) { 
    return LABEL == id || Graphic::IsA(id);
}

Label::Label () {
    string = nil;
    count = 0;
}

Label::Label (const char* string, Graphic* gr) : (gr) {
    if (gr == nil) {
	SetFont(nil);
    } else {
	SetFont(gr->GetFont());
    }
    count = strlen(string);
    this->string = new char[count];
    strncpy(this->string, string, count);
}

Label::Label (const char* string, int count, Graphic* gr) : (gr) {
    if (gr == nil) {
	SetFont(nil);
    } else {
	SetFont(gr->GetFont());
    }
    this->string = new char[count];
    this->count = count;
    strncpy(this->string, string, count);
}

Graphic* Label::Copy () { 
    return new Label(string, count, this);
}

void Label::Delete () {
    delete string;
    Graphic::Delete();
}

void Label::GetOriginal (char*& string, int& n) {
    string = new char[count];
    n = count;
    strncpy(string, this->string, count);
}

boolean Label::read (File* f) {
    boolean ok;
    ok = Graphic::read(f) && font.Read(f) && f->Read(count);
    if (ok) {
	delete string;
	string = new char [count];
	ok = f->Read(string, count);
    }
    return ok;
}

boolean Label::write (File* f) {
    return 
	Graphic::write(f) && font.Write(f) &&
	f->Write(count) && f->Write(string, count);
}

void Label::getExtent (
    float& x0, float& y0, float& cx, float& cy, float& tol, Graphic* gs
) {
    PFont* f = gs->GetFont();
    float width = f->Width(string, count);
    float height = f->Height();

    if (gs->GetTransformer() == nil) {
	x0 = 0;
	y0 = 0;
	cx = width / 2;
	cy = height / 2;
    } else {
	gs->transformRect(0, 0, width, height, x0, y0, cx, cy);
	cx = (cx + x0)/2;
	cy = (cy + y0)/2;
    }
    tol = 0;
}

boolean Label::contains (PointObj& p, Graphic* gs) {
    BoxObj b;

    getBox(b, gs);
    return b.Contains(p);
}

boolean Label::intersects (BoxObj& userb, Graphic* gs) {
    BoxObj b;

    getBox(b, gs);
    return b.Intersects(userb);
}

void Label::SetFont (PFont* font) {
    if (this->font != Ref(font)) {
	this->font = Ref(font);
	invalidateCaches();
    }
}

PFont* Label::GetFont () { 
    return (PFont*) font();
}
