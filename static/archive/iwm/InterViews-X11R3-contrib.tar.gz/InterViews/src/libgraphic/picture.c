/*
 * Picture class implementation.  A Picture is a Graphic that contains other 
 * Graphics.
 */

#include <InterViews/canvas.h>
#include <InterViews/transformer.h>
#include <InterViews/Graphic/grclasses.h>
#include <InterViews/Graphic/picture.h>

void Picture::Delete () {
    while (!refList->IsEmpty()) {
	cur = refList->First();
	refList->Remove(cur);
	delete (*cur)();
	delete cur;
    }
    delete refList;
    uncacheExtent();
    Graphic::Delete();
}

void Picture::setParent (Graphic* p) {
    if (!p->parent.Valid()) {	    // a graphic can have only one parent
	p->parent = Ref(this);
    }
}

void Picture::unsetParent (Graphic* p) {
    p->parent = nil;
    p->invalidateCaches();
}

boolean Picture::read (File* f) {
    return FullGraphic::read(f) && refList->Read(f);
}

boolean Picture::readObjects (File* f) {
    return FullGraphic::readObjects(f) && refList->ReadObjects(f);
}

boolean Picture::write (File* f) {
    return FullGraphic::write(f) && refList->Write(f);
}

boolean Picture::writeObjects (File* f) {
    return FullGraphic::writeObjects(f) && refList->WriteObjects(f);
}

boolean Picture::extentCached () {
    return caching && extent != nil;
}

void Picture::uncacheExtent () {
    delete extent; 
    extent = nil;
}

ClassId Picture::GetClassId  () { 
    return PICTURE;
}

boolean Picture::IsA (ClassId id) {
    return PICTURE == id || FullGraphic::IsA(id);
}

Picture::Picture (Graphic* gr) : (gr) {
    extent = nil;
    refList = cur = new RefList(nil);
}

void Picture::Append (Graphic* p0, Graphic* p1, Graphic* p2, Graphic* p3) {
    p0->invalidateCaches();
    refList->Append(new RefList(p0));
    setParent(p0);
    if (p1 != nil) {
	p1->invalidateCaches();
	refList->Append(new RefList(p1));
	setParent(p1);
    }
    if (p2 != nil) {
	p2->invalidateCaches();
	refList->Append(new RefList(p2));
	setParent(p2);
    }
    if (p3 != nil) {
	p3->invalidateCaches();
	refList->Append(new RefList(p3));
	setParent(p3);
    }
    uncacheExtent();
    uncacheParents();
}

void Picture::Prepend (Graphic* p0, Graphic* p1, Graphic* p2, Graphic* p3) {
    if (p3 != nil) {
	p3->invalidateCaches();
	refList->Prepend(new RefList(p3));
	setParent(p3);
    }
    if (p2 != nil) {
	p2->invalidateCaches();
	refList->Prepend(new RefList(p2));
	setParent(p2);
    }
    if (p1 != nil) {
	p1->invalidateCaches();
	refList->Prepend(new RefList(p1));
	setParent(p1);
    }
    p0->invalidateCaches();
    refList->Prepend(new RefList(p0));
    setParent(p0);
    uncacheExtent();
    uncacheParents();
}

void Picture::InsertAfterCur (
    Graphic* p0, Graphic* p1, Graphic* p2,Graphic* p3
) {
    p0->invalidateCaches();
    cur->Prepend(new RefList(p0));
    setParent(p0);
    if (p1 != nil) {
	p1->invalidateCaches();
	cur->Prepend(new RefList(p1));
	setParent(p1);
    }
    if (p2 != nil) {
	p2->invalidateCaches();
	cur->Prepend(new RefList(p2));
	setParent(p2);
    }
    if (p3 != nil) {
	p3->invalidateCaches();
	cur->Prepend(new RefList(p3));
	setParent(p3);
    }
    uncacheExtent();
    uncacheParents();
}

void Picture::InsertBeforeCur (
    Graphic* p0, Graphic* p1, Graphic* p2, Graphic* p3
) {
    if (p3 != nil) {
	p3->invalidateCaches();
	cur->Append(new RefList(p3));
	setParent(p3);
    }
    if (p2 != nil) {
	p2->invalidateCaches();
	cur->Append(new RefList(p2));
	setParent(p2);
    }
    if (p1 != nil) {
	p1->invalidateCaches();
	cur->Append(new RefList(p1));
	setParent(p1);
    }
    p0->invalidateCaches();
    cur->Append(new RefList(p0));
    setParent(p0);
    uncacheExtent();
    uncacheParents();
}

Graphic* Picture::First () {
    cur = refList->First(); 
    return getGraphic(cur);
}

Graphic* Picture::Last () {
    cur = refList->Last(); 
    return getGraphic(cur);
}

Graphic* Picture::Next () {
    cur = cur->Next(); 
    return getGraphic(cur);
}

Graphic* Picture::Prev () {
    cur = cur->Prev(); 
    return getGraphic(cur);
}

void Picture::RemoveCur () {
    RefList* prev;

    if (cur != refList) {
	unsetParent((Graphic*) (*cur)());
	prev = cur;
        cur = cur->Next();
	refList->Remove(prev);
	delete prev;
	uncacheExtent();
	uncacheParents();
    }
}	
    
void Picture::Remove (Graphic* p) {
    RefList* temp;

    if (getGraphic(cur) == p) {
        RemoveCur ();
    } else if ((temp = refList->Find(Ref(p))) != nil) {
	unsetParent((Graphic*) (*temp)());
	refList->Remove(temp);
	delete temp;
	uncacheExtent();
	uncacheParents();
    }
}

void Picture::SetCurrent (Graphic* p) {
    RefList* temp;

    if ((temp = refList->Find(Ref(p))) != nil) {
        cur = temp;
    }
}

Graphic* Picture::FirstGraphicContaining (PointObj& pt) {
    register RefList* i;
    Graphic* subgr;

    for (i = refList->First(); i != refList->End(); i = i->Next()) {
	subgr = getGraphic(i);
	if (subgr->Contains(pt)) {
	    return subgr;
	}
    }
    return nil;
}

Graphic* Picture::LastGraphicContaining (PointObj& pt) {
    register RefList* i;
    Graphic* subgr;

    for (i = refList->Last(); i != refList->End(); i = i->Prev()) {
	subgr = getGraphic(i);
	if (subgr->Contains(pt)) {
	    return subgr;
	}
    }
    return nil;
}

int Picture::GraphicsContaining (PointObj& pt, Graphic**& garray) {
    register RefList* i;
    RefList glist;
    Graphic* subgr;
    int size = 0, n = 0;

    for (i = refList->First(); i != refList->End(); i = i->Next()) {
	subgr = getGraphic(i);
	if (subgr->Contains(pt)) {
	    glist.Append(new RefList(subgr));
	    ++size;
	}
    }
    if (size != 0) {
	garray = new Graphic*[size];
	for (i = glist.First(); i != glist.End(); i = glist.First(), ++n) {
	    garray[n] = (Graphic*) (*i)();
	    glist.Remove(i);
	    delete i;
	}
    }
    return size;
}

Graphic* Picture::FirstGraphicIntersecting (BoxObj& b) {
    register RefList* i;
    Graphic* subgr;

    for (i = refList->First(); i != refList->End(); i = i->Next()) {
	subgr = getGraphic(i);
	if (subgr->Intersects(b)) {
	    return subgr;
	}
    }
    return nil;
}

Graphic* Picture::LastGraphicIntersecting (BoxObj& b) {
    register RefList* i;
    Graphic* subgr;

    for (i = refList->Last(); i != refList->End(); i = i->Prev()) {
	subgr = getGraphic(i);
	if (subgr->Intersects(b)) {
	    return subgr;
	}
    }
    return nil;
}

int Picture::GraphicsIntersecting (BoxObj& b, Graphic**& garray) {
    register RefList* i;
    RefList glist;
    Graphic* subgr;
    int size = 0, n = 0;

    for (i = refList->First(); i != refList->End(); i = i->Next()) {
	subgr = getGraphic(i);
	if (subgr->Intersects(b)) {
	    glist.Append(new RefList(subgr));
	    ++size;
	}
    }
    if (size != 0) {
	garray = new Graphic*[size];
	for (i = glist.First(); i != glist.End(); i = glist.First(), ++n) {
	    garray[n] = (Graphic*) (*i)();
	    glist.Remove(i);
	    delete i;
	}
    }
    return size;
}

Graphic* Picture::FirstGraphicWithin (BoxObj& userb) {
    register RefList* i;
    Graphic* subgr;
    BoxObj b;

    for (i = refList->First(); i != refList->End(); i = i->Next()) {
	subgr = getGraphic(i);
	subgr->GetBox(b);
	if (b.Within(userb)) {
	    return subgr;
	}
    }
    return nil;
}

Graphic* Picture::LastGraphicWithin (BoxObj& userb) {
    register RefList* i;
    Graphic* subgr;
    BoxObj b;

    for (i = refList->Last(); i != refList->End(); i = i->Prev()) {
	subgr = getGraphic(i);
	subgr->GetBox(b);
	if (b.Within(userb)) {
	    return subgr;
	}
    }
    return nil;
}

int Picture::GraphicsWithin (BoxObj& userb, Graphic**& garray) {
    register RefList* i;
    RefList glist;
    Graphic* subgr;
    int size = 0, n = 0;
    BoxObj b;

    for (i = refList->First(); i != refList->End(); i = i->Next()) {
	subgr = getGraphic(i);
	subgr->GetBox(b);
	if (b.Within(userb)) {
	    glist.Append(new RefList(subgr));
	    ++size;
	}
    }
    if (size != 0) {
	garray = new Graphic*[size];
	for (i = glist.First(); i != glist.End(); i = glist.First(), ++n) {
	    garray[n] = (Graphic*) (*i)();
	    glist.Remove(i);
	    delete i;
	}
    }
    return size;
}

Graphic* Picture::Copy () {
    register RefList* i;
    Picture* newPicture = new Picture(this);
    
    for (i = refList->First(); i != refList->End(); i = i->Next()) {
        newPicture->Append(getGraphic(i)->Copy());
    }
    return newPicture;
}

void Picture::draw (Canvas* c, Graphic* gs) {
    register RefList* i;
    Graphic* gr;
    FullGraphic gstemp;
    Transformer ttemp;

    gstemp.SetTransformer(&ttemp);
    for (i = refList->First(); i != refList->End(); i = i->Next()) {
	gr = getGraphic(i);
	gr->concat(gs, &gstemp);
	gr->draw(c, &gstemp);
    }
    gstemp.SetTransformer(nil);	/* to avoid deleting ttemp explicitly */
}

void Picture::drawClipped (
    Canvas* c, Coord l, Coord b, Coord r, Coord t, Graphic* gs
) {
    register RefList* i;
    Graphic* gr;
    FullGraphic gstemp;
    Transformer ttemp;
    BoxObj box, clipBox(l, b, r, t);
    
    getBox(box, gs);
    if (clipBox.Intersects(box)) {
	gstemp.SetTransformer(&ttemp);
	for (i = refList->First(); i != refList->End(); i = i->Next()) {
	    gr = getGraphic(i);
	    gr->concat(gs, &gstemp);
	    gr->drawClipped(c, l, b, r, t, &gstemp);
	}
	gstemp.SetTransformer(nil); /* to avoid deleting ttemp explicitly */
    }
}

void Picture::cacheExtent (float l, float b, float cx, float cy, float tol) {
    if (caching) {
	uncacheExtent();
	extent = new Extent(l, b, cx, cy, tol);
    }
}

void Picture::uncacheChildren () {
    register RefList* i;
    Graphic* subgr;

    for (i = refList->First(); i != refList->End(); i = i->Next()) {
	subgr = getGraphic(i);
	subgr->uncacheExtent();
	subgr->uncacheChildren();
    }
}

void Picture::getCachedExtent (
    float& l, float& b, float& cx, float& cy, float& tol
) {
    l = extent->left;
    b = extent->bottom;
    cx = extent->cx;
    cy = extent->cy;
    tol = extent->tol;
}

void Picture::getExtent (
    float& l, float& b, float& cx, float& cy, float& tol, Graphic* gs
) {
    register RefList* i;
    Graphic* gr;
    FullGraphic gstemp;
    float right, top, dummy;
    Extent e, te;
    
    if (extentCached()) {
	getCachedExtent(e.left, e.bottom, e.cx, e.cy, e.tol);

    } else {
	if (IsEmpty()) {
	    l = b = cx = cy = tol = 0.0;
	    return;
	} else {
	    i = refList->First();
	    gr = getGraphic(i);
	    gr->concatGS(gs, &gstemp);
	    gstemp.SetTransformer(gr->t);
	    gr->getExtent(e.left, e.bottom, e.cx, e.cy, e.tol, &gstemp);
	    for (i = i->Next(); i != refList->End(); i = i->Next()) {
		gr = getGraphic(i);
		gr->concatGS(gs, &gstemp);
		gstemp.SetTransformer(gr->t);
		gr->getExtent(te.left, te.bottom, te.cx, te.cy,te.tol,&gstemp);
		e.Merge(te);
	    }
	    cacheExtent(e.left, e.bottom, e.cx, e.cy, e.tol);
	}
    }
    right = 2*e.cx - e.left;
    top = 2*e.cy - e.bottom;
    gs->transformRect(e.left, e.bottom, right, top, l, b, dummy, dummy);
    gs->transform(e.cx, e.cy, cx, cy);
    tol = e.tol;
}

boolean Picture::contains (PointObj& po, Graphic* gs) {
    register RefList* i;
    Graphic* gr;
    FullGraphic gstemp;
    Transformer ttemp;
    BoxObj b;
    
    if (!IsEmpty()) {
	getBox(b, gs);
	if (b.Contains(po)) {
	    gstemp.SetTransformer(&ttemp);
	    for (i = refList->First(); i != refList->End(); i = i->Next()) {
		gr = getGraphic(i);
		gr->concat(gs, &gstemp);
		if (gr->contains(po, &gstemp)) {
		    gstemp.SetTransformer(nil);
		    return true;
		}
	    }
	    gstemp.SetTransformer(nil); /* to avoid deleting ttemp explicitly*/
	}
    }
    return false;
}

boolean Picture::intersects (BoxObj& userb, Graphic* gs) {
    register RefList* i;
    Graphic* gr;
    FullGraphic gstemp;
    Transformer ttemp;
    BoxObj b;
    
    if (!IsEmpty()) {
	getBox(b, gs);
	if (b.Intersects(userb)) {
	    gstemp.SetTransformer(&ttemp);
	    for (i = refList->First(); i != refList->End(); i = i->Next()){
		gr = getGraphic(i);
		gr->concat(gs, &gstemp);
		if (gr->intersects(userb, &gstemp)) {
		    gstemp.SetTransformer(nil);
		    return true;
		}
	    }
	    gstemp.SetTransformer(nil); /* to avoid deleting ttemp explicitly*/
	}
    }
    return false;
}

boolean Picture::HasChildren () { 
    return !IsEmpty();
}

void Picture::Propagate () {
    register RefList* i;
    Graphic* gr;
    
    for (i = refList->First(); i != refList->End(); i = i->Next()) {
	gr = getGraphic(i);
	gr->concat(this, gr);
    }
    SetTransformer(nil);
}
