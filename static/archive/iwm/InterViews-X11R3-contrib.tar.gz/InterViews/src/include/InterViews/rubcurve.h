/*
 * Rubberbanding for curves.
 */

#ifndef rubcurve_h
#define rubcurve_h

#include <InterViews/rubband.h>

class RubberEllipse : public Rubberband {
protected:
    Coord centerx, radiusx;
    Coord centery, radiusy;
public:
    RubberEllipse(
        Painter*, Canvas*, Coord cx, Coord cy, Coord rx, Coord ry,
	Coord offx = 0, Coord offy = 0
    );
    virtual void GetOriginal(Coord& cx, Coord& cy, Coord& rx, Coord& ry);
    virtual void GetCurrent(Coord& cx, Coord& cy, Coord& rx, Coord& ry);
    virtual void OriginalRadii(int& xr, int& yr);
    virtual void CurrentRadii(int& xr, int& yr);
    void Draw();
};

class RubberCircle : public RubberEllipse {
public:
    RubberCircle(
        Painter*, Canvas*, Coord cx, Coord cy, Coord rx, Coord ry,
	Coord offx = 0, Coord offy = 0
    );
    void OriginalRadii(int& xr, int& yr);
    void CurrentRadii(int& xr, int& yr);
    void Draw();
};

class RubberPointList : public Rubberband {
protected:
    Coord *x;
    Coord *y;
    int count;
    void Copy(Coord*, Coord*, int, Coord*&, Coord*&);
public:
    RubberPointList(
        Painter*, Canvas*, Coord px[], Coord py[], int n,
	Coord offx = 0, Coord offy = 0
    );
    void Delete();
};    

class RubberVertex : public RubberPointList {
protected:
    int rubberPt;
    void DrawSplineSection (Painter*, Canvas*, Coord x[], Coord y[]);
public:
    RubberVertex(
        Painter*, Canvas*, Coord px[], Coord py[], int n, int pt,
	Coord offx = 0, Coord offy = 0
    );
    virtual void GetOriginal(Coord*& px, Coord*& py, int& n, int& pt);
    virtual void GetCurrent(Coord*& px, Coord*& py, int& n, int& pt);
};

class RubberHandles : public RubberVertex {
protected:
    int d;	/* half of handle size */
public:
    RubberHandles(
        Painter*, Canvas*, Coord x[], Coord y[], int n, int pt, int size,
	Coord offx = 0, Coord offy = 0
    );
    void Track(Coord x, Coord y);
    void Draw();
};

class RubberSpline : public RubberVertex {
public:
    RubberSpline(
        Painter*, Canvas*, Coord px[], Coord py[], int n, int pt,
	Coord offx = 0, Coord offy = 0
    );
    void Draw();
};

class RubberClosedSpline : public RubberVertex {
public:
    RubberClosedSpline(
        Painter*, Canvas*, Coord px[], Coord py[], int n, int pt,
	Coord offx = 0, Coord offy = 0
    );
    void Draw();
};

class SlidingPointList : public RubberPointList {
protected:
    Coord refx;
    Coord refy;
public:
    SlidingPointList (
        Painter*, Canvas*, Coord px[], Coord py[], int n,
	Coord rfx, Coord rfy, Coord offx = 0, Coord offy = 0
    );
    virtual void GetOriginal(Coord*& px, Coord*& py, int& n);
    virtual void GetCurrent(Coord*& px, Coord*& py, int& n);
    void Draw();
    void Track(Coord x, Coord y);
};

class SlidingLineList : public SlidingPointList {
public:
    SlidingLineList(
        Painter*, Canvas*, Coord x[], Coord y[], int n,
	Coord rfx, Coord rfy, Coord offx = 0, Coord offy = 0
    );
    void Draw();
};    

#endif
