/*
 * Interface to BSplines, objects derived from Graphic.
 */

#ifndef splines_h
#define splines_h

#include "lines.h"

class BSpline : public MultiLine {
protected:
    boolean contains(PointObj&, Graphic*);
    boolean intersects(BoxObj&, Graphic*);
    void draw(Canvas*, Graphic*);
public:
    ClassId GetClassId();
    boolean IsA(ClassId);

    BSpline();
    BSpline(Coord* x, Coord* y, int count, Graphic* gr =nil);

    Graphic* Copy();
};

class ClosedBSpline : public BSpline {
protected:
    boolean contains(PointObj&, Graphic*);
    boolean intersects(BoxObj&, Graphic*);
    void draw(Canvas*, Graphic*);
public:
    ClassId GetClassId();
    boolean IsA(ClassId);

    ClosedBSpline();
    ClosedBSpline(Coord* x, Coord* y, int count, Graphic* gr =nil);

    Graphic* Copy();
};

class FillBSpline : public ClosedBSpline {
protected:
    void getExtent(float&, float&, float&, float&, float&, Graphic*);
    boolean contains(PointObj&, Graphic*);
    boolean intersects(BoxObj&, Graphic*);
    void draw(Canvas*, Graphic*);
public:
    ClassId GetClassId();
    boolean IsA(ClassId);

    FillBSpline();
    FillBSpline(Coord* x, Coord* y, int count, Graphic* gr =nil);

    Graphic* Copy();
    void SetPattern(PPattern*);
    PPattern* GetPattern();
    void SetBrush(PBrush*);
    PBrush* GetBrush();
};

#endif
