/*
 * Object association table.
 */

#ifndef table_h
#define table_h

#include <InterViews/defs.h>

typedef void* TableKey;
typedef void* TableValue;

class TableEntry;

class Table {
public:
    Table(int);
    ~Table();

    /* default is to use a pointer value as key */
    void Insert(TableKey, TableValue);
    boolean Find(TableValue&, TableKey);
    void Remove(TableKey);

    /* integer key */
    void Insert(int, TableValue);
    boolean Find(TableValue&, int);
    void Remove(int);

    /* unsigned integer key */
    void Insert(unsigned int, TableValue);
    boolean Find(TableValue&, unsigned int);
    void Remove(unsigned int);

    /* unsigned long key */
    void Insert(unsigned long, TableValue);
    boolean Find(TableValue&, unsigned long);
    void Remove(unsigned long);
private:
    int size;
    TableEntry** first;
    TableEntry** last;

    TableEntry* Probe(TableKey);
    TableEntry** ProbeAddr(TableKey);
};

/*
 * Integer keys are implemented by casting to pointers.
 */

inline void Table::Insert (int i, TableValue v) {
    Insert((TableKey)i, v);
}

inline boolean Table::Find (TableValue& v, int i) {
    return Find(v, (TableKey)i);
}

inline void Table::Remove (int i) {
    Remove((TableKey)i);
}

/*
 * Unsigned integer keys are implemented by casting to pointers.
 */

inline void Table::Insert (unsigned int i, TableValue v) {
    Insert((TableKey)i, v);
}

inline boolean Table::Find (TableValue& v, unsigned int i) {
    return Find(v, (TableKey)i);
}

inline void Table::Remove (unsigned int i) {
    Remove((TableKey)i);
}

/*
 * Unsigned long keys are implemented by casting to pointers.
 */

inline void Table::Insert (unsigned long i, TableValue v) {
    Insert((TableKey)i, v);
}

inline boolean Table::Find (TableValue& v, unsigned long i) {
    return Find(v, (TableKey)i);
}

inline void Table::Remove (unsigned long i) {
    Remove((TableKey)i);
}

#endif
