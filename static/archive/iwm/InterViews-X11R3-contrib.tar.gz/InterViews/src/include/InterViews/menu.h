/*
 * A menu is a list of items to select from using the mouse.
 */

#ifndef menu_h
#define menu_h

#include <InterViews/scene.h>

class Menu : public MonoScene {
public:
    Menu(boolean persistent = true);
    Menu(const char*, boolean persistent = true);
    Menu(Sensor*, Painter*, boolean persistent = true);
    void Compose();
    void GetSelection (Interactor*& i) { i = cur; }
    void Handle(Event&);
    void Popup(Event&, Interactor*&);
protected:
    Scene* layout;
    Interactor* cur;
    Coord xoff, yoff;

    void DoInsert(Interactor*, boolean, Coord&, Coord&);
private:
    boolean persistent;

    void Init();
    void Reconfig();
};

class HMenu : public Menu {
public:
    HMenu(boolean persistent = true);
    HMenu(const char*, boolean persistent = true);
    HMenu(Sensor*, Painter*, boolean persistent = true);
private:
    void Init();
};

class VMenu : public Menu {
public:
    VMenu(boolean persistent = true);
    VMenu(const char*, boolean persistent = true);
    VMenu(Sensor*, Painter*, boolean persistent = true);
private:
    void Init();
};

/*
 * A menu item is an interactor that highlights itself when
 * it gets focus, and unhighlights itself when it loses focus.
 */

class MenuItem : public Interactor {
public:
    int tag;

    MenuItem(int = 0);
    MenuItem(const char*, int = 0);
    MenuItem(Painter*, int = 0);
    void Handle(Event&);
    virtual void Highlight();
    virtual void UnHighlight();
protected:
    Painter* highlight;
    Painter* normal;

    void Delete();
    void Reconfig();
private:
    void Init(int);
};

class TextItem : public MenuItem {
public:
    TextItem(const char*, int = 0);
    TextItem(const char*, const char*, int = 0);
    TextItem(Painter*, const char*, int = 0);
private:
    const char* text;

    void Init(const char*);
    void Reconfig();
    void Redraw(Coord, Coord, Coord, Coord);
};

#endif
