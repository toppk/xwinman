/*
 * Interface to Rects and Polygons, objects derived from Graphic.
 */

#ifndef polygons_h
#define polygons_h

#include "lines.h"

class Rect : public Graphic {
protected:
    Ref patbr;
    Coord x0, y0, x1, y1;

    boolean read(File*);
    boolean write(File*);

    void getExtent(float&, float&, float&, float&, float&, Graphic*);
    boolean contains(PointObj&, Graphic*);
    boolean intersects(BoxObj&, Graphic*);
    void draw(Canvas*, Graphic*);
public:
    ClassId GetClassId();
    boolean IsA(ClassId);

    Rect();
    Rect(Coord x0, Coord y0, Coord x1, Coord y1, Graphic* gr =nil);

    Graphic* Copy();
    void GetOriginal(Coord&, Coord&, Coord&, Coord&);

    void SetBrush(PBrush*);
    PBrush* GetBrush();
};

class FillRect : public Rect {
protected:
    void getExtent(float&, float&, float&, float&, float&, Graphic*);
    boolean contains(PointObj&, Graphic*);
    boolean intersects(BoxObj&, Graphic*);
    void draw(Canvas*, Graphic*);
public:
    ClassId GetClassId();
    boolean IsA(ClassId);

    FillRect();
    FillRect(Coord x0, Coord y0, Coord x1, Coord y1, Graphic* gr =nil);

    Graphic* Copy();
    void SetPattern(PPattern*);
    PPattern* GetPattern();
    void SetBrush(PBrush*);
    PBrush* GetBrush();
};

class Polygon : public MultiLine {
protected:
    boolean contains(PointObj&, Graphic*);
    boolean intersects(BoxObj&, Graphic*);
    void draw(Canvas*, Graphic*);
public:
    ClassId GetClassId();
    boolean IsA(ClassId);

    Polygon();
    Polygon(Coord* x, Coord* y, int count, Graphic* gr =nil);

    Graphic* Copy();
};

class FillPolygon : public Polygon {
protected:
    void getExtent(float&, float&, float&, float&, float&, Graphic*);
    boolean contains(PointObj&, Graphic*);
    boolean intersects(BoxObj&, Graphic*);
    void draw(Canvas*, Graphic*);
public:
    ClassId GetClassId();
    boolean IsA(ClassId);

    FillPolygon();
    FillPolygon(Coord* x, Coord* y, int count, Graphic* gr =nil);

    Graphic* Copy();
    void SetPattern(PPattern*);
    PPattern* GetPattern();
    void SetBrush(PBrush*);
    PBrush* GetBrush();
};

#endif
