/*
 * Interface to Label, an object derived from Graphic.
 */

#ifndef label_h
#define label_h

#include "base.h"

class Label : public Graphic {
    Ref font;
protected:
    char* string;
    int count;
    boolean read(File*);
    boolean write(File*);

    void getExtent(float&, float&, float&, float&, float&, Graphic*);
    boolean contains(PointObj&, Graphic*);
    boolean intersects(BoxObj&, Graphic*);
    void draw(Canvas*, Graphic*);
public:
    ClassId GetClassId();
    boolean IsA(ClassId);

    Label();
    Label(const char* string, Graphic* pict =nil);
    Label(const char* string, int count, Graphic* pict =nil);

    Graphic* Copy();
    void Delete();
    void GetOriginal(char*&, int&);

    void SetFont(PFont*);
    PFont* GetFont();
};

#endif
