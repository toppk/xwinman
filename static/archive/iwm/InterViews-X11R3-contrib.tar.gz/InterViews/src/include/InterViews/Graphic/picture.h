/*
 * Interface to Picture, a composite of one or more Graphics.
 */

#ifndef picture_h
#define picture_h

#include "base.h"

class Picture : public FullGraphic {
    Extent* extent;
    void setParent(Graphic*);
    void unsetParent(Graphic*);
protected:
    RefList* refList, *cur;
    Graphic* getGraphic(RefList* r) { return (Graphic*) (*r)(); }

    boolean read(File*);
    boolean write(File*);
    boolean readObjects(File*);
    boolean writeObjects(File*);
    
    boolean extentCached();
    void cacheExtent(float, float, float, float, float);
    void uncacheExtent();
    void uncacheChildren();
    void getCachedExtent(float&, float&, float&, float&, float&);

    void getExtent(float&, float&, float&, float&, float&, Graphic*);
    boolean contains(PointObj&, Graphic*);
    boolean intersects(BoxObj&, Graphic*);
    void draw(Canvas*, Graphic*);
    void drawClipped(Canvas*, Coord, Coord, Coord, Coord, Graphic*);
public:
    ClassId GetClassId();
    boolean IsA(ClassId);

    Picture(Graphic* gr =nil);
    Graphic* Copy();
    void Delete();

    void Append(Graphic*, Graphic* =nil, Graphic* =nil, Graphic* =nil);
    void Prepend(Graphic*, Graphic* =nil, Graphic* =nil, Graphic* =nil);
    void InsertAfterCur(Graphic*, Graphic* =nil, Graphic* =nil, Graphic* =nil);
    void InsertBeforeCur(Graphic*, Graphic* =nil, Graphic* =nil,Graphic* =nil);
    void Remove(Graphic* p);
    void RemoveCur();
    void SetCurrent(Graphic* p);
    Graphic* GetCurrent () { return getGraphic(cur); }
    Graphic* First();
    Graphic* Last();
    Graphic* Next();
    Graphic* Prev();
    boolean IsEmpty () { return refList->IsEmpty(); }
    boolean AtEnd () { return cur == refList; }

    Graphic* FirstGraphicContaining(PointObj&);
    Graphic* LastGraphicContaining(PointObj&);
    int GraphicsContaining(PointObj&, Graphic**&);

    Graphic* FirstGraphicIntersecting(BoxObj&);
    Graphic* LastGraphicIntersecting(BoxObj&);
    int GraphicsIntersecting(BoxObj&, Graphic**&);

    Graphic* FirstGraphicWithin(BoxObj&);
    Graphic* LastGraphicWithin(BoxObj&);
    int GraphicsWithin(BoxObj&, Graphic**&);

    boolean HasChildren();
    void Propagate();
};

#endif
