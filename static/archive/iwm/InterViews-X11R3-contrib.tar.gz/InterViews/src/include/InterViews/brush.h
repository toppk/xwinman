/*
 * A brush specifies how lines should be drawn.
 */

#ifndef brush_h
#define brush_h

#include <InterViews/resource.h>

class Brush : public Resource {
public:
    Brush(int p, int w = 1);
    ~Brush();
    int Width();
private:
    friend class Painter;
    friend class PainterRep;

    int width;
    void* info;
};

inline int Brush::Width () { return width; }

extern Brush* single;

#endif
