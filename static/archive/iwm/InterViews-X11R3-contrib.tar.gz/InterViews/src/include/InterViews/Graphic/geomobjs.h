/*
 * Interface to geometrical objects used to implement Graphic primitives.
 */

#ifndef geomobjs_h
#define geomobjs_h

#include "file.h"
#include "classes.h"
#include "objman.h"
#include "persistent.h"
#include "ref.h"
#include "reflist.h"
#include "util.h"
#include <math.h>
#include <InterViews/defs.h>

class PointObj : public Persistent {
protected:
    boolean read(File*);
    boolean write(File*);
public:
    ClassId GetClassId();
    boolean IsA(ClassId);

    Coord x, y;
    PointObj(Coord x =0, Coord y =0) { this->x = x; this->y = y; }
    PointObj(PointObj* p) { x = p->x; y = p->y; }

    float Distance(PointObj& p)
	{ return sqrt(float(square(x - p.x) + square(y - p.y))); }
};

class LineObj : public Persistent {
protected:
    boolean read(File*);
    boolean write(File*);
public:
    ClassId GetClassId();
    boolean IsA(ClassId);

    PointObj p1, p2;
    LineObj();
    LineObj(Coord x0, Coord y0, Coord x1, Coord y1)
        { p1.x = x0; p1.y = y0; p2.x = x1; p2.y = y1; }
    LineObj(LineObj* l)
        { p1.x = l->p1.x; p1.y = l->p1.y; p2.x = l->p2.x; p2.y = l->p2.y; }

    boolean Contains(PointObj&);
    int Same(PointObj& p1, PointObj& p2);
    boolean Intersects(LineObj&);
};

class BoxObj : public Persistent {
protected:
    boolean read(File*);
    boolean write(File*);
public:
    ClassId GetClassId();
    boolean IsA(ClassId);

    Coord left, right;
    Coord bottom, top;
    BoxObj(Coord x0 =0, Coord y0 =0, Coord x1 =0, Coord y1 =0) {
	left = min(x0, x1); bottom = min(y0, y1); 
	right = max(x0, x1); top = max(y0, y1);
    }
    BoxObj(BoxObj* b)
        { left = b->left; bottom = b->bottom; right = b->right; top = b->top; }

    boolean Contains(PointObj&);
    boolean Intersects(BoxObj&);
    boolean Intersects(LineObj&);
    BoxObj operator-(BoxObj&);
    BoxObj operator+(BoxObj&);
    boolean Within(BoxObj&);
};

class MultiLineObj : public Persistent {
protected:
    void GrowBuf();
    boolean CanApproxWithLine(
	double x0, double y0, double x2, double y2, double x3, double y3
    );
    void AddLine(double x0, double y0, double x1, double y1);
    void AddBezierArc(
        double x0, double y0, double x1, double y1,
        double x2, double y2, double x3, double y3
    );
    void CalcSection(
	Coord cminus1x, Coord cminus1y, Coord cx, Coord cy,
	Coord cplus1x, Coord cplus1y, Coord cplus2x, Coord cplus2y
    );
    void CreateMultiLine(Coord* cpx, Coord* cpy, int cpcount);

    boolean read(File*);
    boolean write(File*);
public:
    ClassId GetClassId();
    boolean IsA(ClassId);

    Coord* x, *y;
    int count;
    MultiLineObj(Coord* x =nil, Coord* y =nil, int n =0)
        { this->x = x; this->y = y; count = n; }

    void GetBox(BoxObj& b);
    boolean Contains(PointObj&);
    boolean Intersects(LineObj&);
    boolean Intersects(BoxObj&);
    boolean Within(BoxObj&);
    void SplineToMultiLine(Coord* cpx, Coord* cpy, int cpcount);
    void ClosedSplineToPolygon(Coord* cpx, Coord* cpy, int cpcount);
};

class FillPolygonObj : public MultiLineObj {
protected:
    Coord* normx, *normy;
    int normCount;
    int LowestLeft(Coord*, Coord*, int);
    void Normalize();
public:
    ClassId GetClassId();
    boolean IsA(ClassId id);

    FillPolygonObj(Coord* x =nil, Coord* y =nil, int n =0) : (x, y, n)
	{ Normalize(); }

    void Delete();
    boolean Contains(PointObj&);
    boolean Intersects(LineObj&);
    boolean Intersects(BoxObj&);
};

class Extent {
    /* defines lower left and center of an object */
public:
    float left, bottom, cx, cy, tol;

    Extent(float x0 =0, float y0 =0, float x1 =0, float y1 =0, float t =0) {
	left = x0; bottom = y0; cx = x1; cy = y1; tol = t;
    }
    Extent(Extent& e) {
	left = e.left; bottom = e.bottom; cx = e.cx; cy = e.cy; tol = e.tol;
    }
    boolean Undefined() { return left == cx && bottom == cy; }
    boolean Within(Extent& e);
    void Merge(Extent&);
};

#endif
