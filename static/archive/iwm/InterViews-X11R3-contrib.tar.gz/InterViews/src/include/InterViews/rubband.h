/*
 * Rubber - rubberbanding graphical objects
 */

#ifndef rubband_h
#define rubband_h

#include <InterViews/defs.h>
#include <InterViews/resource.h>

enum Side { LeftSide, RightSide, BottomSide, TopSide };

class Rubberband : public Resource {
protected:
    class Painter* output;
    class Canvas* canvas;
    boolean drawn;
    Coord trackx, offx;
    Coord tracky, offy;
    float Angle(Coord, Coord, Coord, Coord);	// angle line makes w/horiz
    float Distance(Coord, Coord, Coord, Coord); // distance between 2 points
public:
    Rubberband(Painter*, Canvas*, Coord offx, Coord offy);
    virtual void Draw();
    void Redraw();
    virtual void Erase();
    virtual void Track(Coord x, Coord y);
    virtual void Delete();
    ~Rubberband();

    virtual void SetPainter(Painter*);
    virtual void SetCanvas(Canvas*);
    Painter* GetPainter() { return output; }
    Canvas* GetCanvas() { return canvas; }
};

#endif
