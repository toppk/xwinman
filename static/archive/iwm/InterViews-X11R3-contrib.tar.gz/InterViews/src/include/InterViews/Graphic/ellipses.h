/*
 * Interface to Ellipses and Circles, objects derived from Graphic.
 */

#ifndef ellipses_h
#define ellipses_h

#include "base.h"

class Ellipse : public Graphic {
protected:
    Ref patbr;
    Coord x0, y0;
    int r1, r2;

    boolean read(File*);
    boolean write(File*);

    void getExtent(float&, float&, float&, float&, float&, Graphic*);
    boolean contains(PointObj&, Graphic*);
    boolean intersects(BoxObj&, Graphic*);
    void draw(Canvas*, Graphic*);
public:
    ClassId GetClassId();
    boolean IsA(ClassId);

    Ellipse();
    Ellipse(Coord x0, Coord y0, int r1, int r2, Graphic* gr =nil);
    
    Graphic* Copy();
    void Delete();
    void GetOriginal(Coord&, Coord&, int&, int&);

    void SetBrush(PBrush*);
    PBrush* GetBrush();
};

class FillEllipse : public Ellipse {
protected:
    void getExtent(float&, float&, float&, float&, float&, Graphic*);
    boolean contains(PointObj&, Graphic*);
    boolean intersects(BoxObj&, Graphic*);
    void draw(Canvas*, Graphic*);
public:
    ClassId GetClassId();
    boolean IsA(ClassId);

    FillEllipse();
    FillEllipse(Coord x0, Coord y0, int r1, int r2, Graphic* gr =nil);

    Graphic* Copy();
    void SetPattern(PPattern*);
    PPattern* GetPattern();
    void SetBrush(PBrush*);
    PBrush* GetBrush();
};

class Circle : public Ellipse {
public:
    ClassId GetClassId();
    boolean IsA(ClassId);

    Circle();
    Circle(Coord x0, Coord y0, int radius, Graphic* gr =nil);

    Graphic* Copy();
};

class FillCircle : public FillEllipse {
public:
    ClassId GetClassId();
    boolean IsA(ClassId);

    FillCircle();
    FillCircle(Coord x0, Coord y0, int radius, Graphic* gr =nil);

    Graphic* Copy();
};

#endif
