#ifndef Xutil_h
#define Xutil_h

#include <InterViews/X11/Xlib.h>

#define class cc_class
#define new cc_new
#define delete cc_delete
#define virtual cc_virtual

#define XSaveContext cc_XSaveContext
#define XFindContext cc_XFindContext
#define XDeleteContext cc_XDeleteContext
#define XGetWMHints cc_XGetWMHints
#define XCreateRegion cc_XCreateRegion
#define XPolygonRegion cc_XPolygonRegion
#define XCreateImage cc_XCreateImage
#define XGetVisualInfo cc_XGetVisualInfo

#define Colormap XColormap

#include <X11/Xutil.h>

#undef Colormap

#undef XSaveContext
#undef XFindContext
#undef XDeleteContext
#undef XGetWMHints
#undef XCreateRegion
#undef XPolygonRegion
#undef XCreateImage
#undef XGetVisualInfo

#undef class
#undef new
#undef delete
#undef virtual

void XGetSizeHints(Display*, Window, XSizeHints&, Atom);
void XSetSizeHints(Display*, Window, XSizeHints&, Atom);

int XSaveContext(Window, XContext, const void*);
int XFindContext(Display*, Window, XContext, void*&);
int XDeleteContext(Window, XContext);

unsigned XParseGeometry(char*, Coord&, Coord&, int&, int&);

void XSetWMHints(Display*, Window, XWMHints&);
XWMHints* XGetWMHints(Display*, Window);
boolean XGetTransientForHint(Display*, Window, Window&);

Region XCreateRegion(), XPolygonRegion();

XImage* XCreateImage(
    Display*, Visual*, int depth, int format, int offset,
    void* data, int width, int height, int bitpad, int bytes_per_line
);
void XPutImage(
    Display*, Drawable, GC, XImage*, int srcx, int srcy,
    int dstx, int dsty, unsigned int width, unsigned int height
);
void XGetImage(
    Display*, Drawable, GC, XImage*, int srcx, int srcy,
    int dstx, int dsty, unsigned int width, unsigned int height,
    unsigned long, int format
);

#endif
