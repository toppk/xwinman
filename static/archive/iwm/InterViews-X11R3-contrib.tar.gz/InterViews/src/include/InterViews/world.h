/*
 * Root scene for a display.
 */

#ifndef world_h
#define world_h

#include <InterViews/scene.h>

/*
 * ParseGeometry return values contains one or more of these bits set.
 */

#define GeomNoValue 0x00
#define GeomXValue 0x01
#define GeomYValue 0x02
#define GeomWidthValue 0x04
#define GeomHeightValue 0x08
#define GeomAllValues 0x0F
#define GeomXNegative 0x10
#define GeomYNegative 0x20

class PropertyData {
public:
    const char* path;
    const char* value;
    const char* type;
};

typedef enum {
    OptionValueNext,		/* argv[i+1] */
    OptionValueImplicit,	/* OptionDesc.value */
    OptionValueIsArg,		/* argv[i] */
    OptionValueAfter		/* &argv[i][strlen(OptionDesc.name)] */
} OptionStyle;

class OptionDesc {
public:
    const char* name;
    const char* path;
    OptionStyle style;
    const char* value;
};

class World : public Scene {
public:
    World(const char*, int& argc, char* argv[]);
    World(const char*, OptionDesc*, int& argc, char* argv[]);
    World(const char*, PropertyData*, OptionDesc*, int& argc, char* argv[]);
    World(const char* prog = nil, const char* device = nil);

    int Width();
    int Height();
    int NPlanes();
    int NButtons();
    int PixelSize();
    Coord InvMapX(Coord);
    Coord InvMapY(Coord);

    /* obsolete -- use Interactor::GetAttribute */
    const char* GetDefault(const char*);
    const char* GetGlobalDefault(const char*);

    /* returns bitset of Geom... flags */
    unsigned int ParseGeometry(char*, Coord& x, Coord& y, int& w, int& h);

    void RingBell(int);
    void SetKeyClick(int);
    void SetAutoRepeat(boolean);
    void SetFeedback(int thresh, int scale);

    void SetCurrent();
    void SetRoot(void*);
    void SetScreen(int);
    int Fileno();
protected:
    void Delete();
    void DoInsert(Interactor*, boolean, Coord& x, Coord& y);
    void DoChange(Interactor*);
    void DoRemove(Interactor*);
private:
    class WorldRep* rep;

    void FinishInsert(Interactor*);
    unsigned int GetGeometry(Interactor*, Coord& x, Coord& y, int& w, int& h);
    void Init(const char* device);
    void FinishInit(const char* name);
    void LoadUserDefaults();
    void ParseArgs(int&, char*[], OptionDesc[]);
    void Setup(const char* name);
    const char* UserDefaults();
};

#endif
