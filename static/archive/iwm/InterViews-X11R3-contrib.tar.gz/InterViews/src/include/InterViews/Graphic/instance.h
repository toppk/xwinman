/*
 * Interface to Instance, a Graphic that refers to another Graphic.
 */

#ifndef instance_h
#define instance_h

#include "base.h"

class Instance : public FullGraphic {
protected:
    Ref refGr;
    Graphic* getGraphic() { return (Graphic*) refGr(); }

    boolean read(File*);
    boolean write(File*);

    void getExtent(float&, float&, float&, float&, float&, Graphic*);
    boolean contains(PointObj&, Graphic*);
    boolean intersects(BoxObj&, Graphic*);
    void draw(Canvas*, Graphic*);
    void drawClipped(Canvas*, Coord, Coord, Coord, Coord, Graphic*);
public:
    ClassId GetClassId();
    boolean IsA(ClassId);

    Instance(Graphic* obj =nil, Graphic* gr =nil);

    Graphic* Copy();
    void GetOriginal(Graphic*&);
};

#endif
