/*
 * A color is defined by rgb intensities and usually accessed by name.
 */

#ifndef color_h
#define color_h

#include <InterViews/resource.h>

/*
 * Color intensity should be subrange 0..65535, but for compatibility
 * reasons it is an integer.
 */
typedef int ColorIntensity;

class Color : public Resource {
public:
    Color(ColorIntensity r, ColorIntensity g, ColorIntensity b);
    Color(int index, ColorIntensity r, ColorIntensity g, ColorIntensity b);
    Color(int index);
    Color(const char*);
    Color(const char*, int);
    ~Color();
    void Intensities(ColorIntensity& r, ColorIntensity& g, ColorIntensity& b);
    int PixelValue();
    boolean Valid();
protected:
    friend class Painter;

    int pixel;
    unsigned short red, green, blue;
    boolean allocated;

    void GetColorByName(const char*);
};

extern Color* black;
extern Color* white;

inline void Color::Intensities (
    ColorIntensity& r, ColorIntensity& g, ColorIntensity& b
) {
    r = red; g = green; b = blue;
}

inline int Color::PixelValue () { return pixel; }

#endif
