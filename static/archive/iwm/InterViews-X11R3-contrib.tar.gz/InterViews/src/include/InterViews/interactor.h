/*
 * Base class for interactive objects.
 */

#ifndef interactor_h
#define interactor_h

#include <InterViews/defs.h>

extern class Sensor* stdsensor;		/* default input */
extern class Painter* stdpaint;		/* default output */

enum CanvasType {
    CanvasShapeOnly, CanvasInputOnly, CanvasInputOutput,
    CanvasSaveUnder, CanvasSaveContents, CanvasSaveBoth
};

class Canvas;
class Cursor;
class Event;
class Perspective;
class Scene;
class Shape;
class StringId;
class TopLevel;

class Interactor {
public:
    Interactor();
    Interactor(const char*);
    ~Interactor();

    /* configuration */
    void Align(Alignment, Coord& x, Coord& y);
    void Config(Scene* = nil);
    virtual void Reconfig();
    const char* GetAttribute(const char*);
    virtual void Reshape(Shape&);
    Shape* GetShape();
    void SetCursor(Cursor*);
    Cursor* GetCursor();
    const char* GetClassName();
    const char* GetInstance();

    /* traversing hierarchy */
    virtual void GetComponents(Interactor**, int, Interactor**&, int&);
    void GetRelative(Coord& x, Coord &y, Interactor* = nil);
    Scene* Parent();
    Scene* Root();

    /* output */
    virtual void Draw();

    /* input events */
    boolean Check();
    int CheckQueue();
    void Flush();
    virtual void Handle(Event&);
    void Listen(Sensor*);
    void Poll(Event&);
    void Read(Event&);
    void Run();
    void Sync();
    void UnRead(Event&);

    /* subject-view communication */
    virtual void Adjust(Perspective&);
    Perspective* GetPerspective();
    virtual void Update();

    /* top-level windows */
    void DeIconify();
    CanvasType GetCanvasType();
    Interactor* GetIcon();
    const char* GetName();
    void Iconify();
    void SetIcon(Interactor*);
    void SetName(const char*);
    void SetCanvasType(CanvasType);
protected:
    Shape* shape;			/* desired shape characteristics */
    Canvas* canvas;			/* actual display area */
    Perspective* perspective;		/* portion displayed */
    Coord xmax;				/* canvas->Width() - 1 */
    Coord ymax;				/* canvas->Height() - 1 */
    Sensor* input;			/* normal input event interest */
    Painter* output;			/* normal output parameters */

    Interactor(Sensor*, Painter*);	/* old-fashioned constructor */

    virtual void Delete();
    boolean IsMapped();
    virtual void Redraw(Coord left, Coord bottom, Coord right, Coord top);
    virtual void RedrawList(int n, Coord[], Coord[], Coord[], Coord[]);
    virtual void Resize();
    void RootConfig(const char*, const char*);
    void SetClassName(const char*);
    void SetInstance(const char*);
private:
    friend class Scene;
    friend class Canvas;

    Scene* parent;			/* where inserted */
    StringId* classname;		/* class for attributes */
    StringId* instance;			/* instance for attributes */
    TopLevel* toplevel;			/* top-level interactor parameters */
    Coord left;				/* relative to parent */
    Coord bottom;			/* relative to parent */
    Sensor* cursensor;			/* current input interest */

    void DefaultConfig(boolean&);
    void DoConfig(boolean);
    void DoSetCursor(Cursor*);
    void DoSetIcon(Interactor*);
    void DoSetName(const char*);
    int Fileno();
    boolean GetEvent(Event&, boolean);
    void Init();
    boolean PrevEvent(Event&);
    boolean Select(Event&);
    void SendRedraw(Coord x, Coord y, int width, int height, int count);
    void SendResize(Coord x, Coord y, int width, int height);
};

inline Scene* Interactor::Parent () { return parent; }
inline Perspective* Interactor::GetPerspective () { return perspective; }
inline Shape* Interactor::GetShape () { return shape; }

#endif
