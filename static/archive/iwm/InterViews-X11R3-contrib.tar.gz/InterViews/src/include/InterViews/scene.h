/*
 * Basic composite object for interaction.
 */

#ifndef scene_h
#define scene_h

#include <InterViews/interactor.h>

class Scene : public Interactor {
public:
    void Change(Interactor* = nil);
    void Insert(Interactor*);
    void Insert(Interactor*, Coord x, Coord y, Alignment = BottomLeft);
    void Lower(Interactor*);
    void Move(Interactor*, Coord x, Coord y, Alignment = BottomLeft);
    void Propagate(boolean);
    void Raise(Interactor*);
    void Remove(Interactor*);
protected:
    boolean propagate;

    Scene();
    Scene(Sensor*, Painter*);
    virtual void DoChange(Interactor*);
    virtual void DoInsert(Interactor*, boolean, Coord& x, Coord& y);
    virtual void DoMove(Interactor*, Coord& x, Coord& y);
    virtual void DoRemove(Interactor*);
    void Map(Interactor*, boolean raised = true);
    void Place(Interactor*, Coord, Coord, Coord, Coord, boolean map = true);
    void PrepareToInsert(Interactor*);
    void Unmap(Interactor*);
    void UserPlace(Interactor*);
    virtual Interactor* Wrap(Interactor*);
private:
    void Assign(Interactor*, Coord x, Coord y, int w, int h);
    void DoAlign(Interactor*, Alignment, Coord& x, Coord& y);
    void DoMap(Interactor*);
    void InitCanvas(Interactor*);
    void MakeWindow(Interactor*, Coord x, Coord y, int w, int h, boolean);
    void Orphan(Interactor*);
};

/* Scene with a single component */
class MonoScene : public Scene {
public:
    MonoScene();
    MonoScene(Sensor*, Painter*);
    void Draw();
    void GetComponents(Interactor**, int, Interactor**&, int&);
    void Resize();
protected:
    Interactor* component;

    void Delete();
    virtual void DoChange(Interactor*);
    virtual void DoInsert(Interactor*, boolean, Coord&, Coord&);
    virtual void DoRemove(Interactor*);
    void Reconfig();
};

#endif
