/*
 * Bitmap - a single plane of image data
 */

#ifndef bitmap_h
#define bitmap_h

#include <InterViews/defs.h>
#include <InterViews/resource.h>

class Bitmap : public Resource {
public:
    Bitmap(const char* filename);		/* bitmap(1) file */
    Bitmap(void*, int width, int height);	/* raw data */
    Bitmap(Bitmap*);				/* duplicate */
    ~Bitmap();

    void Draw(class Canvas*);

    int Width();
    int Height();

    void SetColors(class Color* f, Color* b);
    Color* GetFgColor();
    Color* GetBgColor();

    void Transform(class Transformer*);
    void Scale(float x, float y);
    void Rotate(float);

    void SetOrigin(int x0, int y0);
    void GetOrigin(int& x0, int& y0);

    void FlipHorizontal();
    void FlipVertical();
    void Rotate90();

    void Invert();
    boolean Peek(int x, int y);
    void Poke(boolean bit, int x, int y);
private:
    char* data;
    int width, height;
    Coord x0, y0;
    Color* foreground;
    Color* background;

    void* bitmap;
    void* pixmap;

    void Init();
    void FreePixmap();
    void FreeMaps();
    boolean Valid(int x, int y);
    int Size(int w, int h);
    int Index(int x, int y);
    int Bit(int x, int y);
    void SetBit(int x, int y);
    void ClearBit(int x, int y);
    boolean BitIsSet(int x, int y);
};

inline int Bitmap::Width () { return width; }
inline int Bitmap::Height () { return height; }
inline Color* Bitmap::GetFgColor () { return foreground; }
inline Color* Bitmap::GetBgColor () { return background; }

#endif
