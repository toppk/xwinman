/*
 * Interface to Points, Lines, and MultiLines, objects derived from Graphic.
 */

#ifndef lines_h
#define lines_h

#include "base.h"

class Point : public Graphic {
    Ref brush;
protected:
    Coord x, y;

    boolean read(File*);
    boolean write(File*);

    void getExtent(float&, float&, float&, float&, float&, Graphic*);
    boolean contains(PointObj&, Graphic*);
    boolean intersects(BoxObj&, Graphic*);
    void draw(Canvas*, Graphic*);
public:
    ClassId GetClassId();
    boolean IsA(ClassId);

    Point();
    Point(Coord x, Coord y, Graphic* gr =nil);

    Graphic* Copy();
    void GetOriginal(Coord&, Coord&);

    void SetBrush(PBrush*);
    PBrush* GetBrush();
};

class Line : public Graphic {
    Ref brush;
protected:
    Coord x0, y0, x1, y1;

    boolean read(File*);
    boolean write(File*);

    void getExtent(float&, float&, float&, float&, float&, Graphic*);
    boolean contains(PointObj&, Graphic*);
    boolean intersects(BoxObj&, Graphic*);
    void draw(Canvas*, Graphic*);
public:
    ClassId GetClassId();
    boolean IsA(ClassId);

    Line();
    Line(Coord x0, Coord y0, Coord x1, Coord y1, Graphic* gr =nil);

    Graphic* Copy();
    void GetOriginal(Coord& x0, Coord& y0, Coord& x1, Coord& y1);

    void SetBrush(PBrush*);
    PBrush* GetBrush();
};

class MultiLine : public Graphic {
    Extent* extent;
protected:
    Ref patbr;
    Coord* x, *y;
    int count;

    boolean read(File*);
    boolean write(File*);

    boolean extentCached();
    void cacheExtent(float, float, float, float, float);
    void uncacheExtent();
    void getCachedExtent(float&, float&, float&, float&, float&);
    void getExtent(float&, float&, float&, float&, float&, Graphic*);
    boolean contains(PointObj&, Graphic*);
    boolean intersects(BoxObj&, Graphic*);
    void draw(Canvas*, Graphic*);
public:
    ClassId GetClassId();
    boolean IsA(ClassId);

    MultiLine();
    MultiLine(Coord* x, Coord* y, int count, Graphic* gr =nil);

    Graphic* Copy();
    void Delete();
    void GetOriginal(Coord*& x, Coord*& y, int&);

    void SetBrush(PBrush*);
    PBrush* GetBrush();
};

#endif
