/*
 * A canvas is an area of graphics output.
 */

#ifndef canvas_h
#define canvas_h

#include <InterViews/defs.h>

typedef enum {
    CanvasMapped, CanvasUnmapped, CanvasOffscreen
} CanvasStatus;

class Canvas {
public:
    Canvas(int w, int h);
    Canvas(void*);
    ~Canvas();
    void* Id();
    int Width();
    int Height();
    void SetBackground(class Color*);
    void Clip(Coord, Coord, Coord, Coord);
    void NoClip();
    void ClipOn();
    void ClipOff();
    boolean IsClipped();
    void Map(Coord&, Coord&);
    CanvasStatus Status();
private:
    friend class Interactor;
    friend class Scene;
    friend class World;
    friend class WorldView;
    friend class Painter;
    friend class Image;		/* for Modula-2 idraw (going away) */

    void* id;
    CanvasStatus status;
    int width, height;
    class CanvasRep* rep;

    void WaitForCopy();
};

inline void* Canvas::Id () { return id; }
inline int Canvas::Width () { return width; }
inline int Canvas::Height () { return height; }
inline CanvasStatus Canvas::Status () { return status; }

#endif
