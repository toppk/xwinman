/*
 * An object stub interprets byte stream messages.
 * Stubs can be referenced from several other spaces;
 * therefore they must be reference-counted.
 */

#ifndef objectstub_h
#define objectstub_h

#include <allegro/defs.h>
#include <allegro/tag.h>

class ObjectStub {
    unsigned refcount;
public:
    ObjectStub();
    ~ObjectStub();
    void Reference () { ++refcount; }
    virtual void Message(
	class Connection* sender, ObjectTag, int op, void* msg, int len
    );
    virtual void ChannelReady(int);
    virtual ObjectStub* Clone();
    virtual void Delete();
};

#endif
