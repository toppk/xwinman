/*
 * A catalog is used to map names to objects.
 */

#ifndef catalog_h
#define catalog_h

#include <allegro/stub.h>

class Catalog {
    struct CatalogEntry {
	char* name;
	int len;
	ObjectStub* obj;
	CatalogEntry* chain;
    };

    int nelements;
    CatalogEntry** first;
    CatalogEntry** last;

    unsigned Hash(const char*, int&);
public:
    Catalog(int size);
    ~Catalog();
    void Register(const char*, ObjectStub*);
    void UnRegister(const char*);
    boolean Find(ObjectStub*&, const char*);
};

#endif
