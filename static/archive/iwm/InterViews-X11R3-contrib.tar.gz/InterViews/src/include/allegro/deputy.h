/*
 * Deputy objects perform operations on remote objects.
 */

#ifndef deputy_h
#define deputy_h

#include <allegro/tag.h>

class Deputy {
protected:
    class ChiefDeputy* chief;
    Deputy();
public:
    Deputy(ChiefDeputy*);
    ~Deputy();
    void Sync();
    ObjectTag Tag () { return (unsigned) this; }
    class Connection* GetServer();
};

#endif
