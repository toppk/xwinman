/*
 * An object table provides a mapping from tags to objects.
 */

#ifndef objecttable_h
#define objecttable_h

#include <allegro/stub.h>

class ObjectTableEntry {
    friend class ObjectTable;

    class Connection* client;
    ObjectTag id;
    ObjectStub* ref;
    ObjectTableEntry* chain;

    boolean Match(Connection*, ObjectTag);
};

class ObjectTable {
    int nelements;
    ObjectTableEntry** first;
    ObjectTableEntry** last;

    unsigned Hash(Connection*, ObjectTag);
    ObjectTableEntry* Start(Connection*, ObjectTag);
    ObjectTableEntry** StartAddr(Connection*, ObjectTag);
public:
    ObjectTable(int);
    ~ObjectTable();
    void Add(Connection*, ObjectTag, ObjectStub*);
    ObjectStub* Find(Connection*, ObjectTag);
    void Remove(Connection*, ObjectTag);
    void RemoveAll(Connection*);
};

#endif
