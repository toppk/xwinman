/*
 * Connections provide an interface to
 * the UNIX (or in general any) IPC mechanism.
 */

#ifndef connection_h
#define connection_h

#include <allegro/defs.h>

class Connection {
    int fd;
    int domain;
    const char* name;
    int port;

    boolean MakeSocket (struct sockaddr_in&);
    int MakeLocalSocket (struct sockaddr_un&);
public:
    Connection();
    Connection(int);
    ~Connection();
    void CreateService(const char* host, int port);
    void CreateLocalService(const char*);
    boolean OpenService(const char* host, int port);
    boolean OpenLocalService(const char*);
    Connection* AcceptClient();
    int Pending();
    int Read(void*, int);
    int Write(const void*, int);
    int WritePad(const void*, int, int);
    int Descriptor () { return fd; }
    void Close();
};

inline int WordAlign (int n) {
    return (n + sizeof(int) - 1) & ~(sizeof(int) - 1);
}

#endif
