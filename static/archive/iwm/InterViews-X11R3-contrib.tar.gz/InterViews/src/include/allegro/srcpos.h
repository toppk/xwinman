/*
 * Interface to editor by setting/getting the current source position.
 */

#ifndef srcpos_h

#include <allegro/defs.h>
#include <allegro/deputy.h>

class SourcePos : public Deputy {
public:
    virtual const char* Set();
    virtual const char* Get();
};

class TextSourcePos : public SourcePos {
    const char* freestring;
    const char* Connect();
public:
    TextSourcePos();

    const char* filename;
    int lineno;

    const char* Set();
    const char* Get();
};

static const char* const srcpos_name = "editserver.1";

static const int srcpos_Set = 101;
static const int srcpos_Get = 102;

#endif
