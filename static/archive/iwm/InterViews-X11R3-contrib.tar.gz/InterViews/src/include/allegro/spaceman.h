/*
 * Object space manager.
 */

#ifndef spaceman_h
#define spaceman_h

#include <allegro/defs.h>
#include <allegro/deputy.h>

class Connection;

class SpaceManager : public Deputy {
    char filename[128];
    char hostname[128];
public:
    SpaceManager();
    void Delete();
    void UsePath(const char*);
    void Register(const char*, Connection* local, Connection* remote);
    void UnRegister(const char*);
    Connection* Find(const char*, boolean wait = false);
};

extern const char*const spaceman_dir;
extern const char*const spaceman_mgr;
extern const char*const spaceman_name;

static const int spaceman_UsePath = 1;
static const int spaceman_Register = 2;
static const int spaceman_UnRegister = 3;
static const int spaceman_Find = 4;
static const int spaceman_WaitFor = 5;

#endif
