/*
 * A messenger handles requests for a particular client.
 */

#ifndef messenger_h
#define messenger_h

#include <allegro/defs.h>

typedef enum { ready, waiting, finished } MessengerState;

class Messenger {
    friend class ObjectSpace;

    ObjectSpace* space;
    class Connection* client;
    boolean pending;	/* buffer contains at least one complete packet */
    char* buffer;	/* buffer of incoming packets */
    int buflen;		/* length of buffer */
    int cur;		/* offset in buffer of current packet */
    int count;		/* number of bytes left in buffer */
    Messenger* next;	/* in dispatcher's list */
    Messenger* prev;

    MessengerState ReadData();
    boolean ProcessMessage();
    void GrowBuffer(int);
public:
    Messenger(ObjectSpace*, Connection*);
    ~Messenger();
    MessengerState Run();
    Connection* GetClient () { return client; }
    void SetPending () { pending = true; }
};

#endif
