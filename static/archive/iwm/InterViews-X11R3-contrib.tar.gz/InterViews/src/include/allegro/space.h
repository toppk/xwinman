/*
 * Object space definition.
 */

#ifndef objectspace_h
#define objectspace_h

#include <allegro/stub.h>

class ObjectSpace : public ObjectStub {
    struct MQueue {
	class Messenger* head, * tail;
    };
    struct Stream {
	int channel, mask;
	ObjectStub* object;
	Stream* next;
    };

    Connection* local;
    Connection* remote;
    class SpaceManager* manager;
    int channels;
    int maxchannel;
    MQueue active;
    MQueue inactive;
    Stream* streams;

    void Init();
    void Listen(Connection*);
    boolean Ready(int, Connection*);
    void CheckServer(int, Connection*);
    void CheckClients();
    void Add(Messenger*, MQueue&);
    void Remove(Messenger*, MQueue&);
    void CloseDown(Messenger*);
    virtual void AddClient(Connection*);
protected:
    const char* name;
    class Catalog* dictionary;
    class ObjectTable* table;

    ObjectSpace();
public:
    ObjectSpace(const char*);
    void Delete();
    void Attach(int);
    void Detach(int);
    void StartServer(Connection* local, Connection* remote);
    void Dispatch();
    void Message(Connection*, ObjectTag, int op, void*, int len);
    ObjectStub* Map(Connection*, ObjectTag);
    void Deliver(Connection*, ObjectTag, int op, void*, int);
    void AddChannel(int, ObjectStub*);
    void RemoveChannel(int);
};

/*
 * Protocol definitions.
 */

const int objectspace_Find = 1;
const int objectspace_Clone = 2;
const int objectspace_Destroy = 3;

struct objectspace_Msg {
    ObjectTag tag;
    char name[1];
    /* rest of name */
};

#endif
