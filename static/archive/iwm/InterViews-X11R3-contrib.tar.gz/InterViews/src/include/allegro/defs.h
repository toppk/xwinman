#ifndef defs_h
#define defs_h

typedef enum { false, true} boolean;

#define nil 0

inline int min (int a, int b) {
    return a < b ? a : b;
}

inline int max (int a, int b) {
    return a > b ? a : b;
}

#ifdef sun
/* need this for <CC/stdio.h> */
#define mc68k 1
#endif

#endif
