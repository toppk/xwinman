/*
 * Client management.
 */

#include <allegro/connection.h>
#include <allegro/errhandler.h>
#include <allegro/messenger.h>
#include <allegro/packet.h>
#include <allegro/space.h>
#include <allegro/table.h>
#include <allegro/stub.h>

extern int errno;
extern void bcopy(const void* src, void* dst, int);

/*
 * Initial and maximum allowed buffer sizes for a client.
 * A client's buffer grows when an incoming packet is larger than
 * the packet size.
 */

const int initlen = 256;
const int maxlen = 8192;

Messenger::Messenger (ObjectSpace* s, Connection* c) {
    space = s;
    client = c;
    pending = false;
    buffer = new char[initlen];
    buflen = initlen;
    cur = 0;
    count = 0;
    next = nil;
    prev = nil;
}

Messenger::~Messenger () {
    delete client;
    delete buffer;
}

/*
 * We have reached the head of the active queue, so try to read a message
 * into our buffer and split it into packets.
 */

MessengerState Messenger::Run () {
    if (ProcessMessage()) {
	return ready;
    } else if (pending) {
	return ReadData();
    } else {
	return waiting;
    }
}

/*
 * Read as much data as we can into the buffer.
 */

MessengerState Messenger::ReadData () {
    register int n, last;

    last = cur + count;
    if (last < 0 || last >= buflen) {
	Panic("invalid buffer index %d", last);
    }
    n = client->Read(&buffer[last], buflen - last);
    if (n > 0) {
	count += n;
	pending = false;
	return ready;
    } else {
	if (n < 0) {
	    Warning("error %d reading data", errno);
	}
	return finished;
    }
}

/*
 * Try to process a packet in the buffer.  If there isn't a complete one,
 * return false.  Otherwise handle the packet and return true.
 */

boolean Messenger::ProcessMessage () {
    boolean b;
    register Packet* h;
    register int len, hlen;

    if (cur < 0 || cur >= buflen) {
	Panic("invalid buffer index %d", cur);
    }
    if (count < sizeof(Packet)) {
	/* incomplete packet header in buffer */
	b = false;
    } else {
	h = (Packet*) &buffer[cur];
	hlen = WordAlign(h->length);
	len = sizeof(Packet) + hlen;
	if (hlen > maxlen) {
	    /* bad length, skip over header */
	    b = true;
	    Warning("bad message length %d", h->length);
	    cur += sizeof(Packet);
	    count -= sizeof(Packet);
	    if (count == 0) {
		cur = 0;
	    }
	} else if (count < len) {
	    /* incomplete packet */
	    b = false;
	    if (len > buflen) {
		GrowBuffer(len);
	    }
	} else {
	    b = true;
	    cur += sizeof(Packet);
	    space->Deliver(client, h->tag, h->op, &buffer[cur], h->length);
	    count -= len;
	    if (count == 0) {
		cur = 0;
	    } else {
		cur += hlen;
	    }
	}
    }
    if (!b && cur != 0) {
	/* move incomplete message to beginning of buffer */
	bcopy(&buffer[cur], &buffer[0], count);
	cur = 0;
    }
    return b;
}

/*
 * Grow the buffer to handle a larger message.
 */

void Messenger::GrowBuffer (int len) {
    char* overflow;

    overflow = new char[len];
    bcopy(&buffer[cur], &overflow[0], count);
    cur = 0;
    delete buffer;
    buffer = overflow;
    buflen = len;
}
