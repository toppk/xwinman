/*
 * Editor interface.
 */

#include <allegro/chief.h>
#include <allegro/srcpos.h>
#include <allegro/errhandler.h>
#include <allegro/spaceman.h>
#include <string.h>

extern const char* getenv(const char*);
extern int sprintf(char*, const char* ...);

const char* SourcePos::Set () {
    return "SourcePos::Set unimplemented";
}

const char* SourcePos::Get () {
    return "SourcePos::Get unimplemented";
}

TextSourcePos::TextSourcePos() {
    freestring	= nil;
    filename	= nil;
    lineno	= 0;
}

const char* TextSourcePos::Set () {
    int* msg;
    int n;

    delete freestring;
    if (chief == nil) {
	const char* status = Connect();
	if (status != nil) {
	    return status;
	}
    }
    n = strlen(filename);
    chief->Alloc(msg, chief->Tag(), srcpos_Set, sizeof(int) + n + 1);
    msg[0] = lineno;
    chief->PackString(filename, n, &msg[1]);
    chief->GetReply(&n, sizeof(n));
    if (n != 0) {
	chief->GetString(freestring, n);
    }
    return freestring;
}

const char* TextSourcePos::Get () {
    int r[2];

    delete freestring;
    if (chief == nil) {
	const char* status = Connect();
	if (status != nil) {
	    return status;
	}
    }
    chief->Msg(chief->Tag(), srcpos_Get);
    chief->GetReply(r, sizeof(r));
    if (r[0] == 0) {
	return "editor not available for Get";
    }
    lineno = r[0];
    chief->GetString(filename, r[1]);
			// ^ Potential storage leak
    return nil;
}

const char* TextSourcePos::Connect () {
    char buf[256];

    SpaceManager* m = new SpaceManager;
    const char* name = getenv("SRCPOS");
    if (name == nil) {
	sprintf(buf, "%s/%s", filename, srcpos_name);
	name = buf;
    }
    Connection* c = m->Find(name);
    delete m;
    if (c == nil) {
	return "can't find srcpos space";
    }
    chief = new ChiefDeputy(c);
    return nil;
}
