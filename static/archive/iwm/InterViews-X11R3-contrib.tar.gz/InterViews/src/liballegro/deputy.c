/*
 * Implementation of base deputy class.
 */

#include <allegro/deputy.h>
#include <allegro/chief.h>

Deputy::Deputy () {
    chief = nil;
}

Deputy::Deputy (ChiefDeputy* c) {
    chief = c;
}

Deputy::~Deputy () {
    /* nothing to do yet */
}

void Deputy::Sync () {
    chief->Sync();
}

Connection* Deputy::GetServer () {
    return chief->GetServer();
}
