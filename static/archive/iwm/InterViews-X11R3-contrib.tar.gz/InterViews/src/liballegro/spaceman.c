/*
 * Each host has an object space manager that is a switchboard
 * for naming spaces.
 */

#include <allegro/spaceman.h>
#include <allegro/chief.h>
#include <allegro/connection.h>
#include <stdio.h>
#include <string.h>

extern char* getwd(char*);
extern int gethostname(char*, int);
extern int getpid();
extern void perror(const char*);
extern void exit(int);

const char*const spaceman_dir = "/tmp/.allegro";
const char*const spaceman_mgr = "/tmp/.allegro/spaceman";
const char*const spaceman_name = "/tmp/.allegro/p%5d";

static const int spaceman_namelen = 21;

inline void fatal (const char* s) {
    perror(s);
    exit(1);
}

SpaceManager::SpaceManager () {
    Connection* c;
    char cwd[1024];
    int* tag;

    c = new Connection;
    if (!c->OpenLocalService(spaceman_mgr)) {
	fatal("can't connect to space manager");
    }
    chief = new ChiefDeputy(c);
    hostname[0] = '\0';
    chief->Alloc(tag, chief->Tag(), 0, sizeof(*tag));
    *tag = Tag();
    UsePath(getwd(cwd));
}

void SpaceManager::Delete () {
    delete chief;
}

void SpaceManager::UsePath (const char* s) {
    chief->StringMsg(Tag(), spaceman_UsePath, s);
}

void SpaceManager::Register (const char* name, Connection* a, Connection*) {
    int* msg;

    int pid = getpid();
    sprintf(filename, spaceman_name, pid);
    a->CreateLocalService(filename);
    int n = strlen(name);
    chief->Alloc(msg, Tag(), spaceman_Register, sizeof(int) + n + 1);
    msg[0] = pid;
    chief->PackString(name, n, &msg[1]);
    chief->Sync();
}

void SpaceManager::UnRegister (const char* name) {
    chief->StringMsg(Tag(), spaceman_UnRegister, name);
    chief->Sync();
}

Connection* SpaceManager::Find (const char* name, boolean wait) {
    int pid;
    Connection* c;
    char* local;

    chief->StringMsg(Tag(), wait ? spaceman_WaitFor : spaceman_Find, name);
    chief->GetReply(&pid, sizeof(pid));
    if (pid == 0) {
	c = nil;
    } else {
	c = new Connection;
	local = new char[spaceman_namelen];
	sprintf(local, spaceman_name, pid);
	if (!c->OpenLocalService(local)) {
	    fatal("can't open local service");
	}
    }
    return c;
}
