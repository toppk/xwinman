#ifndef ASSOC_H
#define ASSOC_H

void *assoc_alloc();		/* returns assoc handler */
void assoc_add(/* void *handler, void *key, void *value */);
void *assoc_lookup(/* void *handler, void *key */);
void assoc_del(/* void *handler, void *key */);
void assoc_free(/* void *handler */);


#endif
