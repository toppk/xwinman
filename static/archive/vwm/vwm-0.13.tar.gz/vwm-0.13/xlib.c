#include "config.h"
#ifdef __GNUC__
# define alloca __builtin_alloca
#else
# if HAVE_ALLOCA_H
#  include <alloca.h>
# else
#  ifdef _AIX
#   pragma alloca
#  else
#   ifndef alloca
extern char *alloca();
#   endif
#  endif
# endif
#endif
#define NEED_REPLIES
#include <X11/X.h>
#include <X11/Xatom.h>
#include <X11/Xproto.h>
#include <stdio.h>
#ifdef HAVE_STDLIB_H
# include <stdlib.h>
#endif
#ifdef HAVE_MALLOC_H
# include <malloc.h>
#endif
#ifdef HAVE_STRING_H
# include <string.h>
#else
# include <strings.h>
#endif
#include "vwm.h"
#include "xlib.h"
#include "queue.h"

#define is_spc(c) ((c) == ' ' || (c) == '\t')

static void *x_recv_packet();
static CARD32 x_alloc_id();
static void x_error();
static void (*event_handler)() = NULL;
static void *event_queue;

/*
 * Routines to receive packets.
 */

void x_init()
{
    event_queue = q_alloc();
}

void x_set_event_handler(handler)
    void (*handler)();
{
    event_handler = handler;
}

void x_main_loop()
{
    void *ev;
    
    while (1) {
	ev = x_await_event();
	if (event_handler != NULL)
	    event_handler(ev);
	free(ev);
    }
}

void *x_await_reply()
{
    xGenericReply *gr;
    
    while (1) {
	gr = x_recv_packet();
	if (gr->type == X_Reply)
	    break;
	if (gr->type == X_Error)
	    x_error(gr);
	/* events are processed later. */
	q_put(event_queue, gr);
    }
    return gr;
}

void *x_await_event()
{
    xGenericReply *gr;
    
    if (!q_isempty(event_queue))
	gr = q_get(event_queue);
    else {
	while (1) {
	    gr = x_recv_packet();
	    if (gr->type == X_Error)
		x_error(gr);
	    if (gr->type != X_Reply)
		break;
	    fputs("unexpected X_Reply.\n", stderr);
	}
    }
    return gr;
}

static void *x_recv_packet()
{
    xGenericReply genericReply;
    int length, extra;
    char *p;
    
    recv_sized_packet(sock, &genericReply, sizeof genericReply);
    switch (genericReply.type) {
    case X_Reply:
	extra = genericReply.length * 4;
	length = sizeof genericReply + extra;
	p = malloc(length);
	bcopy((char *) &genericReply, p, sizeof genericReply);
	recv_sized_packet(sock, p + sizeof genericReply, extra);
	break;
    case X_Error:
	length = sizeof genericReply;
	p = malloc(length);
	bcopy((char *) &genericReply, p, sizeof genericReply);
	break;
    default:    /* Events */
	length = sizeof genericReply;
	p = malloc(length);
	bcopy((char *) &genericReply, p, sizeof genericReply);
	break;
    }
    return p;
}

void x_putback_events(evq)
    void *evq;
{
    /* put evq to the head of event_queue. */
    void *new_evq = q_alloc();
    while (!q_isempty(evq))
	q_put(new_evq, q_get(evq));
    while (!q_isempty(event_queue))
	q_put(new_evq, q_get(event_queue));
    q_free(event_queue);
    event_queue = new_evq;
}

/*
 * Interface routines for the X protocol.
 */

void x_select_input(win, mask)
    CARD32 win, mask;
{
    xChangeWindowAttributesReq changeWindowAttributesReq;
    changeWindowAttributesReq.reqType = X_ChangeWindowAttributes;
    changeWindowAttributesReq.length = 3 + 1;
    changeWindowAttributesReq.window = win;
    changeWindowAttributesReq.valueMask = CWEventMask;
    send_packets(sock,
		 &changeWindowAttributesReq, sizeof changeWindowAttributesReq,
		 &mask, sizeof mask,
		 NULL);
}

void x_map_window(win)
    CARD32 win;
{
    xResourceReq mapWindowReq;
    mapWindowReq.reqType = X_MapWindow;
    mapWindowReq.length = 2;
    mapWindowReq.id = win;
    send_packet(sock, &mapWindowReq, sizeof mapWindowReq);
}

void x_unmap_window(win)
    CARD32 win;
{
    xResourceReq unmapWindowReq;
    unmapWindowReq.reqType = X_UnmapWindow;
    unmapWindowReq.length = 2;
    unmapWindowReq.id = win;
    send_packet(sock, &unmapWindowReq, sizeof unmapWindowReq);
}

void x_reparent_window(win, parent, x, y)
    CARD32 win, parent;
    INT16 x, y;
{
    xReparentWindowReq reparentWindowReq;
    reparentWindowReq.reqType = X_ReparentWindow;
    reparentWindowReq.length = 4;
    reparentWindowReq.window = win;
    reparentWindowReq.parent = parent;
    reparentWindowReq.x = x;
    reparentWindowReq.y = y;
    send_packet(sock, &reparentWindowReq, sizeof reparentWindowReq);
}

void x_configure_window(win, mask, x, y, width, height,
			border_width, sibling, stack_mode)
    CARD32 win;
    CARD16 mask;
    INT16 x, y;
    CARD16 width, height, border_width;
    CARD32 sibling;
    CARD8 stack_mode;
{
    xConfigureWindowReq configureWindowReq;
    int num = 0;
    CARD32 value[7];
    configureWindowReq.reqType = X_ConfigureWindow;
    configureWindowReq.window = win;
    configureWindowReq.mask = mask;
    if (mask & CWX)
	value[num++] = x;
    if (mask & CWY)
	value[num++] = y;
    if (mask & CWWidth)
	value[num++] = width;
    if (mask & CWHeight)
	value[num++] = height;
    if (mask & CWBorderWidth)
	value[num++] = border_width;
    if (mask & CWSibling)
	value[num++] = sibling;
    if (mask & CWStackMode)
	value[num++] = stack_mode;
    configureWindowReq.length = 3 + num;
    send_packets(sock,
		 &configureWindowReq, sizeof configureWindowReq,
		 value, num * 4,
		 NULL);
}

void x_circulate_window(win, direction)
    CARD32 win;
    CARD8 direction;	/* 0: raise, 1: lower */
{
    xCirculateWindowReq circulateWindowReq;
    circulateWindowReq.reqType = X_CirculateWindow;
    circulateWindowReq.direction = direction;
    circulateWindowReq.length = 2;
    circulateWindowReq.window = win;
    send_packet(sock, &circulateWindowReq, sizeof circulateWindowReq);
}

void x_resize_window(win, width, height)
    CARD32 win;
    CARD16 width, height;
{
    x_configure_window(win, CWWidth | CWHeight, 0, 0, width, height, 0, 0, 0);
}

void x_query_tree(win, root, parent, children, num_children)
    CARD32 win, *root, *parent, **children;
    unsigned int *num_children;
{
    xResourceReq queryTreeReq;
    xQueryTreeReply *reply;
    int extra;
    
    queryTreeReq.reqType = X_QueryTree;
    queryTreeReq.length = 2;
    queryTreeReq.id = win;
    send_packet(sock, &queryTreeReq, sizeof queryTreeReq);
    
    reply = x_await_reply();
    
    if (root != NULL)
	*root = reply->root;
    if (parent != NULL)
	*parent = reply->parent;
    if (num_children != NULL)
	*num_children = reply->nChildren;
    if (children != NULL) {
	extra = sizeof(CARD32) * reply->nChildren;
	*children = (CARD32 *) malloc(extra);
	bcopy((char *) reply + sizeof *reply, (char *) *children, extra);
    }
    free(reply);
}

void x_grab_button(win, btn, mod, own, msk, ptr, kbd, con, csr)
    CARD32 win, con;
    unsigned int btn, mod, own, msk, ptr, kbd, csr;
{
    xGrabButtonReq grabButtonReq;
    
    grabButtonReq.reqType = X_GrabButton;
    grabButtonReq.ownerEvents = own;
    grabButtonReq.length = 6;
    grabButtonReq.grabWindow = win;
    grabButtonReq.eventMask = msk;
    grabButtonReq.pointerMode = ptr;
    grabButtonReq.keyboardMode = kbd;
    grabButtonReq.confineTo = con;
    grabButtonReq.cursor = csr;
    grabButtonReq.button = btn;
    grabButtonReq.modifiers = mod;
    send_packet(sock, &grabButtonReq, sizeof grabButtonReq);
}

void x_grab_key(win, key, mod, own, ptr, kbd)
    CARD32 win;
    CARD8 key;
    CARD16 mod;
    CARD8 own, ptr, kbd;
{
    xGrabKeyReq grabKeyReq;
    
    grabKeyReq.reqType = X_GrabKey;
    grabKeyReq.ownerEvents = own;
    grabKeyReq.length = 4;
    grabKeyReq.grabWindow = win;
    grabKeyReq.modifiers = mod;
    grabKeyReq.key = key;
    grabKeyReq.pointerMode = ptr;
    grabKeyReq.keyboardMode = kbd;
    send_packet(sock, &grabKeyReq, sizeof grabKeyReq);
}

void x_get_geometry(win, root, x, y, width, height, bw, depth)
    CARD32 win, *root;
    INT16 *x, *y;
    CARD16 *width, *height, *bw, *depth;
{
    xResourceReq getGeometryReq;
    xGetGeometryReply *reply;
    
    getGeometryReq.reqType = X_GetGeometry;
    getGeometryReq.length = 2;
    getGeometryReq.id = win;
    
    send_packet(sock, &getGeometryReq, sizeof getGeometryReq);
    
    reply = x_await_reply();
    
    if (root != NULL)
	*root = reply->root;
    if (x != NULL)
	*x = reply->x;
    if (y != NULL)
	*y = reply->y;
    if (width != NULL)
	*width = reply->width;
    if (height != NULL)
	*height = reply->height;
    if (bw != NULL)
	*bw = reply->borderWidth;
    if (depth != NULL)
	*depth = reply->depth;
    free(reply);
}

CARD32 x_create_gc(win)
    CARD32 win;
{
    xCreateGCReq createGCReq;
    
    createGCReq.reqType = X_CreateGC;
    createGCReq.length = 4;
    createGCReq.gc = x_alloc_id();
    createGCReq.drawable = win;
    createGCReq.mask = 0;
    
    send_packet(sock, &createGCReq, sizeof createGCReq);
    return createGCReq.gc;
}

void x_set_foreground(gc, fore)
    CARD32 gc, fore;
{
    xChangeGCReq changeGCReq;
    
    changeGCReq.reqType = X_ChangeGC;
    changeGCReq.length  = 4;
    changeGCReq.gc      = gc;
    changeGCReq.mask    = GCForeground;
    
    send_packets(sock,
		 &changeGCReq, sizeof changeGCReq,
		 &fore, sizeof fore,
		 NULL);
}

void x_set_background(gc, back)
    CARD32 gc, back;
{
    xChangeGCReq changeGCReq;
    
    changeGCReq.reqType = X_ChangeGC;
    changeGCReq.length  = 4;
    changeGCReq.gc      = gc;
    changeGCReq.mask    = GCBackground;
    
    send_packets(sock,
		 &changeGCReq, sizeof changeGCReq,
		 &back, sizeof back,
		 NULL);
}

void x_set_font(gc, font)
    CARD32 gc, font;
{
    xChangeGCReq changeGCReq;
    
    changeGCReq.reqType = X_ChangeGC;
    changeGCReq.length  = 4;
    changeGCReq.gc      = gc;
    changeGCReq.mask    = GCFont;
    
    send_packets(sock,
		 &changeGCReq, sizeof changeGCReq,
		 &font, sizeof font,
		 NULL);
}

void x_set_function(gc, func)
    CARD32 gc, func;
{
    xChangeGCReq changeGCReq;
    
    changeGCReq.reqType = X_ChangeGC;
    changeGCReq.length  = 4;
    changeGCReq.gc      = gc;
    changeGCReq.mask    = GCFunction;
    
    send_packets(sock,
		 &changeGCReq, sizeof changeGCReq,
		 &func, sizeof func,
		 NULL);
}

void x_set_subwindow_mode(gc, mode)
    CARD32 gc, mode;
{
    xChangeGCReq changeGCReq;
    
    changeGCReq.reqType = X_ChangeGC;
    changeGCReq.length  = 4;
    changeGCReq.gc      = gc;
    changeGCReq.mask    = GCSubwindowMode;
    
    send_packets(sock,
		 &changeGCReq, sizeof changeGCReq,
		 &mode, sizeof mode,
		 NULL);
}

void x_draw_rectangle(win, gc, left, top, right, bottom)
    CARD32 win, gc;
    INT16 left, top, right, bottom;
{
    xPolyRectangleReq polyRectangleReq;
    CARD16 width, height;
    
    polyRectangleReq.reqType = X_PolyRectangle;
    polyRectangleReq.length = 5;
    polyRectangleReq.drawable = win;
    polyRectangleReq.gc = gc;
    width = right - left;
    height = bottom - top;
    
    send_packets(sock,
		 &polyRectangleReq, sizeof polyRectangleReq,
		 &left, sizeof left, &top, sizeof top,
		 &width, sizeof width, &height, sizeof height,
		 NULL);
}

int x_grab_pointer(win, own, msk, ptr, kbd, con, csr, tim)
    CARD32 win, msk, con, csr, tim;
    CARD8 own, ptr, kbd;
{
    xGrabPointerReq grabPointerReq;
    xGrabPointerReply *reply;
    int status;
    
    grabPointerReq.reqType = X_GrabPointer;
    grabPointerReq.ownerEvents = own;
    grabPointerReq.length = 6;
    grabPointerReq.grabWindow = win;
    grabPointerReq.eventMask = msk;
    grabPointerReq.pointerMode = ptr;
    grabPointerReq.keyboardMode = kbd;
    grabPointerReq.confineTo = con;
    grabPointerReq.cursor = csr;
    grabPointerReq.time = tim;
    send_packet(sock, &grabPointerReq, sizeof grabPointerReq);
    
    reply = x_await_reply();
    status = reply->status;
    free(reply);
    
    return status;
}

void x_ungrab_pointer(tim)
    CARD32 tim;
{
    xResourceReq ungrabPointerReq;
    ungrabPointerReq.reqType = X_UngrabPointer;
    ungrabPointerReq.length = 2;
    ungrabPointerReq.id = tim;
    send_packet(sock, &ungrabPointerReq, sizeof ungrabPointerReq);
}

void x_grab_server()
{
    xResourceReq grabServerReq;
    grabServerReq.reqType = X_GrabServer;
    grabServerReq.length = 1;
    send_packet(sock, &grabServerReq, 4);
}

void x_ungrab_server()
{
    xResourceReq ungrabServerReq;
    ungrabServerReq.reqType = X_UngrabServer;
    ungrabServerReq.length = 1;
    send_packet(sock, &ungrabServerReq, 4);
}

#if 0
void x_set_dont_propagate_mask(win, mask)
    CARD32 win;
    CARD32 mask;
{
    xChangeWindowAttributesReq changeWindowAttributesReq;
    changeWindowAttributesReq.reqType = X_ChangeWindowAttributes;
    changeWindowAttributesReq.length = 3 + 1;
    changeWindowAttributesReq.window = win;
    changeWindowAttributesReq.valueMask = CWDontPropagate;
    send_packets(sock,
		 &changeWindowAttributesReq, sizeof changeWindowAttributesReq,
		 &mask, sizeof mask,
		 NULL);
}
#endif

CARD32 x_create_window(parent, x, y, width, height, bw,
		       depth, class, visual, mask, attr)
    CARD32 parent;
    INT16 x, y;
    CARD16 width, height, bw, class;
    CARD8 depth;
    CARD32 visual, mask;
    struct x_create_window_attributes *attr;
{
    xCreateWindowReq createWindowReq;
    CARD32 value[15], *v = value;
    int num_values;
    
    if (mask & CWBackPixmap)		*v++ = attr->back_pixmap;
    if (mask & CWBackPixel)		*v++ = attr->back_pixel;
    if (mask & CWBorderPixmap)		*v++ = attr->border_pixmap;
    if (mask & CWBorderPixel)		*v++ = attr->border_pixel;
    if (mask & CWBitGravity)		*v++ = attr->bit_gravity;
    if (mask & CWWinGravity)		*v++ = attr->win_gravity;
    if (mask & CWBackingStore)		*v++ = attr->backing_store;
    if (mask & CWBackingPlanes)		*v++ = attr->backing_planes;
    if (mask & CWBackingPixel)		*v++ = attr->backing_pixel;
    if (mask & CWOverrideRedirect)	*v++ = attr->override_redirect;
    if (mask & CWSaveUnder)		*v++ = attr->save_under;
    if (mask & CWEventMask)		*v++ = attr->event_mask;
    if (mask & CWDontPropagate)		*v++ = attr->dont_propagate_mask;
    if (mask & CWColormap)		*v++ = attr->colormap;
    if (mask & CWCursor)		*v++ = attr->cursor;
    num_values = v - value;
    
    createWindowReq.reqType = X_CreateWindow;
    createWindowReq.depth = depth;
    createWindowReq.length = 8 + num_values;
    createWindowReq.wid = x_alloc_id();
    createWindowReq.parent = parent;
    createWindowReq.x = x;
    createWindowReq.y = y;
    createWindowReq.width = width;
    createWindowReq.height = height;
    createWindowReq.borderWidth = bw;
    createWindowReq.class = class;
    createWindowReq.visual = visual;
    createWindowReq.mask = mask;
    send_packets(sock,
		 &createWindowReq, sizeof createWindowReq,
		 value, 4 * num_values,
		 NULL);
    
    return createWindowReq.wid;
}

CARD32 x_create_simple_window(parent, x, y, width, height, bw,
			      border, background)
    CARD32 parent;
    INT16 x, y;
    CARD16 width, height, bw;
    CARD32 border, background;
{
    struct x_create_window_attributes attr;
    
    attr.border_pixel = border;
    attr.back_pixel = background;
    
    return x_create_window(parent, x, y, width, height, bw,
			   0, CopyFromParent, CopyFromParent,
			   CWBackPixel | CWBorderPixel, &attr);
}

void x_destroy_window(win)
    CARD32 win;
{
    xResourceReq destroyWindow;
    destroyWindow.reqType = X_DestroyWindow;
    destroyWindow.length = 2;
    destroyWindow.id = win;
    send_packet(sock, &destroyWindow, sizeof destroyWindow);
}

void x_add_to_save_set(win)
    CARD32 win;
{
    xChangeSaveSetReq changeSaveSet;
    changeSaveSet.reqType = X_ChangeSaveSet;
    changeSaveSet.mode = 0;	/* insert */
    changeSaveSet.length = 2;
    changeSaveSet.window = win;
    send_packet(sock, &changeSaveSet, sizeof changeSaveSet);
}

void x_remove_from_save_set(win)
    CARD32 win;
{
    xChangeSaveSetReq changeSaveSet;
    changeSaveSet.reqType = X_ChangeSaveSet;
    changeSaveSet.mode = 1;	/* delete */
    changeSaveSet.length = 2;
    changeSaveSet.window = win;
    send_packet(sock, &changeSaveSet, sizeof changeSaveSet);
}

CARD32 x_load_font(fontname)
    char *fontname;
{
    xOpenFontReq openFontReq;
    int name_len;
    
    name_len = strlen(fontname);
    openFontReq.reqType = X_OpenFont;
    openFontReq.length = 3 + (name_len + 3) / 4;
    openFontReq.fid = x_alloc_id();
    openFontReq.nbytes = name_len;
    send_packets(sock,
		 &openFontReq, sizeof openFontReq,
		 fontname, name_len + PAD(name_len),
		 NULL);
    return openFontReq.fid;
}

void x_query_text_extents(font, text, width, ascent, descent)
    CARD32 font;
    char *text;
    INT16 *width, *ascent, *descent;
{
    xQueryTextExtentsReq queryTextExtentsReq;
    xQueryTextExtentsReply *reply;
    int text_len = strlen(text), buf_len;
    int i;
    char *buf, *p;
    
    buf_len = text_len * 2 + PAD(text_len * 2);
    buf = alloca(buf_len);
    for (i = text_len, p = buf; i > 0; i--) {
	*p++ = 0;
	*p++ = *text++;
    }
    queryTextExtentsReq.reqType = X_QueryTextExtents;
    queryTextExtentsReq.oddLength = text_len & 1;
    queryTextExtentsReq.length = 2 + buf_len / 4;
    queryTextExtentsReq.fid = font;
    send_packets(sock,
		 &queryTextExtentsReq, sizeof queryTextExtentsReq,
		 buf, buf_len,
		 NULL);
    reply = x_await_reply();
    *width = reply->overallWidth;
    *ascent = reply->fontAscent;
    *descent = reply->fontDescent;
    free(reply);
}

CARD32 x_create_pixmap(win, width, height, depth)
    CARD32 win;
    CARD16 width, height;
    CARD8 depth;
{
    xCreatePixmapReq createPixmapReq;
    
    createPixmapReq.reqType = X_CreatePixmap;
    createPixmapReq.depth = depth;
    createPixmapReq.length = 4;
    createPixmapReq.pid = x_alloc_id();
    createPixmapReq.drawable = win;
    createPixmapReq.width = width;
    createPixmapReq.height = height;
    
    send_packet(sock, &createPixmapReq, sizeof createPixmapReq);
    return createPixmapReq.pid;
}

void x_free_pixmap(pix)
    CARD32 pix;
{
    xResourceReq freePixmapReq;
    freePixmapReq.reqType = X_FreePixmap;
    freePixmapReq.length = 2;
    freePixmapReq.id = pix;
    send_packet(sock, &freePixmapReq, sizeof freePixmapReq);
}

void x_draw_image_text(win, gc, text, x, y)
    CARD32 win;
    CARD32 gc;
    char *text;
    INT16 x, y;
{
    xImageText8Req imageText8Req;
    int text_len = strlen(text);
    
    imageText8Req.reqType = X_ImageText8;
    imageText8Req.nChars = text_len;
    imageText8Req.length = 4 + (text_len + 3) / 4;
    imageText8Req.drawable = win;
    imageText8Req.gc = gc;
    imageText8Req.x = x;
    imageText8Req.y = y;
    send_packets(sock,
		 &imageText8Req, sizeof imageText8Req,
		 text, text_len + PAD(text_len),
		 NULL);
}

void x_get_window_property(win, prop, off, len, del, type,
		      atype, aformat, nitems, leftover, data)
    CARD32 win, prop, type, *atype;
    long off, len;
    CARD8 del;
    int *aformat;
    unsigned long *nitems, *leftover, **data;
{
    xGetPropertyReq getPropertyReq;
    xGetPropertyReply *reply;
    xError err;
    char *buf = NULL;
    
    getPropertyReq.reqType = X_GetProperty;
    getPropertyReq.delete = del;
    getPropertyReq.length = 6;
    getPropertyReq.window = win;
    getPropertyReq.property = prop;
    getPropertyReq.type = type;
    getPropertyReq.longOffset = off;
    getPropertyReq.longLength = len;
    send_packet(sock, &getPropertyReq, sizeof getPropertyReq);
    
    reply = x_await_reply();
    
    *aformat = reply->format;
    *atype = reply->propertyType;
    *leftover = reply->bytesAfter;
    *nitems = reply->nItems;
    
    switch (*aformat) {
    case 8:
	buf = malloc(*nitems + 1);
	bcopy((char *) reply + sizeof *reply, buf, *nitems);
	buf[*nitems] = '\0';
	break;
    case 16:
	buf = malloc(*nitems * 2);
	bcopy((char *) reply + sizeof *reply, buf, *nitems * 2);
	buf[*nitems] = '\0';
	buf[*nitems + 1] = '\0';
	break;
    case 32:
	buf = malloc(*nitems * 4);
	bcopy((char *) reply + sizeof *reply, buf, *nitems * 4);
	buf[*nitems] = '\0';
	buf[*nitems + 1] = '\0';
	buf[*nitems + 2] = '\0';
	buf[*nitems + 3] = '\0';
	break;
    default:
	err.type = X_Error;
	err.majorCode = X_GetProperty;
	err.minorCode = 0;
	err.errorCode = BadImplementation;
	x_error(&err);
    }
    *data = (unsigned long *) buf;
    free(reply);
}

char *x_get_icon_name(win)
    CARD32 win;
{
    CARD32 type;
    int format;
    unsigned long nitems, leftover;
    char *data;
    
    x_get_window_property(win, XA_WM_ICON_NAME, 0L, (long)BUFSIZ, 0, XA_STRING,
			  &type, &format, &nitems, &leftover,
			  (unsigned long **) &data);
    if (format == 0 || type == None) {
fputs("can't get prop.\n", stderr);
	return NULL;
    }
    
    if (type == XA_STRING && format == 8)
	return data;
    free(data);
fputs("bad type of prop.\n", stderr);
    return NULL;
}

void x_raise_window(win)
    CARD32 win;
{
    x_configure_window(win, CWStackMode, 0, 0, 0, 0, 0, 0, Above);
}

void x_lower_window(win)
    CARD32 win;
{
    x_configure_window(win, CWStackMode, 0, 0, 0, 0, 0, 0, Below);
}

#if 0
void x_translate_coords(srcwin, dstwin, srcx, srcy, dstx, dsty, child)
    CARD32 srcwin, dstwin;
    INT16 srcx, srcy;
    INT16 *dstx, *dsty;
    CARD32 *child;
{
    xTranslateCoordsReq translateCoordsReq;
    xTranslateCoordsReply *reply;
    xGenericReply *gr;
    
    translateCoordsReq.reqType = X_TranslateCoords;
    translateCoordsReq.length = 4;
    translateCoordsReq.srcWid = srcwin;
    translateCoordsReq.dstWid = dstwin;
    translateCoordsReq.srcX = srcx;
    translateCoordsReq.srcY = srcy;
    send_packet(sock, &translateCoordsReq, sizeof translateCoordsReq);
    
    reply = x_await_reply();
    
    if (dstx != NULL)
	*dstx = reply->dstX;
    if (dsty != NULL)
	*dsty = reply->dstY;
    if (child != NULL)
	*child = reply->child;
    free(reply);
}
#endif


static CARD32 x_alloc_id()
{
    CARD32 id;
    
    id = setup.rid << setup.rid_shift;
    if (id > setup.rid_mask) {
        fputs("resource ID allocation space exhausted!\n", stderr);
        exit(1);
    }
    setup.rid++;
    return setup.rid_base + id;
}

static void x_error(er)
    xError *er;
{
    fputs("X_Error #", stderr);
    fputi(er->errorCode, stderr);
    fputs(".\n seq=", stderr);
    fputi(er->sequenceNumber, stderr);
    fputs(".\n rid=", stderr);
    fputi(er->resourceID, stderr);
    fputs(".\n major=", stderr);
    fputi(er->majorCode, stderr);
    fputs(".\n minor=", stderr);
    fputi(er->minorCode, stderr);
    fputs(".\n", stderr);
    exit(1);
}

/**/
