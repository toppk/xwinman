/* Define if errno is declared in <errno.h>.  */
#undef ERRNO_IN_ERRNO_H
