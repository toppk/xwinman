#ifndef VWM_H
#define VWM_H

#include <X11/X.h>
#include <X11/Xproto.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>


#define PAD(s) ((4 - ((s) % 4)) % 4)

struct acc {
    unsigned long modifier;	/* mask of modifier */
    unsigned long button;	/* button# */
    unsigned long key;		/* keycode */
};
struct keybut {
    char *function;
    void (*handler)();
    int only_button;		/* can't invoke with keys? */
    int num_accs;
    struct acc *accs;
};
struct exec_t {
    struct acc acc;
    char *command;
};

struct setup_info {
    int littleEndian;
    int majorVersion, minorVersion;
    int authorized;
    int last_seq;	/* last seq# */
    CARD32 rid, rid_shift, rid_max, rid_mask, rid_base;
    CARD8 numRoots, numFormats;
    CARD8 minKeyCode, maxKeyCode;
};

struct pixmap_format {
    CARD8 depth, bitsPerPixel, scanLinePad;
};
struct window_root {
    Window windowId;
    Colormap defaultColormap;
    CARD32 whitePixel, blackPixel;
    CARD32 currentInputMask;
    CARD16 pixWidth, pixHeight;
    CARD16 mmWidth, mmHeight;
    CARD16 minInstalledMaps, maxInstalledMaps;
    VisualID rootVisualID;
    CARD8 backingStore;
    BOOL saveUnders;
    CARD8 rootDepth;
    CARD8 nDepths;
    struct depth {
	CARD8 depth;
	CARD16 nVisuals;
	struct visual_type {
	    VisualID visualID;
	    CARD8 class;
	    CARD8 bitsPerRGB;
	    CARD16 colormapEntries;
	    CARD32 redMask, greenMask, blueMask;
	} *visual_types;
    } *depths;
};


extern struct in_addr get_inet_addr();
extern int get_auth();
extern void read_rc();
extern int create_connection();
extern void fputi();
extern void send_packet();
extern void send_pad();
extern void send_packets();
extern int recv_pad();
extern int recv_sized_packet();
#ifndef HAVE_STRDUP
extern char *strdup();
#endif
#ifndef HAVE_GETHOSTNAME
extern int gethostname();
#endif
#ifndef HAVE_BCOPY
extern void bcopy();
#endif
#ifndef HAVE_BZERO
extern void bzero();
#endif
#ifndef HAVE_BCMP
extern int bcmp();
#endif
extern char *ltoa();
extern void remove_defunct_process();
extern void work();

extern struct setup_info setup;
extern int num_pixmap_formats;
extern struct pixmap_format *pixmap_formats;
extern struct window_root *rootw;
extern int sock;

extern struct keybut actions[];
extern struct exec_t *execs;
extern int num_execs;
extern unsigned int deltastop;
extern CARD32 xorvalue;


#endif
