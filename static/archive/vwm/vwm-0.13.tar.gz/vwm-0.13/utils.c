#include "config.h"
#ifdef __GNUC__
# define alloca __builtin_alloca
#else
# if HAVE_ALLOCA_H
#  include <alloca.h>
# else
#  ifdef _AIX
#   pragma alloca
#  else
#   ifndef alloca
extern char *alloca();
#   endif
#  endif
# endif
#endif
#include <stdio.h>
#ifdef HAVE_STDLIB_H
# include <stdlib.h>
#endif
#ifdef HAVE_STRING_H
# include <string.h>
#else
# include <strings.h>
#endif
#ifndef HAVE_GETHOSTNAME /* defined HAVE_UNAME */
# include <sys/utsname.h>
#endif
#ifdef HAVE_SYS_WAIT_H
# include <sys/wait.h>
#endif
#include <errno.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <varargs.h>
#include "vwm.h"

#ifndef ERRNO_IN_ERRNO_H
extern int errno;
#endif

void fputi(i, fp)
    int i;
    FILE *fp;
{
    fputs(ltoa((long) i), fp);
}

void send_packet(s, pack, len)
    int s;
    void *pack;
    size_t len;
{
    if (len < 1)
        return;
    while (send(s, pack, len, 0) < 0) {
        if (errno != EINTR) {
            perror("send");
            exit(1);
        }
    }
}

static char padbuf[4];
void send_pad(s, size)
    int s;
    size_t size;
{
    if (size > 0)
        send_packet(s, padbuf, size);
}

void send_packets(s, va_alist)
    int s;
    va_dcl
{
    va_list ap;
    struct iovec *iovec;
    int i, numvecs;
    
    va_start(ap);
    for (numvecs = 0; va_arg(ap, void *) != NULL; numvecs++)
        i = va_arg(ap, int);	/* i is dummy. */
    va_end(ap);
    
    if (numvecs == 0)
        return;
    
    iovec = (struct iovec *) alloca(sizeof *iovec * numvecs);
    va_start(ap);
    for (i = 0; i < numvecs; i++) {
        iovec[i].iov_base = va_arg(ap, void *);
        iovec[i].iov_len  = va_arg(ap, int);
    }
    va_end(ap);
    
    while (writev(s, iovec, numvecs) < 0) {
        if (errno != EINTR) {
            perror("writev");
            exit(1);
        }
    }
}

int recv_pad(s, size)
    int s;
    size_t size;
{
    char buf[8];
    int siz = (int) size;
    while (size > 0) {
        int len = size > 8 ? 8 : size;
        recv_sized_packet(s, buf, len);
        size -= len;
    }
    return siz;
}

int recv_sized_packet(s, pack, size)
    int s;
    void *pack;
    size_t size;
{
    int i = 0;
    while (i < size) {
        int r;
        if ((r = recv(s, (char *) pack + i, size - i, 0)) < 0) {
            if (errno == EINTR)
                continue;
            perror("recv");
        }
        if (r == 0) {
            exit(1);
        }
        i += r;
    }
    return i;
}

#ifndef HAVE_STRDUP
char *strdup(str)
    char *str;
{
    return strcpy(malloc(strlen(str) + 1), str);
}
#endif

#ifndef HAVE_GETHOSTNAME /* defined HAVE_UNAME */
int gethostname(buf, max)
    char *buf;
    int max;
{
    struct utsname un;
    uname(&un);
    strncpy(buf, un.nodename, max);
    buf[max - 1] = '\0';
    return 0;
}
#endif

#ifndef HAVE_BCOPY
void bcopy(src, dst, len)
    char *src, *dst;
    int len;
{
    for ( ; len > 0; len--)
	*dst++ = *src++;
}
#endif

#ifndef HAVE_BZERO
void bzero(dst, len)
    char *dst;
    int len;
{
    for ( ; len > 0; len--)
	*dst++ = '\0';
}
#endif

#ifndef HAVE_BCMP
int bcmp(src, dst, len)
    char *src, *dst;
    int len;
{
    for ( ; len > 0; len--) {
	if (*dst++ == *src++)
	    return 0;
    }
    return 1;
}
#endif

#define BUFLEN 32
static char buf[BUFLEN];
char *ltoa(i)
    long i;
{
    char *p;
    int neg = i < 0 ? (i = -i, 1) : 0;
    p = buf + BUFLEN - 1;
    *p-- = '\0';
    do {
	*p-- = i % 10 + '0';
	i /= 10;
    } while (i > 0);
    if (neg)
	*p-- = '-';
    return p + 1;
}

void remove_defunct_process()
{
#ifdef HAVE_SYS_WAIT_H
    int status;
# ifdef HAVE_WAIT4
    wait4(-1, &status, WNOHANG, NULL);
# else
#  ifdef HAVE_WAIT3
    wait3(&status, WNOHANG, NULL);
#  else
#   ifdef HAVE_WAITPID
    waitpid(-1, &status, WNOHANG);
#   endif
#  endif
# endif
#endif
}


/**/
