#include "config.h"
#ifdef __GNUC__
# define alloca __builtin_alloca
#else
# if HAVE_ALLOCA_H
#  include <alloca.h>
# else
#  ifdef _AIX
#   pragma alloca
#  else
#   ifndef alloca
extern char *alloca();
#   endif
#  endif
# endif
#endif
#include <X11/Xproto.h>
#include <X11/X.h>
#include <stdio.h>
#include <sys/types.h>
#ifdef HAVE_STDLIB_H
# include <stdlib.h>
#endif
#ifdef HAVE_UNISTD_H
# include <unistd.h>
#endif
#include <sys/param.h>
#include <sys/file.h>
#include <sys/fcntl.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#ifdef HAVE_STRING_H
# include <string.h>
#else
# include <strings.h>
#endif
#include "vwm.h"

#ifndef SEEK_END
# define SEEK_SET 0
# define SEEK_CUR 1
# define SEEK_END 2
#endif

#define FamilyLocal 256

static char mmc[] = "MIT-MAGIC-COOKIE-1";
static int lookup_auth();

struct in_addr get_inet_addr(hostname)
    char *hostname;
{
    struct in_addr retval;
    
    if (*hostname == '\0') {	/* special case */
	retval.s_addr = htonl(0x7f000001);
	return retval;
    }
    
#ifdef USE_GETHOSTBYNAME
    {
	struct hostent *ent;
	if ((ent = gethostbyname(hostname)) != NULL) {
	    bcopy(ent->h_addr, (char *) &retval.s_addr, sizeof retval.s_addr);
	    if (retval.s_addr != 0xffffffff)
		return retval;
	}
# ifdef USE_INET_ADDR
	retval.s_addr = inet_addr(hostname);
	return retval;
# else
	retval.s_addr = 0xffffffff;
	return retval;;
# endif
    }
#else
# ifdef USE_INET_ADDR
    retval.s_addr = inet_addr(hostname);
    return retval;
# else
    retval.s_addr = 0xffffffff;
    return retval;;
# endif
#endif
}

static int memb_len;
static char memb_str[1024];
static char *get_next(p)
    char *p;
{
    CARD16 len;
    bcopy(p, (char *) &len, sizeof len);
    memb_len = (int) (unsigned int) ntohs(len);
    bcopy(p + 2, memb_str, memb_len);
    memb_str[memb_len] = '\0';
    return p + 2 + memb_len;
}


/*
   get_auth extracts auth entry from ~/.Xauthority, and 
   returns:
      0: If successful. *proto=mmc, *data=???.
         You must free data. You must not free proto.
     -1: If failed.
*/
int get_auth(host, dpy, proto, proto_len, data, data_len)
    char *host;
    int dpy;
    char **proto, **data;
    int *proto_len, *data_len;
{
    char fname[MAXPATHLEN], *p;
    char *buffer, *eob;
    long size;
    int fd;
    
    if ((p = getenv("HOME")) == NULL) {
	fputs("auth: Where is your home?\n", stderr);
	exit(1);
    }
    strcat(strcpy(fname, p), "/.Xauthority");
    if ((fd = open(fname, O_RDONLY)) < 0)
	return -1;
    if ((size = (long) lseek(fd, 0, SEEK_END)) < 0) {
	fputs("auth: lseek failed.\n", stderr);
	exit(1);
    }
    buffer = alloca((int) size);
    if (lseek(fd, 0, SEEK_SET) < 0) {
	fputs("auth: lseek failed.\n", stderr);
	exit(1);
    }
    if ((size_t) read(fd, buffer, (size_t) size) != size) {
	fputs("auth: read failed.\n", stderr );
	exit(1);
    }
    close(fd);
    
    p = buffer;
    eob = buffer + size;
    
    if (host == NULL || *host == '\0') {
	char hostname[MAXHOSTNAMELEN];
	gethostname(hostname, MAXHOSTNAMELEN);
	if (lookup_auth(FamilyLocal, buffer, eob, hostname, strlen(hostname),
			dpy, proto, proto_len, data, data_len) == 0)
	    return 0;
    }
    if (host != NULL && *host != '\0') {
	struct in_addr addr;
	addr = get_inet_addr(host);
	if (addr.s_addr == 0xffffffff) {
	    fputs("unknown host.\n", stderr);
	    return -1;
	}
	if (lookup_auth(FamilyInternet, buffer, eob, &addr, sizeof addr,
			dpy, proto, proto_len, data, data_len) == 0)
	    return 0;
    }
    return -1;
}

static int lookup_auth(family, bob, eob, addr, addr_len, dpynum,
		       proto, proto_len, data, data_len)
    int family;
    char *bob, *eob;
    void *addr;
    int addr_len;
    int dpynum;
    char **proto, **data;
    int *proto_len, *data_len;
{
    char *p = bob;
    
    while (p < eob) {
	CARD16 fam;
	int rest;
	
	bcopy(p, (char *) &fam, sizeof fam);
	p += 2;
	if (ntohs(fam) == family) {
	    p = get_next(p);			/* get address */
	    if (memb_len == addr_len &&
		    bcmp(memb_str, (char *) addr, addr_len) == 0) {
		p = get_next(p);		/* get display "number" */
		if (atoi(memb_str) == dpynum) {
		    p = get_next(p);		/* get auth name */
		    if (memb_len == 18 && bcmp(memb_str, mmc, 18) == 0) {
			p = get_next(p);	/* get auth data */
			if (proto_len != NULL)
			    *proto_len = 18;
			if (proto != NULL)
			    *proto = mmc;
			if (data_len != NULL)
			    *data_len = memb_len;
			if (data != NULL)
			    *data = memb_str;
			return 0;		/* FIN !! */
		    } else
			rest = 1;
		} else
		    rest = 2;
	    } else
		rest = 3;
	} else
	    rest = 4;
	for ( ; rest > 0; rest--)
	    p = get_next(p);
    }
    return -1;
}

/**/
