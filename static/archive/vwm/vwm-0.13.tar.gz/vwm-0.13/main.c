#include "config.h"
#ifdef __GNUC__
# define alloca __builtin_alloca
#else
# if HAVE_ALLOCA_H
#  include <alloca.h>
# else
#  ifdef _AIX
#   pragma alloca
#  else
#   ifndef alloca
extern char *alloca();
#   endif
#  endif
# endif
#endif
#include <stdio.h>
#ifdef HAVE_STDLIB_H
# include <stdlib.h>
#endif
#include <sys/types.h>
#ifdef HAVE_STRING_H
# include <string.h>
#else
# include <strings.h>
#endif
#include "vwm.h"

int sock;
char *command_name;

int main(argc, argv)
    int argc;
    char **argv;
{
    char *dpyhost = NULL;
    int dpynumber;
    int scrnumber;
    char *p;
    
    argc--;
    command_name = *argv++;
    while (argc > 0) {
	if (strcmp(*argv, "-display") == 0 || strcmp(*argv, "-d") == 0) {
	    argc--; argv++;
	    if (argc > 0) {
		int len = strlen(*argv);
		dpyhost = alloca(len + 1);
		bcopy(*argv, dpyhost, len + 1);
	    } else {
		fputs("display name required.\n", stderr);
		exit(1);
	    }
	    argc--; argv++;
	} else {
	    fputs("bad option \"", stderr);
	    fputs(*argv, stderr);
	    fputs("\".\n", stderr);
	    exit(1);
	}
    }
    if (dpyhost == NULL) {
	int len;
	if ((p = getenv("DISPLAY")) == NULL) {
	    fputs("Can't open display.\n", stderr);
	    exit(1);
	}
	len = strlen(p);
	dpyhost = alloca(len + 1);
	bcopy(p, dpyhost, len + 1);
    }
    if ((p = strrchr(dpyhost, ':')) == NULL) {
	fputs("bad display name.\n", stderr);
	exit(1);
    }
    *p = '\0';
    dpynumber = atoi(p);		/* needs more check. */
    if ((p = strchr(p, '.')) != NULL) {
	p++;
	scrnumber = atoi(p);
    } else
	scrnumber = 0;
    
    if ((sock = create_connection(dpyhost, dpynumber, scrnumber)) < 0)
	exit(1);
    
    read_rc();
    work();
    
    return 0;
}



/**/
