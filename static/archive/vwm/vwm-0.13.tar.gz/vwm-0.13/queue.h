#ifndef QUEUE_H
#define QUEUE_H

void *q_alloc();			  /* returns a queue id. */
void q_put(/* void *qid, void *value */); /* put something to the tail. */
void *q_get(/* void *qid */);		  /* get something from the top. */
int q_isempty(/* void *qid */);		  /* returns 1 if it is empty. */
void q_free(/* void *qid */);		  /* free the queue. */

#endif
