#ifndef XLIB_H
#define XLIB_H


struct x_create_window_attributes {
    CARD32 back_pixmap, back_pixel, border_pixmap, border_pixel;
    BYTE bit_gravity, win_gravity, backing_store;
    CARD32 backing_planes, backing_pixel;
    BYTE override_redirect, save_under;
    CARD32 event_mask, dont_propagate_mask, colormap, cursor;
};


void x_init();			/* should be called first. */
void x_set_event_handler();
void x_main_loop();
void *x_await_reply();
void *x_await_event();
void x_putback_events();
void x_select_input();
void x_map_window();
void x_unmap_window();
void x_reparent_window();
void x_configure_window();
void x_circulate_window();
void x_resize_window();
void x_query_tree();
void x_grab_button();
void x_grab_key();
void x_get_geometry();
CARD32 x_create_gc();
void x_set_foreground();
void x_set_background();
void x_set_font();
void x_set_function();
void x_set_subwindow_mode();
void x_draw_rectangle();
int x_grab_pointer();
void x_ungrab_pointer();
void x_grab_server();
void x_ungrab_server();
CARD32 x_create_window();
CARD32 x_create_simple_window();
void x_destroy_window();
void x_add_to_save_set();
void x_remove_from_save_set();
CARD32 x_load_font();
void x_query_text_extents();
CARD32 x_create_pixmap();
void x_free_pixmap();
void x_draw_image_text();
void x_get_window_property();
char *x_get_icon_name();
void x_raise_window();
void x_lower_window();

#endif
