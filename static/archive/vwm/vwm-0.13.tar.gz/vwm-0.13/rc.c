#include "config.h"
#ifdef __GNUC__
# define alloca __builtin_alloca
#else
# if HAVE_ALLOCA_H
#  include <alloca.h>
# else
#  ifdef _AIX
#   pragma alloca
#  else
#   ifndef alloca
extern char *alloca();
#   endif
#  endif
# endif
#endif
#include <X11/X.h>
#include <stdio.h>
#ifdef HAVE_STDLIB_H
# include <stdlib.h>
#endif
#ifdef HAVE_STRING_H
# include <string.h>
#else
# include <strings.h>
#endif
#include "vwm.h"

#define is_spc(c) ((c) == ' ' || (c) == '\t')
#define is_token_char(c) (!is_spc(c) && c != '\n' && c != '\0')
#define DEFAULT_TOKEN_BUFLEN 16

#define REASON_NO_CHAR	1
#define REASON_TOO_LONG	2

static void handle_buflen();
static void handle_action();
static void handle_font();
static void handle_exec();
static void handle_deltastop();
static void handle_xorvalue();
static int convert_acc();
static void errmsg();

extern char *iconfontname;

static long token_buflen = 0;
static char *token;
static int reason_of_null = 0;

static char *get_token(string)
    char *string;
{
    char *p = string, *q;
    long i;
    
    if (token_buflen == 0) {
	token_buflen = DEFAULT_TOKEN_BUFLEN;
	token = malloc(token_buflen);
    }
    while (*p == ' ' || *p == '\t')
	p++;
    for (q = token, i = 0; is_token_char(*p) && i < token_buflen; i++)
	*q++ = *p++;
    if (i == 0) {
	reason_of_null = REASON_NO_CHAR;
	return NULL;
    }
    if (i < token_buflen) {
	*q++ = '\0';
	return p;
    }
    reason_of_null = REASON_TOO_LONG;
    return NULL;
}

static char *get_string(string)
    char *string;
{
    char *p = string, *q;
    long i;
    char dq = 0;
    
    while (is_spc(*p))
	p++;
    if (*p == '\n' || *p == '\0') {
	reason_of_null = REASON_NO_CHAR;
	return NULL;
    }
    if (*p == '\"') {
	p++;
	dq = 1;
    }
    for (q = token, i = 0; i < token_buflen; i++) {
	switch (*p) {
	case '\\':
	    switch (*++p) {
	    case '0':
	    case '1':
	    case '2':
		{
		    unsigned char n = *p++ - '0';
		    
		    if (*p >= '0' && *p <= '7') {
			n = n << 8 | (*p++ - '0');
			if (*p > '0' && *p <= '7') {
			    n = n << 8 | (*p++ - '0');
			}
		    }
		    *q++ = n;
		}
		break;
	    case 'e':
		*q++ = '\033';
		p++;
		break;
	    case 'n':
		*q++ = '\n';
		p++;
		break;
	    case 't':
		*q++ = '\t';
		p++;
		break;
	    case '\n':
	    case '\0':
		p++;
		goto eos;
	    default:
		*q++ = *p++;
	    }
	case '\"':
	    if (dq) {
		p++;
		goto eos;
	    }
	    *q++ = *p++;
	    break;
	case ' ':
	case '\t':
	    if (!dq) {
		p++;
		goto eos;
	    }
	    *q++ = *p++;
	    break;
	case '\n':
	case '\0':
	    p++;
	    goto eos;
	default:
	    *q++ = *p++;
	}
    }
    reason_of_null = REASON_TOO_LONG;
    return NULL;
eos:
    *q = '\0';
    return p;
}

static char *buffer;
static long buflen;
void read_rc()
{
    static struct {
	char *keyword;
	void (*handler)();
    } keyword_handlers[] = {
	{"action",    handle_action},
	{"buflen",    handle_buflen},
	{"font",      handle_font},
	{"exec",      handle_exec},
	{"deltastop", handle_deltastop},
	{"xorvalue",  handle_xorvalue},
	{NULL,        NULL},
    }, *hp;
    char *p;
    FILE *fp;
    int lineno;
    
    buflen = 80;
    buffer = malloc(buflen);
    
    if ((p = getenv("HOME")) == NULL) {
	fputs("Where is your home?\n", stderr);
	exit(1);
    }
    strcat(strcpy(buffer, p), "/.vwmrc");
    if ((fp = fopen(buffer, "r")) == NULL) {
	fputs("no rc file.\n", stderr);
	return;
    }
    
    lineno = 0;
    while(fgets(buffer, buflen, fp), !feof(fp)) {
	++lineno;
	
	if ((p = get_token(buffer)) == NULL) {
	    switch (reason_of_null) {
	    case REASON_NO_CHAR:
		break;
	    case REASON_TOO_LONG:
		errmsg("keyword too long", lineno);
		break;
	    }
	    continue;
	}
	
	if (token[0] == '#')
	    continue;
	for (hp = keyword_handlers; hp->keyword != NULL; hp++) {
	    if (strcmp(hp->keyword, token) == 0) {
		(*hp->handler)(lineno, p);
		break;
	    }
	}
	if (hp->keyword == NULL) {
	    errmsg("bad keyword", lineno);
	}
    }
    fclose(fp);
    free(buffer);
    free(token);
    token_buflen = 0;
}

static void handle_buflen(lineno, param)
    int lineno;
    char *param;
{
    char *p, *ep;
    long newlen;
    char **bp;
    long *lp;
    
    if ((p = get_token(param)) == NULL) {
	errmsg("syntax error", lineno);
	return;
    }
    if (strcmp(token, "token") == 0) {
	bp = &token;
	lp = &token_buflen;
    } else if (strcmp(token, "line") == 0) {
	bp = &buffer;
	lp = &buflen;
    } else {
	errmsg("bad name", lineno);
	return;
    }
    
    if ((p = get_token(p)) == NULL) {
	switch (reason_of_null) {
	case REASON_NO_CHAR:
	    errmsg("integer required", lineno);
	    break;
	case REASON_TOO_LONG:
	    errmsg("too long integer", lineno);
	    break;
	}
	return;
    }
    newlen = strtol(token, &ep, 0);
    if (*ep != '\0') {
	errmsg("bad integer", lineno);
	return;
    }
    *lp = newlen;
    *bp = realloc(*bp, *lp);
    if (get_token(p) != NULL || reason_of_null != REASON_NO_CHAR)
	errmsg("garbage chars(ignored)", lineno);
}

static void handle_font(lineno, param)
    int lineno;
    char *param;
{
    char *p;
    
    if ((p = get_token(param)) == NULL || strcmp(token, "icon") != 0) {
	errmsg("syntax error", lineno);
	return;
    }
    if ((p = get_string(p)) == NULL) {
	switch (reason_of_null) {
	case REASON_NO_CHAR:
	    errmsg("font name required", lineno);
	    break;
	case REASON_TOO_LONG:
	    errmsg("font name too long", lineno);
	    break;
	}
	return;
    }
    iconfontname = strdup(token);
    
    if (get_token(p) != NULL || reason_of_null != REASON_NO_CHAR) {
	errmsg("garbage chars(ignored)", lineno);
    }
}

static void handle_action(lineno, param)
    int lineno;
    char *param;
{
    struct keybut *kbp;
    
    param = get_token(param);
    if (param == NULL) {
	errmsg("syntax error", lineno);
	return;
    }
    for (kbp = actions; kbp->function != NULL; kbp++) {
	if (strcmp(kbp->function, token) == 0) {
	    if (kbp->num_accs == 0)
		kbp->accs = (struct acc *) malloc(sizeof *kbp->accs);
	    else {
		kbp->accs =
		    (struct acc *)
		    realloc((char *) kbp->accs,
			    sizeof *kbp->accs * (kbp->num_accs + 1));
	    }
	    if (convert_acc(lineno, param,
			    &kbp->accs[kbp->num_accs], kbp->only_button) < 0) {
		if (kbp->num_accs == 0)
		    free(kbp->accs);
	    } else
		kbp->num_accs++;
	    break;
	}
    }
}

static int convert_acc(lineno, string, acc, only_button)
    int lineno;
    char *string;
    struct acc *acc;
    int only_button;
{
    unsigned long mask;
    unsigned long button, key;
    char *p;
    
    mask = button = key = 0;
    for (p = string; *p != '\0' && *p != '\n'; ) {
	switch (*p) {
	case ' ':					break;
	case '\t':					break;
	case 's':		mask |= ShiftMask;	break;
	case 'l':		mask |= LockMask;	break;
	case 'c':		mask |= ControlMask;	break;
	case 'm':
	    p++;
	    switch (*p) {
	    case '1':		mask |= Mod1Mask;	break;
	    case '2':		mask |= Mod2Mask;	break;
	    case '3':		mask |= Mod3Mask;	break;
	    case '4':		mask |= Mod4Mask;	break;
	    case '5':		mask |= Mod5Mask;	break;
	    default:	goto syntax_error;
	    }
	    break;
	case 'b':
	    p++;
	    if (button != 0 || key != 0)
		goto double_keybut;
	    switch (*p) {
	    case '1':		button = 1;		break;
	    case '2':		button = 2;		break;
	    case '3':		button = 3;		break;
	    case '4':		button = 4;		break;
	    case '5':		button = 5;		break;
	    default:	goto syntax_error;
	    }
	    break;
	case 'k':
	    if (only_button)
		goto cant_use_key;
	    {
		long kc;
		char *ed;
		p++;
		if (button != 0 || key != 0)
		    goto double_keybut;
		
		kc = strtol(p, &ed, 0);
		if (kc < 0 || kc > 255 ||
			kc < setup.minKeyCode || kc > setup.maxKeyCode)
		    goto bad_keycode;
		key = kc;
		p = ed;
	    }
	    break;
	case '1':
	case '2':
	case '3':
	case '4':
	case '5':
	    errmsg("obsolete", lineno);
	    switch (*p) {
	    case '1':		button = 1;		break;
	    case '2':		button = 2;		break;
	    case '3':		button = 3;		break;
	    case '4':		button = 4;		break;
	    case '5':		button = 5;		break;
	    }
	    break;
	default:	goto syntax_error;
	}
	p++;
    }
    
    acc->modifier = mask;
    acc->button = button;
    acc->key = key;
    return 0;
    
syntax_error:
    errmsg("syntax error", lineno);
    return -1;
    
double_keybut:
    errmsg("double key/button", lineno);
    return -1;

cant_use_key:
    errmsg("can't use keys", lineno);
    return -1;

bad_keycode:
    errmsg("bad keycode", lineno);
    return -1;
}

static void handle_exec(lineno, param)
    int lineno;
    char *param;
{
    int acclen;
    char *p, *accstr;
    
    if ((p = strchr(param, '\"')) == NULL) {
	errmsg("no command string", lineno);
	return;
    }
    acclen = p - param;
    accstr = alloca(acclen + 1);
    bcopy(param, accstr, acclen);
    accstr[acclen] = '\0';
    
    if (num_execs == 0)
	execs = (struct exec_t *) malloc(sizeof *execs);
    else
	execs = (struct exec_t *) realloc((char *) execs,
					  sizeof *execs * (num_execs + 1));
    if (convert_acc(lineno, accstr, &execs[num_execs].acc, 0) < 0) {
	if (num_execs == 0)
	    free(execs);
	return;
    }
    
    if ((p = get_string(param + acclen)) == NULL) {
	if (num_execs == 0)
	    free(execs);
	errmsg("command too long", lineno);
	return;
    }
    execs[num_execs].command = strdup(token);
    if (get_string(p) != NULL || reason_of_null != REASON_NO_CHAR) {
	errmsg("garbage chars(ignored)", lineno);
    }
    num_execs++;
}

static void handle_deltastop(lineno, param)
    int lineno;
    char *param;
{
    char *p, *ep;
    long newds;
    
    if ((p = get_token(param)) == NULL) {
	switch (reason_of_null) {
	case REASON_NO_CHAR:
	    errmsg("integer required", lineno);
	    break;
	case REASON_TOO_LONG:
	    errmsg("too big integer", lineno);
	    break;
	}
	return;
    }
    newds = strtol(token, &ep, 0);
    if (*ep != '\0' || newds < 0) {
	errmsg("bad integer", lineno);
	return;
    }
    deltastop = newds;
    if (get_token(p) != NULL || reason_of_null != REASON_NO_CHAR)
	errmsg("garbaage chars(ignored)", lineno);
}

static void handle_xorvalue(lineno, param)
    int lineno;
    char *param;
{
    char *p, *ep;
    long newds;
    
    if ((p = get_token(param)) == NULL) {
	switch (reason_of_null) {
	case REASON_NO_CHAR:
	    errmsg("integer required", lineno);
	    break;
	case REASON_TOO_LONG:
	    errmsg("too big integer", lineno);
	    break;
	}
	return;
    }
    newds = strtol(token, &ep, 0);
    if (*ep != '\0' || newds < 0) {
	errmsg("bad integer", lineno);
	return;
    }
    xorvalue = newds;
    if (get_token(p) != NULL || reason_of_null != REASON_NO_CHAR)
	errmsg("garbaage chars(ignored)", lineno);
}

static void errmsg(msg, lineno)
    char *msg;
    int lineno;
{
    fputs(msg, stderr);
    fputs(" at line ", stderr);
    fputi(lineno, stderr);
    fputs(".\n", stderr);
}

/**/
