#include "config.h"
#include <stdio.h>	/* for NULL */
#ifdef HAVE_STDLIB_H
# include <stdlib.h>	/* for malloc */
#endif
#ifdef HAVE_MALLOC_H
# include <malloc.h>
#endif
#include "queue.h"

struct queue {
    struct qbox *head, *tail;
};

struct qbox {
    struct qbox *next;
    void *value;
};

void *q_alloc()
{
    struct queue *q;
    
    if ((q = (struct queue *) malloc(sizeof *q)) == NULL) {
	fputs("no more memory.\n", stderr);
	exit(1);
    }
    q->head = q->tail = NULL;
    
    return q;
}

void q_put(q, val)
    struct queue *q;
    void *val;
{
    struct qbox *box;
    if ((box = (struct qbox *) malloc(sizeof *box)) == NULL) {
	fputs("no more memory.\n", stderr);
	exit(1);
    }
    box->next = NULL;
    box->value = val;
    if (q->head == NULL) {
	q->head = q->tail = box;
    } else {
	q->tail->next = box;
	q->tail = box;
    }
}

void *q_get(q)
    struct queue *q;
{
    struct qbox *box;
    void *retval;
    
    if (q->head == NULL)
	return NULL;
    
    box = q->head;
    q->head = box->next;
    
    retval = box->value;
    free(box);
    
    return retval;
}

int q_isempty(q)
    struct queue *q;
{
    return q->head == NULL;
}

void q_free(q)
    struct queue *q;
{
    struct qbox *box;
    
    for (box = q->head; box != NULL; ) {
	struct qbox *f = box;
	box = f->next;
	free(f);
    }
}


/**/
