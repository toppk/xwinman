#include "config.h"
#ifdef __GNUC__
# define alloca __builtin_alloca
#else
# if HAVE_ALLOCA_H
#  include <alloca.h>
# else
#  ifdef _AIX
#   pragma alloca
#  else
#   ifndef alloca
extern char *alloca();
#   endif
#  endif
# endif
#endif
#define NEED_EVENTS
#define NEED_REPLIES
#include <X11/X.h>
#include <X11/Xatom.h>
#include <X11/Xproto.h>
#include <stdio.h>
#ifdef HAVE_STDLIB_H
# include <stdlib.h>
#endif
#ifdef HAVE_STRING_H
# include <string.h>
#else
# include <strings.h>
#endif
#ifdef HAVE_UNISTD_H
# include <unistd.h>
#endif

#include "vwm.h"
#include "xlib.h"
#include "queue.h"
#include "assoc.h"

struct window_info {
    CARD32 win, icon, frame;
    CARD32 icon_pixmap;
    INT16 x, y;		/* when iconified. */
    int iconified, just_iconified;
};

static void init_wm();
static void grab_events();
static void event();
static void resize_it(), move_it(), iconify_it();
static void raise_it(), lower_it(), raiselower_it(), moveraiselower_it();
static void create_icon_window();
static int check_deltastop();
static void query_border_position_mn();
static void execute_command();

static CARD32 gc;
static CARD32 font;
static void *window_assoc, *icon_assoc;
unsigned int deltastop = 2;
CARD32 xorvalue = 1;
char *iconfontname = "a14";
struct keybut actions[] = {
    {"resize",         resize_it,         1, 0, NULL },
    {"move",           move_it,           1, 0, NULL },
    {"iconify",        iconify_it,        0, 0, NULL },
    {"raise",          raise_it,          0, 0, NULL },
    {"lower",          lower_it,          0, 0, NULL },
    {"raiselower",     raiselower_it,     0, 0, NULL },
    {"moveraiselower", moveraiselower_it, 1, 0, NULL },
    {NULL,             NULL,              0, 0, NULL },
};
struct exec_t *execs = NULL;
int num_execs = 0;

void work()
{
    
    x_init();
    
    init_wm();
    
    x_main_loop();
}

static void init_wm()
{
    CARD32 root, parent, *children;
    struct exec_t *ep;
    unsigned int num;
    int i;
    
    window_assoc = assoc_alloc();
    icon_assoc = assoc_alloc();
    
    x_set_event_handler(event);
    x_select_input(rootw->windowId,
		   SubstructureRedirectMask
		   | ResizeRedirectMask
		   | ButtonPressMask);
    for (i = num_execs, ep = execs; i > 0; i--, ep++) {
	if (ep->acc.button != 0) {
	    x_grab_button(
		rootw->windowId, ep->acc.button, ep->acc.modifier, 1,
		ButtonPressMask | ButtonReleaseMask | ButtonMotionMask,
		GrabModeAsync, GrabModeAsync, None, None);
	}
	if (ep->acc.key != 0) {
	    x_grab_key(rootw->windowId,
		       ep->acc.key, ep->acc.modifier, 1,
		       GrabModeAsync, GrabModeAsync);
	}
    }
    
    gc = x_create_gc(rootw->windowId);
    font = x_load_font(iconfontname);
    x_set_function(gc, GXxor);
    x_set_foreground(gc, xorvalue);
    x_set_subwindow_mode(gc, 1);
    x_set_font(gc, font);
    
    x_query_tree(rootw->windowId, &root, &parent, &children, &num);
    for (i = 0; i < num; i++) {
	if (children[0] != rootw->windowId) {
	    struct window_info *info;
	    info = (struct window_info *) malloc(sizeof *info);
	    info->win = children[i];
	    info->icon = None;
	    info->iconified = 0;
	    assoc_add(window_assoc, children[i], info);
	    grab_events(children[i]);
#if 0
	    x_set_dont_propagate_mask(children[i],
				      ButtonPressMask | ButtonReleaseMask);
#endif
	}
    }
    free(children);
}

static void grab_events(win)
    CARD32 win;
{
    struct keybut *ap;
    for (ap = actions; ap->function != NULL; ap++) {
	int j;
	struct acc *acc;
	for (j = ap->num_accs, acc = ap->accs; j > 0; j--, acc++) {
	    if (acc->button != 0) {
		x_grab_button(
		    win, acc->button, acc->modifier, 1,
		    ButtonPressMask | ButtonReleaseMask | ButtonMotionMask,
		    GrabModeAsync, GrabModeAsync, None, None);
	    }
	    if (acc->key != 0) {
		x_grab_key(win, acc->key, acc->modifier, 1,
			   GrabModeAsync, GrabModeAsync);
	    }
	}
    }
#if 0
    for (i = num_execs, ep = execs; i > 0; i--, ep++) {
	if (ep->acc.button != 0) {
	    x_grab_button(
		win, ep->acc.button, ep->acc.modifier, 1,
		ButtonPressMask | ButtonReleaseMask | ButtonMotionMask,
		GrabModeAsync, GrabModeAsync, None, None);
	}
	if (ep->acc.key != 0) {
	    x_grab_key(win, ep->acc.key, ep->acc.modifier, 1,
		       GrabModeAsync, GrabModeAsync);
	}
    }
#endif
    x_select_input(win, StructureNotifyMask);
}


static void event(ev)
    xEvent *ev;
{
    struct window_info *info;
    switch (ev->u.u.type) {
    case ReparentNotify:
	break;
    case MapNotify:
	info = assoc_lookup(window_assoc, ev->u.mapNotify.window);
	if (info != NULL) {
	    if (info->iconified)
		x_map_window(info->icon);
	}
	break;
    case UnmapNotify:
	info = assoc_lookup(window_assoc, ev->u.unmapNotify.window);
	if (info != NULL) {
	    if (info->just_iconified)
		info->just_iconified = 0;
	    else {
		if (info->iconified)
		    x_unmap_window(info->icon);
	    }
	}
	break;
    case DestroyNotify:
	info = assoc_lookup(window_assoc, ev->u.destroyNotify.window);
	if (info != NULL) {
	    assoc_del(window_assoc, info->win);
	    if (info->icon != None) {
		assoc_del(icon_assoc, info->icon);
		x_destroy_window(info->icon);
		x_free_pixmap(info->icon_pixmap);
		x_destroy_window(info->frame);
	    }
	    free(info);
	}
	break;
    case MapRequest:
	info = (struct window_info *) malloc(sizeof *info);
	info->win = ev->u.mapRequest.window;
	info->icon = None;
	info->iconified = 0;
	assoc_add(window_assoc, info->win, info);
	grab_events(ev->u.mapRequest.window);
	x_map_window(ev->u.mapRequest.window);
	break;
	
    case ConfigureRequest:
	x_configure_window(ev->u.configureRequest.window,
			   ev->u.configureRequest.valueMask,
			   ev->u.configureRequest.x,
			   ev->u.configureRequest.y,
			   ev->u.configureRequest.width,
			   ev->u.configureRequest.height,
			   ev->u.configureRequest.borderWidth,
			   ev->u.configureRequest.sibling, 0);
	break;
    case ConfigureNotify:
	info = assoc_lookup(window_assoc, ev->u.configureNotify.window);
	if (info != NULL) {
	    info->x = ev->u.configureNotify.x;
	    info->y = ev->u.configureNotify.y;
	}
	break;
    case CirculateRequest:
	x_circulate_window(ev->u.circulate.window,
			   ev->u.circulate.place);
	break;
	
    case ResizeRequest:
	x_resize_window(ev->u.resizeRequest.window,
			ev->u.resizeRequest.width,
			ev->u.resizeRequest.height);
	break;
	
    case ButtonPress:
	{
	    struct acc acc, *accp;
	    struct keybut *ap;
	    struct exec_t *ep;
	    int i;
	    acc.modifier = ev->u.keyButtonPointer.state;
	    acc.button   = ev->u.u.detail;
	    acc.key      = 0;
	    for (ap = actions; ap->function != NULL; ap++) {
		int j;
		for (j = ap->num_accs, accp = ap->accs; j > 0; j--, accp++) {
		    if (bcmp((char *) accp, (char *) &acc, sizeof acc) == 0) {
			(*ap->handler)(ev->u.keyButtonPointer.event,
				       ev->u.keyButtonPointer.eventX,
				       ev->u.keyButtonPointer.eventY);
			break;
		    }
		}
	    }
	    if (ap->function == NULL) {
		for (i = num_execs, ep = execs; i > 0; i--, ep++) {
		    if (bcmp((char *) &ep->acc, 
			     (char *) &acc, sizeof acc) == 0) {
			execute_command(ep->command, ev);
			break;
		    }
		}
	    }
	}
	break;
	
    case KeyPress:
	{
	    struct acc acc, *accp;
	    struct keybut *ap;
	    struct exec_t *ep;
	    int i;
	    acc.modifier = ev->u.keyButtonPointer.state;
	    acc.button   = 0;
	    acc.key      = ev->u.u.detail;
	    for (ap = actions; ap->function != NULL; ap++) {
		int j;
		for (j = ap->num_accs, accp = ap->accs; j > 0; j--, accp++) {
		    if (bcmp((char *) accp, (char *) &acc, sizeof acc) == 0) {
			(*ap->handler)(ev->u.keyButtonPointer.event,
				       ev->u.keyButtonPointer.eventX,
				       ev->u.keyButtonPointer.eventY);
			break;
		    }
		}
	    }
	    if (ap->function == NULL) {
		for (i = num_execs, ep = execs; i > 0; i--, ep++) {
		    if (bcmp((char *) &ep->acc,
			     (char *) &acc, sizeof acc) == 0) {
			execute_command(ep->command, ev);
			break;
		    }
		}
	    }
	}
	break;
    case KeyRelease:
	break;
	
    case ButtonRelease:
#if 0
	fputs("ButtonRelease(", stdout);
	fputi(ev->u.u.detail, stdout);
	fputs(")\n", stdout);
#endif
	break;
	
    case MotionNotify:
#if 0
	fputs("MotionNotify(", stdout);
	fputi(ev->u.u.detail, stdout);
	fputs(")\n", stdout);
#endif
	break;

    default:
	fputs("unexpected event(", stderr);
	fputi(ev->u.u.type, stderr);
	fputs(")\n", stderr);
    }
    remove_defunct_process();
}

static void resize_it(win, x, y)
    CARD32 win;
    INT16 x, y;		/* relative to window */
{
    CARD32 root;
    INT16 left, right, top, bottom;	/* absolute */
    CARD16 width, height, bw;
    INT16 nl, nr, nt, nb;		/* absolute */
    int mode;
    
    x_grab_server();
    
    x_get_geometry(win, &root, &left, &top, &width, &height, &bw, NULL);
    if (x < width / 3)
	mode = 1;
    else if (x < width / 3 * 2)
	mode = 2;
    else
	mode = 3;
    if (y < height / 3)
	mode += 6;
    else if (y < height / 3 * 2)
	mode += 3;
    else
	mode += 0;
    right = left + width - 1;
    bottom = top + height - 1;
    nl = left;
    nr = right;
    nt = top;
    nb = bottom;
    
    x_draw_rectangle(root, gc, nl - 1, nt - 1, nr + 1, nb + 1);
    
    while (1) {
	xEvent *ev;
	INT16 ex, ey;
	ev = x_await_event();
	if (ev->u.u.type == ButtonRelease)
	    break;
	ex = ev->u.keyButtonPointer.rootX;
	ey = ev->u.keyButtonPointer.rootY;
	free(ev);
	x_draw_rectangle(root, gc, nl - 1, nt - 1, nr + 1, nb + 1);
	switch (mode) {
	case 1:
	    if (ex > right)
		ex = right;
	    if (ey < top)
		ey = top;
	    nl = ex;
	    nr = right;
	    nt = top;
	    nb = ey;
	    break;
	case 2:
	    if (ey < top)
		ey = top;
	    nl = left;
	    nr = right;
	    nt = top;
	    nb = ey;
	    break;
	case 3:
	    if (ex < left)
		ex = left;
	    if (ey < top)
		ey = top;
	    nl = left;
	    nr = ex;
	    nt = top;
	    nb = ey;
	    break;
	case 4:
	    if (ex > right)
		ex = right;
	    nl = ex;
	    nr = right;
	    nt = top;
	    nb = bottom;
	    break;
	case 6:
	    if (ex < left)
		ex = left;
	    nl = left;
	    nr = ex;
	    nt = top;
	    nb = bottom;
	    break;
	case 7:
	    if (ex > right)
		ex = right;
	    if (ey > bottom)
		ey = bottom;
	    nl = ex;
	    nr = right;
	    nt = ey;
	    nb = bottom;
	    break;
	case 8:
	    if (ey > bottom)
		ey = bottom;
	    nl = left;
	    nr = right;
	    nt = ey;
	    nb = bottom;
	    break;
	case 9:
	    if (ex < left)
		ex = left;
	    if (ey > bottom)
		ey = bottom;
	    nl = left;
	    nr = ex;
	    nt = ey;
	    nb = bottom;
	}
	x_draw_rectangle(root, gc, nl - 1, nt - 1, nr + 1, nb + 1);
    }
    
    x_draw_rectangle(root, gc, nl - 1, nt - 1, nr + 1, nb + 1);
    x_configure_window(win, CWX | CWY | CWWidth | CWHeight,
		       nl - bw, nt - bw,
		       nr - nl + bw * 2, nb - nt + bw * 2, 0, 0, 0);
    
    x_ungrab_server();
}

static void move_it(win, x, y)
    CARD32 win;
    INT16 x, y;
{
    CARD32 root;
    INT16 left, right, top, bottom;
    CARD16 width, height, bw;
    INT16 nx, ny;
    void *later;
    
    later = q_alloc();
    
    x_grab_server();
    
    x_get_geometry(win, &root, &left, &top, &width, &height, &bw, NULL);
    left += bw;
    top += bw;
    x += left;
    y += top;
    right = left + (INT16) width - 1;
    bottom = top + (INT16) height - 1;
    
    nx = x;
    ny = y;
    query_border_position_mn(root, left, top, right, bottom,
			     x, y, &nx, &ny, later);
    x_configure_window(win, CWX | CWY, left + nx - x - 1, top + ny - y - 1,
		       0, 0, 0, 0, 0);
    
    x_ungrab_server();
    x_putback_events(later);
    q_free(later);
}

static void iconify_it(win, x, y)
    CARD32 win;
    INT16 x, y;
{
    struct window_info *info;
    
    if ((info = assoc_lookup(window_assoc, win)) != NULL) {
	CARD16 width, height;
	
	x_get_geometry(win, NULL, &x, &y, &width, &height, NULL, NULL);
	info->x = x;
	info->y = y;
	
	if (info->icon == None) {
	    info->frame = x_create_window(rootw->windowId,
					  -1, -1, 1, 1, 0,
					  CopyFromParent, CopyFromParent,
					  CopyFromParent, 0, NULL);
	    create_icon_window(info);
	    assoc_add(icon_assoc, info->icon, info);
	    grab_events(info->icon);
	}
	
	x_add_to_save_set(win);
	x_reparent_window(win, info->frame, x, y);
	x_map_window(info->icon);
	info->just_iconified = 1;
    } else if ((info = assoc_lookup(icon_assoc, win)) != NULL) {
	x_unmap_window(info->icon);
	x_reparent_window(info->win, rootw->windowId,
			  info->x, info->y);
	x_remove_from_save_set(info->win);
    }
    
}

static void create_icon_window(info)
    struct window_info *info;
{
    struct x_create_window_attributes attr;
    CARD16 width, as, ds, height;
    char *iname;
    
    iname = x_get_icon_name(info->win);
    x_query_text_extents(font, iname, &width, &as, &ds);
    height = as + ds;
    info->icon_pixmap = x_create_pixmap(info->win, width, height,
					rootw->rootDepth);
    x_set_foreground(gc, rootw->blackPixel);
    x_set_background(gc, rootw->whitePixel);
    x_set_function(gc, GXcopy);
    x_draw_image_text(info->icon_pixmap, gc, iname, 0, as);
    x_set_foreground(gc, xorvalue);
    x_set_function(gc, GXxor);
    
    attr.back_pixmap = info->icon_pixmap;
    info->icon = x_create_window(rootw->windowId, 0, 0, width, height,
				 1, rootw->rootDepth, InputOutput,
				 rootw->rootVisualID,
				 CWBackPixmap, &attr);
}

static void raise_it(win, x, y)
    CARD32 win;
    INT16 x, y;
{
    x_raise_window(win);
}

static void lower_it(win, x, y)
    CARD32 win;
    INT16 x, y;
{
    x_lower_window(win);
}

static void raiselower_it(win, x, y)
    CARD32 win;
    INT16 x, y;
{
    x_configure_window(win, CWStackMode, 0, 0, 0, 0, 0, 0, Opposite);
}

static void moveraiselower_it(win, x, y)
    CARD32 win;
    INT16 x, y;
{
    CARD32 root;
    INT16 left, right, top, bottom;
    CARD16 width, height, bw;
    INT16 nx, ny;
    void *later;
    
    later = q_alloc();
    
    x_grab_server();
    
    x_get_geometry(win, &root, &left, &top, &width, &height, &bw, NULL);
    left += bw;
    top += bw;
    x += left;
    y += top;
    right = left + (INT16) width - 1;
    bottom = top + (INT16) height - 1;
    
    nx = x;
    ny = y;
    if (check_deltastop(&nx, &ny, later)) {
	raiselower_it(win, x, y);
    } else {
	query_border_position_mn(root, left, top, right, bottom,
				 x, y, &nx, &ny, later);
	x_configure_window(win, CWX | CWY, left + nx - x - 1, top + ny - y - 1,
			   0, 0, 0, 0, 0);
    }
    
    x_ungrab_server();
    x_putback_events(later);
    q_free(later);
}

static int check_deltastop(x, y, q)
    INT16 *x, *y;
    void *q;
{
    while (1) {
	xEvent *ev;
	INT16 ex, ey;
	ev = x_await_event();
	if (ev->u.u.type == ButtonRelease) {
	    free(ev);
	    return 1;
	}
	if (ev->u.u.type != MotionNotify) {
	    q_put(q, ev);
	    continue;
	}
	ex = ev->u.keyButtonPointer.rootX;
	ey = ev->u.keyButtonPointer.rootY;
	free(ev);
	if (abs(ex - *x) > deltastop || abs(ey - *y) > deltastop) {
	    *x = ex;
	    *y = ey;
	    return 0;
	}
    }
}

static void query_border_position_mn(root, left, top, right, bottom,
				     x, y, ex, ey, q)
    CARD32 root;
    INT16 left, top, right, bottom, x, y, *ex, *ey;
    void *q;
{
    INT16 nl, nt, nr, nb;
    
    nl = left + *ex - x;
    nt = top + *ey - y;
    nr = right + *ex - x;
    nb = bottom + *ey - y;
    x_draw_rectangle(root, gc, nl - 1, nt - 1, nr + 1, nb + 1);
    while (1) {
	xEvent *ev;
	ev = x_await_event();
	if (ev->u.u.type == ButtonRelease) {
	    free(ev);
	    break;
	}
	if (ev->u.u.type != MotionNotify) {
	    q_put(q, ev);
	    continue;
	}
	*ex = ev->u.keyButtonPointer.rootX;
	*ey = ev->u.keyButtonPointer.rootY;
	free(ev);
	x_draw_rectangle(root, gc, nl - 1, nt - 1, nr + 1, nb + 1);
	nl = left + *ex - x;
	nt = top + *ey - y;
	nr = right + *ex - x;
	nb = bottom + *ey - y;
	x_draw_rectangle(root, gc, nl - 1, nt - 1, nr + 1, nb + 1);
    }
    x_draw_rectangle(root, gc, nl - 1, nt - 1, nr + 1, nb + 1);
}

static void execute_command(command, ev)
    char *command;
    xEvent *ev;
{
    char *p, **pp;
    char *envs[16];
    char *args[4];
    static char *envs_to_pass[] = {
	"USER", "HOME", "PATH", "DISPLAY", "SHELL", "HOST",
    };
    static char *shells[] = {
#ifdef SHELL
	SHELL,
#endif
	"/bin/sh", "/sbin/sh", "/usr/bin/sh", "/usr/sbin/sh", NULL,
    };
    int i, num_envs;
    
    num_envs = 0;
    for (i = 0; i < sizeof envs_to_pass / sizeof envs_to_pass[0]; i++) {
	if ((p = getenv(envs_to_pass[i])) != NULL) {
	    envs[num_envs] = alloca(strlen(p) + strlen(envs_to_pass[i]) + 4);
	    strcpy(envs[num_envs], envs_to_pass[i]);
	    strcat(envs[num_envs], "=");
	    strcat(envs[num_envs], p);
	    num_envs++;
	}
    }
    /*
     * VWMEVENT=type:detail:seq:time:root:event:child:\
     *		rootX:rootY:eventX:eventY:state:sameScreen
     * type = `Key'|`Button'
     * detail = keycode|button#
     * sameScreen = `0'|`1'
     */
    envs[num_envs] = alloca(1024);
    strcpy(envs[num_envs], "VWMEVENT=");
    strcat(envs[num_envs], ev->u.u.type == KeyPress ? "Key" : "Button");
    strcat(envs[num_envs], ":");
    strcat(envs[num_envs], ltoa(ev->u.u.detail));
    strcat(envs[num_envs], ":");
    strcat(envs[num_envs], ltoa(ev->u.u.sequenceNumber));
    strcat(envs[num_envs], ":");
    strcat(envs[num_envs], ltoa(ev->u.keyButtonPointer.time));
    strcat(envs[num_envs], ":");
    strcat(envs[num_envs], ltoa(ev->u.keyButtonPointer.root));
    strcat(envs[num_envs], ":");
    strcat(envs[num_envs], ltoa(ev->u.keyButtonPointer.event));
    strcat(envs[num_envs], ":");
    strcat(envs[num_envs], ltoa(ev->u.keyButtonPointer.child));
    strcat(envs[num_envs], ":");
    strcat(envs[num_envs], ltoa(ev->u.keyButtonPointer.rootX));
    strcat(envs[num_envs], ":");
    strcat(envs[num_envs], ltoa(ev->u.keyButtonPointer.rootY));
    strcat(envs[num_envs], ":");
    strcat(envs[num_envs], ltoa(ev->u.keyButtonPointer.eventX));
    strcat(envs[num_envs], ":");
    strcat(envs[num_envs], ltoa(ev->u.keyButtonPointer.eventY));
    strcat(envs[num_envs], ":");
    strcat(envs[num_envs], ltoa(ev->u.keyButtonPointer.state));
    strcat(envs[num_envs], ":");
    strcat(envs[num_envs], ltoa(ev->u.keyButtonPointer.sameScreen));
    num_envs++;
    envs[num_envs] = NULL;
    
    args[1] = "-c";
    args[2] = command;
    args[3] = NULL;
    
    switch (fork()){
    case -1:
	fputs("vwm: can't fork.\n", stderr);
	break;
    case 0:
	for (pp = shells; *pp != NULL; pp++) {
	    if ((p = strrchr(*pp, '/')) != NULL)
		args[0] = p + 1;
	    else
		args[0] = *pp;
	    execve(*pp, args, envs);
	}
	fputs("can't execute shells.\n", stderr);
	exit(1);
    default:
	;
    }
    
}



/**/
