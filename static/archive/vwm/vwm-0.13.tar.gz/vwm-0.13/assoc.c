#include "config.h"
#include <stdio.h>	/* for NULL */
#ifdef HAVE_STDLIB_H
# include <stdlib.h>	/* for malloc */
#endif
#ifdef HAVE_MALLOC_H
# include <malloc.h>
#endif
#ifdef HAVE_STRING_H
# include <string.h>
#else
# include <strings.h>
#endif
#include "assoc.h"

struct assoc {
    struct entry *array;
    unsigned int num;	/* the number of entries. */
    unsigned int max;	/* the max number of entries. */
#define INITIAL_MAX 10
};

struct entry {
    void *key;
    void *value;
};

void *assoc_alloc()
{
    struct assoc *new;
    
    new = (struct assoc *) malloc(sizeof *new);
    new->num = 0;
    new->max = INITIAL_MAX;
    new->array = (struct entry *) malloc(sizeof *new->array * new->max);
    
    return new;
}

void assoc_add(a, key, val)
    struct assoc *a;
    void *key, *val;
{
    struct entry *ent;
    if (a->num == a->max) {
	a->max += a->max / 2;
	a->array = (struct entry *) realloc(a->array,
					    sizeof *a->array * a->max);
    }
    ent = &a->array[a->num];
    ent->key = key;
    ent->value = val;
    a->num++;
}

void *assoc_lookup(a, key)
    struct assoc *a;
    void *key;
{
    struct entry *ent;
    int i;
    
    for (i = a->num, ent = a->array; i > 0; i--, ent++) {
	if (ent->key == key)
	    return ent->value;
    }
    return NULL;
}

void assoc_del(a, key)
    struct assoc *a;
    void *key;
{
    struct entry *ent;
    int i;
    
    for (i = a->num, ent = a->array; i > 0; i--, ent++) {
	if (ent->key == key)
	    break;
    }
    if (i == 0)
	return;
    
    bcopy((char *) (ent + 1), (char *) ent, sizeof *ent * (i - 1));
    a->num--;
}

void assoc_free(a)
    struct assoc *a;
{
    free(a->array);
    free(a);
}


/**/
