#include "config.h"
#ifdef __GNUC__
# define alloca __builtin_alloca
#else
# if HAVE_ALLOCA_H
#  include <alloca.h>
# else
#  ifdef _AIX
#   pragma alloca
#  else
#   ifndef alloca
extern char *alloca();
#   endif
#  endif
# endif
#endif
#include <X11/X.h>
#include <X11/Xproto.h>
#include <stdio.h>
#include <sys/types.h>
#include <netinet/in.h>
#ifdef HAVE_STDLIB_H
# include <stdlib.h>
#endif
#ifdef HAVE_STRING_H
# include <string.h>
#else
# include <strings.h>
#endif
#include <sys/param.h>
#include "vwm.h"

static int setup_connection();

struct setup_info setup;

int num_pixmap_formats;
int num_window_roots;
struct pixmap_format *pixmap_formats;
static struct window_root *window_roots;
struct window_root *rootw;


static int little_endian()
{
    int s = 1;
    return *(char *) &s;
}

int create_connection(dpyhost, dpy, scr)
    char *dpyhost;
    int dpy, scr;
{
    struct sockaddr_in addr;
    int s;
    
    if ((s = socket(PF_INET, SOCK_STREAM, 0)) < 0) {
	perror("socket");
	exit(1);
    }
    bzero((char *) &addr, sizeof addr);
    addr.sin_family = PF_INET;
    addr.sin_port   = htons(6000 + dpy);
    addr.sin_addr   = get_inet_addr(dpyhost);
    if (addr.sin_addr.s_addr == 0xffffffff) {
	fputs("unknown host.\n", stderr);
	return -1;
    }
    if (connect(s, (struct sockaddr *) &addr, sizeof addr) < 0) {
	perror("connect");
	return -1;
    }
    if (setup_connection(dpyhost, dpy, s) < 0)
	return -1;
    if (scr >= num_window_roots) {
	fputs("bad screen number.\n", stderr);
	return -1;
    }
    rootw = &window_roots[scr];
    return s;
}


static int setup_connection(host, dpy, fd)
    char *host;
    int dpy;
    int fd;
{
    xConnClientPrefix connClientPrefix;
    xConnSetupPrefix connSetupPrefix;
    xConnSetup *connSetup;
    char *p/* , *q */;
    char *proto, *data;
    int proto_len, data_len;
    int i;
    int r = -1;
    CARD32 mask;
    
    connClientPrefix.byteOrder = little_endian() ? 'l' : 'B';
    connClientPrefix.majorVersion = 11;
    connClientPrefix.minorVersion = 0;
    
    if (get_auth(host, dpy, &proto, &proto_len, &data, &data_len) < 0) {
	proto_len = data_len = 0;
	connClientPrefix.nbytesAuthProto  = 0;
	connClientPrefix.nbytesAuthString = 0;
    } else {
	connClientPrefix.nbytesAuthProto  = proto_len;
	connClientPrefix.nbytesAuthString = data_len;
    }
    
    send_packets(fd,
		 &connClientPrefix, sizeof connClientPrefix,
		 proto, proto_len,
		 proto, PAD(proto_len),
		 data, data_len,
		 data, PAD(data_len),
		 NULL);
    
    recv_sized_packet(fd, &connSetupPrefix, sizeof connSetupPrefix);
    
    switch (connSetupPrefix.success) {
    case 0:			/* Failed */
	p = alloca(connSetupPrefix.lengthReason + 1);
	recv_sized_packet(fd, p, connSetupPrefix.lengthReason);
	recv_pad(fd, PAD(connSetupPrefix.lengthReason));
	p[connSetupPrefix.lengthReason] = '\0';
	fputs("connection failed.\n", stderr);
	fputs(p, stderr);
	fputs("\n", stderr);
	r = -1;
	break;
    case 1:			/* Success */
	setup.littleEndian = little_endian();
	setup.majorVersion = connSetupPrefix.majorVersion;
	setup.minorVersion = connSetupPrefix.minorVersion;
	setup.last_seq = 0;
	p = alloca(connSetupPrefix.length * 4);
/*	q = p + connSetupPrefix.length * 4; */
	recv_sized_packet(fd, p, connSetupPrefix.length * 4);
	connSetup = (xConnSetup *)p;
	p += sizeof *connSetup;
	p += connSetup->nbytesVendor;
	p += PAD(connSetup->nbytesVendor);
	setup.rid_mask = connSetup->ridMask;
	setup.rid_base = connSetup->ridBase;
	setup.numRoots = connSetup->numRoots;
	setup.numFormats = connSetup->numFormats;
	setup.minKeyCode = connSetup->minKeyCode;
	setup.maxKeyCode = connSetup->maxKeyCode;
	mask = setup.rid_mask;
	setup.rid_shift = 0;
	while ((mask & 1) == 0) {
	    setup.rid_shift++;
	    mask >>= 1;
	}
	setup.rid_max = setup.rid_mask + 1;
	setup.rid = 0;
	num_pixmap_formats = connSetup->numFormats;
	pixmap_formats = (struct pixmap_format *)
	    malloc(sizeof *pixmap_formats * num_pixmap_formats);
	for (i = 0; i < num_pixmap_formats; i++) {
	    xPixmapFormat *pixmapFormat;
	    pixmapFormat = (xPixmapFormat *) p;
	    p += sizeof *pixmapFormat;
	    pixmap_formats[i].depth = pixmapFormat->depth;
	    pixmap_formats[i].bitsPerPixel = pixmapFormat->bitsPerPixel;
	    pixmap_formats[i].scanLinePad = pixmapFormat->scanLinePad;
	}
	num_window_roots = connSetup->numRoots;
	window_roots = (struct window_root *)
	    malloc(sizeof *window_roots * num_window_roots);
	for (i = 0; i < num_window_roots; i++) {
	    xWindowRoot *windowRoot;
	    int j;
	    windowRoot = (xWindowRoot *) p;
	    p += sizeof *windowRoot;
	    window_roots[i].windowId         = windowRoot->windowId;
	    window_roots[i].defaultColormap  = windowRoot->defaultColormap;
	    window_roots[i].whitePixel       = windowRoot->whitePixel;
	    window_roots[i].blackPixel       = windowRoot->blackPixel;
	    window_roots[i].currentInputMask = windowRoot->currentInputMask;
	    window_roots[i].pixWidth         = windowRoot->pixWidth;
	    window_roots[i].pixHeight        = windowRoot->pixHeight;
	    window_roots[i].mmWidth          = windowRoot->mmWidth;
	    window_roots[i].mmHeight         = windowRoot->mmHeight;
	    window_roots[i].minInstalledMaps = windowRoot->minInstalledMaps;
	    window_roots[i].maxInstalledMaps = windowRoot->maxInstalledMaps;
	    window_roots[i].rootVisualID     = windowRoot->rootVisualID;
	    window_roots[i].backingStore     = windowRoot->backingStore;
	    window_roots[i].saveUnders       = windowRoot->saveUnders;
	    window_roots[i].rootDepth        = windowRoot->rootDepth;
	    window_roots[i].nDepths          = windowRoot->nDepths;
	    window_roots[i].depths = (struct depth *)
		malloc(sizeof(struct depth) * window_roots[i].nDepths);
	    for (j = 0; j < windowRoot->nDepths; j++) {
		int k;
		xDepth *depth;
		depth = (xDepth *) p;
		p += sizeof *depth;
		window_roots[i].depths[j].depth = depth->depth;
		window_roots[i].depths[j].nVisuals = depth->nVisuals;
		window_roots[i].depths[j].visual_types = (struct visual_type *)
		    malloc(sizeof(struct visual_type) * depth->nVisuals);
		for (k = 0; k < depth->nVisuals; k++) {
		    xVisualType *visualType;
		    visualType = (xVisualType *) p;
		    p += sizeof *visualType;
		    window_roots[i].depths[j].visual_types[k].visualID
			= visualType->visualID;
		    window_roots[i].depths[j].visual_types[k].class
			= visualType->class;
		    window_roots[i].depths[j].visual_types[k].bitsPerRGB
			= visualType->bitsPerRGB;
		    window_roots[i].depths[j].visual_types[k].colormapEntries
			= visualType->colormapEntries;
		    window_roots[i].depths[j].visual_types[k].redMask
			= visualType->redMask;
		    window_roots[i].depths[j].visual_types[k].greenMask
			= visualType->greenMask;
		    window_roots[i].depths[j].visual_types[k].blueMask
			= visualType->blueMask;
		}
	    }
	}
	r = 0;
	break;
    case 2:			/* Authenticate */
	p = alloca(connSetupPrefix.length * 4);
	recv_sized_packet(fd, p, connSetupPrefix.length * 4);
	fputs("more auth required: ", stderr);
	fputs(p, stderr);
	fputs("\n", stderr);
	exit(1);
    }
    return r;
}

/**/
