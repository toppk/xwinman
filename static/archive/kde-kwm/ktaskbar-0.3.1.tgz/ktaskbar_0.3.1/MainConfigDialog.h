// -*- C++ -*-

#ifndef MainConfigDialog_included
#define MainConfigDialog_included

#include <qdialog.h>

#include <core/kapp.h>

class MainConfigDialogData;
class TaskBar;

class MainConfigDialog : public QDialog
{
  Q_OBJECT;
public:
  MainConfigDialog( KConfig *conf, TaskBar* par, const char* name = NULL );

public slots:
  void invoke() { readConfig(); show(); }

protected slots:
  void selectPixmap();
  void accept();
  void restart();

protected:
  void readConfig();
  void writeConfig();

  MainConfigDialogData* data;
  KConfig *config;
  QString  pixmap_name;
  TaskBar *parent;
};
#endif // MainConfigDialog_included

