// -*- C++ -*-


#ifndef ConfMenuDialog_included
#define ConfMenuDialog_included

#include <qdialog.h>
#include <qlined.h>

class QLabel;
class QComboBox;
class QPushButton;
class ConfMenuDialogData;
class MenuButton;

class PLineEdit : public QLineEdit
{
  Q_OBJECT;
public:
  PLineEdit(QWidget* parent=0, const char* name=0)
    : QLineEdit(parent, name) { initMetaObject(); }
  ~PLineEdit() {}
protected:
  virtual void focusOutEvent (QFocusEvent* e) 
  { emit returnPressed(); QLineEdit::focusOutEvent(e); }
};

class ConfMenuDialog : public QDialog
{
  friend MenuButton;
  Q_OBJECT;  
public:
  ConfMenuDialog(QWidget* parent = NULL, const char* name = NULL );

public slots:
  void invoke() { exec(); }

protected slots:
  void pixnameChanged ();
  void pixButPressed ();
  
protected:
  void initChildPointer();

  ConfMenuDialogData *itsDialogData;
  QString             old_pixname;
  QLineEdit          *i_name;
  PLineEdit          *i_pixmap;
  QLineEdit          *i_command;
  QComboBox          *c_type;
  QPushButton        *b_pixmap;
  QPushButton        *b_ok;
  QPushButton        *b_cancel;
};

#endif // ConfMenuDialog_included
