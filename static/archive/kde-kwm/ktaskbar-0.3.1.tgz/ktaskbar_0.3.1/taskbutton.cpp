
//
//  ktaskbar
//
//  Copyright (C) 1997 Christoph Neerfeld
//  email:  Christoph.Neerfeld@mail.bonn.netsurf.de
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//

#include <qpushbt.h>

#include <core/kpixmap.h>
#include "taskbutton.h"

//----------------------------------------------------------------------
//---------------  TASKBUTTON  -----------------------------------------
//----------------------------------------------------------------------


TaskButton::TaskButton( const char *text, QWidget *parent,
                          const char *name )
  : QPushButton( text, parent, name )
{
  bpixmap = NULL;
  grayed  = FALSE;
}

QSize TaskButton::sizeHint()
{
  int w, h;
  int tw, th;
  int pw, ph;
  w = h = th = tw = ph = pw = 0;
  if ( bpixmap )
    {
      QPixmap *pm = (QPixmap *) bpixmap;
      pw = pm->width()  + 6;
      ph = pm->height() + 6;
    } 
  if( text() )
    {
      QFontMetrics fm = fontMetrics();
      QRect br = fm.boundingRect( text() );
      //tw = fm.width( text () )  + 6;
      //th = fm.height() + 6;
      tw = br.width()  + 6;
      th = br.height() + 6;
      tw += tw/8 + 16;
      th += th/8 + 8;
    }
  if( text() && bpixmap )
    {
      h = (th > ph ? th : ph) - 6;
      w = tw + pw - 2;
    }
  else if( text() )
    { return QSize( tw, th ); }
  else
    { return QSize( pw, ph ); }
  return QSize( w, h );
}

void TaskButton::setPixmap( const QPixmap &pixmap )
{
  int w, h;
  if ( bpixmap ) 
    {
      w = bpixmap->width();
      h = bpixmap->height();
    } 
  else
    {
      bpixmap = new QPixmap;
      w = h = -1;
    }
  *bpixmap = pixmap;
  if ( autoResize() &&  (w != bpixmap->width() || h != bpixmap->height()) )
    adjustSize();
  else
    {
      if ( w >= 0 && w <= bpixmap->width() && h <= bpixmap->height() )
	{
	  QPainter paint;
	  paint.begin( this );
	  drawButtonLabel( &paint );
	  paint.end();
	}
      else
	update();
    }
}

void TaskButton::drawButtonLabel( QPainter *paint )
{
  register QPainter *p = paint;
  GUIStyle    gs = style();
  QColorGroup g  = colorGroup();
  int         dt = 0;
  switch ( gs )
    {
    case WindowsStyle:
      dt = 1;
      break;
    case MotifStyle:
      p->setPen( g.text() );
      break;
    default:
      ;
    }
  if( grayed )
    p->setPen( palette().disabled().text() );
  QRect r = rect();
  int x, y, w, h;
  r.rect( &x, &y, &w, &h );
  if ( isDown() || isOn() )
    {                 // shift pixmap/text
      x += dt;
      y += dt;
    }
  x += 2;  y += 2;  w -= 4;  h -= 4;
  const QPixmap *pm = bpixmap;
  if ( bpixmap ) 
    {
      if ( pm->width() > w || pm->height() > h )
	p->setClipRect( x, y, w, h );
      if ( gs == WindowsStyle && !isDown() && isOn() ) 
	{
	  if ( pm->depth() == 1 )
	    p->setBackgroundColor( g.background().light() );
	} 
      else
	{
            p->setBackgroundColor( g.background() );
        }
      if( text() )
	x += 2;
      else
	x += w/2 - pm->width()/2;               // center
      // y += h/2 - pm->height()/2;
      p->drawPixmap( x, y + h/2 - pm->height()/2, *pm );
      p->setClipping( FALSE );
    }
  if ( text() )
    if( bpixmap )
      {
	w -= (4 + pm->width());
	QFontMetrics fm = p->fontMetrics();
	QString str = text();
	if( fm.width(str) > w )
	  { 
	    short len = str.length();
	    while( fm.width( str, len ) > w )
	      {
		len--;
	      }
	    str.truncate(len);
	    str += "...";
	    p->drawText( x+pm->width()+2, y, w, h, AlignLeft|AlignVCenter|ShowPrefix, str );
	  }
	p->drawText( x+pm->width()+2, y, w, h, AlignLeft|AlignVCenter|ShowPrefix, text() );
      }
    else
      {
	w -= 2;
	QFontMetrics fm = p->fontMetrics();
	QString str = text();
	if( fm.width(str) > w )
	  { 
	    short len = str.length();
	    while( fm.width( str, len ) > w )
	      {
		len--;
	      }
	    str.truncate(len);
	    str += "...";
	    p->drawText( x+2, y, w, h, AlignLeft|AlignVCenter|ShowPrefix, str );
	  }
	else
	  p->drawText( x+2, y, w, h, AlignLeft|AlignVCenter|ShowPrefix, text() );
      }
}

void TaskButton::mousePressEvent( QMouseEvent *e)
{
  if ( isDown() )
    return;
  bool hit = hitButton( e->pos() );
  if ( hit ) 
    {                                // mouse press on button
      if( e->button() == LeftButton )
	{ emit pressed();
	setDown( TRUE ); }
      else if( e->button() == MidButton )
	emit Mpressed();
      else
	{ emit Rpressed();
	setDown( TRUE ); }
      repaint( FALSE );
    }
}

void TaskButton::mouseReleaseEvent( QMouseEvent *e)
{
  if ( !isDown() && e->button() == LeftButton )
    return;
  bool hit = hitButton( e->pos() );
  setDown( FALSE );
  if ( hit )
    {                                // mouse release on button
      if ( isToggleButton() )
	setOn( !isOn() );
      repaint( FALSE );
      if ( isToggleButton() )
	emit toggled( isOn() );
      if( e->button() == LeftButton )
	{ emit released();
	emit clicked(); }
      else if( e->button() == MidButton )
	{ emit Mreleased();
	emit Mclicked(); }
      else
	{ emit Rreleased();
	emit Rclicked(); }
    }
  else
    {
      repaint( FALSE );
      if( e->button() == LeftButton )
	emit released();
      else if( e->button() == MidButton )
	emit Mreleased();
      else
	emit Rreleased();
    }
}

void TaskButton::mouseMoveEvent( QMouseEvent *e)
{
  if ( isDown()  )
    return;                                 // left mouse button is up
  bool hit = hitButton( e->pos() );
  if ( hit )
    {                                // mouse move in button
      if ( !isDown() ) {
	setDown( TRUE );
	repaint( FALSE );
 	if( e->button() == LeftButton )
	  emit pressed();
	else if( e->button() == MidButton )
	  emit Mpressed();
	else
	  emit Rpressed();
      }
    }
  else
    {                                    // mouse move outside button
      if ( isDown() )
	{
	  setDown( FALSE );
	  repaint( FALSE );
	  if( e->button() == LeftButton )
	    emit released();
	  else if( e->button() == MidButton )
	    emit Mreleased();
	  else
	    emit Rreleased();
	}
    }
}
