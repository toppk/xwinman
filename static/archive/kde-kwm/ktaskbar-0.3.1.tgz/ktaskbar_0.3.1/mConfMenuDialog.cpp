/****************************************************************************
** PLineEdit meta object code from reading C++ file 'ConfMenuDialog.h'
**
** Created: Tue Feb 4 12:32:19 1997
**      by: The Qt Meta Object Compiler ($Revision: 2.5.2.1 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include <qmetaobj.h>
#include "ConfMenuDialog.h"


const char *PLineEdit::className() const
{
    return "PLineEdit";
}

QMetaObject *PLineEdit::metaObj = 0;

void PLineEdit::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QLineEdit::metaObject() )
	QLineEdit::initMetaObject();
    metaObj = new QMetaObject( "PLineEdit", "QLineEdit",
	0, 0,
	0, 0 );
}


const char *ConfMenuDialog::className() const
{
    return "ConfMenuDialog";
}

QMetaObject *ConfMenuDialog::metaObj = 0;

void ConfMenuDialog::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QDialog::metaObject() )
	QDialog::initMetaObject();
    typedef void(ConfMenuDialog::*m1_t0)();
    typedef void(ConfMenuDialog::*m1_t1)();
    typedef void(ConfMenuDialog::*m1_t2)();
    m1_t0 v1_0 = &ConfMenuDialog::invoke;
    m1_t1 v1_1 = &ConfMenuDialog::pixnameChanged;
    m1_t2 v1_2 = &ConfMenuDialog::pixButPressed;
    QMetaData *slot_tbl = new QMetaData[3];
    slot_tbl[0].name = "invoke()";
    slot_tbl[1].name = "pixnameChanged()";
    slot_tbl[2].name = "pixButPressed()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    metaObj = new QMetaObject( "ConfMenuDialog", "QDialog",
	slot_tbl, 3,
	0, 0 );
}
