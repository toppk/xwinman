/****************************************************************************
** PixmapCanvas meta object code from reading C++ file 'pixloader.h'
**
** Created: Tue Feb 4 12:32:19 1997
**      by: The Qt Meta Object Compiler ($Revision: 2.5.2.1 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include <qmetaobj.h>
#include "pixloader.h"


const char *PixmapCanvas::className() const
{
    return "PixmapCanvas";
}

QMetaObject *PixmapCanvas::metaObj = 0;

void PixmapCanvas::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QTableView::metaObject() )
	QTableView::initMetaObject();
    typedef void(PixmapCanvas::*m2_t0)(const char*);
    typedef void(PixmapCanvas::*m2_t1)();
    m2_t0 v2_0 = &PixmapCanvas::nameChanged;
    m2_t1 v2_1 = &PixmapCanvas::doubleClicked;
    QMetaData *signal_tbl = new QMetaData[2];
    signal_tbl[0].name = "nameChanged(const char*)";
    signal_tbl[1].name = "doubleClicked()";
    signal_tbl[0].ptr = *((QMember*)&v2_0);
    signal_tbl[1].ptr = *((QMember*)&v2_1);
    metaObj = new QMetaObject( "PixmapCanvas", "QTableView",
	0, 0,
	signal_tbl, 2 );
}

// SIGNAL nameChanged
void PixmapCanvas::nameChanged( const char* t0 )
{
    activate_signal( "nameChanged(const char*)", t0 );
}

// SIGNAL doubleClicked
void PixmapCanvas::doubleClicked()
{
    activate_signal( "doubleClicked()" );
}


const char *PixLoaderDialog::className() const
{
    return "PixLoaderDialog";
}

QMetaObject *PixLoaderDialog::metaObj = 0;

void PixLoaderDialog::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QDialog::metaObject() )
	QDialog::initMetaObject();
    metaObj = new QMetaObject( "PixLoaderDialog", "QDialog",
	0, 0,
	0, 0 );
}


const char *PixmapLoader::className() const
{
    return "PixmapLoader";
}

QMetaObject *PixmapLoader::metaObj = 0;

void PixmapLoader::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QObject::metaObject() )
	QObject::initMetaObject();
    metaObj = new QMetaObject( "PixmapLoader", "QObject",
	0, 0,
	0, 0 );
}
