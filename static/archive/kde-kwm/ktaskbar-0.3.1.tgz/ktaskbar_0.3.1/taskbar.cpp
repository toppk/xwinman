
//
//  ktaskbar
//
//  Copyright (C) 1997 Christoph Neerfeld
//  email:  Christoph.Neerfeld@mail.bonn.netsurf.de
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//


#include <qfont.h>
#include <qstring.h>
#include <qdstream.h>
#include <qtstream.h>
#include <qfile.h>
#include <qpainter.h>
#include <qsize.h>
#include <qapp.h>
#include <qsocknot.h>
#include <qbttngrp.h>
#include <qlabel.h>
#include <qdatetm.h>
#include <qtimer.h>
#include <qdatetm.h>
#include <qtstream.h>
#include <qlistbox.h>
#include <qframe.h>
#include <qpushbt.h>
#include <qlined.h>
#include <qstrlist.h>
#include <qlayout.h>

#include <core/kpixmap.h>
#include <core/kapp.h>
#include "kwmcom.h"
#include "cpopmenu.h"
#include "pmenu.h"
#include "taskbar.h"
#include "taskconfig.h"
#include "MainConfigDialog.h"
#include "pixloader.h"

extern "C" {
#include "module.h"
#include "fvwmlib.h"
#include <stdlib.h>
}

extern PixmapLoader *global_pix_loader;
extern bool use_kwm;

const taskbar_height = 24;

int _getprop(Window w, Atom a, Atom type, long len, unsigned char **p)
{
  Atom real_type;
  int format;
  unsigned long n, extra;
  int status;
  
  status = XGetWindowProperty(qt_xdisplay(), w, a, 0L, len, False, type, &real_type, &format,
			      &n, &extra, p);
  if (status != Success || *p == 0)
    return -1;
  if (n == 0)
    XFree((void*) *p);
  /* could check real_type, format, extra here... */
  return n;
}

char * getprop(Window w, Atom a) 
{
  unsigned char *p;

  if (_getprop(w, a, XA_STRING, 100L, &p) <= 0)
    return 0;
  return (char *)p;
}

//--------------------------------------------------

WinInfo::WinInfo( int o_pipe, WinInfoList *p )
{
  initMetaObject();
  id = -1; 
  out_pipe = o_pipe;
  iconified = FALSE;
  repaint    = TRUE;
  parent = p;
  ignore = FALSE;
  pixmap = NULL;
}

WinInfo::~WinInfo()
{
  if( button )
    delete button;
}

void WinInfo::left_but()
{
  if( iconified )
    {
      if( !use_kwm )
	::SendInfo( &out_pipe, "Iconify", id );
    }
  if( use_kwm )
    {
      kwmcom_send_to_kwm(kwm_un_minimize_window, id);
    }
  else
    {
      ::SendInfo( &out_pipe, "Focus", id );
    }
}

void WinInfo::mid_but()
{
  emit midPressed( id );
}

void WinInfo::right_but()
{
  if( !use_kwm )
    ::SendInfo( &out_pipe, "Iconify", id );
}

//----------------------------------------------------------------------
//---------------  WININFOLIST  ----------------------------------------
//----------------------------------------------------------------------


WinInfoList::WinInfoList ( TaskbarConfig *task_conf,  int i_fd, int o_fd, QButtonGroup *btg )
{
  initMetaObject();
  current_focus = 0;
  task_config_w = task_conf;
  in_pipe = i_fd;
  out_pipe = o_fd;
  bt_group = btg;
  draw = FALSE;
  nr = 0;
  bt_nr = 0;
  list.setAutoDelete(TRUE);
  mid_menu.insertItem("(Un)maximize", this, SLOT(maximizeWin()) );
  mid_menu.insertItem("(Un)stick", this, SLOT(stickWin()) );
  mid_menu.insertItem("Close", this, SLOT(closeWin()) );
  mid_menu.insertItem("Identify", this, SLOT(identifyWin()) );
}

WinInfoList::~WinInfoList()
{
  list.clear();
}

WinInfo *WinInfoList::add()
{
  bt_nr++;
  WinInfo *new_item = new WinInfo( out_pipe, this );
  new_item->button = new TaskButton("", bt_group);
  new_item->button->setFont( QFont("Helvetica", 12, QFont::Normal) );
  connect( new_item->button, SIGNAL(clicked()), new_item, SLOT(left_but()) );
  connect( new_item->button, SIGNAL(Rclicked()), new_item, SLOT(right_but()) );
  connect( new_item->button, SIGNAL(Mpressed()), new_item, SLOT(mid_but()) );
  connect( new_item, SIGNAL(midPressed(long)), this, SLOT(popupMidMenu(long)) );
  list.append( new_item );
  nr++;
  return new_item;
}

WinInfo* WinInfoList::exists( long id )
{
  WinInfo *item;
  for( item = list.first(); item != NULL; item = list.next() )
    {
      if( item->id == id )
	return item;
    }
  return NULL;
}

void WinInfoList::remove(WinInfo *win)
{
  list.remove(win);
  bt_nr--;
  nr--;
}

void WinInfoList::draw_but()
{
  WinInfo *item;
  int width;
  int x = 0;
  QFont font;
  if( bt_nr != 0 )
    {
      width = bt_group->width() / bt_nr;
      if( width > 180 )
	width = 180;
    }
  else
    {
      width = 180;
    }
  if( !draw )
    return;
  //debug("begin to draw buttons");
  for( item = list.first(); item != NULL; item = list.next() )
    {
      if( item == NULL )
	{ continue; }
      if( item->ignore )
	{ 
	  item->button->hide();
	  continue; 
	}
      //debug( "but = %s", (const char *) item->name );
      item->button->setText( (const char *) item->name );
      item->button->setPixmap( item->pixmap );
      item->button->setGeometry(x, 0, width, 24);
      item->button->set_grayed( item->iconified );
      x += width;
      item->button->show();
      if( item->repaint )
	{
	  if( item->id == (int) current_focus )
	    {
	      item->button->setToggleButton(TRUE);
	      item->button->setOn(TRUE);
	      font = item->button->font();
	      font.setBold(TRUE);
	      item->button->setFont(font);
	    }
	  if( item->id == (int) last_focus )
	    {
	      item->button->setToggleButton(FALSE);
	      font = item->button->font();
	      font.setBold(FALSE);
	      item->button->setFont(font);
	    }
	  item->button->repaint(FALSE);
	  item->repaint = FALSE;
	}
    }
}

void WinInfoList::read()
{
  unsigned long header[HEADER_SIZE];
  unsigned long *body;
  bool redraw=false;
  QString wmString;
  WinInfo *window;
  if( ReadFvwmPacket( in_pipe, header, &body) > 0 )
    {
      //debug ( "type = %i", header[1] );
      switch(header[1]) {
      case M_NEW_PAGE:
	x = body[0];
	y = body[1];
	desk = body[2];
	break;
      case M_ADD_WINDOW:
      case M_CONFIGURE_WINDOW:
	if( (window = exists(body[0])) )
	  {
	    window->id = body[0];
	    window->x = body[3];
	    window->y = body[4];
	    window->desk = body[5];
	  }
	else
	  { // new window
	    window = add();
	    window->id = body[0];
	    window->x = body[3];
	    window->y = body[4];
	    window->desk = body[5];
	    redraw = true;
	  }
	break;
      case M_DESTROY_WINDOW:
	if( (window = exists(body[0])) )
	  {
	    remove(window);
	    redraw=true;
	  }	
	break;
      case M_ICON_NAME:
	break;
      case M_WINDOW_NAME:
	if( (window = exists(body[0])) == NULL )
	  break;
	window->name = (char *) &body[3];

	if( window->name == "KTaskbar" )
	  emit wmWinId( body[0] );
        window->pixmap = task_config_w->pix_contains(window->name);
	if( task_config_w->skip_contains(window->name) )
	  {
	    if( !window->ignore )
	      bt_nr--;
	    window->ignore = TRUE;
	  }
	else
	  {
	    if( window->ignore )
	      {
		window->ignore = FALSE;
		bt_nr++;
	      }
	  }
	redraw=true;
	break;
      case M_DEICONIFY:
	if( (window = exists(body[0])) == NULL )
	  break;
	window->iconified = FALSE;
        window->repaint = TRUE;
	redraw = true;
	break;
      case M_ICONIFY:
	if( (window = exists(body[0])) == NULL )
	  break;
	window->iconified = TRUE;
        window->repaint = TRUE;
	redraw = true;
	break;
      case M_FOCUS_CHANGE:
	if( (window = exists(body[0])) == NULL )
	  break;
	if( current_focus != body[0] )
	  {
	    last_focus = current_focus;
	    current_focus = body[0];
	    window->repaint = TRUE;
	    if( (window = exists(last_focus)) != NULL )
	      window->repaint = TRUE;
	    redraw = TRUE;
	  }
	break;
      case M_STRING:
	wmString = (char *) &body[3];
debug("%s", (const char *) wmString);
	if( wmString == "PopupMenu" )
	  emit wmRequestPopup();
	else if ( wmString == "Iconify" )
	  emit wmRequestIconify();
	else if ( wmString == "Deiconify" )
	  emit wmRequestDeiconify();
	break;
      case M_END_WINDOWLIST:
	draw = TRUE;
	redraw = TRUE;
	break;
      case M_NEW_DESK:
	break;
      }
      delete body;
    }
  if( redraw )
    draw_but();
}

void WinInfoList::popupMidMenu(long id)
{
  popup_win = id;
  WinInfo *info = exists(id);
  int dh = QApplication::desktop()->height();
  QPoint p( bt_group->cursor().pos().x()-35, dh - 48 );
  mid_menu.popup(p, 3);
}

void WinInfoList::maximizeWin()
{
  QString temp, t2;
  int dw = QApplication::desktop()->width();
  int dh = QApplication::desktop()->height();
  temp = "Maximize " + t2.setNum(dw) + "P ";
  temp += t2.setNum(dh-24) + 'P';
  if( !use_kwm )
    ::SendInfo( &out_pipe, (char *) ((const char *) temp), popup_win );  
}

void WinInfoList::stickWin()
{
  if( !use_kwm )
    ::SendInfo( &out_pipe, "Stick", popup_win );
}

void WinInfoList::closeWin()
{
  if( !use_kwm )
    ::SendInfo( &out_pipe, "Close", popup_win );
}

void WinInfoList::identifyWin ()
{
  if( !use_kwm )
    ::SendInfo( &out_pipe, "Module FvwmIdent", popup_win );
}

//----------------------------------------------------------------------
//---------------  TASKBAR  --------------------------------------------
//----------------------------------------------------------------------

TaskBar::TaskBar (int *fd, KConfig *conf, WFlags win_flags )
     //  : QWidget(0, NULL, WStyle_Customize | WStyle_NoBorder )
  : QWidget(0, NULL, win_flags )
{
  initMetaObject();
  config        = conf;
  menu_data     = NULL;
  net_menu_dat  = NULL;
  con_menu_dat  = NULL;
  menu_config_w = NULL;
  main_config_w = NULL;
  connected     = 0;
  minutes = hours = 0;
  in_pipe       = fd[1];
  out_pipe      = fd[0];
  if( use_kwm )
    {
      kwmcom_init(qt_xdisplay(), winId());
      kwmcom_send_to_kwm(kwm_register_module);
    }
  // read rc file
  config->setGroup("ktaskbar");
  use_net_but   = config->readNumEntry("use_net_button")   ? TRUE : FALSE;
  use_netsc_but = config->readNumEntry("use_netsc_button") ? TRUE : FALSE;
  use_clock     = config->readNumEntry("use_clock")        ? TRUE : FALSE;
  menu_file = config->readEntry("menu_config_file");
  menu_file.detach();
  QString home = getenv("HOME");
  if( menu_file.isEmpty() )
    {
      menu_file = home + "/.ktaskbar_menu";
    }
  else
    {
      if( menu_file[0] = '~' )
	{
	  menu_file.remove(0,1);
	  menu_file = home + menu_file;
	}
    }
  //---- end reading rc file
  QWidget *desk = QApplication::desktop();
  int dw = desk->width();
  int dh = desk->height();
  setGeometry( 0, dh - taskbar_height, dw, taskbar_height );
  setCaption("KTaskbar");
  bar_width = width();
  bar_left_pos = 0;
  QFont font("Helvetica", 12, QFont::Bold);
  //----
  menu_bt = new TaskButton(config->readEntry("menu_button_text"), this);
  menu_bt->setFont(font);
  menu_bt->setPixmap( global_pix_loader->loadPixmap(config->readEntry("menu_button_pixmap")) );
  menu_bt->resize(menu_bt->sizeHint().width(), 24);
  bar_left_pos += menu_bt->width()+3;
  connect( menu_bt, SIGNAL(clicked()), this, SLOT(menu_bt_clicked()) );
  //---- end of menu button config
  task_config_w = new TaskbarConfig(config, out_pipe);
  bt_group = new QButtonGroup(this);
  bt_group->resize( width()-menu_bt->width()-91, taskbar_height );
  bt_group->setFrameStyle( QFrame::NoFrame );
  info_list = new WinInfoList( task_config_w, in_pipe, out_pipe, bt_group );
  connect( info_list, SIGNAL(wmRequestPopup()), this, SLOT(menu_bt_clicked()) );
  connect( info_list, SIGNAL(wmRequestIconify()), this, SLOT(taskbarIconify()) );
  connect( info_list, SIGNAL(wmRequestDeiconify()), this, SLOT(taskbarDeiconify()) );
  connect( info_list, SIGNAL(wmWinId(long)), this, SLOT(wmWinId(long)) );
  //---- end of taskbar config
  prog_menu.setFont(font);
  net_b = new TaskButton( "", this);
  net_b->setPixmap( global_pix_loader->loadPixmap("mini-connect.xpm") );
  net_b->resize(taskbar_height, taskbar_height);
  bar_width -= net_b->width();
  net_menu = new CPopupMenu;
  net_menu->setFont(font);
  connect( net_b, SIGNAL(clicked()), this, SLOT(net_bt_clicked()) );
  // create connected button
  con_b = new TaskButton( "==:==", this );
  con_b->setPixmap( global_pix_loader->loadPixmap("mini-connected.xpm") );
  con_b->resize(54, taskbar_height);
  con_menu = new CPopupMenu;
  con_menu->setFont(font);
  connect( con_b, SIGNAL(clicked()), this, SLOT(con_bt_clicked()) );
  con_b->hide();
  if( !use_net_but )
    net_b->hide();

  rebuildMenu();
  //----
  netsc_b = new TaskButton( "", this);
  netsc_b->setPixmap( global_pix_loader->loadPixmap("mini-nscape.xpm") );
  netsc_b->resize(taskbar_height, taskbar_height);
  connect( netsc_b, SIGNAL(clicked()), this, SLOT(netsc_bt_clicked()) );
  bar_width -= netsc_b->width();
  if( !use_netsc_but )
    netsc_b->hide();
  //---- end of button config
  QTime time;
  time = QTime::currentTime();
  QString time_str = time.toString();
  time_str.truncate(5);
  clock = new QLabel( (const char *) time_str, this);
  clock->resize( 40, taskbar_height );
  bar_width -= clock->width();
  clock->setFrameStyle( QFrame::Panel | QFrame::Sunken );
  clock->setAlignment( AlignCenter );
  font.setBold(FALSE);
  clock->setFont(font);
  QTimer::singleShot( (60 - time.second()) * 1000, this, SLOT(update_clock()) );
  if( !use_clock )
    clock->hide();
  //---- end of clock config
  cleanupBar();

  if( use_kwm )
    {
      pipe_check = NULL;
      info_list->draw = TRUE;
    }
  else
    {
      pipe_check = new QSocketNotifier( in_pipe, QSocketNotifier::Read );
      QObject::connect( pipe_check, SIGNAL(activated(int)), info_list, SLOT(read()) );
    }

  configureWM();
  if( !use_kwm )
    {
      ::SendInfo( &out_pipe, "Recapture", 0);
      ::SendInfo( &out_pipe, "Send_WindowList", 0);
    }
}

TaskBar::~TaskBar()
{
  if(use_kwm)
    kwmcom_send_to_kwm(kwm_unregister_module);
  delete info_list;
}

void TaskBar::menu_bt_clicked ()
{
  if( !isVisible() )
    return;
  QPoint poi = pos();
  poi.setY(poi.y() - prog_menu.getRightHeight()+1 );
  prog_menu.popup(poi);
  if( !use_kwm )
    ::SendInfo( &out_pipe, "Focus", wm_win_id);
  prog_menu.grabMouse();
  prog_menu.setActItem(0);
}

void TaskBar::net_bt_clicked ()
{
  QPoint poi = pos();
  poi += net_b->pos();
  poi.setY(poi.y() - net_menu->getRightHeight() );
  net_menu->popup(poi);
}

void TaskBar::update_clock ()
{
  QTime time;
  time = QTime::currentTime();
  QString time_str = time.toString();
  time_str.truncate(5);
  clock->setText( (const char *) time_str);
  clock->update();
  QTimer::singleShot( 60000, this, SLOT(update_clock()) );
}

short TaskBar::parse_conf ()
{
  QFile config(menu_file);
  if( !config.open(IO_ReadOnly) ) 
    return -1;
  QDataStream st( (QIODevice *) &config);
  char c;
  QString buf;
  while( !st.eof() )
    {
      buf = "";
      st >> c;
      while ( c != '\n' && !st.eof() )
	{
	  buf += c; 
	  st >> c;
	}
      buf.simplifyWhiteSpace();
      if( buf == "Main_menu_conf---" )
	{
	  menu_data->parse(st);
	}
      else if( buf == "Net_menu_conf---" )
	{
	  if( net_menu_dat )
	    delete net_menu_dat;
	  net_menu_dat = new PMenu();
	  net_menu_dat->parse(st);
	}
      else if( buf == "Con_menu_conf---" )
	{
	  if( con_menu_dat )
	    delete con_menu_dat;
	  con_menu_dat = new PMenu();
	  con_menu_dat->parse(st);
	}
      else if( buf == "END---" )
	{
	  break;
	}
      else if( buf[0] == '#' )
	{
	  continue;
	}
      else
	{
	  debug( "Wrong format in config file!" );
	}
    }
  config.close();
  return 0;
}

short TaskBar::writeConf ()
{
  // TODO: make a backup copy of old configuration
  QFile config(menu_file);
  if( !config.open(IO_ReadWrite) ) 
    return -1;
  QTextStream st( (QIODevice *) &config);
  st << "Main_menu_conf---\n";
  menu_data->writeConfig(st);
  st << "#-------\n";
  st << "Net_menu_conf---\n";
  net_menu_dat->writeConfig(st);
  st << "#-------\n";
  st << "Con_menu_conf---\n";
  con_menu_dat->writeConfig(st);
  st << "END---\n";
  config.close();
  return 0;
}

void TaskBar::net_up()
{
  net_b->hide();
  con_b->show();
  bt_group->resize(bt_group->width() - (con_b->width() - net_b->width()), taskbar_height );
  connected = 0;
  QTimer::singleShot( 10000, this, SLOT(check_net()) );
}

void TaskBar::net_count()
{
  static char cnt;
  short h1, h2, m1, m2;
  h1 = h2 = m1 = m2 = 0;
  char time_str[6];
  time_str[5] = 0;

  cnt++;
  if( cnt < 3 )
    {
      check_net();
      if( connected == 1 )
	QTimer::singleShot( 20000, this, SLOT(net_count()) );
      return;
    }
  cnt = 0;
  time_str[2] = ':';
  minutes++;
  if( minutes > 59 )
    {
      hours++;
      if( hours > 99 )
        hours = 0;
      minutes = 0;
    }
  h1 = hours / 10; time_str[0] = h1 + 48;
  h2 = hours % 10; time_str[1] = h2 + 48;
  m1 = minutes / 10; time_str[3] = m1 + 48;
  m2 = minutes % 10; time_str[4] = m2 + 48;
  con_b->setText(time_str);
  con_b->update();
  check_net();
  if( connected == 1 )
    QTimer::singleShot( 20000, this, SLOT(net_count()) );
  return;
}

void TaskBar::check_net()
{
  //debug("check");
  unsigned char c;
  int stat;
  short count = 0;
  if ( connected == -1 )
    return;
  QFile route("/proc/net/route");
  //QFile route("/home/chris/temp_ppp");
  if( !route.open(IO_ReadOnly) ) 
    {
      con_b->hide();
      net_b->show();
      bt_group->resize(bt_group->width() + (con_b->width() - net_b->width()), taskbar_height );
      debug("no file");
      return;
    }
  QDataStream st( (QIODevice *) &route);

  while ( !st.eof() )
    {
      st >> c;
      if( c != 'p') { count = 0; continue; }
      count++;
      if(count == 3)
        {
          if( connected == 0 )
            {
              start_time = QDateTime::currentDateTime();
	      connected = 1;
	      con_b->setText("00:00");
	      con_b->update();
	      QTimer::singleShot( 20000, this, SLOT(net_count()) );
            }
          break;
        }
    }
  route.close();
  if( connected == 0 )
    QTimer::singleShot( 10000, this, SLOT(check_net()) );
  else
    if(count != 3)
      {
	net_report();
	connected = 0;
	con_b->hide();
	net_b->show();
	bt_group->resize(bt_group->width() + (con_b->width() - net_b->width()), taskbar_height );
      }
  return;
}

void TaskBar::net_report()
{
  char timebuf1[80];
  char timebuf2[80];
  time_t curtime;
  struct tm *loctime;
  int total;
  QString output;
  QString logname = (QString) getenv("HOME") + "/.ppplog";

  QDateTime stop_time = QDateTime::currentDateTime();
  total = start_time.secsTo(stop_time);

  output  = "Start: " + start_time.toString() + " | ";
  output += "Stop: "  + stop_time.toString()  + " | Total: ";

  QFile logfile((const char *) logname);
  if( !logfile.open( IO_WriteOnly | IO_Append ) )
    return;
  QTextStream log( (QIODevice *) &logfile);
  log << output << total << endl;
  logfile.close();
  con_b->setText("==:==");
}

void TaskBar::con_bt_clicked ()
{
  QPoint poi = pos();
  poi += con_b->pos();
  poi.setY(poi.y() - con_menu->getRightHeight() );
  con_menu->popup(poi);
}

void TaskBar::netsc_bt_clicked()
{
  system("netscape-gold &");
}

void TaskBar::disconnect ()
{
  if( (QString) con_b->text() == (QString) "==:==" )
    {
      con_b->hide();
      net_b->show();
      bt_group->resize(bt_group->width() + (con_b->width() - net_b->width()), taskbar_height );
      connected = -1;
    }
  system( "super stop.all ppp0 &" );
}

void TaskBar::send_fvwm_com( QString com )
{
  if( !use_kwm )
    ::SendInfo( &out_pipe, (char *) ((const char *) com), 0 );
}

void TaskBar::rebuildMenu()
{
  if( menu_data )
    delete menu_data;
  menu_data = new PMenu();
  if( parse_conf() < 0 )
    {
      debug("error reading menu config file. Giving up!");
      exit(1);
    }
  menu_data->add( new PMenuItem( separator, NULL, NULL, NULL,
				 NULL, NULL, NULL, NULL, TRUE ) );
  PMenu *menu_config = new PMenu();
  menu_config->add( new PMenuItem( prog_com, (QString) "Global", NULL, "mini-bball.xpm",
				   NULL, this, SLOT(config_global()), NULL, TRUE ) );
  menu_config->add( new PMenuItem( prog_com, (QString) "Taskbar", NULL, "mini-bball.xpm",
				   NULL, task_config_w, SLOT(invoke()), NULL, TRUE ) );
  menu_config->add( new PMenuItem( prog_com, (QString) "Menu", NULL, "mini-bball.xpm",
				   NULL, this, SLOT(config_menu()), NULL, TRUE ) );
  menu_data->add( new PMenuItem( submenu, (QString) "Config", NULL, "mini-ball.xpm",
				 menu_config, NULL, NULL, new CPopupMenu, TRUE ) );
  menu_data->add( new PMenuItem( prog_com, (QString) "EXIT", NULL, "mini.exit.xpm",
				 NULL, qApp, SLOT(quit()), NULL, TRUE ) );
  prog_menu.clear();
  menu_data->create_cmenu(&prog_menu);  
  prog_menu.adjustSize();
  if( use_net_but )
    {
      net_menu->clear();
      net_menu_dat->set_net_recv( this, SLOT(net_up()) );
      net_menu_dat->create_cmenu( net_menu );
      net_menu->adjustSize();
      con_menu->clear();
      con_menu_dat->add( new PMenuItem( separator, NULL, NULL, NULL,
					NULL, NULL, NULL, NULL, TRUE ) );
      con_menu_dat->add( new PMenuItem ( prog_com, (QString) "Disconnect", NULL,
					 (QString) "mini-stop.xpm", NULL, this,
					 SLOT(disconnect()) ));
      con_menu_dat->create_cmenu( con_menu );
    }
}

void TaskBar::config_menu()
{
  if( menu_config_w )
    {
      if( menu_config_w->isVisible() )
	return;
      delete menu_config_w;
    }
  menu_config_w = new MenuConfig( config, menu_data, this );
  menu_config_w->invoke();
}

void TaskBar::config_global()
{
  if( main_config_w )
    {
      if( main_config_w->isVisible() )
	return;
    }
  else
    {
      main_config_w = new MainConfigDialog( config, this );
    }
  main_config_w->invoke();
}

void TaskBar::cleanupBar()
{
  short wi = 0;
  menu_bt->resize(menu_bt->sizeHint().width(), taskbar_height);
  bar_left_pos = menu_bt->width()+3;
  bar_width = width() - bar_left_pos;
  if( use_net_but )
    bar_width -= net_b->width();
  if( use_netsc_but )
    bar_width -= netsc_b->width();
  if( use_clock )
    bar_width -= clock->width();
  bt_group->setGeometry( bar_left_pos, 0, bar_width, taskbar_height );
  wi = bar_left_pos+bar_width;
  net_b->move(bar_left_pos+bar_width, 0);
  if( use_net_but )
    {
      wi += net_b->width();
      net_b->show();
    }
  con_b->move(bar_left_pos+bar_width - 30, 0);
  netsc_b->move(wi, 0);
  if( use_netsc_but )
    {
      wi += netsc_b->width();
      netsc_b->show();
    }
  if( use_clock )
    clock->show();
  clock->move(wi, 0);
}

void TaskBar::configureWM()
{
  // configure window manager (currently only fvwm2 supported)
  if( use_kwm )
    return;
  config->setGroup("ktaskbar");
  QString wm_command = "Key ";
  QString key = config->readEntry("key_popup");
  QString mod;
  if( key.isNull() )
    {
      ::SendInfo( &out_pipe, "Key F12 A C SendToModule ktaskbar PopupMenu", 0 );
    }
  else
    {
      wm_command += key.left( key.find('(') );
      wm_command += " A N";
      mod = key.right( key.length() - key.find('(') );
      if( mod.contains('C') )
	wm_command += 'C';
      if( mod.contains('A') )
	wm_command += 'M';
      wm_command += " SendToModule ktaskbar PopupMenu";
      ::SendInfo( &out_pipe, (char *) ((const char *) wm_command), 0 );
    }

  key = config->readEntry("key_iconify");
  if( key.isNull() )
    {
      ::SendInfo( &out_pipe, "Key Down A CM SendToModule ktaskbar Iconify", 0 );
    }
  else
    {
      wm_command = "Key ";
      wm_command += key.left( key.find('(') );
      wm_command += " A N";
      mod = key.right( key.length() - key.find('(') );
      if( mod.contains('C') )
	wm_command += 'C';
      if( mod.contains('A') )
	wm_command += 'M';
      wm_command += " SendToModule ktaskbar Iconify";
      ::SendInfo( &out_pipe, (char *) ((const char *) wm_command), 0 );
    }

  key = config->readEntry("key_deiconify");
  if( key.isNull() )
    {
      ::SendInfo( &out_pipe, "Key Up A CM SendToModule ktaskbar Deiconify", 0 );
    }
  else
    {
      wm_command = "Key ";
      wm_command += key.left( key.find('(') );
      wm_command += " A N";
      mod = key.right( key.length() - key.find('(') );
      if( mod.contains('C') )
	wm_command += 'C';
      if( mod.contains('A') )
	wm_command += 'M';
      wm_command += " SendToModule ktaskbar Deiconify";
      ::SendInfo( &out_pipe, (char *) ((const char *) wm_command), 0 );
    }

  wm_command = "Style \"KTaskbar\" NoTitle, NoHandles, Borderwidth 0";
  if( config->readNumEntry("click_to_focus") )
    wm_command += ", ClickToFocus";
  if( config->readNumEntry("sticky") )
    wm_command += ", Sticky";
  if( config->readNumEntry("stay_on_top") )
    wm_command += ", StaysOnTop";
  ::SendInfo( &out_pipe, (char *) ((const char *) wm_command), 0 );
}

void TaskBar::client_message(XClientMessageEvent* e)
{
  WinInfo *window;
  if (e->message_type == kwm_add_window)
    {
      if( (window = info_list->exists(e->data.l[0])) )
	return;
      window = info_list->add();
      window->id = e->data.l[0];
      window->name = getprop(e->data.l[1], XA_WM_NAME);
      window->pixmap = task_config_w->pix_contains(window->name);
      if( info_list->task_config_w->skip_contains(window->name) )
	{
	  if( !window->ignore )
	    info_list->bt_nr--;
	  window->ignore = TRUE;
	}
      else
	{
	  if( window->ignore )
	    {
	      window->ignore = FALSE;
	      info_list->bt_nr++;
	    }
	}
      info_list->draw_but();
      return;
    }
  if (e->message_type == kwm_remove_window)
    {
      if( (window = info_list->exists(e->data.l[0])) )
	{
	  info_list->remove(window);
	  info_list->draw_but();
	}	
      return;
    }
}


