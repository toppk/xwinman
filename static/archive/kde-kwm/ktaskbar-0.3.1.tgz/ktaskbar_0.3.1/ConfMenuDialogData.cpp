#include <qcombo.h>
#include <qlabel.h>
#include <qlined.h>
#include <qpushbt.h>

#include "ConfMenuDialogData.h"
#include "ConfMenuDialog.h"

ConfMenuDialogData::ConfMenuDialogData
(
	QWidget* parent
)
{
	QLineEdit* tmpQLineEdit;
	tmpQLineEdit = new QLineEdit( parent, "i_name" );
	tmpQLineEdit->setGeometry( 24, 32, 160, 24 );
	tmpQLineEdit->setText( "" );

	QLabel* tmpQLabel;
	tmpQLabel = new QLabel( parent, "Label_1" );
	tmpQLabel->setGeometry( 16, 16, 40, 16 );
	tmpQLabel->setText( "Name:" );

	tmpQLabel = new QLabel( parent, "Label_2" );
	tmpQLabel->setGeometry( 16, 64, 48, 16 );
	tmpQLabel->setText( "Pixmap:" );

	tmpQLineEdit = new PLineEdit( parent, "i_pixmap" );
	tmpQLineEdit->setGeometry( 24, 80, 160, 24 );
	tmpQLineEdit->setText( "" );

	tmpQLabel = new QLabel( parent, "Label_4" );
	tmpQLabel->setGeometry( 16, 112, 56, 16 );
	tmpQLabel->setText( "Command:" );

	tmpQLineEdit = new QLineEdit( parent, "i_command" );
	tmpQLineEdit->setGeometry( 24, 128, 160, 24 );
	tmpQLineEdit->setText( "" );

	QComboBox* tmpQComboBox;
	tmpQComboBox = new QComboBox( parent, "c_type" );
	tmpQComboBox->setGeometry( 68, 160, 120, 24 );
	tmpQComboBox->insertItem( "Separator" );
	tmpQComboBox->insertItem( "Submenu" );
	tmpQComboBox->insertItem( "System command" );
	tmpQComboBox->insertItem( "Fvwm command" );

	tmpQLabel = new QLabel( parent, "Label_5" );
	tmpQLabel->setGeometry( 24, 160, 40, 24 );
	tmpQLabel->setText( "Type:" );
	tmpQLabel->setAlignment( 290 );

	QPushButton* tmpQPushButton;
	tmpQPushButton = new QPushButton( parent, "b_ok" );
	tmpQPushButton->setGeometry( 16, 200, 64, 24 );
	tmpQPushButton->setText( "Ok" );

	tmpQPushButton = new QPushButton( parent, "b_cancel" );
	tmpQPushButton->setGeometry( 152, 200, 64, 24 );
	tmpQPushButton->setText( "Cancel" );

	tmpQPushButton = new QPushButton( parent, "b_pixmap" );
	tmpQPushButton->setGeometry( 192, 80, 24, 24 );
	tmpQPushButton->setText( "" );

	parent->resize( 232, 240 );
}
