/****************************************************************************
** MainConfigDialog meta object code from reading C++ file 'MainConfigDialog.h'
**
** Created: Sat Feb 8 14:00:26 1997
**      by: The Qt Meta Object Compiler ($Revision: 2.5.2.1 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include <qmetaobj.h>
#include "MainConfigDialog.h"


const char *MainConfigDialog::className() const
{
    return "MainConfigDialog";
}

QMetaObject *MainConfigDialog::metaObj = 0;

void MainConfigDialog::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QDialog::metaObject() )
	QDialog::initMetaObject();
    typedef void(MainConfigDialog::*m1_t0)();
    typedef void(MainConfigDialog::*m1_t1)();
    typedef void(MainConfigDialog::*m1_t2)();
    typedef void(MainConfigDialog::*m1_t3)();
    m1_t0 v1_0 = &MainConfigDialog::invoke;
    m1_t1 v1_1 = &MainConfigDialog::selectPixmap;
    m1_t2 v1_2 = &MainConfigDialog::accept;
    m1_t3 v1_3 = &MainConfigDialog::restart;
    QMetaData *slot_tbl = new QMetaData[4];
    slot_tbl[0].name = "invoke()";
    slot_tbl[1].name = "selectPixmap()";
    slot_tbl[2].name = "accept()";
    slot_tbl[3].name = "restart()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    metaObj = new QMetaObject( "MainConfigDialog", "QDialog",
	slot_tbl, 4,
	0, 0 );
}
