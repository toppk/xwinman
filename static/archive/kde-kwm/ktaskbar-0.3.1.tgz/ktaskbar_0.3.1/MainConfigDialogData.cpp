#include <qframe.h>
#include <qlabel.h>

#include "MainConfigDialogData.h"


MainConfigDialogData::MainConfigDialogData
(
	QWidget* parent
)
	:
	b_ok( parent, "PushButton_1" ),
	b_cancel( parent, "PushButton_2" ),
	i_menu( parent, "LineEdit_1" ),
	i_ipath( parent, "LineEdit_2" ),
	i_sysmenu( parent, "LineEdit_3" ),
	c_wm_stay( parent, "CheckBox_2" ),
	c_wm_sticky( parent, "CheckBox_3" ),
	c_wm_click( parent, "CheckBox_4" ),
	c_keypopup_alt( parent, "CheckBox_5" ),
	c_keypopup_ctrl( parent, "CheckBox_6" ),
	i_keypopup( parent, "LineEdit_4" ),
	b_menupix( parent, "PushButton_4" ),
	i_keyicon( parent, "LineEdit_5" ),
	i_keydeicon( parent, "LineEdit_6" ),
	c_keyicon_alt( parent, "CheckBox_7" ),
	c_keyicon_ctrl( parent, "CheckBox_8" ),
	c_keydeicon_alt( parent, "CheckBox_9" ),
	c_keydeicon_ctrl( parent, "CheckBox_10" ),
	i_menubutton( parent, "LineEdit_7" ),
	c_but_net( parent, "CheckBox_11" ),
	c_but_netsc( parent, "CheckBox_12" ),
	c_but_clock( parent, "CheckBox_13" ),
	b_restart( parent, "PushButton_4" )
{
	b_ok.raise();
	b_ok.setGeometry( 40, 464, 80, 24 );
	b_ok.setText( "Ok" );

	b_cancel.raise();
	b_cancel.setGeometry( 280, 464, 80, 24 );
	b_cancel.setText( "Cancel" );

	i_menu.raise();
	i_menu.setGeometry( 24, 64, 232, 24 );
	i_menu.setText( "" );

	QLabel* tmpQLabel;
	tmpQLabel = new QLabel( parent, "Label_1" );
	tmpQLabel->setGeometry( 8, 16, 144, 24 );
	tmpQLabel->setText( "General configuration" );

	tmpQLabel = new QLabel( parent, "Label_2" );
	tmpQLabel->setGeometry( 16, 40, 100, 24 );
	tmpQLabel->setText( "Menu config file:" );

	tmpQLabel = new QLabel( parent, "Label_3" );
	tmpQLabel->setGeometry( 16, 136, 64, 24 );
	tmpQLabel->setText( "Icon path:" );

	i_ipath.raise();
	i_ipath.setGeometry( 24, 160, 232, 24 );
	i_ipath.setText( "" );

	tmpQLabel = new QLabel( parent, "Label_4" );
	tmpQLabel->setGeometry( 16, 88, 160, 24 );
	tmpQLabel->setText( "System menu config file:" );

	i_sysmenu.raise();
	i_sysmenu.setGeometry( 24, 112, 232, 24 );
	i_sysmenu.setText( "" );

	QFrame* tmpQFrame;
	tmpQFrame = new QFrame( parent, "Frame_1" );
	tmpQFrame->setGeometry( 264, 56, 120, 128 );
	tmpQFrame->setFrameStyle( 49 );

	tmpQLabel = new QLabel( parent, "Label_5" );
	tmpQLabel->setGeometry( 272, 64, 64, 24 );
	tmpQLabel->setText( "WM options:" );

	c_wm_stay.raise();
	c_wm_stay.setGeometry( 272, 96, 88, 16 );
	c_wm_stay.setText( "StaysOnTop" );

	c_wm_sticky.raise();
	c_wm_sticky.setGeometry( 272, 120, 100, 24 );
	c_wm_sticky.setText( "Sticky" );

	c_wm_click.raise();
	c_wm_click.setGeometry( 272, 152, 100, 24 );
	c_wm_click.setText( "ClickToFocus" );

	tmpQFrame = new QFrame( parent, "Frame_2" );
	tmpQFrame->setGeometry( 16, 200, 240, 168 );
	tmpQFrame->setFrameStyle( 49 );

	tmpQLabel = new QLabel( parent, "Label_6" );
	tmpQLabel->setGeometry( 24, 208, 120, 24 );
	tmpQLabel->setText( "Key to popup menu:" );

	c_keypopup_alt.raise();
	c_keypopup_alt.setGeometry( 136, 232, 48, 24 );
	c_keypopup_alt.setText( "Alt" );

	c_keypopup_ctrl.raise();
	c_keypopup_ctrl.setGeometry( 184, 232, 64, 24 );
	c_keypopup_ctrl.setText( "Control" );

	i_keypopup.raise();
	i_keypopup.setGeometry( 24, 232, 104, 24 );
	i_keypopup.setText( "" );

	tmpQLabel = new QLabel( parent, "Label_7" );
	tmpQLabel->setGeometry( 16, 376, 128, 24 );
	tmpQLabel->setText( "Icon of menu button:" );

	b_menupix.raise();
	b_menupix.setGeometry( 144, 376, 32, 24 );
	b_menupix.setText( "" );

	tmpQLabel = new QLabel( parent, "Label_8" );
	tmpQLabel->setGeometry( 24, 256, 100, 24 );
	tmpQLabel->setText( "Key to iconify:" );

	i_keyicon.raise();
	i_keyicon.setGeometry( 24, 280, 104, 24 );
	i_keyicon.setText( "" );

	tmpQLabel = new QLabel( parent, "Label_9" );
	tmpQLabel->setGeometry( 24, 304, 104, 24 );
	tmpQLabel->setText( "Key to deiconify:" );

	i_keydeicon.raise();
	i_keydeicon.setGeometry( 24, 328, 104, 24 );
	i_keydeicon.setText( "" );

	c_keyicon_alt.raise();
	c_keyicon_alt.setGeometry( 136, 280, 48, 24 );
	c_keyicon_alt.setText( "Alt" );

	c_keyicon_ctrl.raise();
	c_keyicon_ctrl.setGeometry( 184, 280, 64, 24 );
	c_keyicon_ctrl.setText( "Control" );

	c_keydeicon_alt.raise();
	c_keydeicon_alt.setGeometry( 136, 328, 48, 24 );
	c_keydeicon_alt.setText( "Alt" );

	c_keydeicon_ctrl.raise();
	c_keydeicon_ctrl.setGeometry( 184, 328, 64, 24 );
	c_keydeicon_ctrl.setText( "Control" );

	tmpQLabel = new QLabel( parent, "Label_10" );
	tmpQLabel->setGeometry( 16, 408, 120, 24 );
	tmpQLabel->setText( "Text of menu button:" );

	i_menubutton.raise();
	i_menubutton.setGeometry( 144, 408, 112, 24 );
	i_menubutton.setText( "" );

	tmpQFrame = new QFrame( parent, "Frame_3" );
	tmpQFrame->setGeometry( 264, 200, 120, 128 );
	tmpQFrame->setFrameStyle( 49 );

	tmpQLabel = new QLabel( parent, "Label_11" );
	tmpQLabel->setGeometry( 272, 208, 100, 24 );
	tmpQLabel->setText( "Use buttons:" );

	c_but_net.raise();
	c_but_net.setGeometry( 280, 232, 72, 30 );
	c_but_net.setText( "Network" );

	c_but_netsc.raise();
	c_but_netsc.setGeometry( 280, 264, 72, 24 );
	c_but_netsc.setText( "Netscape" );

	c_but_clock.raise();
	c_but_clock.setGeometry( 280, 296, 56, 24 );
	c_but_clock.setText( "Clock" );

	b_restart.raise();
	b_restart.setGeometry( 160, 464, 80, 24 );
	b_restart.setText( "Restart" );

	parent->resize( 400, 507 );
}
