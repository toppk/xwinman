/****************************************************************************
** MenuButton meta object code from reading C++ file 'confmenu.h'
**
** Created: Tue Feb 4 12:32:19 1997
**      by: The Qt Meta Object Compiler ($Revision: 2.5.2.1 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include <qmetaobj.h>
#include "confmenu.h"


const char *MenuButton::className() const
{
    return "MenuButton";
}

QMetaObject *MenuButton::metaObj = 0;

void MenuButton::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !TaskButton::metaObject() )
	TaskButton::initMetaObject();
    typedef void(MenuButton::*m1_t0)();
    typedef void(MenuButton::*m1_t1)(int);
    typedef void(MenuButton::*m1_t2)();
    typedef void(MenuButton::*m1_t3)();
    typedef void(MenuButton::*m1_t4)();
    typedef void(MenuButton::*m1_t5)();
    typedef void(MenuButton::*m1_t6)();
    typedef void(MenuButton::*m1_t7)();
    typedef void(MenuButton::*m1_t8)();
    typedef void(MenuButton::*m1_t9)();
    typedef void(MenuButton::*m1_t10)(int);
    typedef void(MenuButton::*m1_t11)();
    m1_t0 v1_0 = &MenuButton::open;
    m1_t1 v1_1 = &MenuButton::sOpen;
    m1_t2 v1_2 = &MenuButton::new_item;
    m1_t3 v1_3 = &MenuButton::cutItem;
    m1_t4 v1_4 = &MenuButton::copyItem;
    m1_t5 v1_5 = &MenuButton::pasteItem;
    m1_t6 v1_6 = &MenuButton::delete_item;
    m1_t7 v1_7 = &MenuButton::change_item;
    m1_t8 v1_8 = &MenuButton::change_accept;
    m1_t9 v1_9 = &MenuButton::change_reject;
    m1_t10 v1_10 = &MenuButton::popupMenu;
    m1_t11 v1_11 = &MenuButton::childRepos;
    QMetaData *slot_tbl = new QMetaData[12];
    slot_tbl[0].name = "open()";
    slot_tbl[1].name = "sOpen(int)";
    slot_tbl[2].name = "new_item()";
    slot_tbl[3].name = "cutItem()";
    slot_tbl[4].name = "copyItem()";
    slot_tbl[5].name = "pasteItem()";
    slot_tbl[6].name = "delete_item()";
    slot_tbl[7].name = "change_item()";
    slot_tbl[8].name = "change_accept()";
    slot_tbl[9].name = "change_reject()";
    slot_tbl[10].name = "popupMenu(int)";
    slot_tbl[11].name = "childRepos()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    slot_tbl[4].ptr = *((QMember*)&v1_4);
    slot_tbl[5].ptr = *((QMember*)&v1_5);
    slot_tbl[6].ptr = *((QMember*)&v1_6);
    slot_tbl[7].ptr = *((QMember*)&v1_7);
    slot_tbl[8].ptr = *((QMember*)&v1_8);
    slot_tbl[9].ptr = *((QMember*)&v1_9);
    slot_tbl[10].ptr = *((QMember*)&v1_10);
    slot_tbl[11].ptr = *((QMember*)&v1_11);
    typedef void(MenuButton::*m2_t0)(int);
    typedef void(MenuButton::*m2_t1)(int);
    typedef void(MenuButton::*m2_t2)(int);
    typedef void(MenuButton::*m2_t3)(int);
    typedef void(MenuButton::*m2_t4)(int);
    typedef void(MenuButton::*m2_t5)(int);
    typedef void(MenuButton::*m2_t6)(int);
    typedef void(MenuButton::*m2_t7)(int);
    typedef void(MenuButton::*m2_t8)(int);
    typedef void(MenuButton::*m2_t9)(int,QPoint);
    typedef void(MenuButton::*m2_t10)(int);
    typedef void(MenuButton::*m2_t11)(int);
    typedef void(MenuButton::*m2_t12)(int);
    m2_t0 v2_0 = &MenuButton::clicked;
    m2_t1 v2_1 = &MenuButton::Mclicked;
    m2_t2 v2_2 = &MenuButton::Rclicked;
    m2_t3 v2_3 = &MenuButton::pressed;
    m2_t4 v2_4 = &MenuButton::Mpressed;
    m2_t5 v2_5 = &MenuButton::Rpressed;
    m2_t6 v2_6 = &MenuButton::released;
    m2_t7 v2_7 = &MenuButton::Mreleased;
    m2_t8 v2_8 = &MenuButton::Rreleased;
    m2_t9 v2_9 = &MenuButton::posChanged;
    m2_t10 v2_10 = &MenuButton::newButton;
    m2_t11 v2_11 = &MenuButton::delButton;
    m2_t12 v2_12 = &MenuButton::pasteButton;
    QMetaData *signal_tbl = new QMetaData[13];
    signal_tbl[0].name = "clicked(int)";
    signal_tbl[1].name = "Mclicked(int)";
    signal_tbl[2].name = "Rclicked(int)";
    signal_tbl[3].name = "pressed(int)";
    signal_tbl[4].name = "Mpressed(int)";
    signal_tbl[5].name = "Rpressed(int)";
    signal_tbl[6].name = "released(int)";
    signal_tbl[7].name = "Mreleased(int)";
    signal_tbl[8].name = "Rreleased(int)";
    signal_tbl[9].name = "posChanged(int,QPoint)";
    signal_tbl[10].name = "newButton(int)";
    signal_tbl[11].name = "delButton(int)";
    signal_tbl[12].name = "pasteButton(int)";
    signal_tbl[0].ptr = *((QMember*)&v2_0);
    signal_tbl[1].ptr = *((QMember*)&v2_1);
    signal_tbl[2].ptr = *((QMember*)&v2_2);
    signal_tbl[3].ptr = *((QMember*)&v2_3);
    signal_tbl[4].ptr = *((QMember*)&v2_4);
    signal_tbl[5].ptr = *((QMember*)&v2_5);
    signal_tbl[6].ptr = *((QMember*)&v2_6);
    signal_tbl[7].ptr = *((QMember*)&v2_7);
    signal_tbl[8].ptr = *((QMember*)&v2_8);
    signal_tbl[9].ptr = *((QMember*)&v2_9);
    signal_tbl[10].ptr = *((QMember*)&v2_10);
    signal_tbl[11].ptr = *((QMember*)&v2_11);
    signal_tbl[12].ptr = *((QMember*)&v2_12);
    metaObj = new QMetaObject( "MenuButton", "TaskButton",
	slot_tbl, 12,
	signal_tbl, 13 );
}

// SIGNAL clicked
void MenuButton::clicked( int t0 )
{
    activate_signal( "clicked(int)", t0 );
}

// SIGNAL Mclicked
void MenuButton::Mclicked( int t0 )
{
    activate_signal( "Mclicked(int)", t0 );
}

// SIGNAL Rclicked
void MenuButton::Rclicked( int t0 )
{
    activate_signal( "Rclicked(int)", t0 );
}

// SIGNAL pressed
void MenuButton::pressed( int t0 )
{
    activate_signal( "pressed(int)", t0 );
}

// SIGNAL Mpressed
void MenuButton::Mpressed( int t0 )
{
    activate_signal( "Mpressed(int)", t0 );
}

// SIGNAL Rpressed
void MenuButton::Rpressed( int t0 )
{
    activate_signal( "Rpressed(int)", t0 );
}

// SIGNAL released
void MenuButton::released( int t0 )
{
    activate_signal( "released(int)", t0 );
}

// SIGNAL Mreleased
void MenuButton::Mreleased( int t0 )
{
    activate_signal( "Mreleased(int)", t0 );
}

// SIGNAL Rreleased
void MenuButton::Rreleased( int t0 )
{
    activate_signal( "Rreleased(int)", t0 );
}

#if !defined(Q_MOC_CONNECTIONLIST_DECLARED)
#define Q_MOC_CONNECTIONLIST_DECLARED
#include <qlist.h>
#if defined(Q_DECLARE)
Q_DECLARE(QListM,QConnection);
Q_DECLARE(QListIteratorM,QConnection);
#else
// for compatibility with old header files
declare(QListM,QConnection);
declare(QListIteratorM,QConnection);
#endif
#endif

// SIGNAL posChanged
void MenuButton::posChanged( int t0, QPoint t1 )
{
    QConnectionList *clist = receivers("posChanged(int,QPoint)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(int);
    typedef RT1 *PRT1;
    typedef void (QObject::*RT2)(int,QPoint);
    typedef RT2 *PRT2;
    RT0 r0;
    RT1 r1;
    RT2 r2;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	    case 2:
		r2 = *((PRT2)(c->member()));
		(object->*r2)(t0, t1);
		break;
	}
    }
}

// SIGNAL newButton
void MenuButton::newButton( int t0 )
{
    activate_signal( "newButton(int)", t0 );
}

// SIGNAL delButton
void MenuButton::delButton( int t0 )
{
    activate_signal( "delButton(int)", t0 );
}

// SIGNAL pasteButton
void MenuButton::pasteButton( int t0 )
{
    activate_signal( "pasteButton(int)", t0 );
}


const char *ConfMenuItem::className() const
{
    return "ConfMenuItem";
}

QMetaObject *ConfMenuItem::metaObj = 0;

void ConfMenuItem::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QObject::metaObject() )
	QObject::initMetaObject();
    metaObj = new QMetaObject( "ConfMenuItem", "QObject",
	0, 0,
	0, 0 );
}


const char *ConfigureMenu::className() const
{
    return "ConfigureMenu";
}

QMetaObject *ConfigureMenu::metaObj = 0;

void ConfigureMenu::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QFrame::metaObject() )
	QFrame::initMetaObject();
    typedef void(ConfigureMenu::*m1_t0)(int,QPoint);
    typedef void(ConfigureMenu::*m1_t1)(int);
    typedef void(ConfigureMenu::*m1_t2)(int);
    typedef void(ConfigureMenu::*m1_t3)(int);
    typedef void(ConfigureMenu::*m1_t4)(QMoveEvent*);
    m1_t0 v1_0 = &ConfigureMenu::buttonMoved;
    m1_t1 v1_1 = &ConfigureMenu::newButton;
    m1_t2 v1_2 = &ConfigureMenu::delButton;
    m1_t3 v1_3 = &ConfigureMenu::pasteButton;
    m1_t4 v1_4 = &ConfigureMenu::moveEvent;
    QMetaData *slot_tbl = new QMetaData[5];
    slot_tbl[0].name = "buttonMoved(int,QPoint)";
    slot_tbl[1].name = "newButton(int)";
    slot_tbl[2].name = "delButton(int)";
    slot_tbl[3].name = "pasteButton(int)";
    slot_tbl[4].name = "moveEvent(QMoveEvent*)";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    slot_tbl[4].ptr = *((QMember*)&v1_4);
    metaObj = new QMetaObject( "ConfigureMenu", "QFrame",
	slot_tbl, 5,
	0, 0 );
}
