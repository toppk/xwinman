

#include <qobjcoll.h>
#include <qlabel.h>
#include <qlined.h>

#include "ConfMenuDialog.h"
#include "ConfMenuDialogData.h"

#include "pixloader.h"

extern PixmapLoader *global_pix_loader;


ConfMenuDialog::ConfMenuDialog (QWidget* parent, const char* name)
  :QDialog( 0, name, FALSE, WStyle_Customize | WStyle_NormalBorder )
{
  initMetaObject();
  itsDialogData = new ConfMenuDialogData( this );
  initChildPointer();
  i_name->setFocus();
  connect( (QObject *) b_pixmap, SIGNAL(clicked()), this, SLOT(pixButPressed()) );
  connect( (QObject *) b_ok, SIGNAL(clicked()), this, SLOT(accept()) );
  connect( (QObject *) b_ok, SIGNAL(clicked()), parent, SLOT(change_accept()) );
  connect( (QObject *) b_cancel, SIGNAL(clicked()), this, SLOT(reject()) );
  connect( (QObject *) b_cancel, SIGNAL(clicked()), parent, SLOT(change_reject()) );
  connect( (QObject *) i_pixmap, SIGNAL(returnPressed()),\
	   this, SLOT(pixnameChanged()) );
}

void ConfMenuDialog::initChildPointer()
{
  QObjectList *list = queryList();
  QObject *item;
  for( item = list->first(); item != 0; item=list->next() )
    {
      if( item->name() == NULL ) continue;
      if( (QString) item->name() == "b_ok" )
	b_ok = (QPushButton*) item;
      else if( (QString) item->name() == "b_cancel" )
	b_cancel = (QPushButton*) item;
      else if( (QString) item->name() == "b_cancel" )
	b_cancel = (QPushButton*) item;
      else if( (QString) item->name() == "i_name" )
	i_name = (QLineEdit*) item;
      else if( (QString) item->name() == "i_pixmap" )
	i_pixmap = (PLineEdit*) item;
      else if( (QString) item->name() == "i_command" )
	i_command = (QLineEdit*) item;
      else if( (QString) item->name() == "c_type" )
	c_type = (QComboBox*) item;
      else if( (QString) item->name() == "b_pixmap" )
	b_pixmap = (QPushButton*) item;
    }
  delete list;
}

void ConfMenuDialog::pixnameChanged()
{
  QString new_name = i_pixmap->text();
  if( new_name != old_pixname )
    {
      b_pixmap->setPixmap( global_pix_loader->loadPixmap(new_name) );
      old_pixname = new_name;
    }
}

void ConfMenuDialog::pixButPressed()
{
  QString name;
  global_pix_loader->selectPixmap(name);
  i_pixmap->setText(name);
  pixnameChanged();
}
