#ifndef MainConfigDialogData_included
#define MainConfigDialogData_included

#include <qchkbox.h>
#include <qlined.h>
#include <qpushbt.h>

class MainConfigDialogData
{
public:

    MainConfigDialogData
    (
        QWidget* parent
    );


    QPushButton b_ok;
    QPushButton b_cancel;
    QLineEdit i_menu;
    QLineEdit i_ipath;
    QLineEdit i_sysmenu;
    QCheckBox c_wm_stay;
    QCheckBox c_wm_sticky;
    QCheckBox c_wm_click;
    QCheckBox c_keypopup_alt;
    QCheckBox c_keypopup_ctrl;
    QLineEdit i_keypopup;
    QPushButton b_menupix;
    QLineEdit i_keyicon;
    QLineEdit i_keydeicon;
    QCheckBox c_keyicon_alt;
    QCheckBox c_keyicon_ctrl;
    QCheckBox c_keydeicon_alt;
    QCheckBox c_keydeicon_ctrl;
    QLineEdit i_menubutton;
    QCheckBox c_but_net;
    QCheckBox c_but_netsc;
    QCheckBox c_but_clock;
    QPushButton b_restart;

};

#endif // MainConfigDialogData_included
