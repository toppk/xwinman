// -*- C++ -*-

//
//  ktaskbar
//
//  Copyright (C) 1997 Christoph Neerfeld
//  email:  Christoph.Neerfeld@mail.bonn.netsurf.de
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//


extern "C" {
#include <stdio.h>
#include <signal.h>
#include <fcntl.h>
#include <stdlib.h>
#include "/usr/local/src/fvwm-2.0.43/fvwm/module.h"
}

#include <qapp.h>
#include <qmenudta.h>
#include <qpopmenu.h>
#include <qpixmap.h>
#include <qtablevw.h>
#include <qpainter.h>
#include <qdrawutl.h>
#include <qscrbar.h>                            // qDrawArrow
#include <qfont.h>
#include <qstring.h>
#include <qtstream.h>
#include <qdstream.h>
#include <qfile.h>
#include "cpopmenu.h"

#include <core/kapp.h>
#include <core/drag.h>
#include "kwmcom.h"
#include "pmenu.h"
#include "taskbar.h"
#include "pixloader.h"

extern "C" {
void DeadPipe(int);
}

QApplication *main_app;
PixmapLoader *global_pix_loader;
bool use_kwm;

void DeadPipe(int nonsense)
{
  main_app->exit(0);
}

class MyApp:public KApplication {
public:
  MyApp( int &argc, char **argv, const QString& rAppName );
  ~MyApp() {}

  virtual bool x11EventFilter( XEvent * );
};

MyApp::MyApp(int &argc, char **argv , const QString& rAppName)
  : KApplication(argc, argv, rAppName)
{
}

bool MyApp::x11EventFilter( XEvent * ev){
  //debug("Qt: got one event %d for window %d\n", ev->type, ev->xany.window);
  if (ev->type == ClientMessage)
    {
      ((TaskBar *) (main_app->mainWidget()))->client_message(&ev->xclient);
    }
  return FALSE;
}

int main( int argc, char **argv )
{
debug ( "[ktaskbar] started-------------------------" );
  use_kwm = FALSE;
  int fd[2];
  if( argc < 6 )
    {
      debug("Starting ktaskbar in kwm mode");
      fd[0] = fd[1] = 0;
      use_kwm = TRUE;
    }
  else
    {
      debug("Starting ktaskbar in fvwm mode");
      fd[0] = atoi(argv[1]);
      fd[1] = atoi(argv[2]);
    }

  MyApp a( argc, argv, "ktaskbar" );
  main_app = &a;
  global_pix_loader = new PixmapLoader( a.getConfig(), "ktaskbar", "pixmap_path" );
  signal( SIGPIPE, DeadPipe );
  //a.setStyle(WindowsStyle);
  TaskBar *task;
  if( use_kwm )
    task = new TaskBar( fd, a.getConfig(), WStyle_Customize | WStyle_NoBorder );
  else
    task = new TaskBar( fd, a.getConfig(), WStyle_NormalBorder );
  a.setMainWidget( task );
  a.setRootDropZone( new KDNDDropZone( (QWidget *) task, DndNotDnd ) );
  task->show();
  return a.exec();
}





