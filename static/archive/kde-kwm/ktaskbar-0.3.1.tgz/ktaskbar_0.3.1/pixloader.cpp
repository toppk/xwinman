// -*- C++ -*-

//
//  ktaskbar
//
//  Copyright (C) 1997 Christoph Neerfeld
//  email:  Christoph.Neerfeld@mail.bonn.netsurf.de
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//

#include <qdir.h>

#include "pixloader.h"

//----------------------------------------------------------------------
//---------------  PIXMAPCANVAS   --------------------------------------
//----------------------------------------------------------------------
PixmapCanvas::PixmapCanvas (QWidget *parent=0, const char *name=0)
  :QTableView( parent, name )
{
  setFrameStyle(Panel | Sunken);
  setTableFlags(Tbl_autoScrollBars);
  pixmap_list.setAutoDelete(TRUE);
  name_list.setAutoDelete(TRUE);
  sel_id = 0;
}

void PixmapCanvas::loadDir( QString dir_name )
{
  QDir d(dir_name);
  if( !d.exists() )
    return;
  name_list.clear();
  pixmap_list.clear();
  const QStrList *file_list = d.entryList( QDir::Files | QDir::Readable, QDir::Name );
  QStrListIterator it(*file_list);
  QString current;

  KPixmap *new_xpm;
  it.toFirst();
  for( ; it.current(); ++it )
    {
      new_xpm = new KPixmap;
      current = it.current();
      new_xpm->load( dir_name + '/' + current );
      if( new_xpm->isNull() )
	{
	  delete new_xpm;
	  continue;
	}
      name_list.append(current);
      pixmap_list.append(new_xpm);
    }
  setNumCols( width() / 30 - 1 );
  setNumRows( name_list.count() / numCols() + 1 );
  setCellWidth(30);
  setCellHeight(30);
}

void PixmapCanvas::paintCell( QPainter *p, int r, int c )
{
  int item_nr = r * numCols() + c;
  QPixmap *pixmap = pixmap_list.at(item_nr);
  if( !pixmap )
    return;
  int pw = pixmap->width();
  int ph = pixmap->height();
  int x = pw/2;
  int y = ph/2;
  p->drawPixmap( x, y, *pixmap );
  if( item_nr == sel_id )
    p->drawRect( 0, 0, cellWidth(), cellHeight() );
}

void PixmapCanvas::mouseMoveEvent( QMouseEvent *e)
{
  int item_nr = findRow(e->pos().y()) * numCols() + findCol(e->pos().x());
  QString name = name_list.at(item_nr);
  emit nameChanged( (const char *) name );
}

void PixmapCanvas::mousePressEvent( QMouseEvent *e)
{
  int i = sel_id;
  sel_id = findRow(e->pos().y()) * numCols() + findCol(e->pos().x());
  updateCell( i / numCols(), i % numCols() );
  updateCell( findRow(e->pos().y()), findCol(e->pos().x()) );
}

void PixmapCanvas::mouseDoubleClickEvent( QMouseEvent *e)
{
  emit doubleClicked();
}

//----------------------------------------------------------------------
//---------------  PIXLOADERDIALOG   -----------------------------------
//----------------------------------------------------------------------

PixLoaderDialog::PixLoaderDialog ( QWidget *parent=0, const char *name=0 )
  : QDialog( parent, name, TRUE )
{
  resize( 470, 250 );
  QFont font("Helvetica", 12, QFont::Bold);
  QLabel *text = new QLabel(this);
  text->setFont(font);
  text->setText("Select pixmap:");
  text->setGeometry(10, 10, 100, 30);
  //---
  canvas = new PixmapCanvas(this);
  canvas->setGeometry(10, 50, 450, 115);
  //---
  l_name = new QLabel("test", this);
  l_name->setGeometry(10, 165, 100, 30);
  //---
  ok = new QPushButton( "Ok", this );
  cancel = new QPushButton( "Cancel", this );
  ok->setFont(font);
  cancel->setFont(font);
  ok->setGeometry(65, 200, 80, 30);
  cancel->setGeometry(325, 200, 80, 30);
  connect( ok, SIGNAL(clicked()), this, SLOT(accept()) );
  connect( cancel, SIGNAL(clicked()), this, SLOT(reject()) );
  connect( canvas, SIGNAL(nameChanged(const char *)), l_name, SLOT(setText(const char *)) );
  connect( canvas, SIGNAL(doubleClicked()), this, SLOT(accept()) );
}

int PixLoaderDialog::exec()
{
  setResult( 0 );
  canvas->loadDir( dir_name );
  show();
  return result();
}


//----------------------------------------------------------------------
//---------------  PIXMAPLOADER   --------------------------------------
//----------------------------------------------------------------------

PixmapLoader::PixmapLoader( KConfig *conf, QString app_name, QString var_name )
{
  config = conf;
  config->setGroup(app_name);
  pixmap_path = config->readEntry(var_name);
  name_list.setAutoDelete(TRUE);
  pixmap_list.setAutoDelete(TRUE);
}

PixmapLoader::~PixmapLoader()
{
  name_list.clear();
  pixmap_list.clear();
}

QPixmap PixmapLoader::loadPixmap ( QString name )
{
  QPixmap *pix;
  KPixmap new_xpm;
  int index;
  if ( (index = name_list.find(name)) < 0)
    {  
      pix = new QPixmap;
      if( name[0] == '/' )
	new_xpm.load(name);
      else
	new_xpm.load( pixmap_path + '/' + name );
      *pix = new_xpm;
      if( pix->isNull() )
	{
	  debug("ERROR: couldn't find pixmap: %s", (const char *) name);
	}
      else
	{
	  name_list.append(name);
	  pixmap_list.append(pix);
	}
    }
  else
    {
      pix = pixmap_list.at(index);
    }
  return *pix;
}

QPixmap PixmapLoader::selectPixmap(QString &name)
{
  PixLoaderDialog pix_dialog;
  pix_dialog.setDir( pixmap_path );
  QPixmap pixmap;
  QString pix_name;
  if( pix_dialog.exec() )
    {
      pix_name = pix_dialog.getCurrent();
      pixmap = loadPixmap( pix_name );
    }
  name = pix_name;
  return pixmap;
}
