


#include "pixloader.h"
#include "MainConfigDialog.h"
#include "MainConfigDialogData.h"
#include "taskbar.h"

extern PixmapLoader *global_pix_loader;

MainConfigDialog::MainConfigDialog( KConfig *conf, TaskBar* par, const char* name )
  : QDialog( NULL, name, FALSE )
{
  data = new MainConfigDialogData( this );
  config = conf;
  parent = par;
  connect( &(data->b_ok), SIGNAL(clicked()), this, SLOT(accept()) );
  connect( &(data->b_cancel), SIGNAL(clicked()), this, SLOT(reject()) );
  connect( &(data->b_restart), SIGNAL(clicked()), this, SLOT(restart()) );
}

void MainConfigDialog::readConfig()
{
  config->setGroup("ktaskbar");
  data->i_menu.setText(config->readEntry("menu_config_file"));
  data->i_sysmenu.setText(config->readEntry("sys_menu_config_file"));
  data->i_ipath.setText(config->readEntry("pixmap_path"));

  if( config->readNumEntry("stay_on_top") == 1 )
    data->c_wm_stay.setChecked(TRUE);
  if( config->readNumEntry("sticky") == 1 )
    data->c_wm_sticky.setChecked(TRUE);
  if( config->readNumEntry("click_to_focus") == 1 )
    data->c_wm_click.setChecked(TRUE);

  if( config->readNumEntry("use_net_button") == 1 )
    data->c_but_net.setChecked(TRUE);
  if( config->readNumEntry("use_netsc_button") == 1 )
    data->c_but_netsc.setChecked(TRUE);
  if( config->readNumEntry("use_clock") == 1 )
    data->c_but_clock.setChecked(TRUE);

  QString key = config->readEntry("key_popup");
  data->i_keypopup.setText( key.left( key.find('(') ) );
  QString mod = key.right( key.length() - key.find('(') );
  if( mod.contains('A') )
    data->c_keypopup_alt.setChecked(TRUE);
  if( mod.contains('C') )
    data->c_keypopup_ctrl.setChecked(TRUE);

  key = config->readEntry("key_iconify");
  data->i_keyicon.setText( key.left( key.find('(') ) );
  mod = key.right( key.length() - key.find('(') );
  if( mod.contains('A') )
    data->c_keyicon_alt.setChecked(TRUE);
  if( mod.contains('C') )
    data->c_keyicon_ctrl.setChecked(TRUE);

  key = config->readEntry("key_deiconify");
  data->i_keydeicon.setText( key.left( key.find('(') ) );
  mod = key.right( key.length() - key.find('(') );
  if( mod.contains('A') )
    data->c_keydeicon_alt.setChecked(TRUE);
  if( mod.contains('C') )
    data->c_keydeicon_ctrl.setChecked(TRUE);

  pixmap_name = config->readEntry("menu_button_pixmap");
  data->b_menupix.setPixmap( global_pix_loader->loadPixmap(pixmap_name) );
  connect( &(data->b_menupix), SIGNAL(clicked()), this, SLOT(selectPixmap()) );
  data->i_menubutton.setText(config->readEntry("menu_button_text"));  
}


void MainConfigDialog::writeConfig()
{
  config->setGroup("ktaskbar");
  config->writeEntry("menu_config_file", data->i_menu.text() );
  config->writeEntry("sys_menu_config_file", data->i_sysmenu.text() );
  config->writeEntry("pixmap_path", data->i_ipath.text() );

  config->writeEntry( "stay_on_top",      (data->c_wm_stay.isChecked()   ? 1 : 0) );
  config->writeEntry( "sticky",           (data->c_wm_sticky.isChecked() ? 1 : 0) );
  config->writeEntry( "click_to_focus",   (data->c_wm_click.isChecked()  ? 1 : 0) );
  config->writeEntry( "use_net_button",   (data->c_but_net.isChecked()   ? 1 : 0) );
  config->writeEntry( "use_netsc_button", (data->c_but_netsc.isChecked() ? 1 : 0) );
  config->writeEntry( "use_clock",        (data->c_but_clock.isChecked() ? 1 : 0) );

  QString key;
  key = data->i_keypopup.text();
  key += '(';
  if( data->c_keypopup_alt.isChecked() )
    key += 'A';
  if( data->c_keypopup_ctrl.isChecked() )
    key += 'C';
  key += ')';
  key.detach();
  config->writeEntry("key_popup", key);

  key = data->i_keyicon.text();
  key += '(';
  if( data->c_keyicon_alt.isChecked() )
    key += 'A';
  if( data->c_keyicon_ctrl.isChecked() )
    key += 'C';
  key += ')';
  key.detach();
  config->writeEntry("key_iconify", key);

  key = data->i_keydeicon.text();
  key += '(';
  if( data->c_keydeicon_alt.isChecked() )
    key += 'A';
  if( data->c_keydeicon_ctrl.isChecked() )
    key += 'C';
  key += ')';
  config->writeEntry("key_deiconify", key);

  config->writeEntry("menu_button_pixmap", pixmap_name);
  config->writeEntry("menu_button_text", data->i_menubutton.text());

  config->sync();
  // configuration written to disk
  // now change running ktaskbar
  parent->use_net_but = data->c_but_net.isChecked();
  parent->use_netsc_but = data->c_but_netsc.isChecked();
  parent->use_clock = data->c_but_clock.isChecked(); 
  parent->menu_bt->setPixmap(*(data->b_menupix.pixmap()));
  parent->menu_bt->setText(data->i_menubutton.text());
  parent->menu_bt->repaint(TRUE);

  parent->cleanupBar();
}

void MainConfigDialog::selectPixmap()
{
  QString name;
  QPixmap pixmap = global_pix_loader->selectPixmap(name);
  if( pixmap.isNull() )
    return;
  data->b_menupix.setPixmap( pixmap );
  pixmap_name = name;
}

void MainConfigDialog::accept()
{
  done( Accepted );
  writeConfig();
}

void MainConfigDialog::restart()
{
  done( Accepted );
  writeConfig();
  parent->send_fvwm_com( "Restart fvwm2" );
}
