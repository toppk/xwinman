
//
//  ktaskbar
//
//  Copyright (C) 1997 Christoph Neerfeld
//  email:  Christoph.Neerfeld@mail.bonn.netsurf.de
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//


#include <qfont.h>
#include <qstring.h>
#include <qframe.h>
#include <qlabel.h>
#include <qpushbt.h>
#include <qlined.h>
#include <qstrlist.h>
#include <qregexp.h>
#include <qapp.h>

#include <core/kpixmap.h>
#include <core/kapp.h>

#include "taskconfig.h"
#include "taskbar.h"
#include "pixloader.h"
#include "pmenu.h"

extern "C" {
#include "module.h"
#include "fvwmlib.h"
#include <stdlib.h>
}

extern PixmapLoader *global_pix_loader;
extern PMenuItem *global_pmenu_buffer;

//----------------------------------------------------------------------
//---------------  MENUCONFIG   ----------------------------------------
//----------------------------------------------------------------------

MenuConfig::MenuConfig( KConfig *conf, PMenu *pm, TaskBar *par)
  : QDialog( NULL, NULL, FALSE, WStyle_Customize | WStyle_NormalBorder )
{
  config = conf;
  pmenu = pm;
  parent = par;
  resize( 470, 250 );
  QFont font("Helvetica", 14);
  QLabel *text = new QLabel(this);
  text->setFont(font);
  text->setText("
 Press the left mouse button on submenubuttons
if you want to open the corresponding submenu.
 By holding down the middle button you may move
a button.
 The right button of your mouse opens a popupmenu
and you can select variouse commands.
 Please note, that there are protected buttons,
that you can not change at all.");
  text->setGeometry(65, 20, 340, 160);
  text = new QLabel(this);
  text->setText("Changing the popupmenus:");
  font.setBold(TRUE);
  text->setFont(font);
  text->setGeometry(40, 10, 340, 30);
  //---
  ok = new QPushButton( "Accept changes", this );
  cancel = new QPushButton( "Dismiss changes", this );
  font.setPointSize(12);
  ok->setFont(font);
  cancel->setFont(font);
  ok->setGeometry(45, 200, 120, 30);
  cancel->setGeometry(305, 200, 120, 30);
  connect( ok, SIGNAL(clicked()), this, SLOT(accept()) );
  connect( cancel, SIGNAL(clicked()), this, SLOT(reject()) );
}

MenuConfig::~MenuConfig()
{
  if( global_pmenu_buffer )
    {
      delete global_pmenu_buffer;
      global_pmenu_buffer = NULL;
    }

}

void MenuConfig::invoke()
{
  QWidget *desk = QApplication::desktop();
  //int dw = desk->width();
  int dh = desk->height();
  QPoint p(0, dh-24);
  pmenu->popupConfig(p, TRUE);
  connect(pmenu, SIGNAL(reposition()), this, SLOT(reposMain()) );
  show();
}

void MenuConfig::reposMain()
{
  QWidget *desk = QApplication::desktop();
  int dh = desk->height();
  QPoint p(0, dh-25);
  pmenu->moveConfig(p);
}

void MenuConfig::accept()
{
  done( Accepted );
  parent->writeConf();
  parent->rebuildMenu();
}

void MenuConfig::reject()
{
  done( Rejected );
  parent->rebuildMenu();
}


//----------------------------------------------------------------------
//---------------  TASKBARCONFIG  --------------------------------------
//----------------------------------------------------------------------

TaskbarConfig::TaskbarConfig(KConfig *conf, int out_p)
  :QDialog(0, NULL, FALSE, WStyle_Customize | WStyle_NormalBorder)
{
  initMetaObject();
  config = conf;
  out_pipe = out_p;
  win_list.setAutoDelete(TRUE);
  pix_list.setAutoDelete(TRUE);
  QFont font("Helvetica", 12, QFont::Bold);
  resize(470, 460);
  setFixedSize(470, 460);
  setCaption( "Configure Taskbar" ); 

  QFrame *fr1;
  QLabel *title1, *text1_1, *text1_2;
  QPushButton *add1, *change1, *rem1;

  fr1 = new QFrame(this);
  fr1->setGeometry(5, 5, 460, 200);
  fr1->setFrameStyle( QFrame::Sunken | QFrame::Box );
  list1 = new QListBox(fr1);
  list1->setGeometry(10, 30, 200, 160);
  connect( list1, SIGNAL(selected(int)), this, SLOT(pix_select(int)));
  title1 = new QLabel("Pixmap", fr1);
  title1->setGeometry(5, 5, 80, 20);
  title1->setFont(font);

  text1_1 = new QLabel("Window Name:", fr1);
  text1_1->setGeometry(220, 30, 80, 20);
  in1_1 = new QLineEdit(fr1);
  in1_1->setGeometry(225, 50, 220, 25);

  text1_2 = new QLabel("Pixmap:", fr1);
  text1_2->setGeometry(220, 80, 80, 20);
  in1_2 = new QLineEdit(fr1);
  in1_2->setGeometry(225, 100, 160, 25);
  connect( in1_2, SIGNAL(returnPressed()), this, SLOT(add_pix()));
  QPushButton *b_select = new QPushButton("Select", fr1);
  b_select->setGeometry( 395, 100, 50, 25 );
  connect( b_select, SIGNAL(clicked()), this, SLOT(selectPix()) );
  add1 = new QPushButton("Add", fr1);
  add1->setGeometry(225 , 165, 50, 25);
  connect( add1, SIGNAL(clicked()), this, SLOT(add_pix()));
  change1 = new QPushButton("Change", fr1);
  change1->setGeometry(310 , 165, 50, 25);
  connect( change1, SIGNAL(clicked()), this, SLOT(change_pix()));
  rem1 = new QPushButton("Remove", fr1);
  rem1->setGeometry(395 , 165, 50, 25);
  connect( rem1, SIGNAL(clicked()), this, SLOT(remove_pix()));
  //----
  QFrame *fr2;
  QLabel *title2, *text2;
  QPushButton *add2, *rem2;

  fr2 = new QFrame(this);
  fr2->setGeometry(5, 210, 460, 200);
  fr2->setFrameStyle( QFrame::Sunken | QFrame::Box );
  list2 = new QListBox(fr2);
  list2->setGeometry(10, 30, 200, 160);
  title2 = new QLabel( "Skiplist", fr2 );
  title2->setGeometry(5, 5, 80, 20);
  title2->setFont(font);

  text2 = new QLabel("Window Name:", fr2);
  text2->setGeometry(220, 30, 80, 20);
  in2 = new QLineEdit(fr2);
  in2->setGeometry(225, 50, 220, 25);
  connect( in2, SIGNAL(returnPressed()), this, SLOT(add_skip()));

  add2 = new QPushButton("Add", fr2);
  add2->setGeometry(225 , 165, 50, 25);
  connect( add2, SIGNAL(clicked()), this, SLOT(add_skip()));
  rem2 = new QPushButton("Remove", fr2);
  rem2->setGeometry(395 , 165, 50, 25);
  connect( rem2, SIGNAL(clicked()), this, SLOT(remove_skip()));


  //----
  QPushButton *ok, *cancel;
  ok = new QPushButton("Ok", this);
  connect( ok, SIGNAL(clicked()), this, SLOT(accept()) );
  ok->setFont(font);
  ok->setGeometry(40, 425, 70, 25);
  cancel = new QPushButton("Cancel", this);
  connect( cancel, SIGNAL(clicked()), this, SLOT(reject()) );
  cancel->setFont(font);
  cancel->setGeometry(360, 425, 70, 25);

  read_config();
}

void TaskbarConfig::add_skip()
{
  const char *text = in2->text();
  if( text[0] == 0 )
    return;
  list2->inSort(text);
  in2->setText("");
}

void TaskbarConfig::remove_skip()
{
  int item = list2->currentItem();
  if( item >= 0 ) 
    list2->removeItem(item);
}

short TaskbarConfig::read_config()
{
  int nr = 0;
  QString temp;
  config->setGroup("ktaskbar");
  temp = config->readEntry("skip_size");
  bool ok = TRUE;
  nr = temp.toInt(&ok);
  if( ok == FALSE )
    return -1;
  list2->clear();
  int i;
  QString entry = "skip_entry";
  QString num;
  for( i = 0; i < nr; i++)
    {
      temp = config->readEntry( (const char *) (entry + num.setNum(i)) );
      if( !temp.isEmpty() )
	list2->inSort(temp);
    }

  temp = config->readEntry("win_size");
  ok = TRUE;
  nr = temp.toInt(&ok);
  if( ok == FALSE )
    return -1;
  list1->clear();
  entry = "win_entry";
  QPixmap pixmap, buf;
  for( i = 0; i < nr; i++)
    {
      temp = config->readEntry( (const char *) (entry + num.setNum(i)) );
      if( !temp.isEmpty() )
	{
	  QString pix, win;
	  win = temp.left( temp.find(',') );
	  win_list.append( win );
	  pix = temp.right( temp.length() - temp.find(',') - 1 );
	  pix_list.append( pix );
	  pixmap.resize(0, 0);
	  pixmap = global_pix_loader->loadPixmap(pix);
	  make_pix(buf, pixmap, win);
	  list1->insertItem(buf);
	}
    }
  return 0;
}

short TaskbarConfig::write_config()
{
  QString num, temp;
  int nr = list2->count();
  config->setGroup("ktaskbar");
  num.setNum(nr);
  config->writeEntry("skip_size", num, TRUE);
  int i;
  QString entry = "skip_entry";
  for( i = 0; i < nr; i++)
    {
      config->writeEntry( entry + temp.setNum(i), list2->text(i), TRUE);
    }
  nr = list1->count();
  QString num2;
  num2.setNum(nr);
  config->writeEntry("win_size", num2, TRUE);
  entry = "win_entry";
  QString *temp_str = new QString[nr];
  for( i = 0; i < nr; i++)
    {
      temp_str[i] = (QString) win_list.at(i) + ',' + pix_list.at(i);
      config->writeEntry( entry + temp.setNum(i), temp_str[i], TRUE);
    }
  config->sync();
  delete [] temp_str;
  return 0;
}

void TaskbarConfig::reject()
{
 done( Rejected );
 read_config();
}

void TaskbarConfig::accept()
{
  done( Accepted );
  write_config();
  ::SendInfo( &out_pipe, "Send_WindowList", 0);
}

bool TaskbarConfig::skip_contains( QString str )
{
  int i;
  int nr = list2->count();
  for( i = 0; i < nr; i++ )
    {
      if( str == (QString) list2->text(i) )
	return TRUE;
    }
  return FALSE;
}

void TaskbarConfig::add_pix()
{
  QString win, pix;
  win = in1_1->text();
  if( win.isEmpty() )
    return;
  pix = in1_2->text();
  win_list.append(win);
  pix_list.append(pix);
  in1_1->setText("");
  in1_2->setText("");
  QPixmap pixmap, buf;
  pixmap = global_pix_loader->loadPixmap(pix);
  make_pix(buf, pixmap, win);
  list1->insertItem(buf);
  list1->update();
  in1_1->setFocus();
}

void TaskbarConfig::remove_pix()
{
  int item = list1->currentItem();
  if( item >= 0 )
    {
      win_list.remove(item);
      pix_list.remove(item);
      list1->removeItem(item);
    }
}

void TaskbarConfig::change_pix()
{
  QString win, pix;
  win = in1_1->text();
  if( win.isEmpty() )
    return;
  int item = list1->currentItem();
  if( item < 0 )
    return;
  win_list.remove(item);
  pix_list.remove(item);
  pix = in1_2->text();
  win_list.insert(item, win);
  pix_list.insert(item, pix);
  QPixmap pixmap, buf;
  pixmap = global_pix_loader->loadPixmap(pix);
  make_pix(buf, pixmap, win);
  list1->changeItem( buf, item);  

  in1_1->setText("");
  in1_2->setText("");
}

void TaskbarConfig::pix_select( int index )
{
  in1_1->setText( win_list.at(index) );
  in1_2->setText( pix_list.at(index) );
}

QPixmap TaskbarConfig::pix_contains( QString str)
{
  QString current = win_list.first();
  if( current == NULL )
    return NULL;
  QPixmap pixmap;
  char *pix;
  QRegExp r(current, FALSE, TRUE);
  if( str.find(r) >= 0 )
    {
      pix = pix_list.at( win_list.at() );
      pixmap = global_pix_loader->loadPixmap(pix);
      return pixmap;
    }
  while ( (current = win_list.next()) != NULL )
    {
      r = current;
      if( str.find(r) >= 0 )
	{
	  pix = pix_list.at( win_list.at() );
	  pixmap = global_pix_loader->loadPixmap(pix);
	  return pixmap;
	}
    }
  return pixmap;
}

void TaskbarConfig::make_pix(QPixmap &buf, QPixmap &pixmap, QString &win)
{
  int w, h;
  QPainter p;
  QFontMetrics fm = list1->fontMetrics();   // size of font set for this widget

  w  = 2 + pixmap.width() + 4 + fm.width( win ) + 2;
  h = ( pixmap.height() > fm.height() ? pixmap.height() : fm.height() ) + 4; 
  
  buf.resize( w, h );                    // resize pixmap
  buf.fill( list1->backgroundColor() );   // clear it
  
  p.begin( &buf );
  p.drawPixmap( 2, 2, pixmap );              // use 2x2 border
  p.setFont( list1->font() );
  p.drawText( 2 + pixmap.width() + 4,        // center text in item
	      0, w, h,
	      AlignVCenter | ShowPrefix | DontClip | SingleLine,
	      win );
  p.end();
}

void TaskbarConfig::selectPix()
{
  QString name;
  QPixmap pixmap = global_pix_loader->selectPixmap(name);
  if( pixmap.isNull() )
    return;
  in1_2->setText(name);
}
