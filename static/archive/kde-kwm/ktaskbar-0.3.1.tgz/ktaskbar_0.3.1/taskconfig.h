// -*- C++ -*-

//
//  ktaskbar
//
//  Copyright (C) 1997 Christoph Neerfeld
//  email:  Christoph.Neerfeld@mail.bonn.netsurf.de
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//


#ifndef TASKCONFIG_H
#define TASKCONFIG_H

#include <qpushbt.h>
#include <qlistbox.h>
#include <qlined.h>
#include <qdialog.h>
#include <qstrlist.h>
#include <qframe.h>

#include <core/kpixmap.h>
#include <core/kapp.h>
#include "pmenu.h"

class TaskBar;

class MenuConfig : public QDialog
{
  Q_OBJECT
public:
  MenuConfig( KConfig *conf, PMenu *pm, TaskBar *par);
  ~MenuConfig();

public slots:
  void invoke();
  void accept();
  void reject();

protected slots:
  void reposMain();

protected:
  KConfig     *config;
  PMenu       *pmenu;
  QPushButton *ok;
  QPushButton *cancel;
  TaskBar     *parent;
};

class TaskbarConfig : public QDialog
{
  Q_OBJECT
public:
  TaskbarConfig (KConfig  *conf, int out_p);
  ~TaskbarConfig () {}

  bool skip_contains( QString str );
  QPixmap pix_contains( QString str );

public slots:
  void invoke () { exec(); }
  void add_skip ();
  void remove_skip ();
  void add_pix ();
  void remove_pix ();
  void change_pix ();
  void accept();
  void reject();

protected slots:
  void pix_select( int index);
  void selectPix();

protected:
  short read_config ();
  short write_config ();
  void  make_pix (QPixmap &buf, QPixmap &pixmap, QString &win);

  KConfig   *config;
  QListBox  *list1;
  QLineEdit *in1_1;
  QLineEdit *in1_2;
  QListBox  *list2;
  QLineEdit *in2;
  int        out_pipe;
  QStrList   win_list;
  QStrList   pix_list;
};

#endif // TASKCONFIG_H
