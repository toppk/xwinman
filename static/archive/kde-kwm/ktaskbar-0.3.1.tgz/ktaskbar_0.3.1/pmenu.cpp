// -*- C++ -*-

//
//  ktaskbar
//
//  Copyright (C) 1997 Christoph Neerfeld
//  email:  Christoph.Neerfeld@mail.bonn.netsurf.de
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//

#include <qdstream.h>
#include <qtstream.h>
#include <qpainter.h>
#include <qpixmap.h>
#include <qapp.h>
#include <qfont.h>

#include <core/kpixmap.h>
#include <core/kapp.h>

#include "pmenu.h"
#include "taskbar.h"
#include "confmenu.h"
#include "pixloader.h"

extern "C" {
#include <stdlib.h>
}

extern PixmapLoader *global_pix_loader;

extern QApplication *main_app;

PMenuItem::PMenuItem()
{
  initMetaObject();
  entry_type = empty; 
  sub_menu = NULL;
  cmenu = NULL;
  recv = NULL;
  memb = NULL;
  pixmap = NULL;
  read_only = FALSE;
}

PMenuItem::PMenuItem( EntryType e, QString t=0, QString c=0, QString n=0, PMenu *menu=0,
		      QObject *receiver=0, char *member=0, CPopupMenu *cm=0, bool ro = FALSE )
{
  initMetaObject();
  entry_type = e;
  text_name = t;
  command_name = c;
  pixmap_name = n;
  if( !pixmap_name.isEmpty() )
    {
      pixmap = global_pix_loader->loadPixmap( pixmap_name );
    }
  else
    {
      pixmap = NULL;
    }
  sub_menu = menu;
  cmenu = cm;
  recv = receiver;
  memb = member;
  read_only = ro;
}

PMenuItem::PMenuItem( PMenuItem &item )
{
  initMetaObject();
  text_name    = item.text_name;
  pixmap_name  = item.pixmap_name;
  pixmap       = item.pixmap;
  entry_type   = item.entry_type; 
  command_name = item.command_name;
  if( entry_type == submenu )
    {
      sub_menu = new PMenu( *(item.sub_menu) );
      cmenu    = new CPopupMenu;
    }
  else
    {
      sub_menu = NULL;
      cmenu    = NULL;
    }
  recv         = item.cmenu;
  memb         = item.memb;
  if( item.read_only && entry_type == prog_com )
    {
      entry_type = unix_com;
      recv = NULL;
      memb = NULL;
    }
  read_only = FALSE; 
}

PMenuItem::~PMenuItem()
{
  if( cmenu ) 
    delete cmenu;
  if( sub_menu )
    delete sub_menu;
}

QPixmap PMenuItem::getPixmap()
{
  return pixmap;
}

QString &operator<<( QString &s, PMenuItem &item )
{
  if( item.read_only )
    {
      s = "";
      return s;
    }
  switch(item.entry_type) {
  case empty:
    s = "";
    return s;
  case submenu:
    s = "Menu ";
    break;
  case separator:
    s = "Separator ";
    break;
  case label:
    s = "Label ";
    break;
  case unix_com:
    s = "Unix_Com ";
    break;
  case fvwm_com:
    s = "Fvwm_Com ";
    break;
  case net_com:
    s = "Net_Com ";
    break;
  default:
    s = "";
    return s;
  };
  s += item.text_name + ", ";
  s += item.pixmap_name + ", ";
  s += item.command_name;
  return s;
}

short PMenuItem::parse( QString &s, PMenu *menu = NULL)
{
  s.simplifyWhiteSpace();
  short pos = s.find(' ');
  short npos;
  if ( pos < 0 )
    { pos = s.length(); }
  QString command = s.left( pos );
//debug ( "com = '%s'", (const char *) command);
  if ( command == "Menu" )
    {
      entry_type = submenu;
      sub_menu = menu;
      cmenu = new CPopupMenu;
    }
  else if ( command == "Separator" )
    {
      entry_type = separator;
      return 0;
    }
  else if ( command == "Label" )
    { entry_type = label; }
  else if ( command == "Unix_Com" )
    { entry_type = unix_com; }
  else if ( command == "Fvwm_Com" )
    { entry_type = fvwm_com; }
  else if ( command == "Net_Com" )
    { entry_type = net_com; }
  else
    { 
      entry_type = empty;
      return -1; 
    }
  if( (npos = s.find(',', pos)) < 0 )
    { entry_type = empty; return -1; }
  while( s[pos+1] == ' ' )  pos++;
  text_name = s.mid( pos+1, npos-pos-1 );
  pos = npos;
  if( (npos = s.find(',', pos+1)) < 0 )
    { entry_type = empty; return -1; }
  while( s[pos+1] == ' ' )  pos++;
  pixmap_name = s.mid( pos+1, npos-pos-1 );
  while( s[npos+1] == ' ' ) npos++;
  command_name = s.right( s.length()-npos-1 );
//debug ( "text = '%s'", (const char *) text_name);
//debug ( "pix = '%s'", (const char *) pixmap_name);
//debug ( "unix = '%s'", (const char *) command_name);
  if( !pixmap_name.isEmpty() )
    {
      pixmap = global_pix_loader->loadPixmap(pixmap_name);
    }
  return 0;
}

void PMenuItem::exec_system()
{
  if( command_name.isNull() )
    return;
  QString name;
  if( command_name.right(1) != "&" )
    name = command_name + " &";
  else
    name = command_name;
  system( (const char *) name );
}

void PMenuItem::exec_fvwm()
{
 ((TaskBar *) (main_app->mainWidget()))->send_fvwm_com(command_name);
}

//--------------------------------------------------------------------------------------

PMenu::PMenu()
{
  initMetaObject();
  menu_conf = NULL;
  list.setAutoDelete(TRUE);
}

PMenu::PMenu( PMenu &menu )
{
  initMetaObject();
  menu_conf = NULL;
  list.setAutoDelete(TRUE);
  PMenuItem *item, *new_item;
  for( item = menu.list.first(); item != 0; item = menu.list.next() )
    {
      new_item = new PMenuItem( *item );
      list.append(new_item);
    }
}

PMenu::~PMenu()
{
  hideConfig();
  list.clear();
}

short PMenu::create_cmenu( CPopupMenu *menu )
{
  KPixmap buffer;
  PMenuItem *item;
  int i;
  int id;
  EntryType et;
  for( item = list.first(); item != 0; item = list.next() )
    {
      et = item->entry_type;
      switch ( et ) {
      case separator:
	menu->insertSeparator();
	continue;
      case submenu:
	item->cmenu->setFont(menu->font());
	item->sub_menu->create_cmenu( item->cmenu );
	create_pixmap(buffer, item, menu);
	id = menu->insertItem(buffer, item->cmenu, -2);
	continue;
      case label:
	create_pixmap(buffer, item, menu);
	id = menu->insertItem( buffer, -2);
	continue;
      case unix_com:
	create_pixmap(buffer, item, menu);
	id = menu->insertItem( buffer, -2);
	if( !item->command_name.isEmpty() )
	  menu->connectItem( id, item, SLOT(exec_system()) );
	continue;
      case fvwm_com:
	create_pixmap(buffer, item, menu);
	id = menu->insertItem( buffer, -2);
	if( !item->command_name.isEmpty() )
	  menu->connectItem( id, item, SLOT(exec_fvwm()) );
	continue;
      case prog_com:
	create_pixmap(buffer, item, menu);
	id = menu->insertItem( buffer, -2);
	menu->connectItem(id, item->recv, item->memb);
	continue;
      case net_com:
	create_pixmap(buffer, item, menu);
	id = menu->insertItem(buffer, -2);
	menu->connectItem( id, item, SLOT(exec_system()) );
	menu->connectItem( id, item->recv, item->memb );
	continue;
      case empty:
	continue;
      default:
	return -1;
      };
    }
  return 0;
}

void PMenu::add (PMenuItem *item)
{
  list.append(item);
}

short PMenu::parse( QDataStream &s )
{
  QString buf;
  short pos;
  QString command;
  PMenuItem *new_item;
  PMenu *new_menu;
  char c;
  s >> c;
  while ( c != '\n' )
    {
      buf += c; 
      s >> c;
    }
  buf.simplifyWhiteSpace();
//  debug("%s", (const char *) buf);
  if( buf != "Begin_Menu" )
    return -1;
  while( !s.eof() )
    { 
      buf = "";
      s >> c;
      while ( c != '\n' && !s.eof() )
	{
	  buf += c; 
	  s >> c;
	}
      buf.simplifyWhiteSpace();
//debug ( "line = '%s'", (const char *) buf);
      if( buf == "End_Menu" )
	break;
      if( (pos = buf.find(' ')) < 0)
	{
	  if ( buf.length() == 0 )
	    continue;
	  else
	    pos = buf.length();
	}
      if( buf == "End_Menu" )
	break;
      command = buf.left(pos);
      if( command == "Menu" )
	{
	  new_menu = new PMenu();
	  new_item = new PMenuItem;
	  new_item->parse(buf, new_menu);
	  if( new_menu->parse(s) < 0) 
	    {
	      delete new_menu;
	      delete new_item;
	      continue;
	    }
	  add(new_item);
	}
      else
	{
	  new_item = new PMenuItem;
	  new_item->parse(buf);
	  add(new_item);
	}
    }
  if ( buf != "End_Menu" )
    return -1;
  return 0;
}

void PMenu::writeConfig( QTextStream &s )
{
  QString text = "";
  s << "Begin_Menu\n";
  PMenuItem *item;
  for( item = list.first(); item != 0; item = list.next() )
    {
      text << (*item);
      if( text.length() == 0 )
	continue;
      s << text << '\n';
      if( item->getType() == submenu )
	item->sub_menu->writeConfig(s);
    }
  s << "End_Menu\n";
}

void PMenu::move(short item_id, short new_pos)
{
  PMenuItem *current;
  PMenuItem *item;
  if( item_id > new_pos )
    {
      item = list.take(item_id);
      list.insert( new_pos, item);
    }
  else
    {
      item = list.take(item_id);
      list.insert( new_pos - 1, item);
    }
  //debug
  //debug("but_id = %i / new_pos = %i", item_id, new_pos);
  //int i = 0;
  //for( item = list.first(); item != 0; item = list.next(), i++ )
  //  {
  //    debug("PMenu:: name = %s / id = %i", (const char *) item->getText(), i);
  //  }
}

void PMenu::remove( short item_id )
{
  list.remove( item_id );
}

void PMenu::create_pixmap( KPixmap &buf, PMenuItem *item, QPopupMenu *menu)
{
  int w, h;
  QPainter p;
  QFontMetrics fm = menu->fontMetrics();   // size of font set for this widget

  w  = 2 + item->pixmap.width() + 4 + fm.width( item->text_name ) + 2;
  h = ( item->pixmap.height() > fm.height() ? item->pixmap.height() : fm.height() ) + 4; 
  
  buf.resize( w, h );                    // resize pixmap
  buf.fill( menu->backgroundColor() );   // clear it
  
  p.begin( &buf );
  p.drawPixmap( 2, 2, item->pixmap );              // use 2x2 border
  p.setFont( menu->font() );
  /*
  p.drawText( 2 + item->pixmap.width() + 4,        // center text in item
	      (h + fm.height()) / 2 - fm.descent(),
	      item->text_name );
	      */
  p.drawText( 2 + item->pixmap.width() + 4,        // center text in item
	      0, w, h,
	      AlignVCenter | ShowPrefix | DontClip | SingleLine,
	      item->text_name );
  p.end();
}

void PMenu::set_net_recv(QObject *receiver, char *member)
{
  PMenuItem *item;
  for( item = list.first(); item != 0; item = list.next() )
    {
      if( item->entry_type == net_com )
	{
	  item->recv = receiver;
	  item->memb = member;
	}
    }
}

void PMenu::popupConfig(QPoint p, bool bot = FALSE)
{
  if( !menu_conf )
    {
      menu_conf = new ConfigureMenu(this);
      PMenuItem *item;
      for( item = list.first(); item != 0; item = list.next() )
	{
	  menu_conf->append(item);
	}
      if( bot )
	{
	  QPoint np( 0, menu_conf->getHeight()+3 );
	  p -= np;
	}
      QWidget *desk = QApplication::desktop();
      int dw = desk->width();
      int dh = desk->height();
      int width = menu_conf->getWidth();
      int height = menu_conf->getHeight();
      int x = p.x();
      int y = p.y();
      if( (x+width) > dw )
	x = dw - width;
      if( (y+height+27) > dh )
	y = dh - height - 27;
      menu_conf->move(x, y);
      menu_conf->show();
    }
  else
    {
      hideConfig();
    }
}

void PMenu::moveConfig(QPoint p)
{
  if( menu_conf )
    {
      QWidget *desk = QApplication::desktop();
      int dw = desk->width();
      int dh = desk->height();
      int width = menu_conf->getWidth();
      int height = menu_conf->getHeight();
      int x = p.x();
      int y = p.y();
      if( (x+width) > dw )
	x = dw - width;
      if( (y+height+27) > dh )
	y = dh - height - 27;
      menu_conf->move(x, y);
    }
}

void PMenu::hideConfig()
{
  if( menu_conf )
    {
      menu_conf->hide();
      delete menu_conf;
      menu_conf = NULL;
    }
}

