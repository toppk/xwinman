/****************************************************************************
** CPopupMenu meta object code from reading C++ file 'cpopmenu.h'
**
** Created: Tue Feb 4 12:32:19 1997
**      by: The Qt Meta Object Compiler ($Revision: 2.5.2.1 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include <qmetaobj.h>
#include "cpopmenu.h"


const char *CPopupMenu::className() const
{
    return "CPopupMenu";
}

QMetaObject *CPopupMenu::metaObj = 0;

void CPopupMenu::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QPopupMenu::metaObject() )
	QPopupMenu::initMetaObject();
    metaObj = new QMetaObject( "CPopupMenu", "QPopupMenu",
	0, 0,
	0, 0 );
}
