/****************************************************************************
** MenuConfig meta object code from reading C++ file 'taskconfig.h'
**
** Created: Tue Feb 4 12:32:19 1997
**      by: The Qt Meta Object Compiler ($Revision: 2.5.2.1 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include <qmetaobj.h>
#include "taskconfig.h"


const char *MenuConfig::className() const
{
    return "MenuConfig";
}

QMetaObject *MenuConfig::metaObj = 0;

void MenuConfig::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QDialog::metaObject() )
	QDialog::initMetaObject();
    typedef void(MenuConfig::*m1_t0)();
    typedef void(MenuConfig::*m1_t1)();
    typedef void(MenuConfig::*m1_t2)();
    typedef void(MenuConfig::*m1_t3)();
    m1_t0 v1_0 = &MenuConfig::invoke;
    m1_t1 v1_1 = &MenuConfig::accept;
    m1_t2 v1_2 = &MenuConfig::reject;
    m1_t3 v1_3 = &MenuConfig::reposMain;
    QMetaData *slot_tbl = new QMetaData[4];
    slot_tbl[0].name = "invoke()";
    slot_tbl[1].name = "accept()";
    slot_tbl[2].name = "reject()";
    slot_tbl[3].name = "reposMain()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    metaObj = new QMetaObject( "MenuConfig", "QDialog",
	slot_tbl, 4,
	0, 0 );
}


const char *TaskbarConfig::className() const
{
    return "TaskbarConfig";
}

QMetaObject *TaskbarConfig::metaObj = 0;

void TaskbarConfig::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QDialog::metaObject() )
	QDialog::initMetaObject();
    typedef void(TaskbarConfig::*m1_t0)();
    typedef void(TaskbarConfig::*m1_t1)();
    typedef void(TaskbarConfig::*m1_t2)();
    typedef void(TaskbarConfig::*m1_t3)();
    typedef void(TaskbarConfig::*m1_t4)();
    typedef void(TaskbarConfig::*m1_t5)();
    typedef void(TaskbarConfig::*m1_t6)();
    typedef void(TaskbarConfig::*m1_t7)();
    typedef void(TaskbarConfig::*m1_t8)(int);
    typedef void(TaskbarConfig::*m1_t9)();
    m1_t0 v1_0 = &TaskbarConfig::invoke;
    m1_t1 v1_1 = &TaskbarConfig::add_skip;
    m1_t2 v1_2 = &TaskbarConfig::remove_skip;
    m1_t3 v1_3 = &TaskbarConfig::add_pix;
    m1_t4 v1_4 = &TaskbarConfig::remove_pix;
    m1_t5 v1_5 = &TaskbarConfig::change_pix;
    m1_t6 v1_6 = &TaskbarConfig::accept;
    m1_t7 v1_7 = &TaskbarConfig::reject;
    m1_t8 v1_8 = &TaskbarConfig::pix_select;
    m1_t9 v1_9 = &TaskbarConfig::selectPix;
    QMetaData *slot_tbl = new QMetaData[10];
    slot_tbl[0].name = "invoke()";
    slot_tbl[1].name = "add_skip()";
    slot_tbl[2].name = "remove_skip()";
    slot_tbl[3].name = "add_pix()";
    slot_tbl[4].name = "remove_pix()";
    slot_tbl[5].name = "change_pix()";
    slot_tbl[6].name = "accept()";
    slot_tbl[7].name = "reject()";
    slot_tbl[8].name = "pix_select(int)";
    slot_tbl[9].name = "selectPix()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    slot_tbl[4].ptr = *((QMember*)&v1_4);
    slot_tbl[5].ptr = *((QMember*)&v1_5);
    slot_tbl[6].ptr = *((QMember*)&v1_6);
    slot_tbl[7].ptr = *((QMember*)&v1_7);
    slot_tbl[8].ptr = *((QMember*)&v1_8);
    slot_tbl[9].ptr = *((QMember*)&v1_9);
    metaObj = new QMetaObject( "TaskbarConfig", "QDialog",
	slot_tbl, 10,
	0, 0 );
}
