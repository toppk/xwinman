// -*- C++ -*-

//
//  ktaskbar
//
//  Copyright (C) 1997 Christoph Neerfeld
//  email:  Christoph.Neerfeld@mail.bonn.netsurf.de
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//

#ifndef PMENU_H
#define PMENU_H

#include <qpixmap.h>
#include <qlist.h>

#include <core/kpixmap.h>
#include <core/kapp.h>
#include "cpopmenu.h"

class PMenu;
class ConfigureMenu;

enum EntryType { empty, separator, submenu, unix_com, fvwm_com, prog_com, net_com, label };

class PMenuItem : public QObject
{
  Q_OBJECT;
  friend QString &operator<<(QString &, PMenuItem &);
  friend PMenu;
public:
  PMenuItem();
  PMenuItem( EntryType e, QString t=0, QString c=0, QString n=0, PMenu *menu=0,
	      QObject *receiver=0, char *member=0, CPopupMenu *cm=0, bool ro = FALSE );
  PMenuItem( PMenuItem &item );
  ~PMenuItem ();

  short     parse( QString &s, PMenu *menu = NULL);
  void      setText( QString t ) { text_name = t; }
  QString   getText() { return text_name; }
  void      setPixmap( QPixmap pix ) { pixmap = pix; }
  QPixmap   getPixmap();
  void      setPixmapName( QString t ) { pixmap_name = t; }
  QString   getPixmapName() { return pixmap_name; }
  void      setType( EntryType e) { entry_type = e; }
  EntryType getType() { return entry_type; }
  void      setCommand( QString t ) { command_name = t; }
  QString   getCommand() { return command_name; }
  void      setMenu( PMenu *menu );
  PMenu    *getMenu() { return sub_menu; }
  void      removeMenu();
  void      setRecv( QObject *receiver, char *member ) { recv = receiver; memb = member; }
  bool      isReadOnly() { return read_only; }
  void      setReadOnly( bool b ) { read_only = b; }

protected slots:
  void exec_system();
  void exec_fvwm();

protected:
  QString     text_name;
  QString     pixmap_name;
  QPixmap     pixmap;
  EntryType   entry_type;
  QString     command_name;
  PMenu      *sub_menu;
  CPopupMenu *cmenu;
  QObject    *recv;
  char       *memb;
  bool        read_only;
};

class PMenu : public QObject
{
  Q_OBJECT
public:
  PMenu ();
  PMenu ( PMenu &menu );
  ~PMenu ();

  void       add ( PMenuItem *item);
  void       move( short item_id, short new_pos);
  void       remove( short item_id );
  short      parse ( QDataStream &s );
  void       writeConfig( QTextStream &s );
  PMenuItem *cut( short pos ) { return NULL; }
  PMenuItem *copy( short pos ) { return NULL; }
  void       paste( PMenuItem *item ) { item = NULL; }
  short      create_cmenu( CPopupMenu *menu );
  void       create_pixmap( KPixmap &buf, PMenuItem *item, QPopupMenu *menu );
  void       set_net_recv( QObject *receiver, char *member );
  void       popupConfig(QPoint p, bool bot = FALSE);
  void       posRequest() { emit reposition (); }

signals:
  void reposition();

public slots:
  void moveConfig(QPoint p);
  void hideConfig();

protected:
  QList<PMenuItem> list;
  ConfigureMenu   *menu_conf;
};


inline void PMenuItem::setMenu( PMenu *menu )
{
  if( sub_menu )
    delete sub_menu; 
  sub_menu = menu; 
}

inline void PMenuItem::removeMenu()
{
  if( sub_menu )
    delete sub_menu;
  sub_menu = NULL; 
}

#endif // PMENU_H
