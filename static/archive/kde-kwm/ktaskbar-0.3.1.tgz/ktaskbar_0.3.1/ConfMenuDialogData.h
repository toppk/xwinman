#ifndef ConfMenuDialogData_included
#define ConfMenuDialogData_included


class ConfMenuDialogData
{
public:

    ConfMenuDialogData
    (
        QWidget* parent
    );



};

#endif // ConfMenuDialogData_included
