/****************************************************************************
** TaskButton meta object code from reading C++ file 'taskbutton.h'
**
** Created: Tue Feb 4 12:32:19 1997
**      by: The Qt Meta Object Compiler ($Revision: 2.5.2.1 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include <qmetaobj.h>
#include "taskbutton.h"


const char *TaskButton::className() const
{
    return "TaskButton";
}

QMetaObject *TaskButton::metaObj = 0;

void TaskButton::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QPushButton::metaObject() )
	QPushButton::initMetaObject();
    typedef void(TaskButton::*m2_t0)();
    typedef void(TaskButton::*m2_t1)();
    typedef void(TaskButton::*m2_t2)();
    typedef void(TaskButton::*m2_t3)();
    typedef void(TaskButton::*m2_t4)();
    typedef void(TaskButton::*m2_t5)();
    m2_t0 v2_0 = &TaskButton::Mclicked;
    m2_t1 v2_1 = &TaskButton::Rclicked;
    m2_t2 v2_2 = &TaskButton::Mpressed;
    m2_t3 v2_3 = &TaskButton::Rpressed;
    m2_t4 v2_4 = &TaskButton::Mreleased;
    m2_t5 v2_5 = &TaskButton::Rreleased;
    QMetaData *signal_tbl = new QMetaData[6];
    signal_tbl[0].name = "Mclicked()";
    signal_tbl[1].name = "Rclicked()";
    signal_tbl[2].name = "Mpressed()";
    signal_tbl[3].name = "Rpressed()";
    signal_tbl[4].name = "Mreleased()";
    signal_tbl[5].name = "Rreleased()";
    signal_tbl[0].ptr = *((QMember*)&v2_0);
    signal_tbl[1].ptr = *((QMember*)&v2_1);
    signal_tbl[2].ptr = *((QMember*)&v2_2);
    signal_tbl[3].ptr = *((QMember*)&v2_3);
    signal_tbl[4].ptr = *((QMember*)&v2_4);
    signal_tbl[5].ptr = *((QMember*)&v2_5);
    metaObj = new QMetaObject( "TaskButton", "QPushButton",
	0, 0,
	signal_tbl, 6 );
}

// SIGNAL Mclicked
void TaskButton::Mclicked()
{
    activate_signal( "Mclicked()" );
}

// SIGNAL Rclicked
void TaskButton::Rclicked()
{
    activate_signal( "Rclicked()" );
}

// SIGNAL Mpressed
void TaskButton::Mpressed()
{
    activate_signal( "Mpressed()" );
}

// SIGNAL Rpressed
void TaskButton::Rpressed()
{
    activate_signal( "Rpressed()" );
}

// SIGNAL Mreleased
void TaskButton::Mreleased()
{
    activate_signal( "Mreleased()" );
}

// SIGNAL Rreleased
void TaskButton::Rreleased()
{
    activate_signal( "Rreleased()" );
}
