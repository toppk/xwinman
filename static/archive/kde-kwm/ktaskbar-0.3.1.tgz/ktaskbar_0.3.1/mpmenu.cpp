/****************************************************************************
** PMenuItem meta object code from reading C++ file 'pmenu.h'
**
** Created: Tue Feb 4 13:17:53 1997
**      by: The Qt Meta Object Compiler ($Revision: 2.5.2.1 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include <qmetaobj.h>
#include "pmenu.h"


const char *PMenuItem::className() const
{
    return "PMenuItem";
}

QMetaObject *PMenuItem::metaObj = 0;

void PMenuItem::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QObject::metaObject() )
	QObject::initMetaObject();
    typedef void(PMenuItem::*m1_t0)();
    typedef void(PMenuItem::*m1_t1)();
    m1_t0 v1_0 = &PMenuItem::exec_system;
    m1_t1 v1_1 = &PMenuItem::exec_fvwm;
    QMetaData *slot_tbl = new QMetaData[2];
    slot_tbl[0].name = "exec_system()";
    slot_tbl[1].name = "exec_fvwm()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    metaObj = new QMetaObject( "PMenuItem", "QObject",
	slot_tbl, 2,
	0, 0 );
}


const char *PMenu::className() const
{
    return "PMenu";
}

QMetaObject *PMenu::metaObj = 0;

void PMenu::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QObject::metaObject() )
	QObject::initMetaObject();
    typedef void(PMenu::*m1_t0)(QPoint);
    typedef void(PMenu::*m1_t1)();
    m1_t0 v1_0 = &PMenu::moveConfig;
    m1_t1 v1_1 = &PMenu::hideConfig;
    QMetaData *slot_tbl = new QMetaData[2];
    slot_tbl[0].name = "moveConfig(QPoint)";
    slot_tbl[1].name = "hideConfig()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    typedef void(PMenu::*m2_t0)();
    m2_t0 v2_0 = &PMenu::reposition;
    QMetaData *signal_tbl = new QMetaData[1];
    signal_tbl[0].name = "reposition()";
    signal_tbl[0].ptr = *((QMember*)&v2_0);
    metaObj = new QMetaObject( "PMenu", "QObject",
	slot_tbl, 2,
	signal_tbl, 1 );
}

// SIGNAL reposition
void PMenu::reposition()
{
    activate_signal( "reposition()" );
}
