//
//  ktaskbar
//
//  Copyright (C) 1997 Christoph Neerfeld
//  email:  Christoph.Neerfeld@mail.bonn.netsurf.de
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//


#include <qfont.h>
#include <qlist.h>
#include <qcombo.h>
#include <qlabel.h>
#include <qlined.h>
#include <qscrbar.h>
#include <qmsgbox.h>
#include <qapp.h>

#include "confmenu.h"
#include "taskbutton.h"
#include "ConfMenuDialog.h"
#include "pixloader.h"

extern PixmapLoader *global_pix_loader;
const short glob_but_height = 24;
PMenuItem *global_pmenu_buffer = NULL;

//----------------------------------------------------------------------
//---------------  MENUBUTTON  -----------------------------------------
//----------------------------------------------------------------------


MenuButton::MenuButton( PMenuItem *p_it, int i, QWidget *parent,
                          const char *name )
  : TaskButton( p_it->getText(), parent, name )
{
  id = i;
  type = p_it->getType();
  setPixmap( p_it->getPixmap() );
  QFont font("Helvetica", 12, QFont::Bold);
  setFont(font);
  //  but->setStyle(WindowsStyle);
  pmenu_item = p_it;
  dialog = NULL;
  dialog_open = FALSE;
  move_button = FALSE;
  submenu_open = FALSE;
  if( type == submenu )
    {
      popmenu.insertItem("Open/ Close", this, SLOT(open()));
      connect( this, SIGNAL(clicked(int)), this, SLOT(sOpen(int)) );
    }
  if( (pmenu_item->isReadOnly()) )
    {
      popmenu.insertItem("Copy", this, SLOT(copyItem()));
      popmenu.insertItem("! PROTECTED Button !");
    }
  else
    {
      popmenu.insertItem("Change", this, SLOT(change_item()));
      popmenu.insertItem("New", this, SLOT(new_item()));
      popmenu.insertItem("Cut", this, SLOT(cutItem()));
      popmenu.insertItem("Copy", this, SLOT(copyItem()));
      popmenu.insertItem("Paste", this, SLOT(pasteItem()));
      popmenu.insertItem("Delete", this, SLOT(delete_item()));
    }
  connect( this, SIGNAL(Rpressed(int)), this, SLOT(popupMenu(int)) );
}

MenuButton::~MenuButton()
{
  if( dialog )
    delete dialog;
}

void MenuButton::copyItem()
{
  if( global_pmenu_buffer )
    {
      delete global_pmenu_buffer;
      global_pmenu_buffer = NULL;
    }
  global_pmenu_buffer = new PMenuItem( *pmenu_item );
}

void MenuButton::open()
{
  if( dialog_open )
    return;
  QPoint p = pos() + topLevelWidget()->pos();
  QPoint p2(width()-2, 6);
  p += p2;
  pmenu_item->getMenu()->popupConfig(p);
  if( submenu_open )
    {
      submenu_open = FALSE;
      disconnect( pmenu_item->getMenu(), SIGNAL(reposition()),
		  this, SLOT(childRepos()) );
    }
  else
    {
      submenu_open = TRUE;
      connect( pmenu_item->getMenu(), SIGNAL(reposition()),
	       this, SLOT(childRepos()) );
    }
  repaint();
}

void MenuButton::delete_item()
{
  QMessageBox msg_box;
  if( pmenu_item->getType() == submenu )
    {
      if( !msg_box.query( "Warning !",\
			  "If you delete this button you will lose all of its submenus",\
			  "Ok", "Cancel" ) )
	{ return; }
    }
  emit delButton( id );
}

void MenuButton::change_item()
{
  if( dialog_open )
    return;
  dialog = new ConfMenuDialog(this);
  dialog_open = TRUE;
  dialog->i_name->setText(pmenu_item->getText());
  dialog->i_pixmap->setText(pmenu_item->getPixmapName());
  dialog->i_command->setText(pmenu_item->getCommand());
  dialog->c_type->setCurrentItem(pmenu_item->getType()-1);
  dialog->b_pixmap->setPixmap( pmenu_item->getPixmap() );
  dialog->old_pixname = pmenu_item->getPixmapName();
  dialog->show();
}

void MenuButton::change_accept()
{
  if( dialog )
    {
      EntryType old_type = pmenu_item->getType();
      EntryType new_type = (EntryType) (dialog->c_type->currentItem()+1);
      if( old_type != new_type )
	{
	  if( old_type == submenu )
	    {
	      QMessageBox msg_box;
	      if( msg_box.query( "Warning !",\
				 "Changing the type of this button will delete all of its submenus",\
				 "Ok", "Cancel" ) )
		{
		  popmenu.removeItemAt(0);
		  disconnect( this, SIGNAL(clicked(int)), this, SLOT(sOpen(int)) );
		  pmenu_item->removeMenu();
		}
	      else
		{
		  dialog->show();
		  return;
		}
	    }
	  if( new_type == submenu )
	    {
	      popmenu.insertItem( "Open/ Close", 0, 0 );
	      popmenu.connectItem( 0, this, SLOT(open()) );
	      connect( this, SIGNAL(clicked(int)), this, SLOT(sOpen(int)) );
	      PMenu *new_menu = new PMenu();
	      new_menu->add( new PMenuItem(unix_com, "EMPTY", "no command") );
	      pmenu_item->setMenu( new_menu );
	    }
	}
      pmenu_item->setType( new_type );
      pmenu_item->setText(dialog->i_name->text());
      setText(pmenu_item->getText());
      pmenu_item->setPixmapName(dialog->i_pixmap->text());
      pmenu_item->setCommand(dialog->i_command->text());
      pmenu_item->setPixmap( global_pix_loader->loadPixmap( dialog->i_pixmap->text()) );
      setPixmap( pmenu_item->getPixmap() );
      ((ConfigureMenu *) parentWidget()->parentWidget())->update();
      delete dialog;
      dialog = NULL;
      dialog_open = FALSE;
    }
}

void MenuButton::change_reject()
{
  if( dialog )
    {
      delete dialog;
      dialog = NULL;
      dialog_open = FALSE;
    }
}

void MenuButton::popupMenu(int)
{
  if( dialog_open )
    return;
  QPoint p = pos() + topLevelWidget()->pos();
  QPoint p2(width()/2, height()/2);
  p += p2;
  setDown(FALSE);
  repaint(FALSE);
  popmenu.popup(p);
}

void MenuButton::moveEvent( QMoveEvent *e)
{
  if( pmenu_item->getMenu() )
    {
      QPoint p = pos() + topLevelWidget()->pos();
      QPoint p2(width()-2, 6);
      p += p2;
      pmenu_item->getMenu()->moveConfig(p);
//debug("name = %s", text() );
    }
}

void MenuButton::mousePressEvent( QMouseEvent *e)
{
  if ( isDown() )
    return;
  bool hit = hitButton( e->pos() );
  if ( hit ) 
    {                                // mouse press on button
      setDown( TRUE );
      repaint( FALSE );
      if( e->button() == LeftButton )
	emit pressed(id);
      else if( e->button() == MidButton )
	{
	  if( !(pmenu_item->isReadOnly()) )
	    {
	      move_button = TRUE;
	      setCursor(sizeAllCursor);
	      raise();
	      move_offset = e->pos();
	      emit Mpressed(id);
	    }
	}
      else
	emit Rpressed(id);
    }
}

void MenuButton::mouseReleaseEvent( QMouseEvent *e)
{
  if ( !isDown() )
    return;
  bool hit = hitButton( e->pos() );
  setDown( FALSE );
  if( e->button() == MidButton )
    {
      move_button = FALSE;
      setCursor(arrowCursor);
      emit posChanged(id, pos());
    }
  if ( hit )
    {                                // mouse release on button
      if ( isToggleButton() )
	setOn( !isOn() );
      repaint( FALSE );
      if ( isToggleButton() )
	emit toggled( isOn() );
      if( e->button() == LeftButton )
	{ emit released(id);
	emit clicked(id); }
      else if( e->button() == MidButton )
	{ emit Mreleased(id);
	emit Mclicked(id); }
      else
	{ emit Rreleased(id);
	emit Rclicked(id); }
    }
  else
    {
      repaint( FALSE );
      if( e->button() == LeftButton )
	emit released(id);
      else if( e->button() == MidButton )
	emit Mreleased(id);
      else
	emit Rreleased(id);
    }
}

void MenuButton::mouseMoveEvent( QMouseEvent *e)
{
  if( move_button )
    {
      int y = mapToParent(e->pos()).y() - move_offset.y();
      if( y < 0 )
	y = 0;
      if( y+height() > parentWidget()->height() )
	y = parentWidget()->height() - height();
      move(0, y);
      return;
    }
  bool hit = hitButton( e->pos() );
  if ( hit )
    {                                // mouse move in button
      if ( !isDown() )
	{
	  setDown( TRUE );
	  repaint( FALSE );
	  if( e->button() == LeftButton )
	    emit pressed(id);
	  else if( e->button() == MidButton )
	    emit Mpressed(id);
	  else
	    emit Rpressed(id);
	}
    }
  else
    {                                    // mouse move outside button
      /*
      if ( isDown() )
	{
	  setDown( FALSE );
	  repaint( FALSE );
	  if( e->button() == LeftButton )
	    emit released(id);
	  else if( e->button() == MidButton )
	    emit Mreleased(id);
	  else
	    emit Rreleased(id);
	}
	*/
    }
}

void MenuButton::drawButtonLabel( QPainter *paint )
{
  if( pmenu_item->getType() == separator )
    return;
  register QPainter *p = paint;
  GUIStyle    gs = style();
  QColorGroup g  = colorGroup();
  int         dt = 0;
  switch ( gs )
    {
    case WindowsStyle:
      dt = 1;
      break;
    case MotifStyle:
      p->setPen( g.text() );
      break;
    default:
      ;
    }
  if( grayed )
    p->setPen( palette().disabled().text() );
  QRect r = rect();
  int x, y, w, h;
  r.rect( &x, &y, &w, &h );
  if ( isDown() || isOn() )
    {                 // shift pixmap/text
      x += dt;
      y += dt;
    }
  x += 2;  y += 2;  w -= 4;  h -= 4;
  const QPixmap *pm = bpixmap;
  if ( bpixmap ) 
    {
      if ( pm->width() > w || pm->height() > h )
	p->setClipRect( x, y, w, h );
      if ( gs == WindowsStyle && !isDown() && isOn() ) 
	{
	  if ( pm->depth() == 1 )
	    p->setBackgroundColor( g.background().light() );
	} 
      else
	{
            p->setBackgroundColor( g.background() );
        }
      if( text() )
	x += 2;
      else
	x += w/2 - pm->width()/2;               // center
      // y += h/2 - pm->height()/2;
      p->drawPixmap( x, y + h/2 - pm->height()/2, *pm );
      p->setClipping( FALSE );
    }
  if ( text() )
    if( bpixmap )
      {
	w -= (4 + pm->width());
	QFontMetrics fm = p->fontMetrics();
	QString str = text();
	if( fm.width(str) > w )
	  { 
	    short len = str.length();
	    while( fm.width( str, len ) > w )
	      {
		len--;
	      }
	    str.truncate(len);
	    str += "...";
	    p->drawText( x+pm->width()+2, y, w, h, AlignLeft|AlignVCenter|ShowPrefix, str );
	  }
	p->drawText( x+pm->width()+2, y, w, h, AlignLeft|AlignVCenter|ShowPrefix, text() );
      }
    else
      {
	w -= 2;
	QFontMetrics fm = p->fontMetrics();
	QString str = text();
	if( fm.width(str) > w )
	  { 
	    short len = str.length();
	    while( fm.width( str, len ) > w )
	      {
		len--;
	      }
	    str.truncate(len);
	    str += "...";
	    p->drawText( x+2, y, w, h, AlignLeft|AlignVCenter|ShowPrefix, str );
	  }
	else
	  p->drawText( x+2, y, w, h, AlignLeft|AlignVCenter|ShowPrefix, text() );
      }
  if( pmenu_item->getType() == submenu )
    {
      qDrawArrow( p, RightArrow, gs, submenu_open,
		  width() - 10,  height()/2-2,
		  4, 4, g );
    }
}

//----------------------------------------------------------------------
//---------------  CONFMENUITEM  ---------------------------------------
//----------------------------------------------------------------------

ConfMenuItem::ConfMenuItem(MenuButton *but, PMenuItem *item)
{
  button = but;
  pmenu_item = item;
}

//----------------------------------------------------------------------
//---------------  CONFIGUREMENU  --------------------------------------
//----------------------------------------------------------------------


ConfigureMenu::ConfigureMenu( PMenu *m, QWidget *parent, const char *name )
  : QFrame( parent, name, WStyle_Customize | WStyle_NoBorder )
     //: QFrame( parent, name )

{
    initMetaObject();
    setCaption("KTaskbar Menu");
    setFrameStyle( QFrame::Panel | QFrame::Raised );
    pmenu = m;
    but_list.setAutoDelete(TRUE);
    prot_group = new QButtonGroup(this);
    prot_group->setFrameStyle( QFrame::NoFrame );
    prot_group->move(3,3);
    but_group = new QButtonGroup(this);
    but_group->setFrameStyle( QFrame::NoFrame );
    but_group->move(3,3);
    but_group->hide();
    but_nr = 0;
    width = 0;
    height = 3;
    group_height = 0;
}

ConfigureMenu::~ConfigureMenu()
{
  ConfMenuItem *item;
  for( item = but_list.first(); item != 0; item = but_list.next() )
    {
      if( item->pmenu_item->getMenu() )
	{
	  item->pmenu_item->getMenu()->hideConfig();
	}
    }
  but_list.clear();
  if( but_group )
    delete but_group;
}

void ConfigureMenu::append(PMenuItem *item)
{
  short but_width, but_height;
  MenuButton *but;
  ConfMenuItem *conf_item;
  but = new MenuButton(item, but_nr, item->isReadOnly() ? prot_group : but_group);
  but_width = but->sizeHint().width();
  if( item->getType() == separator )
    but_height = 5;
  else
    but_height = glob_but_height;
  height += but_height;
  if( !(item->isReadOnly()) )
    {
      group_height += but_height;
      but_group->show();
    }
  if( but_width+6 > width )
    {
      width = but_width+6;
      ConfMenuItem *l_but;
      for( l_but = but_list.first(); l_but != 0; l_but = but_list.next() )
	{
	  l_but->button->resize(width-6, l_but->button->height());
	}
    }
  but_group->resize(width-6, group_height);
  prot_group->resize(width-6, height-3);
  resize(width, height+3);
  but->setGeometry( 0, height-but_height-3, width-6, but_height );
  but->show();
  pmenu->posRequest();
  //----
  conf_item = new ConfMenuItem(but, item);
  but_list.append(conf_item);
  connect( but, SIGNAL(posChanged(int,QPoint)), this, SLOT(buttonMoved(int, QPoint)) );
  connect( but, SIGNAL(newButton(int)), this, SLOT(newButton(int)) );
  connect( but, SIGNAL(delButton(int)), this, SLOT(delButton(int)) );
  connect( but, SIGNAL(pasteButton(int)), this, SLOT(pasteButton(int)) );
  but_nr++;
}

void ConfigureMenu::update()
{
  hide();
  QListIterator<ConfMenuItem> it1(but_list);
  QListIterator<ConfMenuItem> it2(but_list);
  short but_width, but_height;
  ConfMenuItem *item;
  height = 3;
  group_height = 0;
  width = 0;
  for( ; it1.current(); ++it1 )
    {
      item = it1.current();
      but_width = item->button->sizeHint().width();
      if( item->pmenu_item->getType() == separator )
	but_height = 5;
      else
	but_height = glob_but_height;
      height += but_height;
      if( !(item->pmenu_item->isReadOnly()) )
	{
	  group_height += but_height;
	  but_group->show();
	}
      if( but_width+6 > width )
	{
	  width = but_width+6;
	  ConfMenuItem *l_but;
	  it2.toFirst();
	  for( ; it2.current(); ++it2 )
	    {
	      l_but = it2.current();
	      l_but->button->resize(width-6, l_but->button->height());
	      l_but->button->move( l_but->button->pos() );
	    }
	}
      but_group->resize(width-6, group_height);
      prot_group->resize(width-6, height-3);
      resize(width, height+3);
      item->button->setGeometry( 0, height-but_height-3, width-6, but_height );
    }
  pmenu->posRequest();
  show();
  QWidget::update();
}

void ConfigureMenu::buttonMoved( int but_id, QPoint p )
{
  ConfMenuItem *item;
  int i;
  int y = p.y();
  int h = 0;
  for( i = 0, item = but_list.first(); item != 0; item = but_list.next(), i++ )
    {
      if( y <= item->button->y() )
	if( i == but_id )
	  continue;
	else
	  break;
      h += item->button->height();
    }
  //debug( "i = %i", i);
  int moved_b_height = but_list.at(but_id)->button->height();
  MenuButton *current = but_list.at(but_id)->button;
  if( but_id > i )
    {
      current->move(0, h);
      current->setId(i);
      for( int j = i; j < but_id; j++ )
	{
	  current = but_list.at(j)->button;
	  current->move( 0, current->pos().y() + moved_b_height ) ;
	  current->setId(j+1);
	}
      item = but_list.take(but_id);
      but_list.insert( i, item);
    }
  else
    {
      current->setId(i-1);
      for( int j = but_id+1; j < i; j++ )
	{
	  current = but_list.at(j)->button;
	  current->move( 0, current->pos().y() - moved_b_height ) ;
	  current->setId(j-1);
	}
      if( i-1 == but_id ) // button was not moved to a new position
	{
	  but_list.at(but_id)->button->move( 0, h);
	}
      else
	{
	  but_list.at(but_id)->button->move( 0, current->pos().y() + current->height() );
	  item = but_list.take(but_id);
	  but_list.insert( i-1, item);
	}
    }
  pmenu->move(but_id, i);
  //debug
  //for( item = but_list.first(); item != 0; item = but_list.next() )
  //  {
  //    debug("name = %s / id = %i", item->button->text(), item->button->getId());
  //  }
}

void ConfigureMenu::newButton( int but_id )
{
  PMenuItem *new_it = new PMenuItem;
  new_it->setType(unix_com);
  new_it->setText("EMPTY");
  new_it->setCommand("no command");
  append(new_it);
  pmenu->add(new_it);
  buttonMoved( but_nr-1, but_list.at(but_id)->button->pos() );
}

void ConfigureMenu::delButton( int but_id )
{
  pmenu->remove( but_id );
  but_list.remove( but_id );
  but_nr--;
  ConfMenuItem *item;
  int i = 0;
  for( item = but_list.first(); item != 0; item = but_list.next(), i++ )
    {
      item->button->setId(i);
    }
  update();
}

void ConfigureMenu::pasteButton( int but_id )
{
  if( !global_pmenu_buffer )
    return;
  PMenuItem *new_it = new PMenuItem( *global_pmenu_buffer );
  append( new_it );
  pmenu->add( new_it );
  buttonMoved( but_nr-1, but_list.at(but_id)->button->pos() );
}

void ConfigureMenu::moveEvent( QMoveEvent *e )
{
  ConfMenuItem *l_but;
  for( l_but = but_list.first(); l_but != 0; l_but = but_list.next() )
    {
      l_but->button->parentMoved();
    }  
}
