// -*- C++ -*-

//
//  ktaskbar
//
//  Copyright (C) 1997 Christoph Neerfeld
//  email:  Christoph.Neerfeld@mail.bonn.netsurf.de
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//

#ifndef TASKBAR_H
#define TASKBAR_H

#include <qwidget.h>
#include <qpushbt.h>
#include <qsocknot.h>
#include <qbttngrp.h>
#include <qlabel.h>
#include <qtimer.h>
#include <qdatetm.h>
#include <qdialog.h>
#include <qframe.h>
#include <qstrlist.h>
#include <qlist.h>
#include <qlistbox.h>
#include <qlined.h>

#include <core/kpixmap.h>
#include <core/kapp.h>
#include "pmenu.h"
#include "cpopmenu.h"
#include "taskbutton.h"

class WinInfoList;
class TaskButton;
class TaskBar;

class WinInfo : public QObject
{
  Q_OBJECT
  friend WinInfoList;
  friend TaskBar;
public:
  WinInfo ( int o_pipe, WinInfoList *p);
  ~WinInfo ();

  void setInfo () {}
  long get_id () { return id; }

signals:
  void midPressed( long );

public slots:
  void left_but();
  void mid_but();
  void right_but();

protected:
  long             id;
  QString          name;
  bool             iconified;
  QString          pix_name;
  QPixmap          pixmap;
  short            desk;
  long             x;
  long             y;
  TaskButton      *button;
  int              out_pipe;
  bool             repaint;
  WinInfoList     *parent;
  bool             ignore;
};

class TaskbarConfig;
class MenuConfig;
class MainConfigDialog;
class WinInfoList : public QObject
{
  Q_OBJECT;
  friend TaskBar;
public:
  WinInfoList ( TaskbarConfig *task_conf, int i_fd, int o_fd, QButtonGroup *btg );
  ~WinInfoList ();

  WinInfo *add();
  WinInfo *exists(long id);
  void     remove(WinInfo *win);
  short    get_index( long id ) { id = 0; return 0; }
  void     draw_but();
  long     get_x() { return x; }
  long     get_y() { return y; }

signals:
  void wmRequestPopup();
  void wmRequestIconify();
  void wmRequestDeiconify();
  void wmWinId( long );

public slots:  
  void read();

protected slots:
  void popupMidMenu(long);
  void maximizeWin();
  void stickWin();
  void closeWin();
  void identifyWin();

protected:
  short          nr;
  short          bt_nr;
  QList<WinInfo> list;
  int            in_pipe;
  int            out_pipe;
  unsigned long  current_focus;
  unsigned long  last_focus;
  QButtonGroup  *bt_group;
  bool           draw;
  long           x;
  long           y;
  short          desk;
  TaskbarConfig *task_config_w;
  QPopupMenu     mid_menu;
  long           popup_win;
};


class TaskBar : public QWidget
{
  friend MainConfigDialog;
  Q_OBJECT;
public:
  TaskBar ( int *fd, KConfig *conf, WFlags win_flags );
  virtual ~TaskBar ();

  void send_fvwm_com( QString com );
  void rebuildMenu();
  short writeConf();
  void client_message(XClientMessageEvent* ev);

protected slots:
  void menu_bt_clicked ();
  void net_bt_clicked ();
  void con_bt_clicked ();
  void netsc_bt_clicked ();
  void update_clock ();
  void net_up ();
  void disconnect ();
  void check_net ();
  void net_count ();
  void config_menu ();
  void config_global ();
  void wmWinId( long i) { wm_win_id = i; }
  void cleanupBar();
  void taskbarIconify() { iconify(); }
  void taskbarDeiconify() { show(); }
  
protected:
  short            parse_conf();
  void             net_report();
  void             configureWM();
  
  short            bar_width;
  short            bar_left_pos;
  PMenu           *menu_data;
  CPopupMenu       prog_menu;
  TaskButton      *menu_bt;
  WinInfoList     *info_list;
  int              in_pipe;
  int              out_pipe;
  QSocketNotifier *pipe_check;
  QButtonGroup    *bt_group;
  QLabel          *clock;
  TaskButton      *net_b;
  TaskButton      *con_b;
  TaskButton      *netsc_b;
  PMenu           *net_menu_dat;
  CPopupMenu      *net_menu;
  PMenu           *con_menu_dat;
  CPopupMenu      *con_menu;
  bool             use_net_but;
  bool             use_netsc_but;
  bool             use_clock;
  short            connected;
  short            minutes;
  short            hours;
  QDateTime        start_time;
  QString          menu_file;
  KConfig         *config;
  TaskbarConfig   *task_config_w;
  MenuConfig      *menu_config_w;
  MainConfigDialog *main_config_w;
  long             wm_win_id;
};

#endif // TASKBAR_H
