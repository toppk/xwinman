
/** Support for win'95 keyboard. 
 *
 * If compiled, it can be enabled/disabled in the .rc file.
 *
 * ICEWM assumes the following keyboard mappings:
 *
 * xmodmap - <<EOF
 * ! Left Window key
 * keycode 115 = Meta_L
 * ! Right Window key
 * keycode 116 = Meta_R
 * ! Menu key
 * keycode 117 = Menu
 * EOF
 *
 */
#define SUPPORT_WIN95KBD

/** Use Linux 2.0 Penguin as start button */
#define LINUX_START

/** Show title bars at the bottom of the window */
#undef TITLEBAR_BOTTOM

/** No not include configurability of options */
#undef NO_CONFIGURE

/** Do not include configurable menus */
#undef NO_CONFIGURE_MENUS
