/*
 * ICEWM
 *
 * Copyright (C) 1997 Marko Macek
 *
 * TaskBar
 */

#include "icewm.h"

TaskBarApp::TaskBarApp(YFrameWindow *frame, YWindow *aParent, Window win): YWindow(aParent, win) {
    fFrame = frame;
    fPrev = fNext = 0;
    selected = 0;
    fShown = 1;
}

TaskBarApp::~TaskBarApp() {
}

void TaskBarApp::showApp(int ashow) {
    if (ashow != fShown) {
        fShown = ashow;
    }
}

void TaskBarApp::paint(int /*x*/, int /*y*/, unsigned int /*width*/, unsigned int /*height*/) {
    GC backGC = backNormalTaskBarAppGC;
    GC foreGC = foreNormalTaskBarAppGC;
    int x, y;
    
    if (frame()->focused() || selected == 2) {
        GC brightGC; 
        GC darkGC;

        x = y = 2;

        if (frame()->focused()) {
            brightGC = brightActiveTaskBarAppGC;
            darkGC = darkActiveTaskBarAppGC;
            backGC = backActiveTaskBarAppGC;
            foreGC = foreActiveTaskBarAppGC;
        } else {
            brightGC = brightNormalTaskBarAppGC;
            darkGC = darkNormalTaskBarAppGC;
        }

        drawBorderW(handle(), 1, brightGC, darkGC,
                    0, 0, width() - 1, height() - 1);
    } else {
        GC brightGC = brightNormalTaskBarAppGC;
        GC darkGC = darkNormalTaskBarAppGC;
        x = y = 1;
        
        drawBorderW(handle(), 0, brightGC, darkGC,
                    0, 0, width() - 1, height() - 1);
    }

    XFillRectangle(app->display(),
                   handle(),
                   backGC,
                   x, y, width() - 3, height() - 3);

    drawMaskPixmap(handle(),
                   x + 1, y + 1,
                   frame()->clientIcon()->small());

    char *str = (char *)frame()->client()->iconTitle();
    if (str == 0 || str[0] == 0)
        str = (char *)frame()->client()->windowTitle();
    if (str)
        XDrawString(app->display(),
                    handle(),
                    foreGC,
                    x + 3 + 16, y + height() - titleFont->max_bounds.descent - 4,
                    (char *)str, strlen(str));
}

void TaskBarApp::handleButton(const XButtonEvent &button) {
    YWindow::handleButton(button);
    if (button.button == 1 || button.button == 2) {
        if (button.type == ButtonPress) {
            selected = 2;
            repaint();
        } else if (button.type == ButtonRelease) {
            if (selected == 2) {
                if (button.button == 1) {
                    if (button.state & Mod1Mask)
                        frame()->wmMinimize();
                    else
                        frame()->activate();
                } else if (button.button == 2) {
                    if (button.state & Mod1Mask) {
                        frame()->client()->setWorkspaces(frame()->client()->workspaces() | (1 << app->activeWorkspace()));
                        frame()->activate();
                    } else {
                        frame()->wmOccupyOnlyWorkspace(app->activeWorkspace());
                        frame()->activate();
                    }
                }
            }
            selected = 0;
            repaint();
        }
    }
}

void TaskBarApp::handleCrossing(const XCrossingEvent &crossing) {
    if (selected > 0) {
        if (crossing.type == EnterNotify) {
            selected = 2;
            repaint();
        } else if (crossing.type == LeaveNotify) {
            selected = 1;
            repaint();
        }
    }
}

void TaskBarApp::handleClick(const XButtonEvent &/*down*/, const XButtonEvent &up, int /*count*/) {
    //if (up.button == 2)
    //    frame()->wmMinimize();
    //else
    if (up.button == 3) {
        frame()->updateMenu();
        windowMenu->popup(0, frame(),
                          up.x_root, up.y_root, -1, -1,
                          YPopupWindow::pfCanFlipVertical |
                          YPopupWindow::pfCanFlipHorizontal |
                          YPopupWindow::pfPopupMenu);
    }
}

YClock::YClock(YWindow *aParent, Window win): YWindow(aParent, win) {
    selected = 0;
    setSize(96, 20);
}

YClock::~YClock() {
}

void YClock::handleButton(const XButtonEvent &button) {
    if (button.type == ButtonPress) {
        selected = 2;
        repaint();
    } else if (button.type == ButtonRelease) {
        if (selected == 2) {
            selected = 0;
            repaint();
        } else
            selected = 0;
    }
}

void YClock::handleCrossing(const XCrossingEvent &crossing) {
    if (crossing.type == EnterNotify) {
        if (selected == 1) {
            selected = 2;
            repaint();
        }
    } else if (crossing.type == LeaveNotify) {
        if (selected == 2) {
            selected = 1;
            repaint();
        }
    }
}

void YClock::paint(int /*x*/, int /*y*/, unsigned int /*width*/, unsigned int /*height*/) {
    /*XFillRectangle(app->display(),
                   handle(),
                   blackGC,
                   0, 0, width(), height());*/

    int x = 0;
    time_t newTime = time(NULL);
    YPixmap *pix[6];
    YPixmap *deli;

    struct tm *t = localtime(&newTime);

    if (selected == 2) {
        deli = PixNoColon;
        pix[0] = PixNum[(t->tm_year / 10) % 10];
        pix[1] = PixNum[t->tm_year % 10];
        pix[2] = PixNum[((t->tm_mon + 1) / 10) % 10];
        pix[3] = PixNum[(t->tm_mon + 1) % 10];
        pix[4] = PixNum[(t->tm_mday / 10) % 10];
        pix[5] = PixNum[t->tm_mday % 10];
    } else {
        deli = PixColon;
        pix[0] = PixNum[(t->tm_hour / 10) % 10];
        pix[1] = PixNum[t->tm_hour % 10];
        pix[2] = PixNum[(t->tm_min / 10) % 10];
        pix[3] = PixNum[t->tm_min % 10];
        pix[4] = PixNum[(t->tm_sec / 10) % 10];
        pix[5] = PixNum[t->tm_sec % 10];
    }
    drawPixmap(handle(), x, 0, pix[0]); x += pix[0]->width();
    drawPixmap(handle(), x, 0, pix[1]); x += pix[1]->width();
    drawPixmap(handle(), x, 0, deli); x += deli->width();
    drawPixmap(handle(), x, 0, pix[2]); x += pix[2]->width();
    drawPixmap(handle(), x, 0, pix[3]); x += pix[3]->width();
    drawPixmap(handle(), x, 0, deli); x += deli->width();
    drawPixmap(handle(), x, 0, pix[4]); x += pix[4]->width();
    drawPixmap(handle(), x, 0, pix[5]); x += pix[5]->width();
}

TaskBar::TaskBar(YWindow *aParent, Window win): YWindow(aParent, win) {
    unsigned int ht = 26;

    fWorkspaceButton = 0;
    if (taskBarShowWorkspaces) {
        fWorkspaceButton = (YButton **)malloc(sizeof(YButton *) * workspaceCount);
        assert(fWorkspaceButton != 0);
    }
    
    fFirst = fLast = 0;
    fCount = 0;
    setStyle(wsOverrideRedirect);

    fClock = new YClock(this);
    if (fClock->height() + 4 > ht) ht = fClock->height() + 4;
    fApplications = new YButton(this, rootMenu);
    fApplications->setPixmap(startPixmap);
    if (fApplications->height() + 4 > ht) ht = fApplications->height() + 4;
    fWinList = new YButton(this, windowListMenu);
    fWinList->setPixmap(windowsPixmap);
    if (fWinList->height() + 4 > ht) ht = fWinList->height() + 4;

    if (taskBarShowWorkspaces) {
        for (int w = 0; w < workspaceCount; w++) {
            YButton *wk = new YButton(this, cmdActivateWorkspace, (void *)w);
            wk->setText(workspaceNames[w]);
            if (wk->height() + 4 > ht) ht = wk->height() + 4;
            fWorkspaceButton[w] = wk;
        }
    }
    setGeometry(0,
                taskBarAtTop ? 0 : app->root()->height() - ht,
                app->root()->width(), ht);

    leftX = 0;
    rightX = width() - 2;
    fClock->setPosition(rightX - fClock->width(),
                        2 + (height() - 2 - fClock->height()) / 2);
    fClock->show();
    rightX -= fClock->width() - 2;
    leftX += 2;
    fApplications->setPosition(leftX,
                               2 + (height() - 2 - fApplications->height()) / 2);
    fApplications->show();
    leftX += fApplications->width();
    leftX += 2;
    fWinList->setPosition(2 + fApplications->width() + 2,
                         2 + (height() - 3 - fWinList->height()) / 2);
    fWinList->show();
    leftX += fWinList->width() + 2;

    if (taskBarShowWorkspaces) {
        for (int w = 0; w < workspaceCount; w++) {
            YButton *wk = fWorkspaceButton[w];
            leftX += 2;
            wk->setPosition(leftX, 2 + (height() - 3 - wk->height()) / 2);
            wk->show();
            leftX += wk->width();
        }
        leftX += 4;
    }
}

TaskBar::~TaskBar() {
    delete fClock; fClock = 0;
}

void TaskBar::paint(int /*x*/, int /*y*/, unsigned int /*width*/, unsigned int /*height*/) {
    GC brightGC = brightTaskBarGC;
    GC darkGC = darkTaskBarGC;

    drawBorder1(handle(), 0, brightGC, darkGC, backTaskBarGC,
                0, 0, width() - 1, height() - 1);

    XFillRectangle(app->display(),
                   handle(),
                   backTaskBarGC,
                   1, 1, width() - 2, height() - 2);
}

void TaskBar::handleButton(const XButtonEvent &button) {
    if (button.type == ButtonPress) {
        if (button.button == 1) {
            if (button.state & Mod1Mask)
                lower();
            else if (!(button.state & ControlMask))
                raise();
        }
    }
    YWindow::handleButton(button);
}

void TaskBar::handleClick(const XButtonEvent &down, const XButtonEvent &up, int count) {
    if (up.button == 1) {
    } else if (up.button == 2) {
    } else if (up.button == 3 && count == 1) {
        rootMenu->popup(0, 0, up.x_root, up.y_root, -1, -1,
                        YPopupWindow::pfCanFlipVertical |
                        YPopupWindow::pfCanFlipHorizontal);
    }
    YWindow::handleClick(down, up, count);
}

void TaskBar::insert(TaskBarApp *tapp) {
    fCount++;
    tapp->setNext(0);
    tapp->setPrev(fLast);
    if (fLast)
        fLast->setNext(tapp);
    else
        fFirst = tapp;
    fLast = tapp;
}

void TaskBar::remove(TaskBarApp *tapp) {
    fCount--;

    if (tapp->getPrev())
        tapp->getPrev()->setNext(tapp->getNext());
    else
        fFirst = tapp->getNext();

    if (tapp->getNext())
        tapp->getNext()->setPrev(tapp->getPrev());
    else
        fLast = tapp->getPrev();
}

TaskBarApp *TaskBar::addApp(YFrameWindow *frame) {
    TaskBarApp *tapp = new TaskBarApp(frame, this);

    if (tapp != 0) {
        insert(tapp);
        tapp->show();
        relayout();
    }
    return tapp;
}

void TaskBar::removeApp(YFrameWindow *frame) {
    TaskBarApp *f = fFirst;

    while (f) {
        if (f->frame() == frame) {
            f->hide();
            remove(f);
            delete f;
            relayout();
            return ;
        }
        f = f->getNext();
    }
}

void TaskBar::relayout() {
    int x, y, w, h;
    int tc = 0;

    TaskBarApp *a = fFirst;
    
    while (a) {
        if (a->shown())
            tc++;
        a = a->getNext();
    }

    if (tc < 3) tc = 3;

    h = 21;
    w = (rightX - leftX - 2) / tc - 2;
    x = leftX;
    y = 2 + (height() - 3 - h) / 2;

    TaskBarApp *f = fFirst;
        
    while (f) {
        if (f->shown()) {
            f->setGeometry(x, y, w, h);
            f->show();
            x += w;
            x += 2;
        } else
            f->hide();
        f = f->getNext();
    }
}
