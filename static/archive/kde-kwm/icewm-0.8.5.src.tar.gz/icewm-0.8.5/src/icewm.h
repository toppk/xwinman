/*
 * ICEWM
 *
 * Copyright (C) 1997 Marko Macek
 */

#ifndef ICEWM_H
#define ICEWM_H

#include "config.h"

#define ICON_SMALL 16   // small: 16x16
#define ICON_LARGE 32   // large: 32x32

#define XPM_PATH LIBPATH
#define ICON_PATH LIBPATH "/icons"
#define ETC_PATH ETCPATH

extern "C" {
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <limits.h>
#include <unistd.h>
#include <stdarg.h>
#include <signal.h>
#include <ctype.h>
#include <fcntl.h>

#include <X11/Xproto.h>
#include <X11/Xatom.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>
#include <X11/cursorfont.h>
#include <X11/keysym.h>
#include <X11/xpm.h>
#ifdef SHAPE
#include <X11/extensions/shape.h>
#endif
#ifndef NO_MWM_HINTS
#include "MwmUtil.h"
#endif
}

#include "default.h"

extern char *menuFile;

extern char **progNames;
extern char **progCmds;
extern char ***progArgs;
extern int progCount;

#define MAXWORKSPACES 32 /* don't change */
#define ALLWORKSPACES 0xFFFFFFFF

extern int workspaceCount;
extern char *workspaceNames[MAXWORKSPACES];
extern Atom workspaceAtoms[MAXWORKSPACES];
extern Atom workspaceAtomAll;

#define DO_BORDER(x) 0 // (x)      // 0 looks much better
#define KEY_MODMASK(x) ((x) & (ControlMask | ShiftMask | Mod1Mask))

void die(int exitcode, const char *msg, ...);

class YApplication;
class YWindow;
class YPopupWindow;
class YMenu;
class YRootWindow;
class YFrameWindow;
class YFrameControl;
class YFrameTitle;
class YFrameButton;
class YFrameClient;
class TaskBar;
class TaskBarApp;

#ifdef DEBUG
extern int debug;
extern int debug_z;

void msg(const char *msg, ...);
void logEvent(XEvent xev);
void dumpZorder(const char *oper, YFrameWindow *w, YFrameWindow *a = 0);

#define DBG if (debug)
#define MSG(x) DBG msg x
#else

#define DBG if (0)
#define MSG(x)
#endif

extern YApplication *app;
extern TaskBar *taskBar;

typedef enum {
    cmdNone = 0,
    cmdSubmenu,
    cmdSeparator,
    cmdRestore,
    cmdMove,
    cmdSize,
    cmdMinimize, cmdHide,
    cmdMaximize, cmdMaximizeVert,
    cmdShade,
    cmdLower,    cmdRaise,
    cmdClose,    cmdKill,
    cmdSysMenu,
    cmdWindowList,
    cmdActivate,
    // cmdRefresh,
    cmdCloseSession,
    cmdExit,
    cmdExec,
    cmdRestart,
    cmdOccupyAll,
    cmdOccupyAllOrCurrent,
    cmdOccupyWorkspace,
    cmdOccupyOnlyWorkspace,
    cmdActivateWorkspace
} WMCommand;

typedef enum {
    phaseStartup,
    phaseShutdown,
    phaseRunning
} PhaseType;

typedef int FrameState;

class YColor {
public:
    YColor(unsigned short red, unsigned short green, unsigned short blue);
    YColor(const char *clr, int type = 1); // 0 = darken, 2 = brighten

    void alloc();
    unsigned long pixel() { return color.pixel; }
private:
    XColor color;
};

class YPixmap {
public:
    YPixmap(char *fileName);
    ~YPixmap();

    Pixmap pixmap() { return fPixmap; }
    unsigned int width() { return fWidth; }
    unsigned int height() { return fHeight; }
private:
    Pixmap fPixmap;
    unsigned int fWidth, fHeight;
};

class YMaskPixmap {
public:
    YMaskPixmap(char *fileName);
    ~YMaskPixmap();

    Pixmap pixmap() { return fPixmap; }
    Pixmap mask() { return fMask; }
    unsigned int width() { return fWidth; }
    unsigned int height() { return fHeight; }
private:
    Pixmap fPixmap;
    Pixmap fMask;
    unsigned int fWidth, fHeight;
};

class YIcon {
public:
    YIcon(char *fileName);
    ~YIcon();

    YMaskPixmap *large();
    YMaskPixmap *small();

    char *iconName() { return fPath; }
    YIcon *next() { return fNext; }
private:
    char *fPath;
    YMaskPixmap *fSmall;
    YMaskPixmap *fLarge;
    YIcon *fNext;
    int loadedS;
    int loadedL;

    int findIcon(char **fullPath, int size);
    YMaskPixmap *loadIcon(int size);
};

extern YIcon *defaultAppIcon;

class YWindow {
public:
    YWindow(YWindow *aParent, Window win = 0);
    virtual ~YWindow();

    void setStyle(int aStyle);

    void show();
    void hide();
    virtual void raise();
    virtual void lower();

    void repaint();

    void reparent(YWindow *parent, int x, int y);

    void setGeometry(int x, int y, unsigned int width, unsigned int height);
    void setSize(unsigned int width, unsigned int height);
    void setPosition(int x, int y);
    virtual void configure(int x, int y, unsigned int width, unsigned int height);

    virtual void paint(int x, int y, unsigned int width, unsigned int height);
    void draw(int x, int y, unsigned int width, unsigned int height);

    virtual void handleEvent(const XEvent &event);

    virtual void handleExpose(const XExposeEvent &expose);
    virtual void handleGraphicsExpose(const XGraphicsExposeEvent &graphicsExpose);
    virtual void handleConfigure(const XConfigureEvent &configure);
    virtual void handleKey(const XKeyEvent &key);
    virtual void handleButton(const XButtonEvent &button);
    virtual void handleMotion(const XMotionEvent &motion);
    virtual void handleCrossing(const XCrossingEvent &crossing);
    virtual void handleProperty(const XPropertyEvent &property);
    virtual void handleColormap(const XColormapEvent &colormap);
#if 0
    virtual void handleFocus(const XFocusChangeEvent &focus);
    virtual void handleClientMessage(const XClientMessageEvent &message);
    virtual void handleVisibility(const XVisibilityEvent &visibility);
    virtual void handleCreateWindow(const XCreateWindowEvent &createWindow);
#endif
    virtual void handleMap(const XMapEvent &map);
    virtual void handleUnmap(const XUnmapEvent &unmap);
    virtual void handleDestroyWindow(const XDestroyWindowEvent &destroyWindow);
    virtual void handleConfigureRequest(const XConfigureRequestEvent &configureRequest);
    virtual void handleMapRequest(const XMapRequestEvent &mapRequest);
#ifdef SHAPE
    virtual void handleShapeNotify(const XShapeEvent &shape);
#endif

    virtual void handleClick(const XButtonEvent &down, const XButtonEvent &up, int count);
    virtual void handleBeginDrag(const XButtonEvent &down, const XMotionEvent &motion);
    virtual void handleDrag(const XButtonEvent &down, const XMotionEvent &motion);
    virtual void handleEndDrag(const XButtonEvent &down, const XButtonEvent &up);
    
    void setPointer(Cursor pointer);
    void setGrabPointer(Cursor pointer);
    void grabKey(int key, unsigned int modifiers);

    Window handle();
    YWindow *parent() { return fParent; }

    int x() { return fX; }
    int y() { return fY; }
    unsigned int width() { return fWidth; }
    unsigned int height() { return fHeight; }

    int visible() { return (flags & wfVisible) ? 1 : 0; }
    int created() { return (flags & wfCreated) ? 1 : 0; }
    int adopted() { return (flags & wfAdopted) ? 1 : 0; }
    int destroyed() { return (flags & wfDestroyed) ? 1 : 0; }
    int unmapped() { return (flags & wfUnmapped) ? 1 : 0; }

    virtual void donePopup(YPopupWindow * /*command*/);

    typedef enum {
        wsOverrideRedirect = 1 << 0,
        wsSaveUnder        = 1 << 1
    } WindowStyle;

private:
    typedef enum {
        wfVisible   = 1 << 0,
        wfCreated   = 1 << 1,
        wfAdopted   = 1 << 2,
        wfDestroyed = 1 << 3,
        wfUnmapped  = 1 << 4
    } WindowFlags;

    void create();
    void destroy();
    
    YWindow *fParent;
    Window fHandle;
    unsigned long flags;
    unsigned long fStyle;
    int fX, fY;
    unsigned int fWidth, fHeight;
    Cursor fPointer;
    int unmapCount;

    static XButtonEvent fClickEvent;
    static YWindow *fClickWindow;
    static Time fClickTime;
    static int fClickCount;
    static int fClickDrag;
    static unsigned int fClickButton;
    static unsigned int fClickButtonDown;
};

class MoveSizeStatus: public YWindow {
public:
    MoveSizeStatus(YWindow *aParent, Window win = 0);
    virtual ~MoveSizeStatus();

    virtual void paint(int x, int y, unsigned int width, unsigned int height);

    void setStatus(YFrameWindow *frame, int x, int y, int width, int height);
    void setStatus(YFrameWindow *frame);
    void begin(YFrameWindow *frame);
    void end() { hide(); }
private:
    int fX, fY, fW, fH;
};

class YPopupWindow: public YWindow {
public:
    YPopupWindow(YWindow *aParent);
    virtual ~YPopupWindow();

    virtual void sizePopup();
    
    void popup(YWindow *forWindow, YFrameWindow *commandWindow,
               int x, int y,
               int x_delta, int y_delta,
               unsigned int flags);
    void popup(YWindow *forWindow, YFrameWindow *commandWindow,
               unsigned int flags);
    void popdown();

    virtual void updatePopup();
    void finishPopup(WMCommand command, void *context);
    void cancelPopup();

    virtual void handleKey(const XKeyEvent &key);
    virtual void handleButton(const XButtonEvent &button);
    virtual void handleMotion(const XMotionEvent &motion);

    virtual void activatePopup();
    virtual void deactivatePopup();

    unsigned int popupFlags() { return fFlags; }

    YFrameWindow *commandWindow() { return fCommandWindow; }
    YPopupWindow *prevPopup() { return fPrevPopup; }
    void setPrevPopup(YPopupWindow *prevPopup) { fPrevPopup = prevPopup; }

    enum {
        pfButtonDown        = 1 << 0,
        pfCanFlipVertical   = 1 << 1,
        pfCanFlipHorizontal = 1 << 2,
        pfFlipVertical      = 1 << 3,
        pfFlipHorizontal    = 1 << 4,
        pfNoPointerChange   = 1 << 5,
        pfPopupMenu         = 1 << 6
    } PopupFlags;

private:
    unsigned int fFlags;
    YWindow *fForWindow;
    YFrameWindow *fCommandWindow;
    YPopupWindow *fPrevPopup;
};

class YMenu: public YPopupWindow {
public:
    class YMenuItem {
    public:
        YMenuItem(const char *name, int hotCharPos, const char *param, WMCommand command, YMenu *submenu, void *context = 0);
        YMenuItem() { fName = 0; fHotCharPos = -1; fParam = 0; fCommand = cmdSeparator; fContext = 0; fEnabled = 0; fSubmenu = 0; }
        ~YMenuItem();
        char *name() { return fName; }
        char *param() { return fParam; }
        WMCommand command() { return fCommand; }
        void *context() { return fContext; }
        YMenu *submenu() { return fSubmenu; }
        int enabled() { return fEnabled; }
        void enable() { fEnabled = 1; }
        void disable() { fEnabled = 0; }
        int hotChar() { return (fName && fHotCharPos >= 0) ? fName[fHotCharPos] : -1; }
        int hotCharPos() { return fHotCharPos; }
        YMaskPixmap *pixmap() { return fPixmap; }
        void setPixmap(YMaskPixmap *pixmap);
        void setCheck(int value);
        int checked() { return fChecked; }
    private:
        char *fName;
        char *fParam;
        WMCommand fCommand;
        void *fContext;
        int fEnabled;
        int fHotCharPos;
        YMenu *fSubmenu;
        YMaskPixmap *fPixmap;
        int fChecked;
    };

    YMenu(YWindow *parent);
    virtual ~YMenu();

    virtual void sizePopup();
    virtual void activatePopup();
    virtual void deactivatePopup();
    virtual void donePopup(YPopupWindow *popup);
    
    virtual void paint(int x, int y, unsigned int width, unsigned int height);

    virtual void handleKey(const XKeyEvent &key);
    virtual void handleButton(const XButtonEvent &button);
    virtual void handleMotion(const XMotionEvent &motion);
    
    YMenuItem *add(YMenuItem *item);
    YMenuItem *addItem(const char *name, int hotCharPos, const char *param, WMCommand command, void *context = 0);
    YMenuItem *addSubmenu(const char *name, int hotCharPos, YMenu *submenu);
    YMenuItem *addSeparator();
    void removeAll();
    YMenuItem *findItem(WMCommand command);

    void enableCommand(WMCommand cmd); // cmdNone == All
    void disableCommand(WMCommand cmd); // cmdNone == All

    int itemCount() { return fItemCount; }
    YMenuItem *item(int n) { return fItems[n]; }

private:
    int fItemCount;
    YMenuItem **fItems;
    int selectedItem;
    int paintedItem;
    int paramPos;
    YPopupWindow *fPopup;
    YPopupWindow *fPopupActive;

    void paintItem(int i, int &y, int paint);
    void paintItems();
    int findItemPos(int item, int &x, int &y);
    int findItem(int x, int y);
    int findActiveItem(int cur, int direction);
    void focusItem(int item, int submenu, int byMouse);
    int activateItem(int no, int byMouse);
    int onCascadeButton(int selectedItem, int x, int y);
};

class YWindowListMenu: public YMenu {
public:
    YWindowListMenu(YWindow *parent);
    virtual void updatePopup();
};

class SwitchWindow: public YPopupWindow {
public:
    SwitchWindow(YWindow *parent);
    virtual ~SwitchWindow();

    virtual void paint(int x, int y, unsigned int width, unsigned int height);

    void begin(int next);

    virtual void activatePopup();
    virtual void deactivatePopup();
    
    virtual void handleKey(const XKeyEvent &key);
    virtual void handleButton(const XButtonEvent &button);

    void destroyed(YFrameWindow *frame);
private:
    YFrameWindow *fActiveWindow;
};

class YRootWindow: public YWindow {
public:
    YRootWindow(YWindow *parent, Window win = 0);
    virtual ~YRootWindow();

    virtual void handleClick(const XButtonEvent &down, const XButtonEvent &up, int count);
    virtual void handleKey(const XKeyEvent &key);

    virtual void handleConfigureRequest(const XConfigureRequestEvent &configureRequest);
    virtual void handleMapRequest(const XMapRequestEvent &mapRequest);
    virtual void handleUnmap(const XUnmapEvent &unmap);
    virtual void handleDestroyWindow(const XDestroyWindowEvent &destroyWindow);
    virtual void handleClientMessage(const XClientMessageEvent &message);
};

class YFrameControl: public YWindow {
public:
    YFrameControl(YWindow *parent, YFrameWindow *frame, Window win = 0): YWindow((YWindow *)parent, win) { fFrame = frame; }
    virtual ~YFrameControl() { }

    YFrameWindow *frame() { return fFrame; }
    virtual void setFrame(YFrameWindow *newFrame);
private:
    YFrameWindow *fFrame;
};

class YFrameClient: public YFrameControl {
public:
    YFrameClient(YWindow *parent, YFrameWindow *frame, Window win = 0);
    virtual ~YFrameClient();

    void configureClient(const XConfigureRequestEvent &configureRequest);

    virtual void handleProperty(const XPropertyEvent &property);
    virtual void handleColormap(const XColormapEvent &colormap);
    virtual void handleUnmap(const XUnmapEvent &unmap);
    virtual void handleDestroyWindow(const XDestroyWindowEvent &destroyWindow);
#ifdef SHAPE
    virtual void handleShapeNotify(const XShapeEvent &shape);
#endif

    Window clientWindow() { return fClient; }

    unsigned int border() { return fBorder; }
    void setBorder(unsigned int border) { fBorder = border; }
    void setFrame(YFrameWindow *newFrame);

    enum {
        wpDeleteWindow = 1 << 0,
        wpTakeFocus    = 1 << 1
    } WindowProtocols;

    unsigned long protocols() { return fProtocols; }
    void getProtocols();

    unsigned char *windowTitle() { return fWindowTitle; }
    unsigned char *iconTitle() { return fIconTitle; }

    void setWindowTitle(unsigned char *aWindowTitle);
    void setIconTitle(unsigned char *aIconTitle);

    void sendMessage(Atom msg, Time timeStamp = CurrentTime);

    XSizeHints *sizeHints() { return fSizeHints; }
    void getSizeHints();
    void constrainSize(int &w, int &h, int round = 0);
    void gravityOffsets (int &xp, int &yp);

    XWMHints *hints() { return fHints; }

    Colormap colormap() { return fColormap; }
    void setColormap(Colormap cmap);

    void setWMState(FrameState state);
    FrameState getWMState();
    int focusable();

    void getTransient();
    void addAsTransient();
    void removeAsTransient();
    void removeTransients();

#ifdef SHAPE
    int shaped() { return fShaped; }
    void queryShape();
#endif

#ifndef NO_MWM_HINTS
    MwmHints *mwmHints() { return fMwmHints; }
    void getMwmHints();
    CARD32 mwmFunctions();
    CARD32 mwmDecors();
#endif
    
    void setTransient(YFrameClient *transient) { fTransient = transient; }
    void setNextTransient(YFrameClient *nextTransient) { fNextTransient = nextTransient; }
    void setOwner(YFrameClient *owner) { fOwner = owner; }
    YFrameClient *transient() { return fTransient; }
    YFrameClient *nextTransient() { return fNextTransient; }
    YFrameClient *owner() { return fOwner; }

    void setClientWorkspaces();
    void getClientWorkspaces();
    int allWorkspaces() { return fAllWorkspaces; }
    void setAllWorkspaces(int allWorkspaces);
    void setWorkspaces(unsigned long workspace);
    unsigned long workspaces() { return fWorkspaces; }

private:
    int fProtocols;
    int haveButtonGrab;
    Window fClient;
    unsigned int fBorder;
    XSizeHints *fSizeHints;
    XWMHints *fHints;
    Colormap fColormap;
    int fShaped;

    Window fTransientFor;
    YFrameClient *fOwner;
    YFrameClient *fTransient;
    YFrameClient *fNextTransient;

    unsigned char *fWindowTitle;
    unsigned char *fIconTitle;

    MwmHints *fMwmHints;

    unsigned long fWorkspaces;
    int fAllWorkspaces;
};

class YClientContainer: public YFrameControl {
public:
    YClientContainer(YWindow *parent, YFrameWindow *frame);
    //: YFrameControl(parent, frame) { isActive = 0; movingWindow = 0; }
    virtual ~YClientContainer();

    virtual void handleButton(const XButtonEvent &button);
    virtual void handleConfigureRequest(const XConfigureRequestEvent &configureRequest);
    virtual void handleMapRequest(const XMapRequestEvent &mapRequest);
    virtual void handleCrossing(const XCrossingEvent &crossing);

    void grabButtons();
    void releaseButtons();
    int haveGrab() { return haveButtonGrab; }
private:
    int haveButtonGrab;
};

class YFrameTitleBar: public YFrameControl {
public:
    YFrameTitleBar(YWindow *parent, YFrameWindow *frame): YFrameControl(parent, frame) { isActive = 0; movingWindow = 0; }
    virtual ~YFrameTitleBar() { }

    void activate();
    void deactivate();
    
    virtual void paint(int x, int y, unsigned int width, unsigned int height);

    virtual void handleButton(const XButtonEvent &button);
    virtual void handleMotion(const XMotionEvent &motion);

    virtual void handleClick(const XButtonEvent &down, const XButtonEvent &up, int count);
    virtual void handleBeginDrag(const XButtonEvent &down, const XMotionEvent &motion);
    virtual void handleDrag(const XButtonEvent &down, const XMotionEvent &motion);
    virtual void handleEndDrag(const XButtonEvent &down, const XButtonEvent &up);

    int active() { return isActive; }

private:
    int buttonDownX, buttonDownY;
    int movingWindow;
    int isActive;
};

class YFrameButton: public YFrameControl {
public:
    YFrameButton(YWindow *parent, YFrameWindow *frame, WMCommand command, WMCommand command2 = cmdNone);
    virtual ~YFrameButton();

    virtual void paint(int x, int y, unsigned int width, unsigned int height);

    void activate();
    void deactivate();

    virtual void handleButton(const XButtonEvent &button);
    virtual void handleMotion(const XMotionEvent &motion);
    virtual void handleClick(const XButtonEvent &down, const XButtonEvent &up, int count);

    void setCommand(WMCommand command, WMCommand command2 = cmdNone);

    virtual void donePopup(YPopupWindow *popup);
    void popupMenu();
    void popdownMenu();
        
private:
    WMCommand fCommand;
    WMCommand fCommand2;

    int isDown;
    int isActive;
    int wasPopupActive;
    YPopupWindow *fPopup;
};

class YFrameWindow: public YWindow {
public:
    YFrameWindow(YWindow *parent, YFrameClient *client);
    virtual ~YFrameWindow();

    void createPointerWindows();

    void activate();
    void deactivate();

    void manage(YFrameClient *client);
    void unmanage();
    
    virtual void configure(int x, int y, unsigned int width, unsigned int height);

    void configureClient(const XConfigureRequestEvent &configureRequest);
    void sendConfigure();

    virtual void paint(int x, int y, unsigned int width, unsigned int height);

    virtual void handleKey(const XKeyEvent &key);
    virtual void handleButton(const XButtonEvent &button);
    virtual void handleClick(const XButtonEvent &down, const XButtonEvent &up, int count);
    virtual void handleBeginDrag(const XButtonEvent &down, const XMotionEvent &motion);
    virtual void handleDrag(const XButtonEvent &down, const XMotionEvent &motion);
    virtual void handleEndDrag(const XButtonEvent &down, const XButtonEvent &up);
    virtual void handleMotion(const XMotionEvent &motion);
    virtual void handleCrossing(const XCrossingEvent &crossing);

    void handleCommand(WMCommand command, void *context);
    
    void wmRestore();
    void wmMinimize();
    void wmMaximize();
    void wmMaximizeVert();
    void wmShade();
    void wmHide();
    void wmLower();
    void doLower();
    void wmRaise();
    void doRaise();
    void wmClose();
    void wmKill();
    void wmNextWindow();
    void wmPrevWindow();
    void wmLastWindow();
    void wmMove();
    void wmSize();
    void wmOccupyAll();
    void wmOccupyAllOrCurrent();
    void wmOccupyWorkspace(int workspace);
    void wmOccupyOnlyWorkspace(int workspace);

    void DoMaximize(int what);

    void loseFocus();
    void setFocus();
    int focused() { return fFocused; }

    YFrameClient *client() { return fClient; }
    YFrameTitleBar *titlebar() { return fTitleBar; }
    YClientContainer *container() { return fClientContainer; }

    virtual void raise();
    virtual void lower();

    void startMoveSize(int doMove, int byMouse,
                       int sideX, int sideY,
                       int mouseXroot, int mouseYroot);
    void endMoveSize();
    void moveWindow(int newX, int newY);

    void drawOutline(int x, int y, int w, int h);
    int handleMoveKeys(const XKeyEvent &xev, int &newX, int &newY);
    int handleResizeKeys(const XKeyEvent &key,
                         int &newX, int &newY, int &newWidth, int &newHeight,
                         int incX, int incY);
    void handleMoveMouse(const XMotionEvent &motion, int &newX, int &newY);
    void handleResizeMouse(const XMotionEvent &motion,
                           int &newX, int &newY, int &newWidth, int &newHeight);

    void outlineMove();
    void outlineResize();
    
    void constrainPositionByModifier(int &x, int &y, const XMotionEvent &motion);
    void constrainMouseToWorkspace(int &x, int &y);

    int canSize();
    int canMove();
    int canClose();
    int canMaximize();
    int canMinimize();
    int canShade();
    int canHide();

    void insert();
    void remove();
    void setAbove(YFrameWindow *aboveFrame); // 0 = at the bottom
    void setBelow(YFrameWindow *belowFrame); // 0 = at the top
    YFrameWindow *next() { return fNext; }
    YFrameWindow *prev() { return fPrev; }
    void setNext(YFrameWindow *next) { fNext = next; }
    void setPrev(YFrameWindow *prev) { fPrev = prev; }

    typedef enum {
        fwfVisible    = 1 << 0, // visible windows only
        fwfCycle      = 1 << 1, // cycle when bottom(top) reached
        fwfBackward   = 1 << 2, // go up in zorder (default=down)
        fwfNext       = 1 << 3, // start from next window
        fwfFocusable  = 1 << 4, // only focusable windows
        fwfWorkspace  = 1 << 5, // current workspace only
        fwfSame       = 1 << 6 // return same if no match and same matches
    } FindWindowFlags;

    YFrameWindow *findWindow(int flag);
    int maximized() { return (style & fsMaximized) ? 1 : 0; }
    int minimized() { return (style & fsMinimized) ? 1 : 0; }
    int shaded() { return (style & fsShaded) ? 1 : 0; }
    int hidden() { return (style & fsHidden) ? 1 : 0; }

    int focusable();

    YFrameButton *menuButton() { return fMenuButton; }
    YFrameButton *closeButton() { return fCloseButton; }
    YFrameButton *minimizeButton() { return fMinimizeButton; }
    YFrameButton *maximizeButton() { return fMaximizeButton; }
    void updateMenu();

    FrameState frameState() { return fState; }
    void setFrameState(FrameState state);
    void changeState(FrameState state);

#ifdef SHAPE
    void setShape();
#endif

    void setPopupActive(YPopupWindow *popup);
    void popupSystemMenu();

    void updateTitle();
    void updateIconTitle();

#ifndef NO_MWM_HINTS
    // !!! optimize
    unsigned int borderX() {
        return
            (client()->mwmDecors() & MWM_DECOR_RESIZEH) ? wsBorderX : wsDlgBorderX;
    }
    unsigned int borderY() {
        return (client()->mwmDecors() & MWM_DECOR_RESIZEH) ? wsBorderX : wsDlgBorderX;
    }
    unsigned int titleY() {
        return (client()->mwmDecors() & MWM_DECOR_TITLE) ? wsTitleBar : 0;
    }
#else
    unsigned int borderX() { return wsBorderX; }
    unsigned int borderY() { return wsBorderY; }
    unsigned int titleY() { return wsTitlebar; }
#endif
    
    void layoutTitleBar();
    void layoutButtons();
    void layoutResizeIndicators();
    void layoutClient();

    void workspaceShow();
    void workspaceHide();

    void addToMenu(YMenu *menu);

    YIcon *clientIcon() { return defaultAppIcon; }

    int visibleOn(int workspace) {
        return (client()->allWorkspaces() ||
                (client()->workspaces() & (1 << workspace))) ? 1 : 0;
    }
    int visibleNow();
    
private:
    typedef enum {
        fsMinimized       = 1 << 0,
        fsMaximized       = 1 << 1,
        fsShaded          = 1 << 2,
        fsHidden          = 1 << 3,
        fsWorkspaceHidden = 1 << 4
    } FrameStateFlags;

    int fFocused;

    int normalX, normalY;
    unsigned int normalWidth, normalHeight;

    YFrameClient *fClient;
    YClientContainer *fClientContainer;
    YFrameTitleBar *fTitleBar;
    YFrameButton *fCloseButton;
    YFrameButton *fMenuButton;
    YFrameButton *fMaximizeButton;
    YFrameButton *fMinimizeButton;

    YPopupWindow *fPopupActive;

    unsigned long style;
    FrameState fState;
    FrameState fSavedFrameState;

    int buttonDownX, buttonDownY;
    int grabX, grabY;
    int movingWindow, sizingWindow;
    int sizeByMouse;
    int origX, origY, origW, origH;

    YFrameWindow *fNext; // window below this one
    YFrameWindow *fPrev; // window above this one

    Window topSide, leftSide, rightSide, bottomSide;
    Window topLeftCorner, topRightCorner, bottomLeftCorner, bottomRightCorner;
    int indicatorsVisible;

    TaskBarApp *fTaskBarApp;
};

class YButton: public YWindow {
public:
    YButton(YWindow *parent, WMCommand command, void *context);
    YButton(YWindow *parent, YPopupWindow *popup);
    virtual ~YButton();

    virtual void paint(int x, int y, unsigned int width, unsigned int height);
    virtual void handleButton(const XButtonEvent &button);
    virtual void handleCrossing(const XCrossingEvent &crossing);

    void setCommand(WMCommand command, void *context);
    void setPopup(YPopupWindow *popup);
    void setPixmap(YPixmap *pixmap);
    void setText(char *str);
    void setPressed(int pressed);

    virtual void donePopup(YPopupWindow *popup);

    void popup();
    void popdown();

private:
    WMCommand fCommand;
    YPopupWindow *fPopup;
    YPixmap *fPixmap;
    char *fText;
    void *fContext;
    int fPressed;

    int selected;
    int isActive;
    int wasPopupActive;
};

class TaskBarApp: public YWindow {
public:
    TaskBarApp(YFrameWindow *frame, YWindow *aParent, Window win = 0);
    ~TaskBarApp();

    virtual void paint(int x, int y, unsigned int width, unsigned int height);
    virtual void handleButton(const XButtonEvent &button);
    virtual void handleClick(const XButtonEvent &down, const XButtonEvent &up, int count);
    virtual void handleCrossing(const XCrossingEvent &crossing);

    YFrameWindow *frame() { return fFrame; }

    void showApp(int show);
    int shown() { return fShown; }
    
    TaskBarApp *getNext() { return fNext; }
    TaskBarApp *getPrev() { return fPrev; }
    void setNext(TaskBarApp *next) { fNext = next; }
    void setPrev(TaskBarApp *prev) { fPrev = prev; }
private:
    YFrameWindow *fFrame;
    TaskBarApp *fPrev, *fNext;
    int fShown;
    int selected;
};

class YClock: public YWindow {
public:
    YClock(YWindow *aParent, Window win = 0);
    ~YClock();

    virtual void handleButton(const XButtonEvent &button);
    virtual void handleCrossing(const XCrossingEvent &crossing);
    virtual void paint(int x, int y, unsigned int width, unsigned int height);
private:
    int selected;
};

class TaskBar: public YWindow {
public:
    TaskBar(YWindow *aParent, Window win = 0);
    virtual ~TaskBar();

    virtual void paint(int x, int y, unsigned int width, unsigned int height);
    virtual void handleButton(const XButtonEvent &button);
    virtual void handleClick(const XButtonEvent &down, const XButtonEvent &up, int count);

    void insert(TaskBarApp *tapp);
    void remove(TaskBarApp *tapp);

    TaskBarApp *addApp(YFrameWindow *frame);
    void removeApp(YFrameWindow *frame);

    void relayout();

    YClock *clock() { return fClock; }
    YButton *workspaceButton(int n) { return fWorkspaceButton[n]; }
private:
    TaskBarApp *fFirst, *fLast;
    int fCount;
    YClock *fClock;
    YButton *fWinList;
    YButton *fApplications;
    YButton **fWorkspaceButton;
    int leftX, rightX;
};

class YApplication {
public:
    YApplication(const char *displayName = 0);
    virtual ~YApplication();

    int mainLoop();
    void exitLoop(int exitCode);
    void exit(int exitCode);
    
    void wmCloseSession();

    YRootWindow *root() { return fRoot; }
    Display *display() { return fDisplay; }

    void saveEventTime(XEvent &xev);
    Time getEventTime() { return lastEventTime; }

    void manageClients();
    void unmanageClients();

    YFrameClient *manageWindow(Window win);
    YFrameWindow *mapWindow(Window win, int newClient = 1);
    YFrameClient *unmapWindow(Window win);
    void unmanageWindow(Window win);
    void destroyedWindow(Window win);
    YFrameClient *manageClient(Window win);
    YFrameClient *findClient(Window win);
    
    void unmanageFrame(YFrameWindow *frame);

    YFrameWindow *getFrame(Window win);
    YFrameWindow *createFrame(YFrameClient *client);

    YFrameClient *getClient(Window win);
    YFrameClient *createClient(Window win);

    void setFocus(YFrameWindow *window);
    void loseFocus(YFrameWindow *window);
    YFrameWindow *focus() { return fFocus; }
    void activate(YFrameWindow *frame);

    void installColormap(Colormap cmap);
    void setColormapWindow(YFrameWindow *frame);
    YFrameWindow *colormapWindow() { return fColormapWindow; }

    int minX();
    int minY();
    int maxX();
    int maxY();
    int maxWidth() { return maxX() - minX(); }
    int maxHeight() { return maxY() - minY(); }

    void placeWindow(YFrameWindow *frame, int x, int y, int newClient = 1);

    YFrameWindow *top() { return fTop; }
    void setTop(YFrameWindow *top);
    YFrameWindow *bottom() { return fBottom; }
    void setBottom(YFrameWindow *bottom) { fBottom = bottom; }

    void restackWindows(YFrameWindow *win, int oper = 0);

    YMenu *createWindowMenu(YMenu *menu, int workspace);
    int windowCount(int workspace);
    void windowList(int x, int y);
    void handleCommand(WMCommand command, void *context);

    YPopupWindow *popup() { return fPopup; }
    void popup(YWindow *forWindow, YPopupWindow *popup);
    void popdown(YPopupWindow *popdown);

    int activeWorkspace() { return fActiveWorkspace; }
    void activateWorkspace(int workspace);
    int workspaceCount() { return ::workspaceCount; }
    char *workspaceName(int workspace) { return ::workspaceNames[workspace]; }

    int grabEvents(YWindow *win, Cursor ptr, unsigned int eventMask, int grabMouse = 1, int grabKeyboard = 1);
    int releaseEvents();
    void handleGrabEvent(YWindow *win, XEvent &xev);
    
private:
    Display *fDisplay;
    YRootWindow *fRoot;
    YFrameWindow *fFocus;
    Time lastEventTime;
    YPopupWindow *fPopup;

    YFrameWindow *fTop;
    YFrameWindow *fBottom;

    YFrameWindow *fColormapWindow;
    YWindow *fGrabWindow;
    int fGrabMouse;

    int fActiveWorkspace;

    int fLoopLevel;
    int fExitLoop;
    int fExitCode;
    int fExitApp;
};

extern Colormap defaultColormap;

extern GC blackGC;
extern GC whiteGC;

extern GC outlineGC;

extern GC backNormalBorderGC;
extern GC brightNormalBorderGC;
extern GC darkNormalBorderGC;

extern GC backActiveBorderGC;
extern GC brightActiveBorderGC;
extern GC darkActiveBorderGC;

extern GC backButtonGC;
extern GC brightButtonGC;
extern GC darkButtonGC;

extern GC backNormalTitlebarGC;
extern GC brightNormalTitlebarGC;
extern GC darkNormalTitlebarGC;

extern GC backActiveTitlebarGC;
extern GC brightActiveTitlebarGC;
extern GC darkActiveTitlebarGC;

extern GC activeTitlebarStringGC;
extern GC normalTitlebarStringGC;

extern GC backMenuGC;
extern GC brightMenuGC;
extern GC darkMenuGC;
extern GC activeMenuItemGC;

extern GC normalMenuStringGC;
extern GC activeMenuStringGC;
extern GC disabledMenuStringGC;

extern GC backStatusGC;
extern GC foreStatusGC;
extern GC brightStatusGC;
extern GC darkStatusGC;

extern GC backTaskBarGC;
extern GC brightTaskBarGC;
extern GC darkTaskBarGC;

extern GC backNormalTaskBarAppGC;
extern GC brightNormalTaskBarAppGC;
extern GC darkNormalTaskBarAppGC;
extern GC foreNormalTaskBarAppGC;

extern GC backActiveTaskBarAppGC;
extern GC brightActiveTaskBarAppGC;
extern GC darkActiveTaskBarAppGC;
extern GC foreActiveTaskBarAppGC;
    
extern YPixmap *closePixmap;
extern YPixmap *minimizePixmap;
extern YPixmap *maximizePixmap;
extern YPixmap *restorePixmap;


extern YPixmap *startPixmap;
extern YPixmap *windowsPixmap;

extern YPixmap *PixNum[10];
extern YPixmap *PixNoColon;
extern YPixmap *PixColon;

extern XFontStruct *titleFont;
extern XFontStruct *menuFont;
extern XFontStruct *statusFont;
extern XFontStruct *normalTaskBarFont;
extern XFontStruct *activeTaskBarFont;

extern Cursor leftPointer;
extern Cursor rightPointer;

extern Cursor movePointer;

extern Cursor sizeRightPointer;
extern Cursor sizeTopRightPointer;
extern Cursor sizeTopPointer;
extern Cursor sizeTopLeftPointer;
extern Cursor sizeLeftPointer;
extern Cursor sizeBottomLeftPointer;
extern Cursor sizeBottomPointer;
extern Cursor sizeBottomRightPointer;

#ifdef SHAPE
extern int shapesSupported;
extern int shapeEventBase, shapeErrorBase;
#endif

extern XContext windowContext;
extern XContext frameContext;
extern XContext clientContext;

extern YMenu *windowMenu;
extern YMenu *occupyMenu;
extern YMenu *windowListMenu;
extern YMenu *rootMenu;
extern MoveSizeStatus *statusMoveSize;
extern SwitchWindow *switchWindow;

extern Atom _XA_WM_PROTOCOLS;
extern Atom _XA_WM_TAKE_FOCUS;
extern Atom _XA_WM_DELETE_WINDOW;
extern Atom _XA_WM_STATE;
extern Atom _XA_WM_CHANGE_STATE;
extern Atom _XATOM_MWM_HINTS;
extern Atom _XA_WM_WORKSPACES;
extern Atom _XA_WM_WORKSPACE;

extern const char *clrBlack;
extern const char *clrWhite;

extern int configurationLoaded;
extern PhaseType phase;

void getOptions(int &argc, char **argv);
void loadConfiguration(const char *fileName);
void loadMenus(const char *fileName);
int addProgram(const char *name, const char *command, char **args = 0);
void addWorkspace(const char *name);
int findPath(const char *path, int mode, const char *name, char **fullname);

YIcon *getIcon(char *name);
    
void drawBorder1(Window win, int down, GC bright, GC dark, GC back,
                 int xl, int yt, int xr, int yb);
void drawBorderW(Window win, int down, GC bright, GC dark,
                 int xl, int yt, int xr, int yb);
void drawPixmap(Window win, int x, int y, YPixmap *pix);
void drawMaskPixmap(Window win, int x, int y, YMaskPixmap *maskpix);
void drawCenteredPixmap(Window win, int x, int y, int w, int h, GC back, YPixmap *pix);
void drawOutline(Window win, GC gc, int l, int t, int r, int b, int iw, int ih);

void xCopyClipArea(Display *display,
                   Pixmap pix,
                   Pixmap mask,
                   Drawable draw,
                   GC gc,
                   int orgX, int orgY,
                   int width, int height,
                   int dstX, int dstY);

#endif
