/*
 * ICEWM
 *
 * Copyright (C) 1997 Marko Macek
 */

#include "icewm.h"

void YFrameTitleBar::handleButton(const XButtonEvent &button) {
    if (button.type == ButtonPress) {
        if (!(button.state & ControlMask)) {
            if (//button.button != 2 &&
                (button.button != 1 || (button.state & Mod1Mask) == 0))
            {
                frame()->activate();
                if (raiseOnClickTitleBar)
                    frame()->wmRaise();
            }
        }
    }
    YWindow::handleButton(button);
}

void YFrameTitleBar::handleMotion(const XMotionEvent &motion) {
    YWindow::handleMotion(motion);
}

void YFrameTitleBar::handleClick(const XButtonEvent &down, const XButtonEvent &up, int count) {
    if (count == 2) {
        if (down.button == 1 && (down.state & (Mod1Mask | ShiftMask)) == 0)
            frame()->wmMaximize();
        else if (down.button == 2 && (down.state & (Mod1Mask | ShiftMask)) == 0)
            frame()->wmShade();
    } else if (count == 1) {
        if (down.button == 3 && (KEY_MODMASK(down.state) & (ShiftMask | Mod1Mask)) == 0) {
            frame()->updateMenu();
            windowMenu->popup(0, frame(),
                              up.x_root, up.y_root, -1, -1,
                              YPopupWindow::pfCanFlipVertical |
                              YPopupWindow::pfCanFlipHorizontal);
        } else if (down.button == 1 && KEY_MODMASK(down.state) == Mod1Mask) {
            frame()->wmLower();
        }
    }
}

void YFrameTitleBar::handleBeginDrag(const XButtonEvent &down, const XMotionEvent &/*motion*/) {
    if (frame()->canMove()) {
        frame()->startMoveSize(1, 1,
                               0, 0,
                               down.x + x(), down.y + y());
    }
    //handleDrag(down, motion);
}

void YFrameTitleBar::handleDrag(const XButtonEvent &/*down*/, const XMotionEvent &/*motion*/) {
}

void YFrameTitleBar::handleEndDrag(const XButtonEvent &/*down*/, const XButtonEvent &/*motion*/) {
}

void YFrameTitleBar::activate() {
    if (!isActive) {
        isActive = 1;
        repaint();
        if (wmLook == lookWin95 || wmLook == lookNice)
            frame()->menuButton()->repaint();
    }
}

void YFrameTitleBar::deactivate() {
    if (isActive) {
        isActive = 0;
        repaint();
        if (wmLook == lookWin95 || wmLook == lookNice)
            frame()->menuButton()->repaint();
    }
}

void YFrameTitleBar::paint(int , int , unsigned int , unsigned int ) {
    GC backGC = isActive ? backActiveTitlebarGC : backNormalTitlebarGC;
    int ol = 0;
    int or = 0;
    
    if (frame()->menuButton()->visible())
        ol += frame()->menuButton()->width();
    if (frame()->closeButton()->visible())
        or += frame()->closeButton()->width();
    if (frame()->minimizeButton()->visible())
        or += frame()->minimizeButton()->width();
    if (frame()->maximizeButton()->visible())
        or += frame()->maximizeButton()->width();

    if (wmLook == lookWin95 || wmLook == lookNice) {
        XFillRectangle(app->display(),
                       handle(),
                       backGC,
                       0, 0, width(), height());
    } else if (wmLook == lookWarp3) {
        GC darkGC = darkNormalTitlebarGC;
        
        XFillRectangle(app->display(),
                       handle(),
                       backGC,
#ifdef TITLEBAR_BOTTOM
                       0, 1, width(), height()
#else
                       0, 0, width(), height() - 1
#endif
                      );
        XDrawLine(app->display(), handle(), darkGC,
#ifdef TITLEBAR_BOTTOM
                  0, 0, width(), 0
#else
                  0, height() - 1, width(), height() - 1
#endif
                 );
    } else if (wmLook == lookWarp4) {
        GC brightGC = isActive ? brightActiveBorderGC : brightNormalTitlebarGC;
        GC darkGC = isActive ? darkActiveBorderGC : darkNormalTitlebarGC;

        if (isActive) {
            XFillRectangle(app->display(),
                           handle(),
                           backGC,
                           1, 1, width() - 2, height() - 2);

            drawBorder1(handle(), 1, brightGC, darkGC, backActiveBorderGC,
                        ol, 0, width() - or - 1, height() - 1);
        } else {
            XFillRectangle(app->display(),
                           handle(),
                           backGC,
                           0, 0, width(), height());
        }
    } else if (wmLook == lookMotif) {
        GC brightGC = isActive ? brightActiveTitlebarGC : brightNormalTitlebarGC;
        GC darkGC = isActive ? darkActiveTitlebarGC : darkNormalTitlebarGC;

        XFillRectangle(app->display(),
                       handle(),
                       backGC,
                       1, 1, width() - 2, height() - 2);


        drawBorder1(handle(), 0, brightGC, darkGC, backGC,
                    ol, 0, width() - or - 1, height() - 1);
    }
    if (frame()->client()) {
        int stringOffset = ol + 3;

        if (wmLook == lookWarp4 || wmLook == lookMotif)
            stringOffset++;
        
        unsigned char *title = frame()->client()->windowTitle();
        int yPos =
            (height() - (titleFont->max_bounds.descent +
                         titleFont->max_bounds.ascent)) / 2
            + titleFont->max_bounds.ascent;
        if (title) {
            XDrawString(app->display(),
                        handle(),
                        isActive ? activeTitlebarStringGC : normalTitlebarStringGC,
                        stringOffset,
                        yPos,
                        (char *)title, strlen((char *)title));
        }
    }
}
