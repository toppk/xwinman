/*
 * ICEWM
 *
 * Copyright (C) 1997 Marko Macek
 */

#include "icewm.h"

void drawBorder1(Window win, int down, GC bright, GC dark, GC back, int xl, int yt, int xr, int yb) {
    GC top = down ? dark : bright;
    GC bottom = down ? bright : dark;

    XDrawLine(app->display(), win, top,
              xl, yt, xr - 1, yt);
    XDrawLine(app->display(), win, top,
              xl, yt + 1, xl, yb);
    XDrawLine(app->display(), win, bottom,
              xr, yt + 1, xr, yb);
    XDrawLine(app->display(), win, bottom,
              xl + 1, yb, xr, yb);
    XDrawPoint(app->display(), win, back, xl, yb);
    XDrawPoint(app->display(), win, back, xr, yt);
}

void drawBorderW(Window win, int down, GC bright, GC dark, int xl, int yt, int xr, int yb) {
    if (down) {
        XDrawLine(app->display(), win, blackGC,
                  xl, yt, xr, yt);
        XDrawLine(app->display(), win, blackGC,
                  xl, yt, xl, yb);
        XDrawLine(app->display(), win, dark,
                  xl + 1, yt + 1, xr - 1, yt + 1);
        XDrawLine(app->display(), win, dark,
                  xl + 1, yt + 1, xl + 1, yb - 1);
        XDrawLine(app->display(), win, bright,
                  xr, yt + 1, xr, yb);
        XDrawLine(app->display(), win, bright,
                  xl + 1, yb, xr, yb);
    } else {
        XDrawLine(app->display(), win, bright,
                  xl, yt, xr - 1, yt);
        XDrawLine(app->display(), win, bright,
                  xl, yt, xl, yb - 1);
        XDrawLine(app->display(), win, dark,
                  xr - 1, yt + 1, xr - 1, yb - 1);
        XDrawLine(app->display(), win, dark,
                  xl + 1, yb - 1, xr - 1, yb - 1);
        XDrawLine(app->display(), win, blackGC,
                  xr, yt, xr, yb);
        XDrawLine(app->display(), win, blackGC,
                  xl, yb, xr, yb);
    }
}

void xCopyClipArea(Display *display,
                   Pixmap pix,
                   Pixmap mask,
                   Drawable draw,
                   GC gc,
                   int orgX, int orgY,
                   int width, int height,
                   int dstX, int dstY)
{
    XGCValues gcv;
    unsigned long gcm;
    
    gcm = GCClipMask|GCClipXOrigin|GCClipYOrigin;
    gcv.clip_mask = mask;
    gcv.clip_x_origin = dstX;
    gcv.clip_y_origin = dstY;
    XChangeGC(display, gc, gcm, &gcv);
    
    XCopyArea(display,
              pix, draw,
              gc, orgX, orgY, width, height, dstX, dstY);
    
    gcm = GCClipMask;
    gcv.clip_mask = None;
    XChangeGC(display, gc, gcm, &gcv);
}

void drawPixmap(Window win, int x, int y, YPixmap *pix) {
    if (pix)
        XCopyArea(app->display(), pix->pixmap(), win, blackGC,
                  0, 0, pix->width(), pix->height(), x, y);
}

void drawMaskPixmap(Window win, int x, int y, YMaskPixmap *maskpix) {
    if (maskpix)
        xCopyClipArea(app->display(),
                      maskpix->pixmap(),
                      maskpix->mask(),
                      win, blackGC,
                      0, 0, maskpix->width(), maskpix->height(),
                      x, y);
}

void drawCenteredPixmap(Window win, int x, int y, int w, int h, GC back, YPixmap *pixmap) {
    int r = x + w;
    int b = y + h;
    int pw = pixmap->width();
    int ph = pixmap->height();

    drawOutline(win, back, x, y, r, b, pw, ph);
    drawPixmap(win,
               x + w / 2 - pw / 2,
               y + h / 2 - ph / 2,
               pixmap);
}

void drawOutline(Window win, GC gc, int l, int t, int r, int b, int iw, int ih) {
    if (l + iw >= r && t + ih >= b)
        return ;

    int li = (l + r) / 2 - iw / 2;
    int ri = (l + r) / 2 + iw / 2;
    int ti = (t + b) / 2 - ih / 2;
    int bi = (t + b) / 2 + ih / 2;

    if (l < li)
        XFillRectangle(app->display(), win, gc,
                       l, t, li - l, b - t);

    if (ri < r)
        XFillRectangle(app->display(), win, gc,
                       ri, t, r - ri, b - t);

    if (t < ti)
        if (li < ri)
            XFillRectangle(app->display(), win, gc,
                           li, t, ri - li, ti - t);

    if (bi < b)
        if (li < ri)
            XFillRectangle(app->display(), win, gc,
                           li, bi, ri - li, b - bi);
}

