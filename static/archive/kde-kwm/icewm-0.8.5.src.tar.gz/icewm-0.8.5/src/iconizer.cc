/*
 * ICEWM
 *
 * Copyright (C) 1997 Marko Macek
 */

#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdarg.h>
#include <X11/Xproto.h>
#include <X11/Xatom.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>
#include <X11/cursorfont.h>
#include <X11/keysym.h>
#include <X11/xpm.h>
#ifndef NO_MWM_HINTS
#include "MwmUtil.h"
#endif

extern int debug;

void die(int exitcode, char *msg, ...);
void msg(char *msg, ...);
void logEvent(XEvent xev);

char *displayName = 0;
Display *display = 0;
Colormap defaultColormap;
Window root = 0;

Atom _WM_MWM_HINTS;
Atom _WM_ICONS;

class propKey {
public:
    propKey(char *rname, char *rclass);
    ~propKey();
    
    int match(XClassHint *hint);

private:
    char *res_name;
    char *res_class;
};

class icon {
public:
    Pixmap pixmap;
    Pixmap mask;
};

class iconPair {
public:
    iconPair(char *rname, char *rclass, char *smallIcon, char *largeIcon);
    
private:
    iconPair *next;

    propKey key;

    char *smallIconName;
    char *largeIconName;
    icon smallIcon;
    icon largeIcon;
};

propKey::propKey(char *rname, char *rclass) {
    res_name = rname ? strdup(rname) : 0;
    res_name = rclass ? strdup(rclass) : 0;
}

propKey::~propKey() {
    free(res_name);
    free(res_class);
}

int propKey::match(XClassHint *hint) {
    if (!hint)
        return 0;
    if (res_name && strcmp(hint->res_name, res_name) != 0)
        return 0;
    if (res_class && strcmp(hint->res_class, res_class) != 0)
        return 0;
    return 1;
}

void checkClassHint(Window win) {
    XClassHint *classHint = 0;
    
    if (XGetClassHint(display, win, classHint)) {
        MSG(("window: 0x%lX, name: %s, class: %s",
             win,
             classHint->res_name,
             classHint->res_class));
    }

    if (classHint) {
        XFree(classHint->res_name);
        XFree(classHint->res_class);
        XFree(classHint);
    }
}

int loadPixmap(char *path, Pixmap &pixmap, Pixmap &mask) {
    XpmAttributes xpmAttributes;
    int rc;
    
    xpmAttributes.colormap  = defaultColormap;
    xpmAttributes.closeness = 40000;
    xpmAttributes.valuemask = XpmSize|XpmReturnPixels|XpmColormap|XpmCloseness;

    rc = XpmReadFileToPixmap(display, root,
                             path,
                             &pixmap, &mask,
                             &xpmAttributes);

    if (rc != 0)
        fprintf(stderr, "create pixmap %s: rc=%d\n", path, rc);

    return rc;
}

int main(int argc, char **argv) {
    if (!(display = XOpenDisplay(displayName)))
        die(1, "can't open display: %s", displayName);

    root = RootWindow(display, DefaultScreen(display));
    defaultColormap = DefaultColormap(display, DefaultScreen(display));

    _WM_MWM_HINTS = XInternAtom(display, _XA_MOTIF_WM_HINTS, False);
    _WM_ICONS = XInternAtom(display, "WM_ICONS", False);

    assert(XSelectInput(display, root, SubstructureNotifyMask) == Success);

    while (1) {
        XEvent xev;
    
        XNextEvent(display, &xev);

        //logEvent(xev);

        switch (xev.type) {
        case CreateNotify:
            if (xev.xcreatewindow.override_redirect == False) {
                assert(XSelectInput(display, xev.xcreatewindow.window,
                                    PropertyChangeMask) == Success);

                checkClassHint(xev.xcreatewindow.window);
            }
            break;
            
        case DestroyNotify:
            break;
            
        case PropertyNotify:
            if (xev.xproperty.atom == XA_WM_CLASS) {
                if (xev.xproperty.state == PropertyNewValue) {
                    checkClassHint(xev.xproperty.window);
                } else {
                }
            }
            break;
        }
    }
}
