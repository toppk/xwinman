
#ifndef NO_CONFIGURE
#ifdef CFGDEF
#define XIV(t,a,b) t a = b;
#else
#define XIV(t,a,b) extern t a;
#endif
#else
#ifdef CFGDEF
#define XIV(t,a,b)
#else
#define XIV(t,a,b) static const t a = b;  // I hope this can be optimized away ?
#endif
#endif

#ifndef CFGDEF
typedef enum {
    lookWin95, lookMotif,
    lookWarp3, lookWarp4,
    lookNice
    // lookWin31
} WMLook;
#endif

XIV(int, clickFocus                   , 1)
XIV(int, raiseOnFocus                 , 1)
XIV(int, focusOnClickClient           , 1)
XIV(int, raiseOnClickClient           , 1)
XIV(int, raiseOnClickButton           , 1)
XIV(int, raiseOnClickFrame            , 1)
XIV(int, raiseOnClickTitleBar         , 1)
XIV(int, passFirstClickToClient       , 1)
XIV(int, focusOnMap                   , 1)
XIV(int, pointerColormap              , 0)
XIV(int, sizeMaximized                , 0)
XIV(int, useXButton                   , 1)
XIV(int, taskBarAtTop                 , 0)
XIV(int, showTaskBar                  , 1)
XIV(int, showMoveSizeStatus           , 1)
XIV(int, warpPointer                  , 0)
XIV(int, opaqueMove                   , 0)
XIV(int, opaqueResize                 , 0)
XIV(int, win95keys                    , 0)
XIV(int, taskBarShowWorkspaces        , 0)
XIV(int, taskBarShowAllWindows        , 0)
XIV(WMLook, wmLook                    , lookNice)
XIV(unsigned int, wsBorderX           , 6)
XIV(unsigned int, wsBorderY           , 6)
XIV(unsigned int, wsDlgBorderX        , 2)
XIV(unsigned int, wsDlgBorderY        , 2)
XIV(unsigned int, wsTitleBar          , 20)
XIV(unsigned int, wsCornerX           , 24)
XIV(unsigned int, wsCornerY           , 24)
XIV(unsigned int, ClickMotionDistance , 5)
XIV(unsigned int, MultiClickTime      , 400)
XIV(const char *, titleFontName             , "-adobe-helvetica-bold-r-*-*-*-120-*-*-*-*-*-*")
XIV(const char *, menuFontName              , "-adobe-helvetica-bold-r-*-*-*-120-*-*-*-*-*-*")
XIV(const char *, statusFontName            , "-adobe-courier-bold-r-*-*-*-120-*-*-*-*-*-*")
XIV(const char *, normalTaskBarFontName     , "-adobe-helvetica-medium-r-*-*-*-120-*-*-*-*-*-*")
XIV(const char *, activeTaskBarFontName     , "-adobe-helvetica-bold-r-*-*-*-120-*-*-*-*-*-*")
XIV(const char *, xpmPath                   , XPM_PATH)
XIV(const char *, iconPath                  , ICON_PATH)
XIV(const char *, clrActiveBorder           , "rgb:C0/C0/C0")
XIV(const char *, clrNormalBorder           , "rgb:C0/C0/C0")
XIV(const char *, clrNormalButton           , "rgb:C0/C0/C0")
XIV(const char *, clrActiveTitlebar         , "rgb:00/00/A0")
XIV(const char *, clrNormalTitlebar         , "rgb:80/80/80")
XIV(const char *, clrActiveTitlebarString   , "rgb:FF/FF/FF")
XIV(const char *, clrNormalTitlebarString   , "rgb:00/00/00")
XIV(const char *, clrNormalMenu             , "rgb:C0/C0/C0")
XIV(const char *, clrActiveMenuItem         , "rgb:00/00/A0")
XIV(const char *, clrActiveMenuItemString   , "rgb:FF/FF/FF")
XIV(const char *, clrNormalMenuItemString   , "rgb:00/00/00")
XIV(const char *, clrDisabledMenuItemString , "rgb:80/80/80")
XIV(const char *, clrMoveSizeStatus         , "rgb:C0/C0/C0")
XIV(const char *, clrMoveSizeStatusText     , "rgb:00/00/00")
XIV(const char *, clrDefaultTaskBar         , "rgb:C0/C0/C0")
XIV(const char *, clrNormalTaskBarApp       , "rgb:C0/C0/C0")
XIV(const char *, clrNormalTaskBarAppText   , "rgb:00/00/00")
XIV(const char *, clrActiveTaskBarApp       , "rgb:E0/E0/E0")
XIV(const char *, clrActiveTaskBarAppText   , "rgb:00/00/00")

#if defined(CFGDEF) && !defined(NO_CONFIGURE)

static struct {
    const char *option;
    int *value;
} bool_options[] = {
    { "ShowXButton", &useXButton },
    { "ClickToFocus", &clickFocus },
    { "RaiseOnFocus", &raiseOnFocus },
    { "FocusOnClickClient", &focusOnClickClient },
    { "RaiseOnClickClient", &raiseOnClickClient },
    { "RaiseOnClickTitleBar", &raiseOnClickTitleBar },
    { "RaiseOnClickButton", &raiseOnClickButton },
    { "RaiseOnClickFrame", &raiseOnClickFrame },
    { "PassFirstClickToClient", &passFirstClickToClient },
    { "FocusOnMap", &focusOnMap },
    { "PointerColormap", &pointerColormap },
    { "SizeMaximized", &sizeMaximized },
    { "TaskBarAtTop" , &taskBarAtTop },
    { "ShowTaskBar", &showTaskBar },
    { "ShowMoveSizeStatus", &showMoveSizeStatus },
    { "WarpPointer" , &warpPointer },
    { "OpaqueMove", &opaqueMove },
    { "OpaqueResize", &opaqueResize },
    { "Win95Keys", &win95keys },
    { "TaskBarShowWorkspaces", &taskBarShowWorkspaces },
    { "TaskBarShowAllWindows", &taskBarShowAllWindows },
#ifdef DEBUG
    { "debug", &debug },
    { "debug_z", &debug_z },
#endif
};

static struct {
    const char *option;
    unsigned int *value;
    int min, max;
} uint_options[] = {
    { "BorderSizeX", &wsBorderX, 0, 128 },
    { "BorderSizeY", &wsBorderY, 0, 128 },
    { "DlgBorderSizeX", &wsDlgBorderX, 0, 128 },
    { "DlgBorderSizeY", &wsDlgBorderY, 0, 128 },
    { "TitleBarHeight", &wsTitleBar, 0, 128 },
    { "CornerSizeX", &wsCornerX, 0, 64 },
    { "CornerSizeY", &wsCornerY, 0, 64 },
    { "ClickMotionDistance", &ClickMotionDistance, 0, 32 },
    { "MultiClickTime", &MultiClickTime, 0, 5000 },
};

static struct {
    const char *option;
    const char **value;
    int initial;
} string_options[] = {
//    { "display", &displayName, 1 },
    { "TitleFontName", &titleFontName, 1 },
    { "MenuFontName", &menuFontName, 1 },
    { "StatusFontName", &statusFontName, 1 },
    { "NormalTaskBarFontName", &normalTaskBarFontName, 1 },
    { "ActiveTaskBarFontName", &activeTaskBarFontName, 1 },
    { "LibPath", &xpmPath, 1 },
    { "IconPath", &iconPath, 1 },
    { "ColorActiveBorder", &clrActiveBorder, 1 },
    { "ColorNormalBorder", &clrNormalBorder, 1 },
    { "ColorNormalButton", &clrNormalButton, 1 },
    { "ColorActiveTitleBar", &clrActiveTitlebar, 1 },
    { "ColorNormalTitleBar", &clrNormalTitlebar, 1 },
    { "ColorActiveTitleBarString", &clrActiveTitlebarString, 1 },
    { "ColorNormalTitleBarString", &clrNormalTitlebarString, 1 },
    { "ColorNormalMenu", &clrNormalMenu, 1 },
    { "ColorActiveMenuItem", &clrActiveMenuItem, 1 },
    { "ColorActiveMenuItemString", &clrActiveMenuItemString, 1 },
    { "ColorNormalMenuItemString", &clrNormalMenuItemString, 1 },
    { "ColorDisabledMenuItemString", &clrDisabledMenuItemString, 1 },
    { "ColorMoveSizeStatus", &clrMoveSizeStatus, 1 },
    { "ColorMoveSizeStatusText", &clrMoveSizeStatusText, 1 },
    { "ColorDefaultTaskBar", &clrDefaultTaskBar, 1 },
    { "ColorNormalTaskBarApp", &clrNormalTaskBarApp, 1 },
    { "ColorNormalTaskBarAppText", &clrNormalTaskBarAppText, 1 },
    { "ColorActiveTaskBarApp", &clrActiveTaskBarApp, 1 },
    { "ColorActiveTaskBarAppText", &clrActiveTaskBarAppText, 1 },
};

#define ACOUNT(x) (sizeof(x)/sizeof(x[0]))
#endif

#undef XIV
