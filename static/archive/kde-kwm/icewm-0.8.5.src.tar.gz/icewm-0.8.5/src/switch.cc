/*
 * ICEWM
 *
 * Copyright (C) 1997 Marko Macek
 *
 * Windows/OS2 like Alt{+Shift}+Tab window switching
 */

#include "icewm.h"

SwitchWindow::SwitchWindow(YWindow *parent): YPopupWindow(parent) {
    int sW = 4 + app->root()->width() / 5 * 3;
    int sH = 4 + 32;
        //statusFont->max_bounds.ascent +
        //statusFont->max_bounds.descent;

    setGeometry(app->root()->width() / 2 - sW / 2,
                app->root()->height() / 2 - sH / 2,
                sW, sH);

    setStyle(wsOverrideRedirect);
}

SwitchWindow::~SwitchWindow() {
}

void SwitchWindow::paint(int /*x*/, int /*y*/, unsigned int /*width*/, unsigned int /*height*/) {
    GC brightGC = brightStatusGC;
    GC darkGC = darkStatusGC;

    drawBorderW(handle(), 0, brightGC, darkGC,
                0, 0, width() - 1, height() - 1);

    XFillRectangle(app->display(),
                   handle(),
                   backStatusGC,
                   1, 1, width() - 3, height() - 3);

    if (fActiveWindow) {

        char *str = (char *)fActiveWindow->client()->windowTitle();
        if (str != 0)
            XDrawString(app->display(),
                        handle(),
                        foreStatusGC,
                        width() / 2 - XTextWidth(statusFont, str, strlen(str)) / 2,
                        height() / 2
                         + (statusFont->max_bounds.ascent +
                            statusFont->max_bounds.descent) / 2
                            - statusFont->max_bounds.descent,
                        (char *)str, strlen(str));
    }
}

void SwitchWindow::begin(int next) {
    fActiveWindow = app->top();
    if (fActiveWindow) {
        fActiveWindow =
            fActiveWindow->findWindow(YFrameWindow::fwfNext |
                                      YFrameWindow::fwfCycle |
                                      YFrameWindow::fwfFocusable |
                                      YFrameWindow::fwfWorkspace |
                                      YFrameWindow::fwfSame |
                                      (next ? 0 : YFrameWindow::fwfBackward));
    }
    popup(0, 0, YPopupWindow::pfNoPointerChange);
}

void SwitchWindow::activatePopup() {
}

void SwitchWindow::deactivatePopup() {
}

void SwitchWindow::destroyed(YFrameWindow *frame) {
    if (frame == fActiveWindow) {
        fActiveWindow = app->top();
        if (fActiveWindow)
            fActiveWindow = fActiveWindow->findWindow(YFrameWindow::fwfNext |
                                                      YFrameWindow::fwfCycle |
                                                      YFrameWindow::fwfFocusable |
                                                      YFrameWindow::fwfWorkspace);
        repaint();
    }
}

void SwitchWindow::handleKey(const XKeyEvent &key) {
    int k = XKeycodeToKeysym(app->display(), key.keycode, 0);
    int m = KEY_MODMASK(key.state);
    
    if (key.type == KeyPress) {
        if (k == XK_Tab && m == Mod1Mask) {
            if (fActiveWindow)
                fActiveWindow = fActiveWindow->findWindow(YFrameWindow::fwfNext |
                                                          YFrameWindow::fwfCycle |
                                                          YFrameWindow::fwfFocusable |
                                                          YFrameWindow::fwfSame |
                                                          YFrameWindow::fwfWorkspace);
            else
                fActiveWindow = app->top();
            repaint();
        } else if ((/*k == XK_BackTab ||*/ k == XK_Tab) && (m == Mod1Mask + ShiftMask)) {
            if (fActiveWindow)
                fActiveWindow = fActiveWindow->findWindow(YFrameWindow::fwfNext |
                                                          YFrameWindow::fwfBackward |
                                                          YFrameWindow::fwfCycle |
                                                          YFrameWindow::fwfFocusable |
                                                          YFrameWindow::fwfSame |
                                                          YFrameWindow::fwfWorkspace);
            else
                fActiveWindow = app->bottom();
            repaint();
        } else if (k == XK_Escape && m == Mod1Mask) {
            cancelPopup();
        }
    } else if (key.type == KeyRelease) {
        if (fActiveWindow &&
            (k == XK_Alt_L || k == XK_Alt_R ||
             k == XK_Meta_L || k == XK_Meta_R))
        {
            fActiveWindow->wmRaise();
            app->activate(fActiveWindow);
            cancelPopup();
        }
    }
    YPopupWindow::handleKey(key);
}

void SwitchWindow::handleButton(const XButtonEvent &button) {
    YPopupWindow::handleButton(button);
}
