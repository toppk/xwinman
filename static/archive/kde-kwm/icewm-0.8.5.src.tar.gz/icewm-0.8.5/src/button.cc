/*
 * ICEWM
 *
 * Copyright (C) 1997 Marko Macek
 */

#include "icewm.h"

YFrameButton::YFrameButton(YWindow *parent,
                           YFrameWindow *frame,
                           WMCommand command,
                           WMCommand command2):
    YFrameControl(parent, frame)
{
    fCommand = command;
    fCommand2 = command2;
    isDown = isActive = wasPopupActive = 0;
    fPopup = 0;

    int w = minimizePixmap->width(), h = minimizePixmap->height();
    switch (wmLook) {
    case lookWarp3:
        setSize(w + 2, h + 2);
        break;
    case lookWarp4:
        setSize(w + 0, h / 2 + 0);
        break;
    case lookNice:
    case lookWin95:
        setSize(w + 3, h + 3);
        break;
    case lookMotif:
        setSize(w + 2, h + 2);
        break;
    }
}

YFrameButton::~YFrameButton() {
    if (fPopup)
        fPopup->popdown();
}

void YFrameButton::activate() {
    if (!isActive && isDown) {
        isActive = 1;
        repaint();
    }
}

void YFrameButton::deactivate() {
    if (isActive) {
        isActive = 0;
        repaint();
    }
}

void YFrameButton::handleButton(const XButtonEvent &button) {
    if (button.type == ButtonPress) {
        if (fPopup == 0) {
            if (!(button.state & ControlMask) && raiseOnClickButton) {
                frame()->activate();
                if (raiseOnClickButton)
                    frame()->wmRaise();
            }
        }
        isDown = 1;
        if (fCommand == cmdSysMenu) {
            wasPopupActive = 0;
            if (fPopup) {
                wasPopupActive = 1;
            } else {
                activate();
                fPopup = windowMenu;
                frame()->updateMenu();
                windowMenu->popup(this, frame(),
                                  x() + frame()->titlebar()->x() + frame()->x(),
                                  height() + y() + frame()->titlebar()->y() + frame()->y(),
                                  width(), height(),
                                  YPopupWindow::pfButtonDown |
                                  YPopupWindow::pfCanFlipVertical);
            }
        } else {
            activate();
        }
    } else if (button.type == ButtonRelease) {
        int inWindow = (button.x >= 0 &&
                        button.y >= 0 &&
                        button.x < int (width()) &&
                        button.y < int (height()));
        int down = isDown;

        isDown = 0;
        if (fCommand == cmdSysMenu) {
            if (wasPopupActive || !inWindow) {
                if (fPopup) {
                    donePopup(windowMenu);
                    deactivate();
                }
            }
        } else {
            deactivate();

            if (inWindow && down)
                if ((button.state & Mod1Mask) && fCommand2 != cmdNone)
                    frame()->handleCommand(fCommand2, 0);
                else
                    frame()->handleCommand(fCommand, 0);

            return ;
        }
    }
    YWindow::handleButton(button);
}

void YFrameButton::handleClick(const XButtonEvent &/*down*/, const XButtonEvent &/*up*/, int count) {
    if (fCommand == cmdSysMenu) {
        if (count == 2)
            frame()->wmClose();
    }
}

void YFrameButton::handleMotion(const XMotionEvent &motion) {
    if (isActive && fCommand == cmdSysMenu) {
    } else if (isDown) {
        if (motion.x >= 0 && motion.y >= 0 &&
            motion.x < int(width()) && motion.y < int(height()))
            activate();
        else
            deactivate();
    }
    YWindow::handleMotion(motion);
}

void YFrameButton::setCommand(WMCommand command, WMCommand command2) {
    fCommand2 = command2;
    if (command != fCommand) {
        fCommand = command;
        repaint();
    }
}

void YFrameButton::donePopup(YPopupWindow *popup) {
    if (popup != fPopup) {
        MSG(("popup differs for button??"));
        return ;
    }
    popdownMenu();
}

void YFrameButton::popupMenu() {
    assert(fPopup == 0);
    if (fCommand == cmdSysMenu) {
        isDown = 1;
        wasPopupActive = 0;
        activate();
        fPopup = windowMenu;
        frame()->updateMenu();
        windowMenu->popup(this, frame(),
                          x() + frame()->titlebar()->x() + frame()->x(),
                          height() + y() + frame()->titlebar()->y() + frame()->y(),
                          width(), height(),
                          YPopupWindow::pfCanFlipVertical);
        isDown = 0;
    }
}

void YFrameButton::popdownMenu() {
    if (fPopup) {
        MSG(("done popup in frame button"));
        fPopup->popdown();
        deactivate();
        fPopup = 0;
    }
}

void YFrameButton::paint(int , int , unsigned int , unsigned int ) {
    int xPos = 1, yPos = 1;
    GC backGC = backButtonGC;
    GC brightGC = brightButtonGC;
    GC darkGC = darkButtonGC;

    YPixmap *pixmap = 0;
    YMaskPixmap *icon = 0;

    switch (fCommand) {
    case cmdMaximize: pixmap = maximizePixmap; break;
    case cmdMinimize: pixmap = minimizePixmap; break;
    case cmdRestore: pixmap = restorePixmap; break;
    case cmdClose: pixmap = closePixmap; break;
    case cmdSysMenu: icon = frame()->clientIcon()->small(); break;
    default:
        pixmap = 0;
    }

    if (wmLook == lookWarp4) {
        if (fCommand == cmdSysMenu) {
            GC gc = isActive ? backActiveTitlebarGC : backGC;

            XDrawRectangle(app->display(), handle(), backGC,
                           0, 0, width() - 1, height() - 1);

            XFillRectangle(app->display(),
                           handle(),
                           gc,
                           1, 1, width() - 2, height() - 2);
            
            if (icon)
                drawMaskPixmap(handle(),
                               (width() - icon->width()) / 2,
                               (height() - icon->height()) / 2,
                               icon);
        } else {
            int picYpos = isActive ? 20 : 0;

            XFillRectangle(app->display(),
                           handle(),
                           backGC,
                           0, 0, width(), height());
            
            if (pixmap)
                XCopyArea(app->display(),
                          pixmap->pixmap(), handle(),
                          backGC, 0, picYpos, pixmap->width(), pixmap->height() / 2,
                          (width() - pixmap->width()) / 2,
                          (height() - pixmap->height() / 2) / 2);
        }
    } else if (wmLook == lookMotif || wmLook == lookWarp3) { // Warp3 ?
        drawBorder1(handle(), isActive ? 1 : 0, brightGC, darkGC, backGC,
                    0, 0, width() - 1, height() - 1);
        if (wmLook == lookWarp3) {
            if (isActive) {
                xPos = 3;
                yPos = 3;

                XDrawLine(app->display(), handle(), backGC,
                          1, 1, width() - 2, 1);
                XDrawLine(app->display(), handle(), backGC,
                          1, 1, 1, height() - 2);
                XDrawLine(app->display(), handle(), backGC,
                          2, 2, width() - 3, 2);
                XDrawLine(app->display(), handle(), backGC,
                          2, 2, 2, height() - 3);
            } else {
                xPos = 2;
                yPos = 2;

                drawBorder1(handle(), 0, backGC, backGC, backGC,
                            1, 1, width() - 2, width() - 2);
            }
        }

        int xW, yW;
        
        if (wmLook == lookWarp3) {
            xW = width() - 4;
            yW = height() - 4;
        } else {
            xW = width() - 2;
            yW = height() - 2;
        }
        if (fCommand == cmdSysMenu) {
            GC gc = backGC;

            XFillRectangle(app->display(),
                           handle(),
                           gc,
                           xPos, yPos, xW, yW);
            
            if (icon)
                drawMaskPixmap(handle(),
                               xPos - 1 + (width() - icon->width()) / 2,
                               yPos - 1 + (height() - icon->height()) / 2,
                               icon);
        } else {
            drawCenteredPixmap(handle(),
                               xPos, yPos, xW, yW, backGC, pixmap);
            //drawPixmap(handle(), xPos, yPos, pixmap);
        }
    } else if (wmLook == lookWin95 || wmLook == lookNice) {
        
        if (fCommand == cmdSysMenu) {
            GC gc = isActive ? activeMenuItemGC : frame()->titlebar()->active() ? backActiveTitlebarGC : backNormalTitlebarGC;
            
            XFillRectangle(app->display(),
                           handle(),
                           gc,
                           0, 0, width(), height());
            if (icon)
                drawMaskPixmap(handle(),
                               (width() - icon->width()) / 2,
                               (height() - icon->height()) / 2,
                               icon);
        } else {
            drawBorderW(handle(), isActive ? 1 : 0, brightGC, darkGC,
                        0, 0, width() - 1, height() - 1);
            if (isActive)
                xPos = yPos = 2;

            drawCenteredPixmap(handle(),
                               xPos, yPos, width() - 3, height() - 3, backGC, pixmap);
            //drawPixmap(handle(), xPos, yPos, pixmap);
        }
    }
}

YButton::YButton(YWindow *parent, WMCommand command, void *context): YWindow(parent) {
    selected = 0;
    isActive = 0;
    fPopup = 0;
    fCommand = command;
    fContext = context;
    wasPopupActive = 0;
    fPixmap = 0;
    fPressed = 0;
}

YButton::YButton(YWindow *parent, YPopupWindow *popup): YWindow(parent) {
    selected = 0;
    isActive = 0;
    fPopup = popup;
    fCommand = cmdNone;
    wasPopupActive = 0;
    fPixmap = 0;
    fText = 0;
    fContext = 0;
    fPressed = 0;
}

YButton::~YButton() {
    if (isActive)
        popdown();
}

void YButton::paint(int /*x*/, int /*y*/, unsigned int /*width*/, unsigned int /*height*/) {
    GC darkGC = darkTaskBarGC;
    GC brightGC = brightTaskBarGC;
    GC backGC = backTaskBarGC;

    int d = (fPressed || isActive) ? 1 : 0;
    
    drawBorderW(handle(), d, brightGC, darkGC,
                0, 0, width() - 1, height() - 1);
    if (fPixmap) {
        XCopyArea(app->display(), fPixmap->pixmap(), handle(), backGC,
                  0, 0, width() - 3, height() - 3, 1 + d, 1 + d);
    } else {
        XFillRectangle(app->display(), handle(), backGC,
                       1 + d, 1 + d, width() - 3, height() - 3);

        GC fontGC;
        XFontStruct *font;
        
        if (fPressed) {
            font = activeTaskBarFont;
            fontGC = foreActiveTaskBarAppGC;
        } else {
            font = normalTaskBarFont;
            fontGC = foreNormalTaskBarAppGC;
        }

        if (fText) {
            int w = XTextWidth(font, fText, strlen(fText));
            int p = (width() - w) / 2;
            int yp =  (height() - 1 + d - (font->max_bounds.descent +
                                       font->max_bounds.ascent)) / 2
                + font->max_bounds.ascent;

            XDrawString(app->display(), handle(), fontGC,
                        d + p, yp, fText, strlen(fText));
        }
    }
}

void YButton::handleButton(const XButtonEvent &button) {
    if (button.type == ButtonPress) {
        selected = 2;
        if (fPopup) {
            wasPopupActive = isActive;
            if (!isActive)
                popup();
        } else {
        }
        isActive = 1;
        repaint();
    } else if (button.type == ButtonRelease) {
        int inWindow = (button.x >= 0 &&
                        button.y >= 0 &&
                        button.x < int (width()) &&
                        button.y < int (height()));
        selected = 0;
        if (fPopup) {
            if ((!inWindow || wasPopupActive) && isActive) {
                popdown();
                isActive = 0;
                repaint();
            }
        } else {
            int wasActive = isActive;
            if (isActive) {
                isActive = 0;
                repaint();
            }
            if (inWindow && wasActive)
                app->handleCommand(fCommand, fContext);
        }
    }
}

void YButton::handleCrossing(const XCrossingEvent &crossing) {
    if (selected > 0) {
        if (crossing.type == EnterNotify) {
            selected = 2;
            if (!fPopup) { 
                isActive = 1;
                repaint();
            }
        } else if (crossing.type == LeaveNotify) {
            selected = 1;
            if (!fPopup) { 
                isActive = 0;
                repaint();
            }
        }
    }
}

void YButton::setCommand(WMCommand command, void *context) {
    fCommand = command;
    fContext = context;
}

void YButton::setPixmap(YPixmap *pixmap) {
    fPixmap = pixmap;
    if (pixmap) {
        setSize(pixmap->width() + 3,
                pixmap->height() + 3);
    }
}

void YButton::setPressed(int pressed) {
    if (fPressed != pressed) {
        fPressed = pressed;
        repaint();
    }
}

void YButton::setText(char *str) {
    fText = str ? strdup(str) : 0;
    if (fText) {
        int w = XTextWidth(activeTaskBarFont, fText, strlen(fText));
        int h = statusFont->ascent + statusFont->descent;
        
        setSize(3 + w + 4, 3 + h + 2);
    }
}

void YButton::setPopup(YPopupWindow *popup) {
    if (fPopup) {
        popdown();
        delete fPopup;
    }
    fPopup = popup;
}

void YButton::donePopup(YPopupWindow *popup) {
    if (popup != fPopup) {
        MSG(("popup different?"));
        return ;
    }
    popdown();
    isActive = 0;
    selected = 0;
    repaint();
}

void YButton::popup() {
    if (fPopup) {
        fPopup->popup(this, 0, x() + parent()->x() - 2, y() + parent()->y() + width(), 0, width(),
                      YPopupWindow::pfCanFlipVertical | 
                      YPopupWindow::pfButtonDown);
    }
}

void YButton::popdown() {
    if (isActive && fPopup) {
        fPopup->popdown();
        isActive = 0;
    }
}
