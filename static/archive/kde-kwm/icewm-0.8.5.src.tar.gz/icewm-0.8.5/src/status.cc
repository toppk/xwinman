/*
 * ICEWM
 *
 * Copyright (C) 1997 Marko Macek
 *
 * Status display for resize/move
 */

#include "icewm.h"

MoveSizeStatus::MoveSizeStatus(YWindow *aParent, Window win): YWindow(aParent, win) {
    int sW =
        XTextWidth(statusFont, "9999x9999+9999+9999", 19);
    int sH =
        statusFont->max_bounds.ascent +
        statusFont->max_bounds.descent;
    
    setGeometry((app->root()->width() - sW) / 2,
                (app->root()->height() - sH) - 8, // / 2,
                sW + 2, sH + 4);
    setStyle(wsOverrideRedirect);
}

MoveSizeStatus::~MoveSizeStatus() {
}

void MoveSizeStatus::paint(int /*x*/, int /*y*/, unsigned int /*width*/, unsigned int /*height*/) {
    char str[50];
    GC brightGC = brightStatusGC;
    GC darkGC = darkStatusGC;

    sprintf(str, "%dx%d+%d+%d",
            fW, fH,
            fX, fY);

    drawBorderW(handle(), 0, brightGC, darkGC,
                0, 0, width() - 1, height() - 1);

    XFillRectangle(app->display(),
                   handle(),
                   backStatusGC,
                   1, 1, width() - 3, height() - 3);

    XDrawString(app->display(),
                handle(),
                foreStatusGC,
                width() / 2 - XTextWidth(statusFont, str, strlen(str)) / 2,
                height() - statusFont->max_bounds.descent - 2,
                (char *)str, strlen(str));

}

void MoveSizeStatus::begin(YFrameWindow *frame) {
    if (showMoveSizeStatus) {
        raise();
        show();
    }
    setStatus(frame);
}

void MoveSizeStatus::setStatus(YFrameWindow *frame, int x, int y, int width, int height) {
    XSizeHints *sh = frame->client()->sizeHints();

    width -= frame->borderX() * 2;
    height -= frame->borderY() * 2 + frame->titleY();
    
    fX = x + frame->borderX();
    fY = y + frame->borderY() + frame->titleY();
    fW = (width - (sh ? sh->base_width : 0)) / (sh ? sh->width_inc : 1);
    fH = (height - (sh ? sh->base_height : 0)) / (sh ? sh->height_inc : 1);
    repaint();
}

void MoveSizeStatus::setStatus(YFrameWindow *frame) {
    XSizeHints *sh = frame->client()->sizeHints();
    
    fX = frame->x() + frame->borderX();
    fY = frame->y() + frame->borderY() + frame->titleY();
    fW = (frame->client()->width() - (sh ? sh->base_width : 0)) / (sh ? sh->width_inc : 1);
    fH = (frame->client()->height() - (sh ? sh->base_height : 0)) / (sh ? sh->height_inc : 1);
    repaint();
}
