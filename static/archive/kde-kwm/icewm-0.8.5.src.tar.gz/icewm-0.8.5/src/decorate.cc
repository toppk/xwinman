/*
 * ICEWM
 *
 * Copyright (C) 1997 Marko Macek
 */

#include "icewm.h"

void YFrameWindow::updateMenu() {
    // enable all commands
    windowMenu->enableCommand(cmdNone);

    if (style & fsMaximized)
        windowMenu->disableCommand(cmdMaximize);
    if (style & fsMinimized)
        windowMenu->disableCommand(cmdMinimize);
    if (!(style & (fsMaximized | fsMinimized)))
        windowMenu->disableCommand(cmdRestore);
    if (this == app->bottom())
        windowMenu->disableCommand(cmdLower);
#ifndef NO_MWM_HINTS
    CARD32 func = ~client()->mwmFunctions();

    if (func & MWM_FUNC_MOVE)
        windowMenu->disableCommand(cmdMove);
    if (func & MWM_FUNC_RESIZE)
        windowMenu->disableCommand(cmdSize);
    if (func & MWM_FUNC_MINIMIZE) {
        windowMenu->disableCommand(cmdHide);
        windowMenu->disableCommand(cmdMinimize);
        windowMenu->disableCommand(cmdShade);
    }
    if (func & MWM_FUNC_MAXIMIZE)
        windowMenu->disableCommand(cmdMaximize);
    if (func & MWM_FUNC_CLOSE)
        windowMenu->disableCommand(cmdClose);
#endif

    YMenu::YMenuItem *item = windowMenu->findItem(cmdShade);
    if (item)
        item->setCheck(shaded() ? 1 : 0);
    item = windowMenu->findItem(cmdOccupyAll);
    if (item)
        item->setCheck(client()->allWorkspaces() ? 1 : 0);
    for (int ii = 0; ii < occupyMenu->itemCount(); ii++) {
        item = occupyMenu->item(ii);
        if (item->command() == cmdOccupyAll)
            item->setCheck(client()->allWorkspaces() ? 1 : 0);
        else if (item->command() == cmdOccupyWorkspace) {
            item->setCheck(visibleOn((int)item->context()) ? 1 : 0);
            if (client()->allWorkspaces())
                item->disable();
            else
                item->enable();
        }
    }
}

#ifdef SHAPE
void YFrameWindow::setShape() {
    if (shapesSupported && client()->shaped()) {
        XShapeCombineShape (app->display(), handle(),
                            ShapeBounding,
                            borderX(),
                            borderY()
#ifndef TITLEBAR_BOTTOM
                                + wsTitleBar
#endif
                                ,
                            client()->handle(),
                            ShapeBounding, ShapeSet);
        if (titlebar()) {
            XRectangle rect;
            
            rect.x = borderX();
            rect.y = borderY();
            rect.width  = width() - 2 * borderX();
            rect.height = titlebar()->height();

            XShapeCombineRectangles(app->display(), handle(),
                                    ShapeBounding,
                                    0, 0, &rect, 1,
                                    ShapeUnion, Unsorted);
        }
        if (client()->mwmDecors() & MWM_DECOR_RESIZEH) {
            XRectangle rect[4];

            rect[0].x = 0;
            rect[0].y = 0;
            rect[0].width = width();
            rect[0].height = borderY();

            rect[1] = rect[0];
            rect[1].y = height() - borderY();

            rect[2].x = 0;
            rect[2].y = borderY();
            rect[2].width = borderX();
            rect[2].height = height() - 2 * borderY();

            rect[3] = rect[2];
            rect[3].x = width() - borderX();
            
            XShapeCombineRectangles(app->display(), handle(),
                                    ShapeBounding,
                                    0, 0, rect, 4,
                                    ShapeUnion, Unsorted);
        }
    }
}
#endif

void YFrameWindow::configure(int x, int y, unsigned int width, unsigned int height) {
    //int oldX = this->x();
    //int oldY= this->y();
#ifdef SHAPE
    unsigned int oldWidth = this->width();
    unsigned int oldHeight = this->height();
#endif
    
    YWindow::configure(x, y, width, height);

    layoutTitleBar();

    layoutButtons();

    layoutResizeIndicators();

    layoutClient();
    
    // ?
    //if (x != oldX ||
    //    y != oldY)
    sendConfigure();
    
#ifdef SHAPE
    if (width != oldWidth || height != oldHeight)
        setShape();
#endif
    
}

void YFrameWindow::layoutTitleBar() {

    if (titleY() == 0) {
        titlebar()->hide();
    } else {
        titlebar()->show();

        int title_width = width() - 2 * borderX();
        MSG(("configure titlebar: width = %d", title_width - 2));
        titlebar()->setGeometry(borderX(),
                                borderY()
#ifdef TITLEBAR_BOTTOM
                                + height() - titleY() - 2 * borderY()
#endif
                                ,
                                (title_width > 0) ? title_width : 1,
                                titleY());
    }
}

void YFrameWindow::layoutButtons() {
    if (titleY() == 0)
        return ;
    
    int title_width = width() - 2 * borderX();

    if (client()->mwmDecors() & MWM_DECOR_MINIMIZE)
        fMinimizeButton->show();
    else
        fMinimizeButton->hide();

    if (client()->mwmDecors() & MWM_DECOR_MAXIMIZE)
        fMaximizeButton->show();
    else
        fMaximizeButton->hide();

    if ((client()->mwmFunctions() & MWM_FUNC_CLOSE) && useXButton)
        fCloseButton->show();
    else
        fCloseButton->hide();

    if (client()->mwmDecors() & MWM_DECOR_MENU)
        fMenuButton->show();
    else
        fMenuButton->hide();

    int xPos = title_width;

    if (wmLook == lookWin95 || wmLook == lookNice) {
        fMenuButton->setGeometry(0, 0, wsTitleBar, wsTitleBar);

        if ((client()->mwmFunctions() & MWM_FUNC_CLOSE) && useXButton) {
            xPos -= titleY() + 1;
            fCloseButton->setGeometry(xPos, 2, titleY(), titleY() - 3);
            xPos -= 2;
        }


        if (client()->mwmDecors() & MWM_DECOR_MAXIMIZE) {
            xPos -= titleY();
            fMaximizeButton->setGeometry(xPos, 2, titleY(), titleY() - 3);
        }

        if (client()->mwmDecors() & MWM_DECOR_MINIMIZE) {
            xPos -= titleY();
            fMinimizeButton->setGeometry(xPos, 2, titleY(), titleY() - 3);
        }
    } else if (wmLook == lookMotif || wmLook == lookWarp3 || wmLook == lookWarp4) {
        fMenuButton->setGeometry(0, 0, wsTitleBar, wsTitleBar);
        
        if (client()->mwmDecors() & MWM_DECOR_MAXIMIZE) {
            xPos -= titleY();
            fMaximizeButton->setGeometry(xPos, 0, titleY(), titleY());
        }
        if (client()->mwmDecors() & MWM_DECOR_MINIMIZE) {
            xPos -= titleY();
            fMinimizeButton->setGeometry(xPos, 0, titleY(), titleY());
        }
        if ((client()->mwmFunctions() & MWM_FUNC_CLOSE) && useXButton) {
            xPos -= titleY();
            fCloseButton->setGeometry(xPos, 0, titleY(), titleY());
        }
    }
}

void YFrameWindow::layoutResizeIndicators() {
    if (client()->mwmDecors() & MWM_DECOR_RESIZEH) {
        if (!indicatorsVisible) {
            indicatorsVisible = 1;

            XMapRaised(app->display(), topSide);
            XMapRaised(app->display(), leftSide);
            XMapRaised(app->display(), rightSide);
            XMapRaised(app->display(), bottomSide);

            XMapRaised(app->display(), topLeftCorner);
            XMapRaised(app->display(), topRightCorner);
            XMapRaised(app->display(), bottomLeftCorner);
            XMapRaised(app->display(), bottomRightCorner);
        }
    } else {
        if (indicatorsVisible) {
            indicatorsVisible = 0;
            
            XUnmapWindow(app->display(), topSide);
            XUnmapWindow(app->display(), leftSide);
            XUnmapWindow(app->display(), rightSide);
            XUnmapWindow(app->display(), bottomSide);

            XUnmapWindow(app->display(), topLeftCorner);
            XUnmapWindow(app->display(), topRightCorner);
            XUnmapWindow(app->display(), bottomLeftCorner);
            XUnmapWindow(app->display(), bottomRightCorner);
        }
    }

    if (!indicatorsVisible)
        return ;
    
    XMoveResizeWindow(app->display(), topSide, 0, 0, width(), borderY());
    XMoveResizeWindow(app->display(), leftSide, 0, 0, borderX(), height());
    XMoveResizeWindow(app->display(), rightSide, width() - borderX(), 0, borderY(), height());
    XMoveResizeWindow(app->display(), bottomSide, 0, height() - borderY(), width(), borderY());
    
    XMoveResizeWindow(app->display(), topLeftCorner, 0, 0, wsCornerX, wsCornerY);
    XMoveResizeWindow(app->display(), topRightCorner, width() - wsCornerX, 0, wsCornerX, wsCornerY);
    XMoveResizeWindow(app->display(), bottomLeftCorner, 0, height() - wsCornerY, wsCornerX, wsCornerY);
    XMoveResizeWindow(app->display(), bottomRightCorner, width() - wsCornerX, height() - wsCornerY, wsCornerX, wsCornerY);
}

void YFrameWindow::layoutClient() {
    if (style & fsShaded) {
        fClientContainer->setGeometry(borderX(),
                                      borderY()
#ifndef TITLEBAR_BOTTOM
                                      + titleY()
#endif
                                      ,
                                      width() - 2 * borderX(),
                                      client()->height());

        fClient->setGeometry(0, 0,
                             width() - 2 * borderX(),
                             client()->height());
    } else {
        fClientContainer->setGeometry(borderX(),
                                      borderY()
#ifndef TITLEBAR_BOTTOM
                                      + titleY()
#endif
                                      ,
                                      width() - 2 * borderX(),
                                      height() - 2 * borderY() - titleY());
        fClient->setGeometry(0, 0,
                             width() - 2 * borderX(),
                             height() - 2 * borderY() - titleY());
    }
}

int YFrameWindow::canClose() {
    if (client()->mwmFunctions() & MWM_FUNC_CLOSE)
        return 1;
    else
        return 0;
}

int YFrameWindow::canMaximize() {
    if (client()->mwmFunctions() & MWM_FUNC_MAXIMIZE)
        return 1;
    else
        return 0;
}

int YFrameWindow::canMinimize() {
    if (client()->mwmFunctions() & MWM_FUNC_MINIMIZE)
        return 1;
    else
        return 0;
}

int YFrameWindow::canShade() {
    return canMinimize();
}

int YFrameWindow::canHide() {
    return canMinimize();
}

