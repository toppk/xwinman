// kpanel. Part of the KDE project.
//
// Copyright (C) 1996,97 Matthias Ettrich
//

#include "kpanel.h"
#include "kwmcom.h"
#include <qapp.h>
#include <qmsgbox.h>
#include <stdio.h>
#include <unistd.h>


class MyApp:public KApplication {
public:
  MyApp( int &argc, char **argv, const QString& rAppName );
  virtual bool x11EventFilter( XEvent * );
};

MyApp::MyApp(int &argc, char **argv , const QString& rAppName):
  KApplication(argc, argv, rAppName){
}


kPanel *the_panel;

bool MyApp::x11EventFilter( XEvent * ev){
//   printf("Qt: got one event %d for window %d\n", ev->type, ev->xany.window);
  if (ev->type == ClientMessage){
    the_panel->client_message(&ev->xclient);
  }
  
  return FALSE;
}



MyApp* the_app;
int o_argc;
char ** o_argv;

char*  icon_path =NULL;
char*  applications_path =NULL;
char*  personal_applications_path =NULL;
char*  personal_applications_path_name =NULL;

int _getprop(Window w, Atom a, Atom type, long len, unsigned char **p) {
  Atom real_type;
  int format;
  unsigned long n, extra;
  int status;

  status = XGetWindowProperty(qt_xdisplay(), w, a, 0L, len, False, type, &real_type, &format, &n, &extra, p);
  if (status != Success || *p == 0)
    return -1;
  if (n == 0)
    XFree((void*) *p);
  /* could check real_type, format, extra here... */
  return n;
}

char * getprop(Window w, Atom a) {
  unsigned char *p;

  if (_getprop(w, a, XA_STRING, 100L, &p) <= 0)
    return 0;
  return (char *)p;
 }


 


void restart_the_panel(){
  QApplication::exit();
  execvp(o_argv[0],  o_argv);
}


void kPanel::set_correct_popup_size(QPopupMenu* popup){
  popup->installEventFilter( this );
  //popup->setMouseTracking( TRUE );
  popup->move(-1000, -1000);
  popup->show();
  popup->hide();
}

void kPanel::show_popup(QPopupMenu* popup, QWidget* button){
  int xp;
  int yp;

  if (orientation == vertical){
    yp = button->y();
    if (position == top_left)
      xp = button->x() + button->width();
    else
      xp = button->x() - popup->width();
  }
  else {
    xp = button->x();
    if (position == top_left)
      yp = button->y() + button->height();
    else
      yp = button->y() - popup->height();
  }
  
  xp = xp + x();
  yp = yp + y();
  
  // QCursor::setPos(xp+5, yp+5);
  popup->popup(QPoint(xp, yp));
}



kPanel::kPanel( QWidget *parent, const char *name )
  : QFrame( parent, name,WStyle_Customize | WStyle_NoBorder | WStyle_Tool ){
    

    setFrameStyle(QFrame::Panel| QFrame::Raised);
    setMouseTracking( TRUE );
    
    orientation = horizontal;
    position = top_left;
    
    //     box_width = 40;
    //     box_height = 40;
    //     margin = 0;
    //     pm_scale_factor = 0.8;
    
    
    box_width = 52;
    box_height = 52;
    margin = 4;
    pm_scale_factor = 1;
    dbhs = 6;
    
    
    // parse the configuration
    KConfig *config = KApplication::getKApplication()->getConfig();
    config->setGroup("kpanel");
    QString a = config->readEntry("Position");
    
    if ( a == "left"){
      orientation = vertical;
      position = top_left;
    }
    else if ( a == "right"){
      orientation = vertical;
      position = bottom_right;
    }
    else if ( a == "top"){
      orientation = horizontal;
      position = top_left;
    }
    else if ( a == "bottom"){
      orientation = horizontal;
      position = bottom_right;
    }

    if (config->hasKey("BoxWidth"))
      box_width = config->readNumEntry("BoxWidth");
    if (config->hasKey("BoxHeight"))
      box_height = config->readNumEntry("BoxHeight");
    if (config->hasKey("Margin"))
      margin = config->readNumEntry("Margin");
    if (config->hasKey("IconScale")){
      pm_scale_factor = config->readEntry("IconScale").toFloat();
    }
    if (config->hasKey("DesktopButtonHorizontalSize"))
      dbhs = config->readNumEntry("DesktopButtonHorizontalSize");
    


    if (config->hasKey("MenuFont")){
      QFont tmpfont;
      tmpfont.setRawMode(TRUE);
      tmpfont.setFamily(config->readEntry("MenuFont"));
      KApplication::setFont(tmpfont);
    }
    

//   setBackgroundPixmap(load_pixmap("background.xpm"));
//   setBackgroundColor(backgroundColor().light(105));
    
    nbuttons = 0;
    moving_button = NULL;
    
    int tx, ty;

    menu_item_id = 0;

    applications_popup = new QPopupMenu;
    applications_popup->installEventFilter( this );
    add_application_popup = new QPopupMenu;
    add_application_popup->installEventFilter( this );

    openDir(applications_path, applications_popup, add_application_popup, NULL, FALSE);

    if (personal_applications_path){
      personal_applications_popup = new QPopupMenu;
      personal_applications_popup->installEventFilter( this );
    
      add_personal_application_popup = new QPopupMenu;
      add_personal_application_popup->installEventFilter( this );
    
      if (openDir(personal_applications_path, personal_applications_popup, 
		  add_personal_application_popup,personal_applications_path_name, TRUE)>0){
	applications_popup->insertSeparator();
	applications_popup->insertItem(personal_applications_path_name,
				       personal_applications_popup);
	add_application_popup->insertSeparator();
	add_application_popup->insertItem(personal_applications_path_name,
					  add_personal_application_popup);
      }
    }

    popup_position = new QPopupMenu;
    CHECK_PTR( popup_position);
    popup_position->insertItem("Top");
    popup_position->insertItem("Left");
    popup_position->insertItem("Bottom (Do not use!)");
    popup_position->insertItem("Right (Do not use!)");
    set_correct_popup_size(popup_position);

    connect( popup_position, SIGNAL(activated( int )), 
	     SLOT(popup_position_activated(int)) );


    special_popup = new QPopupMenu;
    CHECK_PTR( special_popup);
    special_popup->insertItem("Windowlist");
    set_correct_popup_size(special_popup);
    connect( special_popup, SIGNAL(activated( int )), 
	     SLOT(popup_special_activated(int)) );



    popup_panel = new QPopupMenu;
    CHECK_PTR( popup_panel);
    popup_panel->insertItem("Add application", add_application_popup);
    popup_panel->insertItem("Add special", special_popup);
    popup_panel->insertItem("Location", popup_position);
    popup_panel->insertItem("Configure", this,SLOT(configure_panel()));
    popup_panel->insertItem("Restart", this, SLOT(restart()));
    set_correct_popup_size(popup_panel);


    popup_item = new QPopupMenu;
    CHECK_PTR( popup_item);
    popup_item->insertItem("Move");
    popup_item->insertItem("Remove");
    popup_item->insertSeparator();
    popup_item->insertItem("Properties");
    set_correct_popup_size(popup_item);

    connect( popup_item, SIGNAL(activated( int )), 
	     SLOT(popup_item_activated(int)) );



    //     tmp_kde = new QPopupMenu;
    //     CHECK_PTR( tmp_kde );

    tmp_kde = applications_popup;

//     tmp_kde->insertItem( "Start", applications_popup);
    tmp_kde->insertSeparator();
    tmp_kde->insertItem( "Help", this, SLOT(call_help()));
    tmp_kde->insertItem( "Home", this, SLOT(call_home()));
    tmp_kde->insertItem( "Trashcan", this, SLOT(call_trash()));
    tmp_kde->insertItem( "Panel", popup_panel);
    tmp_kde->insertSeparator();
    tmp_kde->insertItem( "Lock screen", this, SLOT(call_klock()) );
    tmp_kde->insertItem( "Logout", this, SLOT(ask_logout()) );
    set_correct_popup_size(tmp_kde);

    tmp_windows = new QPopupMenu;
    CHECK_PTR( tmp_windows );
    connect( tmp_windows, SIGNAL(activated( int )), 
	     SLOT(windowlist_activated(int)) );
    set_correct_popup_size(tmp_windows);

    QPushButton* tmp_push_button;
    QButton* tmp_button;
    int i;
    int w = QApplication::desktop()->width();
    int h = QApplication::desktop()->height();


    label_date = new QLabel(this);
    if (config->hasKey("DateFont")){
      QFont tmpfont;
      tmpfont.setRawMode(TRUE);
      tmpfont.setFamily(config->readEntry("DateFont"));
      label_date->setFont(tmpfont);
    }
    set_label_date();

    
    entries[nbuttons++].button=tmp_push_button = new QPushButton( "KDE", this);
    entries[nbuttons-1].button->installEventFilter( this );
    connect( entries[nbuttons-1].button, SIGNAL(clicked()), 
	     SLOT(button_clicked()) );
    connect( entries[nbuttons-1].button, SIGNAL(pressed()), 
	     SLOT(button_pressed()) );
    entries[nbuttons-1].popup = applications_popup;
    tmp_kde_button = entries[nbuttons-1].button;
    tmp_push_button->setPixmap(create_arrow_pixmap(load_pixmap("wheels.xpm"), 
						   tmp_push_button->backgroundColor()));


    // The control group
    control_group = new QFrame( this);
    control_group->setBackgroundColor(backgroundColor());
    control_group->installEventFilter( this );

    desktopbar = new QButtonGroup(control_group);
    CHECK_PTR( desktopbar );
    desktopbar->setFrameStyle(QFrame::NoFrame);
    desktopbar->setExclusive(TRUE);
    desktopbar->setBackgroundColor(backgroundColor());
    desktopbar->installEventFilter( this );


    //     QColorGroup motif_nor( black, lightGray,
    // 			   white, lightGray.dark(), gray,
    // 			   black, white );

//     QColor col = backgroundColor().light(96);
//     QColorGroup colgrp = QColorGroup( black, col, white, col.dark(), col.dark(120),
// 				      black, white );
//     QPalette pal = QPalette(colgrp,colgrp,colgrp);

    
    tmp_push_button = new QPushButton("One", desktopbar);
    tmp_push_button->setToggleButton(TRUE);
    tmp_push_button->installEventFilter( this );
    tmp_push_button->toggle();
    connect(tmp_push_button, SIGNAL(clicked()), SLOT(desktop1()));
    if (config->hasKey("Desktop1"))
      tmp_push_button->setText(config->readEntry("Desktop1"));
    //     tmp_push_button->setPalette(pal);

    tmp_push_button = new QPushButton("Two", desktopbar);
    tmp_push_button->installEventFilter( this );
    tmp_push_button->setToggleButton(TRUE);
    connect(tmp_push_button, SIGNAL(clicked()), SLOT(desktop2()));
    if (config->hasKey("Desktop2"))
      tmp_push_button->setText(config->readEntry("Desktop2"));
    //     tmp_push_button->setPalette(pal);
  
    tmp_push_button = new QPushButton("Three", desktopbar);
    tmp_push_button->installEventFilter( this );
    tmp_push_button->setToggleButton(TRUE);
    connect(tmp_push_button, SIGNAL(clicked()), SLOT(desktop3()));
    if (config->hasKey("Desktop3"))
      tmp_push_button->setText(config->readEntry("Desktop3"));
    //     tmp_push_button->setPalette(pal);
   
    tmp_push_button = new QPushButton("Four", desktopbar);
    tmp_push_button->installEventFilter( this );
    tmp_push_button->setToggleButton(TRUE);
    connect(tmp_push_button, SIGNAL(clicked()), SLOT(desktop4()));
    if (config->hasKey("Desktop4"))
      tmp_push_button->setText(config->readEntry("Desktop4"));
    //     tmp_push_button->setPalette(pal);

    if (config->hasKey("DesktopButtonFont")){
      QFont tmpfont;
      tmpfont.setRawMode(TRUE);
      tmpfont.setFamily(config->readEntry("DesktopButtonFont"));
      for (i=0; (tmp_button = desktopbar->find(i)); i++){
	tmp_button->setFont(tmpfont);
      }
    }

    exit_button = new QPushButton("Exit", control_group);
    connect(exit_button, SIGNAL(clicked()), SLOT(ask_logout()));
    exit_button->installEventFilter( this );
    //     exit_button->setPalette(pal);
    exit_button->setPixmap(load_pixmap("exit.xpm"));
    
    lock_button = new QPushButton("lock", control_group);
    connect(lock_button, SIGNAL(clicked()), SLOT(call_klock()));
    lock_button->installEventFilter( this );
    //     lock_button->setPalette(pal);
    lock_button->setPixmap(load_pixmap("key.xpm"));
    

    panel_button = new QPushButton("panel", this);
    panel_button->setPixmap(load_pixmap("panel.xpm"));
    if (orientation == vertical){
      QWMatrix m;
      m.rotate(90);
      panel_button->setPixmap(panel_button->pixmap()->xForm(m));
	
    }

    connect( panel_button, SIGNAL(clicked()), 
	     SLOT(call_help()) );


    if (orientation == horizontal){
      
      exit_button->setGeometry(0,0,
			       box_width/2 - margin/4,
			       box_height/2 - margin/4
			       );

      lock_button->setGeometry(0,
			       box_height - exit_button->height(),
			       exit_button->width(),
			       exit_button->height());
      
      for (i=0; (tmp_button = desktopbar->find(i)); i++){
	switch (i){
	case 0:
	  tmp_button->setGeometry(0, 0,
				  exit_button->width() * dbhs, 
				  exit_button->height());
	  break;
	case 1:
	  tmp_button->setGeometry(exit_button->width() * dbhs + margin/3, 0, 
				  exit_button->width() * dbhs, 
				  exit_button->height());
	  break;
	case 2:
	  tmp_button->setGeometry(0, 
				  lock_button->y(),
				  exit_button->width() * dbhs, 
				  exit_button->height());
	  break;
	case 3:    
	  tmp_button->setGeometry(exit_button->width() * dbhs + margin/3,
				  lock_button->y(),
				  exit_button->width() * dbhs, 
				  exit_button->height());
	  break;
	}
      }


      desktopbar->setGeometry(exit_button->width() + margin*2/3,
			      0, 
			      exit_button->width() * dbhs * 2 + margin/3, 
			      box_height);

      control_group->setGeometry(w/2 - (exit_button->width() + margin*2/3 + desktopbar->width())/2,
				 margin,
				 exit_button->width() + margin*2/3 + desktopbar->width(),
				 box_height);

      panel_button->setGeometry(margin,
				margin,
				(box_width-(margin/2))/2,
				box_height);
      
      tmp_kde_button->setGeometry(panel_button->x()+panel_button->width(),
				  margin,
				  box_width, box_height);
      
      bound_top_left = control_group->x();
      bound_bottom_right = control_group->x() + control_group->width();

      label_date->setGeometry(w - margin - 2*box_width - 3,
			      3,
			      2*box_width-6, 
			      box_height+2*margin-6);
      label_date->setAlignment( AlignRight|AlignVCenter );
      
      
      ty = margin;
	
      tx = 5+24+12;
      for (i=0; i < nbuttons; i++){
	switch (i){
	case 3:
	  tx = w - 2*box_width - box_width/2;
	  break;
	case 6:
	  tx = w - box_width-3;
	  break;
	}
	entries[i].button->setGeometry(tx, ty, box_width, box_height);
	tx += box_width;
	
      }
      

      if (position == top_left){
	setGeometry(0,
		    0, 
		    w, 
		    box_height+2*margin);
      }
      else{
	setGeometry(0,
		    h - box_height-2*margin, 
		    w, 
		    box_height+2*margin);
      }
    }
    else { // orientation == vertical
      

      exit_button->setGeometry(0,0,
			       box_width/2 - margin/4,
			       box_height/2 - margin/4
			       );

      lock_button->setGeometry(box_width-exit_button->width(),
			       0,
			       exit_button->width(),
			       exit_button->height());

      for (i=0; (tmp_button = desktopbar->find(i)); i++){
	tmp_button->setGeometry(0,i*box_height/2, 
				box_width, box_height/2);
      }

      desktopbar->setGeometry(0,
			      exit_button->height() + margin*2/3,
			      box_width,
			      2*box_height);

      control_group->setGeometry(margin,
				 h/2 - (exit_button->height() + margin*2/3 + desktopbar->height())/2,
				 box_width,
				 exit_button->height() + margin*2/3 + desktopbar->height());

      panel_button->setGeometry(margin,
				margin,
				box_width,
				(box_height-(margin/2))/2);
      tmp_kde_button->setGeometry(margin,
				  panel_button->y()+panel_button->height(),
				  box_width, box_height);
     

      bound_top_left = control_group->y();
      bound_bottom_right = control_group->y() + control_group->height();


      label_date->setGeometry(3,
			      h - margin - 3-box_height,
			      box_width+2*margin-6, 
			      box_height);

      label_date->setAlignment( AlignHCenter|AlignBottom);


      tx = margin;
      ty = panel_button->y()+panel_button->height();
      for (i=0; i < nbuttons; i++){
	switch (i){
	case 2:
	  ty = h/4;
	  break;
	case 3:
	  ty = h - 4*box_height - box_height/2;
	  break;
	case 6:
	  ty = h - box_height;
	  break;
	}
	entries[i].button->setGeometry(tx, ty, box_width, box_height);
	ty += box_height;
      }

      if (position == top_left){
	setGeometry(0,
		    0, 
		    box_width+2*margin, 
		    h);
      }
      else{
	setGeometry(w - box_width - 2*margin,
		    0,
		    box_width+2*margin, 
		    h);
      }
    }

    read_in_configuration();

    startTimer( 60000 );

    // set up communication to kwm 
    kwmcom_init(qt_xdisplay(), winId());
    kwmcom_send_to_kwm(kwm_register_module);

}

void  kPanel::timerEvent( QTimerEvent * ){
  set_label_date();
}


void kPanel::set_label_date(){
  QDateTime d = QDateTime::currentDateTime();
  QString s;
  s.sprintf(" %.2d:%.2d \n %s %d ",
	    d.time().hour(),
	    d.time().minute(),
// 	    d.date().dayName(d.date().dayOfWeek()),
	    d.date().monthName(d.date().month()),
	    d.date().day());
  
  //   s = d.time().toString() + "\n" +d.date().toString();
  label_date->setText(s);
}


void kPanel::restart(){
  // write all the options back and restart.
  kwmcom_send_to_kwm(kwm_unregister_module);
  KApplication::getKApplication()->getConfig()->sync();
  restart_the_panel();
}

void kPanel::desktop1(){
  kwmcom_send_to_kwm(kwm_command, "desktop1");
}
void kPanel::desktop2(){
  kwmcom_send_to_kwm(kwm_command, "desktop2");
}
void kPanel::desktop3(){
  kwmcom_send_to_kwm(kwm_command, "desktop3");
}
void kPanel::desktop4(){
  kwmcom_send_to_kwm(kwm_command, "desktop4");
}



QPixmap kPanel::create_arrow_pixmap(QPixmap pm, QColor bg){
  //QColor col(151, 168, 185);
  //  QColor col = bg.light(70);
  QColor col = bg;
  QColorGroup colgrp = QColorGroup( black, col, col.light(), col.dark(), col.dark(120),
				    black, white );
  QPalette pal = QPalette(colgrp,colgrp,colgrp);


  QPixmap pm2 = QPixmap(box_width, box_height);
  QPainter p;
  pm2.fill( bg );
  p.begin( &pm2 ); 
  p.drawPixmap( (pm2.width()-pm.width())/2, 
		(pm2.height()-pm.height())/2, 
		pm, 0, 0, pm.width(), pm.height());
  
  if (orientation == horizontal){
    if (position == top_left)
      qDrawArrow( &p, DownArrow, MotifStyle, FALSE,
		  box_width*4/5-2, box_height*4/5-2, box_width/5, box_height/5, colgrp);
    else
      qDrawArrow( &p, UpArrow, MotifStyle, FALSE,
		  box_width*4/5-2, 2, box_width/5, box_height/5, colgrp);
  }
  else{ // position == vertical
    if (position == top_left)
      qDrawArrow( &p, RightArrow, MotifStyle, FALSE,
		  box_width*4/5-2, box_height*4/5-2, box_width/5, box_height/5, colgrp);
    else
      qDrawArrow( &p, LeftArrow, MotifStyle, FALSE,
		  2, box_height*4/5-2, box_width/5, box_height/5, colgrp);
  }
  
  p.end();
  return pm2;
}

void kPanel::reposition(){
  int i,i2,d;

  // brain dead. Don't ask me why I don't use a list, plase....

  DesktopEntry tmp;
  bool changed = FALSE;
  // the KDE-button has a fix position
  // tmp_kde_button->move(0,0);
  do {
    changed = FALSE;
    for (i=1; i<nbuttons-1; i++){
      if ((orientation == vertical && entries[i].button->y() > entries[i+1].button->y())
	  || (orientation == horizontal && entries[i].button->x() > entries[i+1].button->x())){
	tmp = entries[i];
	entries[i] = entries[i+1];
	entries[i+1] = tmp;
	changed = TRUE;
      }
    }
  } while (changed);

  // the first button is always the KDE button
  if (orientation == vertical){
    if (nbuttons > 1 && entries[0].button->y() > entries[1].button->y())
      entries[0].button->move(entries[0].button->x(), 
			      entries[1].button->y()-entries[0].button->height());
    if (entries[0].button->y()<panel_button->y() + panel_button->height()) 
	  entries[0].button->move(entries[0].button->x(),
				  panel_button->y() + panel_button->height());
  }
  else{
    if (nbuttons > 1 && entries[0].button->x() > entries[1].button->x())
      entries[0].button->move(entries[1].button->x() - entries[0].button->width(), 
			      entries[0].button->y()); 
    if (entries[0].button->x()<panel_button->x() + panel_button->width()) 
	  entries[0].button->move(panel_button->x() + panel_button->width(),
				  entries[0].button->y());
  }


  if (orientation == vertical){
    for (i=0; i<nbuttons-1; i++){
      d = entries[i].button->y() + entries[i].button->height() - entries[i+1].button->y();
      if (d>0){
	for (i2=i+1; 
	     i2<nbuttons && 
	       entries[i2].button->y() < entries[i2-1].button->y() +entries[i2-1].button->height(); 
	     i2++){
	  entries[i2].button->move(entries[i2].button->x(), entries[i2].button->y() + d);
	  if (entries[i2].button->y() > bound_top_left - entries[i2].button->height()&&
	      entries[i2].button->y() < bound_bottom_right
	      && height() - bound_bottom_right > entries[i2].button->height()
	      )
	    entries[i2].button->move(entries[i2].button->x(), bound_bottom_right);
	}
      } 
    }
    
    d = entries[nbuttons-1].button->y() + entries[nbuttons-1].button->height() - height();
    if (entries[nbuttons-1].button->y() < bound_bottom_right &&
	entries[nbuttons-1].button->y() + entries[nbuttons-1].button->height() > bound_top_left)
      d = entries[nbuttons-1].button->y() + entries[nbuttons-1].button->height() - bound_top_left;
    if ( d > 0) {
      entries[nbuttons-1].button->move(entries[nbuttons-1].button->x(), 
				entries[nbuttons-1].button->y() - d);
      for (i=nbuttons-2; 
	   i>=0 &&
	     entries[i].button->y() + entries[i].button->height() > entries[i+1].button->y(); 
	   i--){
	entries[i].button->move(entries[i].button->x(), entries[i].button->y() - d);
	if (entries[i].button->y() > bound_top_left - entries[i].button->height()&&
	    entries[i].button->y() < bound_bottom_right)
	  entries[i].button->move(entries[i].button->x(), bound_top_left - entries[i].button->height());
      }
      reposition();
    }
  }
  else { // orientation == horizontal
 
    for (i=0; i<nbuttons-1; i++){
      d = entries[i].button->x() + entries[i].button->width() - entries[i+1].button->x();
      if (d>0){
	for (i2=i+1; 
	     i2<nbuttons && 
	       entries[i2].button->x() < entries[i2-1].button->x() +entries[i2-1].button->width(); 
	     i2++){
	  entries[i2].button->move(entries[i2].button->x() + d, entries[i2].button->y());
	  if (entries[i2].button->x() > bound_top_left - entries[i2].button->width()&&
	      entries[i2].button->x() < bound_bottom_right
	      && width() - bound_bottom_right > entries[i2].button->width()
	      )
	    entries[i2].button->move(bound_bottom_right, entries[i2].button->y());
	}
      } 
    }
    
    d = entries[nbuttons-1].button->x() + entries[nbuttons-1].button->width() - width();
    if (entries[nbuttons-1].button->x() < bound_bottom_right &&
	entries[nbuttons-1].button->x() + entries[nbuttons-1].button->width() > bound_top_left)
      d = entries[nbuttons-1].button->x() + entries[nbuttons-1].button->width() - bound_top_left;
    if ( d > 0) {
      entries[nbuttons-1].button->move(entries[nbuttons-1].button->x() - d, 
				entries[nbuttons-1].button->y());
      for (i=nbuttons-2; 
	   i>=0 &&
	     entries[i].button->x() + entries[i].button->width() > entries[i+1].button->x(); 
	   i--){
	entries[i].button->move(entries[i].button->x() - d, entries[i].button->y());
	if (entries[i].button->x() > bound_top_left - entries[i].button->width()&&
	    entries[i].button->x() < bound_bottom_right)
	  entries[i].button->move(bound_top_left - entries[i].button->width(), entries[i].button->y());
      }
      reposition();
    }
  }
}



void kPanel::open()
{
}


void kPanel::close()
{
}


void kPanel::undo()
{
}


void kPanel::redo()
{
}


void kPanel::about()
{
}


void kPanel::resizeEvent( QResizeEvent * )
{
  //  setGeometry(0,0,QApplication::desktop()->width(), menu->height());

}


void kPanel::mousePressEvent( QMouseEvent */* ev */  ){

}



void kPanel::ask_logout(){
  if (
      QMessageBox::query("Logout?", 
			 "Do you really want to exit the KDE?", 
			 "Logout", "Cancel")
      ){
    kwmcom_send_to_kwm(kwm_unregister_module);
    KApplication::getKApplication()->getConfig()->sync();
    QApplication::exit();
    kwmcom_send_to_kwm(kwm_command, "exit");
  }
}





void kPanel::call_klock(){
  QMessageBox::message( "Hi!", "This will invoke the fabulous KLOCK (xlock replacement)");
}

void kPanel::call_help(){
    QMessageBox::message( "Hi!", "This will invoke the KDE Help system with the\n KDE Startup Screen." );
}

void kPanel::call_home(){
  system("kfmclient openURL \"file:$HOME\"");
}

void kPanel::call_trash(){
  system("kfmclient openURL \"file:$HOME/Trash\"");
}



void kPanel::read_in_configuration(){

  KConfig *config = KApplication::getKApplication()->getConfig();
  config->setGroup("kpanelButtons");
  
  QListIterator <ListItem> it(apps);
  ListItem* li;
  bool found = FALSE;
  
    // now parse the buttons

  int control = 1;
  int controldelta = -1;
  
  if (config->hasKey("control"))
    control = config->readEntry("control").toInt();

  if (config->hasKey("controldelta"))
    controldelta = config->readEntry("controldelta").toInt();
  
  if (controldelta >= 0){
    bound_top_left = 0;
    bound_bottom_right = 0;
  }

  
  QString button_entry;
  QString button_entry_value;

  int x;
  int y;
  int real_space;
  if (orientation == vertical){
    real_space = height() - bound_bottom_right + bound_top_left 
      - panel_button->y() - panel_button->height();
    x = margin; y = panel_button->y() + panel_button->height();
  }
  else{
    real_space = width() - bound_bottom_right + bound_top_left 
      - panel_button->x() - panel_button->width();
    y = margin; x = panel_button->x() + panel_button->width();
  }
  
  int num = -1;
  int delta = 0;
    
  

  while (num < 0 ||
	 (config->hasKey(button_entry) && config->readEntry(button_entry) != "end")){

    if (num>=0){
      button_entry_value = config->readEntry(button_entry);
      button_entry.setNum(num); 
      button_entry.insert(0, "delta");
      delta = config->readEntry(button_entry).toInt();
      
      if (num == 0){
	// the unremovable tmp_kde_button!
	if (orientation == horizontal){
	  tmp_kde_button->move(x + delta * real_space / 10000 , y);
	  x = tmp_kde_button->x() + tmp_kde_button->width();
	}
	else {
	  tmp_kde_button->move(x, y + delta * real_space / 10000);
	  y = tmp_kde_button->y() + tmp_kde_button->height();
	}
      }
      else {
	it.toFirst();
	while ( (li = it.current()) != 0L ){
	  if (button_entry_value.left(1) == "~")
	    found = (li->personal_flag) &&
	      (li->path.right(li->path.length()
			      - qstrlen(personal_applications_path))
	       == button_entry_value);
	  else
	    found = li->path.right(li->path.length()
				   - qstrlen(applications_path))
	      == button_entry_value;
	  if (found) break;
	  ++it;
	}
	if (found){
	  if (orientation == horizontal)
	    x += delta * real_space / 10000;
	  else 
	    y +=delta * real_space / 10000;
	}
	else {// maybe a special
	  li = NULL;
	}
	if (add_button(li, x, y, button_entry_value)){
	  if (orientation == horizontal)
	    x = entries[nbuttons-1].button->x()+entries[nbuttons-1].button->width();
	  else 
	    y = entries[nbuttons-1].button->y()+entries[nbuttons-1].button->height();
	}
      }
    }
    
    if (num >= control && controldelta>=0){
      if (orientation == horizontal){
	control_group->move(x + controldelta * real_space / 10000, y);
	if (control_group->x() + control_group->width() > width())
	  control_group->move(width() - control_group->width(), y);
	bound_top_left = control_group->x();
	bound_bottom_right = control_group->x() + control_group->width();
	x = bound_bottom_right;
      }
      else {
	control_group->move(x, y  + controldelta * real_space / 10000);
	if (control_group->y() + control_group->height() > height())
	  control_group->move(x, height() - control_group->height());
	bound_top_left = control_group->y();
	bound_bottom_right = control_group->y() + control_group->height();
	y = bound_bottom_right;
      }
      controldelta = -1;
    }


    num++;
    button_entry.setNum(num);
    button_entry.insert(0, "button");
  }
  
}


void kPanel::write_out_configuration(){
  int i;
  QPushButton* tmp_push_button;
  KConfig *config = KApplication::getKApplication()->getConfig();
  config->setGroup("kpanelButtons"); 
  QString s;
  QString b;
  int delta;
  int delta2;
  int left_side;
  int real_space;

  if (orientation == vertical)
    real_space = height() - bound_bottom_right + bound_top_left 
      - panel_button->y() - panel_button->height();
  else
    real_space = width() - bound_bottom_right + bound_top_left 
      - panel_button->x() - panel_button->width();

  ListItem* li = NULL;
  for (i=0; i<nbuttons;i++){
    s = "dummy";
    if (entries[i].app_id >= 1000){
      li = apps.at(entries[i].app_id - 1000);
      if (li){
	if (li->personal_flag)
	  s = QString("~")+ li->path.right(li->path.length()
					   - qstrlen(personal_applications_path));
	else
	  s = li->path.right(li->path.length()
			     - qstrlen(applications_path));
      }
    }
    else {
      // the special
      if (i==0)
	s="KDE";
      else	if (entries[i].popup == tmp_windows)
	s="Windowlist";
    }
    b.setNum(i);
    b.insert(0, "button");
    config->writeEntry(qstrdup(b.data()), qstrdup(s.data()));

    if (i>0)
      tmp_push_button = entries[i-1].button;
    else
      tmp_push_button = panel_button;
      
    if (orientation == vertical){
      delta = entries[i].button->y() - tmp_push_button->y() - tmp_push_button->height();
      left_side = entries[i].button->y() - bound_bottom_right;
    }
    else{
      delta = entries[i].button->x() - tmp_push_button->x() - tmp_push_button->width();
      left_side = entries[i].button->x() - bound_bottom_right;
    }

    if ((left_side >= 0 && left_side < delta) || (left_side < 0 && i == nbuttons-1)){
      if (left_side >= 0){
	delta = left_side;
	s.setNum(i-1);
      }
      else{
	// there is no button on the right of the control_group,
	// that means "i" is the lastbutton that is on the left
	tmp_push_button = entries[i].button;
	s.setNum(i);
      }
      b = "control";
      config->writeEntry(qstrdup(b.data()), qstrdup(s.data()));
      b="controldelta";
      if (orientation == vertical)
	delta2 =bound_top_left - tmp_push_button->y() - tmp_push_button->height();
      else
	delta2 = bound_top_left - tmp_push_button->x() - tmp_push_button->width();
      s.setNum(delta2*10000/real_space);
      config->writeEntry(qstrdup(b.data()), qstrdup(s.data()));
    }

    b.setNum(i);
    b.insert(0, "delta");
    s.setNum(delta*10000/real_space);
    config->writeEntry(qstrdup(b.data()), qstrdup(s.data()));

  }

  b.setNum(i);
  b.insert(0, "button");
  config->writeEntry(qstrdup(b.data()), "end");
};



void kPanel::configure_panel(){
  QMessageBox::message( "Hi!", "Not yet implemented!\n This will show a nice dialog window that allows you to set\n all kpanel attributes graphically. \nYet you have to edit your .kderc manually and then restart the panel....\n Will come the very next release!" );
}


void kPanel::button_clicked(){
  
  int i;
  QWidget* ob = active_button;
  for (i=0; i<nbuttons && entries[i].button != ob;i++);
  if (i<nbuttons){
    if (entries[i].popup){
//       show_popup(entries[i].popup, entries[i].button);
    }
    else {
      if (entries[i].app_id >= 1000 && 
	  apps.at(entries[i].app_id-1000) && !apps.at(entries[i].app_id-1000)->is_directory)
	execute_kde_desktop_entry(apps.at(entries[i].app_id-1000)->path);
    }
  }
}

void kPanel::button_pressed(){
  
  int i;
  QWidget* ob = active_button;
  for (i=0; i<nbuttons && entries[i].button != ob;i++);
  if (i<nbuttons){
    if (entries[i].popup){
      show_popup(entries[i].popup, entries[i].button);
    }
    else {
    }
  }
}

void kPanel::windowlist_activated(int item){
  kwmcom_send_to_kwm(kwm_un_minimize_window, item);
}


void kPanel::popup_position_activated(int item){
  KConfig *config = KApplication::getKApplication()->getConfig();
  config->setGroup("kpanel");
  switch (item){
  case 0: // top
    config->writeEntry("Position", "top");
    break;
  case 1:// left
    config->writeEntry("Position", "left");
    break;
  case 2:// bottom
    config->writeEntry("Position", "bottom");
    break;
  case 3: // right
    config->writeEntry("Position", "right");
    break;
  }
  restart();
}

void kPanel::popup_item_activated(int item){
  int i;
  switch (item){
  case 3:  {//properties
    for (i=0; i<nbuttons && entries[i].button!=button_to_be_modified; i++);
    if (i<nbuttons && button_to_be_modified){
      if (entries[i].app_id >= 1000 && 
	  apps.at(entries[i].app_id-1000)){
	QString s = "kfmclient openProperties \"file:";
	s.append(apps.at(entries[i].app_id-1000)->path);
	if (apps.at(entries[i].app_id-1000)->is_directory)
	  s.append("/.directory");
	s.append("\"");
	system(s);
      }
    }
  }
  break;
  case 0: //move
    moving_button = button_to_be_modified;
    moving_button_offset = QPoint(moving_button->width()/2,
				  moving_button->height()/2);
    moving_button->raise();
    moving_button->setCursor(sizeAllCursor);
    moving_button->grabMouse();
    break;
  case 1: // remove
    {
      for (i=0; i<nbuttons && entries[i].button!=button_to_be_modified; i++);
      if (i<nbuttons && button_to_be_modified){
	nbuttons--;
	for (;i<nbuttons;i++)
	  entries[i] = entries[i+1];
	delete button_to_be_modified;
	if (tmp_kde_button == button_to_be_modified)
	  tmp_kde_button = NULL;
	button_to_be_modified = NULL;
      }
    }
      
    break;
  }
}

void kPanel::menu_item_activated(int item){
      if (item >= 1000 &&
	  apps.at(item-1000) && !apps.at(item-1000)->is_directory)
	execute_kde_desktop_entry(apps.at(item-1000)->path);
}



void kPanel::popup_special_activated(int item){
  switch (item){
  case 0: 
    add_button(NULL, -1, -1, "Windowlist");
    break;
  }
}

bool kPanel::add_button(ListItem* li, int x, int y, QString name){
  QPixmap pm;
  entries[nbuttons++].button=new QPushButton( "Button", this ); 
  entries[nbuttons-1].button->installEventFilter( this );
  connect( entries[nbuttons-1].button, SIGNAL(clicked()), 
	   SLOT(button_clicked()) );
  connect( entries[nbuttons-1].button, SIGNAL(pressed()), 
	   SLOT(button_pressed()) );

  if (li)
    entries[nbuttons-1].app_id = apps.find(li)+1000;
  
  if (x != -1)
    entries[nbuttons-1].button->setGeometry(x, y, 
					    box_width, box_height);
  else
    find_a_free_place();
  
  if (!li){
    // maybe a special?
    if (name == "Windowlist"){
      pm = load_pixmap("tv.xpm"); 
      pm = create_arrow_pixmap(pm, entries[nbuttons-1].button->backgroundColor());
      entries[nbuttons-1].popup = tmp_windows;
    }
    else {
      //nothing found. Remove the weird button!
      printf("ERROR: Don't know what to do with button '%s'\n",
	     name.data());
      delete entries[nbuttons-1].button;
      nbuttons--;
      return FALSE;
    }
  }
  else if (!li->is_directory){
    
    QFile*  myfile = new QFile(li->path);
    if (myfile->exists()){
      myfile->open ( IO_ReadOnly );
      KTextStream* mystream = new KTextStream(myfile);
      KConfig *pConfig = new KConfig( mystream );
      pConfig->setGroup("KDE Desktop Entry");
      QString aString;
      aString = pConfig->readEntry("Icon");
      pm = load_pixmap(aString.data());
      delete pConfig;
      delete mystream;
    }
    delete myfile;
    entries[nbuttons-1].popup = NULL;
  }
  else {
    QString ts = li->path;
    ts = ts + "/.directory";
    QFile*  myfile = new QFile(ts.data());
    if (myfile->exists()){
      myfile->open ( IO_ReadOnly );
      KTextStream* mystream = new KTextStream(myfile);
      KConfig *pConfig = new KConfig( mystream );
      pConfig->setGroup("KDE Desktop Entry");
      QString aString;
      aString = pConfig->readEntry("icon");
      pm = load_pixmap(aString.data());
      delete pConfig;
      delete mystream;
    }
    else {
      pm = load_pixmap("folder.xpm");
    }
    delete myfile;
    
    
    pm = create_arrow_pixmap(pm, entries[nbuttons-1].button->backgroundColor());
    QPopupMenu* new_popup = new QPopupMenu;
    openDir(li->path, new_popup, NULL, NULL, li->personal_flag);
    set_correct_popup_size(new_popup);
    entries[nbuttons-1].popup = new_popup;
  }
  entries[nbuttons-1].button->setPixmap(pm);
  entries[nbuttons-1].button->show();
  check_button_bounds(entries[nbuttons-1].button);
  reposition();
  return True;
}

void kPanel::add_menu_item_activated(int item){
  if (item <= 1000 || !apps.at(item-1000))
    return;

  add_button(apps.at(item-1000));
  write_out_configuration();
}


void kPanel::find_a_free_place(){
  int i;
  if (orientation == vertical)
    entries[nbuttons-1].button->setGeometry(margin, 
					    entries[nbuttons-2].button->y() 
					    +entries[nbuttons-2].button->height(),
					    box_width, box_height);
  else
    entries[nbuttons-1].button->setGeometry(
					    entries[nbuttons-2].button->x() 
					    +entries[nbuttons-2].button->width(),
					    margin,
					    box_width, box_height);

  // find a free place.
  for (i=1; i<nbuttons-1; i++){
    if (orientation == vertical){
      if (entries[i-1].button->y()+box_height <= entries[i].button->y()-box_height){
	entries[nbuttons-1].button->setGeometry(margin,
						entries[i-1].button->y()+box_height,
						box_width, box_height);
	return;
      }
    }
    else{   // orientation == horizontal
      if (entries[i-1].button->x()+box_width <= entries[i].button->x()-box_width){
	entries[nbuttons-1].button->setGeometry(entries[i-1].button->x()+box_width,
						margin, 
						box_width, box_height);
	return;
      }
    }
  }
}


bool kPanel::eventFilter(QObject *ob, QEvent *ev){
  int i;
//    printf("event %d \n", ev->type());
  switch (ev->type()){
  case Event_MouseButtonPress: case Event_MouseButtonDblClick: {
    QMouseEvent* mev = (QMouseEvent*)ev;
    if (moving_button){
      // disable the button that is moved around
      active_button = NULL;
      break;
    }
    if ((mev->button()==MidButton || mev->button()==RightButton)){
      if (ob->isWidgetType() && !((QWidget*)ob)->isPopup()){
	moving_button = (QWidget*)ob;
	moving_button_offset = moving_button->mapToGlobal(mev->pos());
	if (moving_button->parentWidget() == desktopbar ||
	    moving_button->parentWidget() == control_group)
	  moving_button = control_group;
	
	position_of_new_item = moving_button->pos();
	moving_button_offset = moving_button->mapFromGlobal(moving_button_offset);
      }
      
      
      if (mev->button() == RightButton){
	button_to_be_modified = moving_button;
	moving_button = NULL;
	if (button_to_be_modified){
	  popup_item->setItemEnabled(0, TRUE);
	  popup_item->setItemEnabled(1, TRUE);
	  popup_item->setItemEnabled(3, TRUE);
	  // the KDE-button cannot be removed 
	  if (button_to_be_modified == tmp_kde_button){
	    popup_item->setItemEnabled(0, TRUE);
	    popup_item->setItemEnabled(1, FALSE);
	    popup_item->setItemEnabled(3, FALSE);
	  }
	  // the control group cannot be removed 
	  if (button_to_be_modified == control_group){
	    popup_item->setItemEnabled(0, TRUE);
	    popup_item->setItemEnabled(1, FALSE);
	    popup_item->setItemEnabled(3, FALSE);
	  }
	  for (i=0; i<nbuttons && entries[i].button != button_to_be_modified;i++);
	  if (i<nbuttons && entries[i].popup == tmp_windows){
	    // you cannot set properties of the Windowlist
	    popup_item->setItemEnabled(0, TRUE);
	    popup_item->setItemEnabled(1, TRUE);
	    popup_item->setItemEnabled(3, FALSE);
	  }
	  active_button = button_to_be_modified;
	  show_popup(popup_item, button_to_be_modified);
	}
	break;
      }

      if (moving_button){
	moving_button->raise();
	moving_button->setCursor(sizeAllCursor);
      }
    }
    else{
      int i;
      for (i=0; i<nbuttons && entries[i].button != ob;i++);
      if (i<nbuttons){
	active_button = (QWidget*)ob;
      }
    }
  }
  break;

  case Event_MouseButtonRelease: {
    QMouseEvent* mev = (QMouseEvent*)ev;
    if (moving_button){
      moving_button->setCursor(arrowCursor);
      moving_button->releaseMouse();
      if (moving_button != control_group)
	check_button_bounds(moving_button);
      else {
	if (orientation == horizontal){
	  bound_top_left = control_group->x();
	  bound_bottom_right = control_group->x() + control_group->width();
	}
	else {
	  bound_top_left = control_group->y();
	  bound_bottom_right = control_group->y() + control_group->height();
	}
	int i;
	for (i=0; i<nbuttons; i++){
	  check_button_bounds(entries[i].button);
	}
      }
      moving_button = NULL;
      reposition();
      write_out_configuration();
    }
    if (mev->button()==MidButton){
      // ehem...
    }
    else {
      // ARRGH....
      if (ob->isWidgetType() && ((QWidget*)ob)->isPopup()){
	if (active_button){
	  // pull the button
 	    QWidget* tmpbutton = active_button;
 	    active_button = NULL;
 	    QApplication::sendEvent(tmpbutton, ev);
 	    //active_button = tmpbutton;

	    // some userfriendlyness
 	    QPoint a = ((QWidget*)ob)->mapToGlobal(mev->pos());
 	    QPoint b = mapToGlobal(tmpbutton->pos());
 	    if (a.x() >= b.x() && a.x() <= b.x()+tmpbutton->width()
 		&& a.y() >= b.y() && a.y() <= b.y()+tmpbutton->height()){
 	      return TRUE;
 	    }
	    else {
 	    // nothing
 	  }
	}
	else {
	  // the panel popup
	}
      }
    }
  }
  break;
  
  case Event_MouseMove:{
    QMouseEvent* mev = (QMouseEvent*)ev;
    if (moving_button){
      if (orientation == horizontal){
	int x = mapFromGlobal(((QWidget*)ob)->mapToGlobal(mev->pos())).x()
	  - moving_button_offset.x();
	if (x<panel_button->x() + panel_button->width()) 
	  x=panel_button->x() + panel_button->width();
	if (x + moving_button->width() > width()) 
	  x = width() - moving_button->width ();
	moving_button->move(x, moving_button->y());
      }
      else {
	int y = mapFromGlobal(((QWidget*)ob)->mapToGlobal(mev->pos())).y()
	  - moving_button_offset.y();
	if (y<panel_button->y() + panel_button->height()) 
	  y=panel_button->y() + panel_button->height();
	if (y + moving_button->height() > height()) 
	  y = height() - moving_button->height ();
	moving_button->move(moving_button->x(), y );
      }
    }
  }
  break;
  case Event_Close:
    // this never occurs ?!
    break;
  }

  
  return FALSE;
}


void kPanel::client_message(XClientMessageEvent *e){
  if (e->message_type == kwm_add_window){
    tmp_windows->insertItem(getprop(e->data.l[1], XA_WM_NAME), 
			    e->data.l[0]);
    return;
  }
  if (e->message_type == kwm_remove_window){
    tmp_windows->removeItem(e->data.l[0]);
    return;
  }
  if (e->message_type == kwm_command){
    int i;
    QString com = e->data.b;
    if (com == "desktop1"){
      for (i=0; i<4; i++)
	if ((i==0 && !((QPushButton*)(desktopbar->find(i)))->isOn())
	    ||
	    (i!=0 && ((QPushButton*)(desktopbar->find(i)))->isOn()))
	  ((QPushButton*)(desktopbar->find(i)))->toggle();
    }
    else if (com == "desktop2"){
      for (i=0; i<4; i++)
	if ((i==1 && !((QPushButton*)(desktopbar->find(i)))->isOn())
	    ||
	    (i!=1 && ((QPushButton*)(desktopbar->find(i)))->isOn()))
	  ((QPushButton*)(desktopbar->find(i)))->toggle();
    }
    else if (com == "desktop3"){
      for (i=0; i<4; i++)
	if ((i==2 && !((QPushButton*)(desktopbar->find(i)))->isOn())
	    ||
	    (i!=2 && ((QPushButton*)(desktopbar->find(i)))->isOn()))
	  ((QPushButton*)(desktopbar->find(i)))->toggle();
    }
    else if (com == "desktop4"){
      for (i=0; i<4; i++)
	if ((i==3 && !((QPushButton*)(desktopbar->find(i)))->isOn())
	    ||
	    (i!=3 && ((QPushButton*)(desktopbar->find(i)))->isOn()))
	  ((QPushButton*)(desktopbar->find(i)))->toggle();
    }

  }
}


void kPanel::check_button_bounds(QWidget* button){
  if (orientation == vertical){
    if (button->y() > bound_top_left - button->height()&&
	button->y() < bound_bottom_right)
      if ((2 * button->y() + button->height()
	  < bound_top_left + bound_bottom_right
	   && bound_top_left - panel_button->y() - panel_button->height()
	   > button->height())
	  || bound_bottom_right > height() - button->height())	
	button->move(button->x(), bound_top_left - button->height());
      else
	button->move(button->x(), bound_bottom_right);
  }
  else {
    if (button->x() > bound_top_left - button->width()&&
	button->x() < bound_bottom_right)
      if ((2 * button->x() + button->width()
	   < bound_top_left + bound_bottom_right
	   && bound_top_left - panel_button->x() - panel_button->width()
	   > button->width())
	  || bound_bottom_right > width() - button->width())
	button->move(bound_top_left - button->width(), button->y());
      else
	button->move(bound_bottom_right, button->y());
  }
}


int kPanel::openDir( const char *_dir, QPopupMenu* popup1, QPopupMenu* popup2, const char* folder_name, bool personal_flag) {


  connect( popup1, SIGNAL(activated( int )), 
	   SLOT(menu_item_activated(int)) );

  if (popup2){
    connect( popup2, SIGNAL(activated( int )), 
	     SLOT(add_menu_item_activated(int)) );
  }


  int result = 0;
  QPopupMenu* new_popup1 = NULL;
  QPopupMenu* new_popup2 = NULL;
  QDir d(_dir);
  if (!d.exists())
    return 0;

  // d.setFilter( QDir::Files | QDir::Hidden | QDir::NoSymLinks );
  // d.setSorting( QDir::Size | QDir::Reversed );
  // d.setSorting( QDir::Unsorted );
  QString dir = _dir;

  const QFileInfoList *list = d.entryInfoList();
  QFileInfoListIterator it( *list );      // create list iterator
  QFileInfo *fi;                          // pointer for traversing
  
  QFile*  myfile = NULL;
  KTextStream * mystream = NULL;

  QString ts;
  if (folder_name && popup2){
    ListItem* li = new ListItem;
    li->path = dir;
    li->is_directory = TRUE;
    li->personal_flag = personal_flag;
    apps.append(li);
    popup2->insertItem(ts + "\"" + folder_name +"\"", apps.at()+1000);
    popup2->insertSeparator();
  }
  
  
  
  while ( ( fi = it.current() ) != 0L )
    {
      if ( fi->fileName() !=  "." )
	{
	  if ( fi->isDir() )
	    {
	      if (fi->fileName() != ".."){
		new_popup1 = new QPopupMenu();
		if (popup2){
		  new_popup2 = new QPopupMenu();
		  new_popup2->installEventFilter( this );
		}
		new_popup1->installEventFilter( this );
		if (result += openDir(dir + "/" + fi->fileName().data(), 
				      new_popup1, new_popup2, 
				      fi->fileName().data(),
				      personal_flag)>0){
		  popup1->insertItem(fi->fileName().data(), new_popup1, 0);
		  if (popup2)
		    popup2->insertItem(fi->fileName().data(), new_popup2, 0);
		}
	      }
	    }
	  else {
	    QString mypath = dir + "/" + fi->fileName().data();
	    myfile = new QFile(mypath);
	    myfile->open ( IO_ReadOnly );
	    mystream = new KTextStream(myfile);
	    // read the first line
	    QString rString = "";
	    QString tag = "[KDE Desktop Entry]";
	    int nInput = '\0';
	    
	    QIODevice* pDevice = mystream->device();
	    do 
	      { 
		nInput = pDevice->getch();
		rString += (char)nInput;
	      } 
	    while ( nInput != EOF && rString.length() < tag.length());
	    if (tag == rString){
// 	      QString ts;
// 	      new_actions_popup->insertItem(ts + "Execute \"" + fi->fileName().data()+"\"");
// 	      new_actions_popup->insertItem(ts + "Add \"" + fi->fileName().data()+"\""+" to panel");
// 	      new_actions_popup->insertItem(ts + "Add \"" + fi->fileName().data()+"\""+" to personal folder");
	      
	      ListItem* li = new ListItem;
	      li->path = mypath;
	      li->is_directory = FALSE;
	      li->personal_flag = personal_flag;
	      apps.append(li);

	      result++;
	      QString filename;
	      if (fi->fileName().right(7)==".kdelnk")
		filename = fi->fileName().left(fi->fileName().length()-7);
	      else
		filename = fi->fileName();
	      popup1->insertItem(filename.data(), apps.at()+1000);
	      if (popup2)
		popup2->insertItem(filename.data(), apps.at()+1000);
	      KConfig *pConfig = new KConfig( mystream );
	      pConfig->setGroup("KDE Desktop Entry");
	      QString aString;
// 	      aString = pConfig->readEntry("Exec");
// 	      printf("execute: %s \n", aString.data());
// 	      aString = pConfig->readEntry("icon");
// 	      printf("icon: %s \n", aString.data());
// 	      aString = pConfig->readEntry("info");
// 	      printf("info: %s \n", aString.data());
	      delete pConfig;
	    }
	    else{
	      // No Desktop Entry. Just ignore...
	    }
	    if (myfile)
	      delete myfile;
	    if (mystream)
	      delete mystream;
	    myfile = NULL;
	    mystream = NULL;
	  }
	  
	}
	++it;                               // goto next list element
    }
  return result;
}

QPixmap kPanel::load_pixmap(const char* name){
  KPixmap pm;
  pm.resize(0,0);
  if (!name || name[0]=='\0')
    name = "exec.xpm";
  QString s = icon_path;
  s = s + "/" + name;
  pm.load(s.data());
  if (pm_scale_factor != 1){
    QWMatrix m;
    m.scale(pm_scale_factor, pm_scale_factor);
    return pm.xForm(m);
  }
  return pm;
}

void kPanel::execute_kde_desktop_entry(const char* name){
  if (!name)
    return;

  printf("execute %s \n", name);

   QFile*  myfile = new QFile(name);
   if (myfile->open ( IO_ReadOnly )){
     KTextStream* mystream = new KTextStream(myfile);
     KConfig *pConfig = new KConfig( mystream );
     pConfig->setGroup("KDE Desktop Entry");
     QString aString;
     aString = pConfig->readEntry("Exec");
     if (aString.isNull())
       return;
     aString=aString + " & ";
     QString bString;
     bString = pConfig->readEntry("Terminal");
     if (!bString.isNull() && bString.toInt() != 0){
       KConfig *config = KApplication::getKApplication()->getConfig();
       config->setGroup( "Terminal" );
       QString terminal = config->readEntry( "Terminal" );
       if ( terminal.isNull() ){
	 terminal = "kvt";
       }
       QString options = pConfig->readEntry( "TerminalOptions" );
       if ( !options.isNull() )
	 terminal = terminal + " " + options;
       aString = terminal + " -e " + aString;
     }
     system(aString.data());  
     delete pConfig;
     delete mystream;
   }
   delete myfile;


}






#include "kpanel.moc"


int main( int argc, char ** argv )
{

  o_argc = argc;
  o_argv = new char*[o_argc + 2];
  int v;
  for (v=0; v<o_argc; v++) o_argv[v] = argv[v];

  the_app = new MyApp( argc, argv, "kpanel" );

  KConfig *config = KApplication::getKApplication()->getConfig();
  config->setGroup( "Icons" );
  QString iconpath = config->readEntry( "Path" );
  if ( iconpath.isNull() )
    {
      printf("ERROR: No path for icons specified in config files\n");
      exit(1);
    }
  icon_path = qstrdup(iconpath.data());
  
  config->setGroup( "KDE Desktop Entries" );
  QString appspath = config->readEntry( "Path" );
  if ( appspath.isNull() )
    {
      printf("ERROR: No path for KDE Desktop Entries  specified in config files\n");
      exit(1);
    }
  applications_path = qstrdup(appspath.data());
  
  config->setGroup( "KDE Desktop Entries" );
  QString persappspath = config->readEntry( "PersonalPath" );
  if ( persappspath.isNull() )
    {
      personal_applications_path = NULL;
    }
  else{
    personal_applications_path_name = qstrdup(persappspath.data());
    persappspath.insert(0, "/");
    persappspath.insert(0, getenv( "HOME" ));
    personal_applications_path = qstrdup(persappspath.data());
  }
  
  the_panel = new kPanel;
  the_app->setMainWidget(the_panel);
  the_panel->show();
  return the_app->exec();
}

