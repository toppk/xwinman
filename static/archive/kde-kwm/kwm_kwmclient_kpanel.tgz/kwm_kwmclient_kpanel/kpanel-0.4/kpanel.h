//
// kpanel. Part of the KDE project.
//
// Copyright (C) 1996,97 Matthias Ettrich
//

#ifndef KPANEL_H
#define KPANEL_H
#define STDC_HEADERS
#include <qwidget.h>
#include <qmenubar.h>
#include <qlabel.h>
#include <qbttngrp.h>
#include <qpushbt.h>
#include <qpixmap.h>
#include <qpainter.h>
#include <qcolor.h>
#include <qpaintd.h>
#include <qpalette.h>
#include <qscrbar.h>
#include <qpopmenu.h>
#include <qfiledlg.h>
#include <qtooltip.h>
#include <qdatetm.h>
//#include "aclock/aclock.h"

// KDE includes
#include <Kconfig.h>
#include <kpixmap.h>
#include <kapp.h>

enum Orientation {horizontal, vertical};
enum Position {top_left, bottom_right};


class ListItem {
public:
  ListItem(){
    personal_flag = FALSE;
    is_directory = FALSE;
    path = "";
  };
  bool personal_flag;
  bool is_directory;
  QString path;
};

class DesktopEntry {
public:
  DesktopEntry(){
    button = NULL;
    popup = NULL;
    app_id = 0;
  };
  QPushButton* button;
  QPopupMenu* popup;
  int app_id;
};
  


class kPanel : public QFrame
{
  Q_OBJECT
public:
  kPanel(QWidget *parent=0, const char *name=0 );

  void client_message(XClientMessageEvent* ev);
  
 public slots:
 void    open();
  void    close();
  void    undo();
  void    redo();
  void    about();
  void popup_position_activated(int);
  void popup_item_activated(int);
  void popup_special_activated(int);
  void windowlist_activated(int);
  
  void menu_item_activated(int);
  void add_menu_item_activated(int);
  
  void button_clicked();
  void button_pressed();
  
  void ask_logout();
  void call_help();
  void call_home();
  void call_trash();
  void call_klock();

  void desktop1();
  void desktop2();
  void desktop3();
  void desktop4();

  
  void configure_panel();
  
  void write_out_configuration();
  void read_in_configuration();
  
  void restart();
  
  
protected:
    void    resizeEvent( QResizeEvent * );
    bool eventFilter(QObject *, QEvent *);
    void mousePressEvent( QMouseEvent * );
    void  timerEvent( QTimerEvent * );

signals:
    
private:

  DesktopEntry entries[100];
  int nbuttons;
  
  QFrame *control_group;
  QButtonGroup *desktopbar;
  QPushButton *exit_button;
  QPushButton *lock_button;
  QPushButton *panel_button;
  QPushButton *mock_button;
  
  int bound_top_left;
  int bound_bottom_right;
  
  QPopupMenu *popup_item;
  QPopupMenu *popup_panel;
  QPopupMenu *popup_position;
  QPopupMenu* special_popup;


  int menu_item_id;
  QPopupMenu* applications_popup;
  QPopupMenu* add_application_popup;

  QPopupMenu* personal_applications_popup;
  QPopupMenu* add_personal_application_popup;
  
  QLabel *label_date;

  QWidget *moving_button;
  QPoint moving_button_offset;

  QWidget *active_button;

  QPoint position_of_new_item;

  QWidget *button_to_be_modified;

  QList <ListItem> apps;

  void execute_kde_desktop_entry(const char* name);

// options
     Orientation orientation;
     Position position;

     int box_width;
     int box_height;
     int margin;
     int dbhs;

     float  pm_scale_factor;

  // tools
  QPixmap create_arrow_pixmap(QPixmap pm, QColor bg);
  void show_popup(QPopupMenu* popup, QWidget* button);
  void set_correct_popup_size(QPopupMenu* popup);
  void check_button_bounds(QWidget* button);
  void reposition();
  void set_label_date();

  void find_a_free_place();
  bool add_button(ListItem* li, int x = -1, int y = -1, QString name = "");

  // dialogs
  

  // development

  QPopupMenu* tmp_kde;
  QPushButton* tmp_kde_button;

  QPopupMenu* tmp_windows;
  
  QPixmap load_pixmap(const char* name);

  
  int openDir( const char *_dir, QPopupMenu* popup1, QPopupMenu* popup2, const char* folder_name , bool personal_flag);

  



};


#endif // KPANEL_H
