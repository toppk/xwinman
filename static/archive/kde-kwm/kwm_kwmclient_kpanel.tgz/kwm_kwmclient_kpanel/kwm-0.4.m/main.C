#include <qapp.h>
#include <qpushbt.h>
#include <qbitmap.h>
#include <qfiledlg.h>
#include <qwindefs.h>
#include <qmsgbox.h>
#include <qdialog.h>
#include <qaccel.h>
#include <qstring.h>
#include <stdio.h>
#include <stdlib.h>
#include <X11/X.h>
#include <X11/Xos.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/extensions/shape.h>

#include <kapp.h>

extern void initkwm(int , char**);

#include <qwidget.h>
#include <qmenubar.h>

#include "dat.h"
#include "fns.h"
#include "devel.h"

#include "options.h"
#include "client.h"
#include "main.h"

#include "communication.h" // Matthias

// Global development/user options.
int WindowMoveType;
int buttonGroup;
int buttonSpacing;
int BUTTON_SEPARATION;
int TITLEBUTTON_SEPARATION;
int TITLEWINDOW_SEPARATION;

KConfig *config;

extern int ABUTTON;
extern int BBUTTON;
extern int CBUTTON;
extern int DBUTTON;
extern int EBUTTON;
extern int FBUTTON;

extern int shape_event;

QPalette *title_palette = NULL;
QPixmap *default_miniicon=NULL;
QBitmap *bm_minimize;
QBitmap *bm_maximize1;
QBitmap *bm_maximize2;
QBitmap *bm_maximize3;
QBitmap *bm_close1;
QBitmap *bm_close2;
QBitmap *bm_close3;
QBitmap *bm_close4;
QBitmap *bm_pinup;         
QBitmap *bm_pindown;         

QPopupMenu *operations;

int currentVD;

void open() {
  QFileDialog::getOpenFileName();
}


wmMenuWidget *m;



wmMenuWidget::wmMenuWidget( QWidget *parent, const char *name )
    : QWidget( parent, name ){

  QPopupMenu *file = new QPopupMenu;
  CHECK_PTR( file );
  file->insertItem( "Run",  this, SLOT(run()) );
  file->insertItem( "Restart",  this, SLOT(restart()) );
  file->insertItem( "Exit",  kapp , SLOT(quit()) );

  view = new QPopupMenu;
  CHECK_PTR( view );
  view->insertItem( "Page 1",  this, SLOT(page1()) );
  view->insertItem( "Page 2",  this, SLOT(page2()) );
  view->insertItem( "Page 3",  this, SLOT(page3()) );
  view->insertItem( "Page 4",  this, SLOT(page4()) );

  QPopupMenu *help = new QPopupMenu;
  CHECK_PTR( help );
  help->insertItem( "KWM Help",  this, SLOT(kwmhelp()) );
  help->insertSeparator();
  help->insertItem( "About",  this, SLOT(about()) );

  windows = new QPopupMenu;
  CHECK_PTR( help );

  QPopupMenu *options = new QPopupMenu;
  CHECK_PTR( help );
  int checkT = options->insertItem( "Transparent Move",  this, SLOT(transpMove()) );
  options->setItemChecked(checkT,TRUE);
  int checkO = options->insertItem( "Opaque Move",  this, SLOT(opaqueMove()) );
  options->insertItem( "Titlebar",  this, SLOT(changeTitlebar()) );
//  options->insertSeparator();
//  int enableSO = options->insertItem( "Save Options", kapp, SLOT(saveOptions()) );
//  options->setItemEnabled( enableSO, FALSE);  

  menu = new QMenuBar( this );
  CHECK_PTR( menu );
  menu->insertItem( "File", file );
  menu->insertItem( "View", view );
  menu->insertItem( "Windows", windows );
  menu->insertItem( "Options", options );
  menu->insertSeparator();
  menu->insertItem( "Help", help );
  menu->setGeometry( 0, 0, 300, 22);

  setGeometry(0,0,308,28);

}  /* end wmMenuWidget::wmMenuWidget */

void wmMenuWidget::run(){
  system("acli &");
}  /* end wmMenuWidget::run */

void wmMenuWidget::restart(){
  system("kwmclient restart &");
}  /* end wmMenuWidget::run */

void wmMenuWidget::vdRequest(int newvd){
  // for now, no reason to deny requests
  currentVD = newvd;

  // Matthias
  switch (currentVD) {
  case 1:  kwmcom_send_to_modules(kwm_command, "desktop1"); break;
  case 2:  kwmcom_send_to_modules(kwm_command, "desktop2"); break;
  case 3:  kwmcom_send_to_modules(kwm_command, "desktop3"); break;
  case 4:  kwmcom_send_to_modules(kwm_command, "desktop4"); break;
  }
  
  emit switchVD();
}  /* end wmMenuWidget::run */

void wmMenuWidget::page1(){
  if (currentVD == 1)
    return;
  fprintf(stderr,"Switching to Virtual Desktop 1\n");
  vdRequest(1);
}  /* end wmMenuWidget::page1 */

void wmMenuWidget::page2(){
  if (currentVD == 2)
    return;
  fprintf(stderr,"Switching to Virtual Desktop 2\n");
  vdRequest(2);
}  /* end wmMenuWidget::page2 */

void wmMenuWidget::page3(){
  if (currentVD == 3)
    return;
  fprintf(stderr,"Switching to Virtual Desktop 3\n");
  vdRequest(3);
}  /* end wmMenuWidget::page3 */

void wmMenuWidget::page4(){
  if (currentVD == 4)
    return;
  fprintf(stderr,"Switching to Virtual Desktop 4\n");
  vdRequest(4);
}  /* end wmMenuWidget::page4 */

void wmMenuWidget::transpMove(){

  config->setGroup("General");
  config->writeEntry("WindowMoveType","Transparent");

  WindowMoveType=TRANSPARENT;

}  /* end wmMenuWidget::transpMove */

void wmMenuWidget::opaqueMove(){

  config->setGroup("General");
  config->writeEntry("WindowMoveType","Opaque");

  WindowMoveType=OPAQUE;

}  /* end wmMenuWidget::opaqueMove */

void wmMenuWidget::changeTitlebar(){

   ot   = new TitleOptions;
   ot->show();
    
   //  buttonGroup=W95BUTTONS;
}  /* end wmMenuWidget::changeTitlebar */

void wmMenuWidget::kwmhelp(){
  char c[150];
  strcpy(c,"kdehelp ");
  strcat(c,getenv("KDEDIR"));
  strcat(c,"/doc/HTML/kwmhelp.html &\n");
  
  system(c);
  
}  /* end wmMenuWidget::kwmhelp */

void wmMenuWidget::about(){
    QString str = "kwm version 0.4\n";
    str += "\nBrian H. Cooper 1997\n";
    str += "cooperb@er4.eng.ohio-state.edu\n";
    str += "\nFor the KDE project\n";
    str += "http://www-pu.informatik.uni-tuebingen.de/users/ettrich/kde.html\n";
    str += "\nkwm 0.1 copyright Matthias Ettrich 1996\n";
    str += "Parts based on 9wm copyright David Hogan 1994\n";
    str += "Please read the README's\n";
    QMessageBox::message( "About kwm", str, 0 );
}  /* end wmMenuWidget::about */

void wmMenuWidget::addMenuWin(Client *c){

  // ICCCM calls for XA_WM_ICON_NAME here
  // but that doesn't quite cut it IMHO (Brian)
  
  // No Name, No listing
  if( !getprop(c->window,XA_WM_NAME) ) return;
  
  c->id = windows->insertItem(getprop(c->window,XA_WM_NAME),c,SLOT(unMinimize()));
  fprintf(stderr,"adding window with unique id %d and name %s\n",c->id,getprop(c->window,XA_WM_NAME));
  connect(c,SIGNAL(clientClosed( int )), m,SLOT(removeMenuWin( int)));

  kwmcom_send_to_modules(kwm_add_window, -c->id, c->window); // Matthias

}  /* end wmMenuWidget::addMenuWin */

void wmMenuWidget::removeMenuWin(int id){

  windows->removeItem( id );
  fprintf(stderr,"removing window with unique id %d\n",id);

  kwmcom_send_to_modules(kwm_remove_window, -id); // Matthias


}  /* end wmMenuWidget::removeMenuWin */

void wmMenuWidget::nabWindow(){
}  /* end wmMenuWidget::nabWindow */




MyApp::MyApp(int &argc = 0, char **argv = 0, const QString& rAppName = 0):KApplication(argc, argv, rAppName ){

QString key;

  // Get KConfigs and set defaults if need be
  
  config = getKApplication()->getConfig();
  config->setGroup( "General" );
  key = config->readEntry("WindowMoveType");
  if( key == "Transparent")
    WindowMoveType = TRANSPARENT;
  else if( key == "Opaque")
    WindowMoveType = OPAQUE;
  else{
    config->writeEntry("WindowMoveType","Transparent");
    WindowMoveType = TRANSPARENT;
  }
  
  config->setGroup( "Titlebar");
  
  key = config->readEntry("ButtonA");
  if( key == "Off" )
    ABUTTON = NOFUNC;
  else if( key == "Maximize" )
    ABUTTON = MAXIMIZE;
  else if( key == "Minimize" )
    ABUTTON = MINIMIZE;
  else if( key == "Close" )
    ABUTTON = CLOSE;
  else if( key == "Sticky" )
    ABUTTON = STICKY;
  else{
    config->writeEntry("ButtonA","Close");
    ABUTTON = CLOSE;
  }
  key = config->readEntry("ButtonB");
  if( key == "Off" )
    BBUTTON = NOFUNC;
  else if( key == "Maximize" )
    BBUTTON = MAXIMIZE;
  else if( key == "Minimize" )
    BBUTTON = MINIMIZE;
  else if( key == "Close" )
    BBUTTON = CLOSE;
  else if( key == "Sticky" )
    BBUTTON = STICKY;
  else{
    config->writeEntry("ButtonB","Sticky");
    BBUTTON = STICKY;
  }
  key = config->readEntry("ButtonC");
  if( key == "Off" )
    CBUTTON = NOFUNC;
  else if( key == "Maximize" )
    CBUTTON = MAXIMIZE;
  else if( key == "Minimize" )
    CBUTTON = MINIMIZE;
  else if( key == "Close" )
    CBUTTON = CLOSE;
  else if( key == "Sticky" )
    CBUTTON = STICKY;
  else{
    config->writeEntry("ButtonC","Off");
    CBUTTON = NOFUNC;
  }
  key = config->readEntry("ButtonD");
  if( key == "Off" )
    DBUTTON = NOFUNC;
  else if( key == "Maximize" )
    DBUTTON = MAXIMIZE;
  else if( key == "Minimize" )
    DBUTTON = MINIMIZE;
  else if( key == "Close" )
    DBUTTON = CLOSE;
  else if( key == "Sticky" )
    DBUTTON = STICKY;
  else{
    config->writeEntry("ButtonD","Off");
    DBUTTON = NOFUNC;
  }
  key = config->readEntry("ButtonE");
  if( key == "Off" )
    EBUTTON = NOFUNC;
  else if( key == "Maximize" )
    EBUTTON = MAXIMIZE;
  else if( key == "Minimize" )
    EBUTTON = MINIMIZE;
  else if( key == "Close" )
    EBUTTON = CLOSE;
  else if( key == "Sticky" )
    EBUTTON = STICKY;
  else{
    config->writeEntry("ButtonE","Minimize");
    EBUTTON = MINIMIZE;
  }
  key = config->readEntry("ButtonF");
  if( key == "Off" )
    FBUTTON = NOFUNC;
  else if( key == "Maximize" )
    FBUTTON = MAXIMIZE;
  else if( key == "Minimize" )
    FBUTTON = MINIMIZE;
  else if( key == "Close" )
    FBUTTON = CLOSE;
  else if( key == "Sticky" )
    FBUTTON = STICKY;
  else{
    config->writeEntry("ButtonF","Maximize");
    FBUTTON = MAXIMIZE;
  }
  
  
  // Here's a (colored) desktop widget
  QWidget *d = QApplication::desktop();
  d->setBackgroundColor( QColor(43,110,128) );

  m = new wmMenuWidget();
  setMainWidget(m);
  m->show();

}

void MyApp::saveOptions(){
// This workaround is mainly because of the sync() bug
// But I may leave it in with modifications because it
// provides a little more control

  if(config)
    delete config;
  config = getKApplication()->getConfig();  
}

void MyApp::quit(){
printf("MyApp::quit\n");
exit(0);
}

bool MyApp::x11EventFilter( XEvent * ev){
  //  printf("Qt: got one event %d \n", ev->type);


  switch (ev->type) {
  case ButtonPress:
    break;
  case ButtonRelease:
    break;
  case MapRequest:
    mapreq(&ev->xmaprequest);
    break;
  case ConfigureRequest:
    configurereq(&ev->xconfigurerequest);
    break;
  case CirculateRequest:
    circulatereq(&ev->xcirculaterequest);
    break;
  case UnmapNotify:
     unmap(&ev->xunmap);
    break;
  case CreateNotify:
    newwindow(&ev->xcreatewindow);
    break;
  case DestroyNotify:
    destroywin(ev->xdestroywindow.window);
    break;
  case ClientMessage:
    clientmesg(&ev->xclient);
    break;
  case ColormapNotify:
    cmap(&ev->xcolormap);
    break;
  case PropertyNotify:
    property(&ev->xproperty);
    break;
  case SelectionClear:
    fprintf(stderr, "kwm: SelectionClear (this should not happen)\n");
    break;
  case SelectionNotify:
    fprintf(stderr, "kwm: SelectionNotify (this should not happen)\n");
    break;
  case SelectionRequest:
    fprintf(stderr, "kwm: SelectionRequest (this should not happen)\n");
    break;
  case EnterNotify:
    if (!current || current != current->mouseGrabber())
      enter(&ev->xcrossing); 
    break;
  case ReparentNotify:
     reparent(&ev->xreparent);
    break;
  case MotionNotify:
    break;
  case ConfigureNotify:
    // this is because Qt cannot handle (usually does not need to)
    // SubstructureNotify events. (Matthias)
    if (ev->xconfigure.window != ev->xconfigure.event){
      return TRUE;
    }
    break;
  case MapNotify:
  case Expose:
  case FocusIn:
  case FocusOut:
  case MappingNotify:
    /* not interested */
    break;
  default:
#ifdef  SHAPE
    if (shape && ev->type == shape_event)
      shapenotify((XShapeEvent *)ev);
    else
#endif
      //fprintf(stderr, "kwm: unknown ev->type %d\n", ev->type);
    break;
  }

  return FALSE;
}

extern Display *dpy;

#include "client.moc"
#include "main.moc"
#include "options.moc"

void initdevel(){
  BUTTON_SEPARATION = 0;
  TITLEBUTTON_SEPARATION = 2;
  TITLEWINDOW_SEPARATION = 1;

  currentVD=1;
  
}  /* end initdevel() */

int main( int argc, char ** argv )
{

  initdevel();
  MyApp a(argc, argv,"kwm");
  a.setStyle(MotifStyle);

  OperationsHandler op;

  QBitmap tmpbm;

//  default_miniicon = new QPixmap;
//  default_miniicon->load("default_miniicon.bmp");
//  tmpbm.load("default_miniicon.xbm");
//  default_miniicon->setMask(tmpbm);

   operations  = new QPopupMenu ();
   CHECK_PTR( operations );
   operations->insertItem( "(Un-)Maximize", OP_MAXIMIZE);
   operations->insertItem( "Iconify", OP_ICONIFY);
   operations->insertItem( "Move", OP_MOVE);
   operations->insertItem( "Reshape", OP_RESHAPE);
   operations->insertSeparator();
   operations->insertItem( "Destroy", OP_DESTROY);
   QObject::connect(operations, SIGNAL(activated(int)), &op, SLOT(handle_operations_popup(int)));


  dpy = qt_xdisplay();
  initkwm(argc, argv);
  return a.exec();

}

