#ifndef OPTIONS_H
#define OPTIONS_H

#include <qdialog.h>
#include <qchkbox.h>
#include <qframe.h>
#include <qcombo.h>


// button function types

#define MAXIMIZE    0
#define MINIMIZE    1
#define CLOSE       2
#define STICKY      3
#define NOFUNC      -1



class SampleClient : public QFrame
{
   Q_OBJECT	
 public:
   SampleClient (QWidget *parent=0, const char *name=0, bool is_active=FALSE );
 private:
   QBitmap getBitmap( QComboBox *funcType );
};

class SampleFrame : public QFrame
{
   Q_OBJECT	
 public:
   SampleFrame (QWidget *parent=0, const char *name=0);
   void changeSample();
 
 private:
   SampleClient *activeSample;
   SampleClient *inactiveSample;
};

class TitleOptions : public QDialog
{
   Q_OBJECT
 public:
   TitleOptions  ( QWidget *parent=0, const char *name=0 );
   
 private slots:
   void comboBoxItemActivated( int );
   void doDefault();
   void doApply();
   void doCancel();
   void aClicked();
   void bClicked();
   void cClicked();
   void dClicked();
   void eClicked();
   void fClicked();
   
 private:
   SampleFrame *sframe;

};


#endif  // OPTIONS_H
