#include <stdio.h>
#include <qpushbt.h>
#include <malloc.h>
#include <X11/X.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/extensions/shape.h>

#include "dat.h"
#include "fns.h"

#include "client.h"
#include "main.h"
extern wmMenuWidget *m;


int manage(Client*  c, int mapped){
    int fixsize, dohide, doreshape, state, n, order;
    long msize;
    XClassHint klass;
    XWMHints *hints;



#ifdef SHAPE
       /* fall out if window is non-rectangular */
       XShapeGetRectangles(dpy, c->window, ShapeBounding, &n, &order);
       if ( n > 1 ) return 1;
#endif

if (c->already_managed) {
 fprintf(stderr,"Redundant managing\n");
} 

    m->addMenuWin(c);           // add this to the windowlist

    c->already_managed = TRUE;
    
    XSelectInput(dpy, c->window, ColormapChangeMask | EnterWindowMask | PropertyChangeMask);

    /* Get loads of hints */

    if (XGetClassHint(dpy, c->window, &klass) != 0) {   /* ``Success'' */
        c->instance = klass.res_name;
        c->klass = klass.res_class;
    }
    else {
        c->instance = 0;
        c->klass = 0;
    }
    c->iconname = getprop(c->window, XA_WM_ICON_NAME);
    c->name = getprop(c->window, XA_WM_NAME);
    fprintf(stderr,"Managing %s\n",c->name);
    setwindowlabel(c);

    hints = XGetWMHints(dpy, c->window);
    if (XGetWMNormalHints(dpy, c->window, &c->size, &msize) == 0 || c->size.flags == 0)
        c->size.flags = PSize;      /* not specified - punt */

    getcmaps(c);
    getwindowproto(c);
    getwindowtrans(c);


    if(c->trans){
      if(c->buttonA) c->buttonA->hide();
      if(c->buttonB) c->buttonB->hide();
      if(c->buttonC) c->buttonC->hide();
      if(c->buttonD) c->buttonD->hide();
      if(c->buttonE) c->buttonE->hide();
      if(c->buttonF) c->buttonF->hide();
      if(c->rightResizeFrame) c->rightResizeFrame->hide();
    }

    // readjust dx and dy so they are Client sizes
    c->dx += 2*BORDER;
    if(!c->trans)
      c->dy += 2*BORDER + TITLEBAR_HEIGHT;
    else
      c->dy += 2*BORDER;
    c->setGeometry(c->x,c->y,c->dx,c->dy);

    if (!getwindowstate(c->window, &state))
        state = hints ? hints->initial_state : NormalState;
    dohide = (state == IconicState);

    fixsize = 0;
    if ((c->size.flags & (USSize|PSize)))
        fixsize = 1;
    if ((c->size.flags & (PMinSize|PMaxSize)) == PMinSize|PMaxSize && c->size.min_width == c->size.max_width && c->size.min_height == c->size.max_height)
        fixsize = 1;
    doreshape = !mapped;
    if (fixsize) {
        if (c->size.flags & USPosition)
            doreshape = 0;
        if (dohide && (c->size.flags & PPosition))
            doreshape = 0;
        if (c->trans != None)
            doreshape = 0;
    }
    if (c->size.flags & PBaseSize) {
        c->min_dx = c->size.base_width;
        c->min_dy = c->size.base_height;
    }
    else if (c->size.flags & PMinSize) {
        c->min_dx = c->size.min_width;
        c->min_dy = c->size.min_height;
    }
    else
        c->min_dx = c->min_dy = 0;

    if (hints)
        XFree(hints);

    /* Now do it!!! */

    if (doreshape) {
      cmapfocus(0);
      if (c->x == 0 && c->y == 0)
	drag(c);
      else{
	sendconfig( c );
      }
    }
    else {
      gravitate(c, 0);
    }
    
      c->setGeometry(c->x , c->y ,
		     c->dx , c->dy );

    if (mapped)
        c->reparenting = 1;
    if (doreshape && !fixsize){
       if(!c->trans)
         XResizeWindow(dpy, c->window, c->dx - 2*BORDER, c->dy - 2*BORDER - TITLEBAR_HEIGHT);
       else
         XResizeWindow(dpy, c->window, c->dx - 2*BORDER, c->dy - 2*BORDER);
    }
    XSetWindowBorderWidth(dpy, c->window, 0);
    if (c->trans)
      XReparentWindow(dpy, c->window, c->parent_window, (BORDER), (BORDER));
    else
      XReparentWindow(dpy, c->window, c->parent_window, (BORDER), (BORDER) + 
		      TITLEBAR_HEIGHT);


#ifdef  SHAPE
    if (shape) {
        XShapeSelectInput(dpy, c->window, ShapeNotifyMask);
        ignore_badwindow = 1;       /* magic */
        setshape(c);
        ignore_badwindow = 0;
    }
#endif
    XAddToSaveSet(dpy, c->window);
    if (dohide)
        hidec(c);
    else {
      XMapWindow(dpy, c->window);
      // XMapWindow(dpy, c->parent_window);
      c->show();
      // c->repaint();
       // The following lines may be important for click-to-focus (Matthias)
//         if (c->trans != None && current && current->window == c->trans)
// 	  active(c);
//         else
// 	  setactive(c, 0);
        setwindowstate(c, NormalState);
    }
    if (current != c)
      cmapfocus(current);
    
    c->init = 1; 
    
  XRaiseWindow(dpy, c->parent_window);
  XMapWindow(dpy, c->window);
	  
    return 1;
}

void getwindowtrans(Client * c)
{
    Window trans;

    trans = None;
    if (XGetTransientForHint(dpy, c->window, &trans) != 0)
        c->trans = trans;
    else
        c->trans = None;
}

void withdraw(Client *c)
{
fprintf(stderr,"withdraw\n");
// Doing all this is probably silly, since I'll probably just
// leave the rmclient(c) at the bottom.  This keeps blank frames
// from popping up, plus that it eliminates some annoying nutscrape
// behavior.

    XUnmapWindow(dpy, c->parent_window);
    gravitate(c, 1);
    if(!c->trans)
      XReparentWindow(dpy, c->window, root, c->x - 2*BORDER, c->y - 2*BORDER - TITLEBAR_HEIGHT);
    else
      XReparentWindow(dpy, c->window, root, c->x - 2*BORDER, c->y - 2*BORDER);
      
    gravitate(c, 0);
    XRemoveFromSaveSet(dpy, c->window);
    setwindowstate(c, WithdrawnState);

    /* flush any errors */
    ignore_badwindow = 1;
    XSync(dpy, False);
    ignore_badwindow = 0;
    
    // .... Hey Me! Look here!
    rmclient(c);
}

void gravitate(Client* c, int invert)
{

  // Do Nothing.  Who needs this crap?

}  /* end gravitate */

void cleanup()
{
    Client *c;
    XWindowChanges wc;

    for (c = clients; c; c = c->next) {
      gravitate(c, 1);
      XReparentWindow(dpy, c->window, root, c->x , c->y );
       
      wc.border_width = c->border;
      XConfigureWindow(dpy, c->window, CWBorderWidth, &wc);
    }
    XSetInputFocus(dpy, PointerRoot, RevertToPointerRoot, timestamp());
    cmapfocus(0);
    XCloseDisplay(dpy);
}

static void installcmap(Colormap cmap)
{
    XInstallColormap(dpy, (cmap == None) ? def_cmap : cmap);
}

void cmapfocus(Client *c)
{
    int i, found;
    Client *cc;

    if (c == 0)
        installcmap(None);
    else if (c->ncmapwins != 0) {
        found = 0;
        for (i = c->ncmapwins-1; i >= 0; i--) {
            installcmap(c->wmcmaps[i]);
            if (c->cmapwins[i] == c->window)
                found++;
        }
        if (!found)
            installcmap(c->cmap);
    }
    else if (c->trans != None && (cc = getclient(c->trans, 0)) != 0 && cc->ncmapwins != 0)
        cmapfocus(cc);
    else
        installcmap(c->cmap);
}

void getcmaps(Client *c)
{
    int n, i;
    Window *cw;
    XWindowAttributes attr;

    if (!c->init) {
        XGetWindowAttributes(dpy, c->window, &attr);
        c->cmap = attr.colormap;
    }

    n = _getprop(c->window, wm_colormaps, XA_WINDOW, 100L, (unsigned char **)&cw);
    if (c->ncmapwins != 0) {
        XFree((char *)c->cmapwins);
        free((char *)c->wmcmaps);
    }
    if (n <= 0) {
        c->ncmapwins = 0;
        return;
    }

    c->ncmapwins = n;
    c->cmapwins = cw;

    c->wmcmaps = (Colormap*)malloc(n*sizeof(Colormap));
    for (i = 0; i < n; i++) {
        if (cw[i] == c->window)
            c->wmcmaps[i] = c->cmap;
        else {
            XSelectInput(dpy, cw[i], ColormapChangeMask);
            XGetWindowAttributes(dpy, cw[i], &attr);
            c->wmcmaps[i] = attr.colormap;
        }
    }
}

void setwindowlabel(Client *c)
{

    if (getprop(c->window,XA_WM_NAME))
        c->setlabel(getprop(c->window,XA_WM_NAME));
    else if (c->iconname)
        c->setlabel( c->iconname);
    else if (c->name)
        c->setlabel  (c->name);
    else if (c->instance)
        c->setlabel (c->instance);
    else
        c->setlabel("???");
    
}

#ifdef  SHAPE
void setshape(Client* c)
{
    int n, order;
    XRectangle *rect;

    /* cheat: don't try to add a border if the window is non-rectangular */
    rect = XShapeGetRectangles(dpy, c->window, ShapeBounding, &n, &order);
    if (n > 1){
      if (!c->trans)
	XShapeCombineShape(dpy, c->parent_window, ShapeBounding, 
			   (BORDER), (BORDER) + TITLEBAR_HEIGHT,
			   c->window, ShapeBounding, ShapeSet);
      else
	XShapeCombineShape(dpy, c->parent_window, ShapeBounding, 
			   (BORDER), (BORDER),
			   c->window, ShapeBounding, ShapeSet);
    }
    XFree((void*)rect);
}
#endif

int _getprop(Window w, Atom a, Atom type, long len, unsigned char **p) {
    Atom real_type;
    int format;
    unsigned long n, extra;
    int status;

    status = XGetWindowProperty(dpy, w, a, 0L, len, False, type, &real_type, &format, &n, &extra, p);
    if (status != Success || *p == 0)
        return -1;
    if (n == 0)
        XFree((void*) *p);
    /* could check real_type, format, extra here... */
    return n;
}

char * getprop(Window w, Atom a) {
    unsigned char *p;
    int n;

    if (_getprop(w, a, XA_STRING, 100L, &p) <= 0)
        return 0;
    return (char *)p;
}

int
get1prop(Window w, Atom a, Atom type) {

    unsigned char *p, *x;

    if (_getprop(w, a, type, 1L, &p) <= 0)
        return 0;
    x = p;
    XFree((void*) p);
    return (int)x;
}

Window
getwprop(Window w, Atom a){
    return get1prop(w, a, XA_WINDOW);
}

int getiprop(Window w, Atom a){
    return get1prop(w, a, XA_INTEGER);
}

void setwindowstate(Client *c, int state){
    long data[2];

    data[0] = (long) state;
    data[1] = (long) None;

    c->state = state;
    XChangeProperty(dpy, c->window, wm_state, wm_state, 32,
        PropModeReplace, (unsigned char *)data, 2);
}

int getwindowstate(Window w, int* state) {
    long *p = 0;

    if (_getprop(w, wm_state, wm_state, 2L, (unsigned char**)&p) <= 0)
        return 0;

    *state = (int) *p;
    XFree((char *) p);
    return 1;
}

void getwindowproto(Client *c) {
    Atom *p;
    int i;
    long n;
    Window w;

    w = c->window;
    c->proto = 0;
    if ((n = _getprop(w, wm_protocols, XA_ATOM, 20L, (unsigned char**)&p)) <= 0)
        return;

    for (i = 0; i < n; i++)
        if (p[i] == wm_delete)
            c->proto |= Pdelete;
        else if (p[i] == wm_take_focus)
            c->proto |= Ptakefocus;

    XFree((char *) p);
}


void move(Client *c){
fprintf(stderr,"move()\n");
    if (c == 0)
        return;
    if (drag(c) == 0)
        return;
    active(c);
    XRaiseWindow(dpy, c->parent_window);
    XMoveWindow(dpy, c->parent_window, c->x, c->y);

    sendconfig(c);
}


void hidec(Client *c){
     XUnmapWindow(dpy, c->window);
     setwindowstate(c, IconicState);  /* Rethink this  (Brian) */
     if (c == current)
         nofocus();
}


void unhidec(Client *c, int map){

  // Do Nothing. Obsolete.
  
}

void renamec(Client *c, char* name){

  // Do Nothing.  It didn't do anything when I got it...

}

void reshape(Client *c){
  int odx, ody;
fprintf(stderr,"reshape\n");
    if (c == 0)
        return;
    odx = c->dx;
    ody = c->dy;
    if (sweep(c) == 0)
        return;
    active(c);
    XRaiseWindow(dpy, c->parent_window);
      c->setGeometry(c->x , c->y ,
		     c->dx , c->dy);
      
    
    if (c->dx == odx && c->dy == ody)
      sendconfig(c);
    else
      {
	if (c->trans != None) 
	  XMoveResizeWindow(dpy, c->window, (BORDER), (BORDER), c->dx - 2*BORDER, c->dy - 2*BORDER);
	else
	  XMoveResizeWindow(dpy, c->window, (BORDER), (BORDER) + TITLEBAR_HEIGHT,
			    c->dx - 2*BORDER, c->dy - 2*BORDER - TITLEBAR_HEIGHT);
      }
}



