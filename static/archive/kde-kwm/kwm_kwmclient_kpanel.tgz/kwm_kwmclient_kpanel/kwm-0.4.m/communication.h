// communication.h
//
// Running proposal for a communication
// between kwm and modules like kpanel
//
// Part of the KDE project.
//
// Copyright (C) 1997 Matthias Ettrich
//

#ifndef COMMUNICATION_H
#define COMMUNICATION_H

extern Atom kwm_add_window;
extern Atom kwm_remove_window;
extern Atom kwm_un_minimize_window;
extern Atom kwm_register_module;
extern Atom kwm_unregister_module;
extern Atom kwm_command;

void kwmcom_init();
void kwmcom_send_to_modules(Atom a, char* s);
void kwmcom_send_to_modules(Atom a, long a1=0, long a2=0, 
			    long a3=0, long a4=0,long a5=0);
void kwmcom_register_module(Window w);
void kwmcom_unregister_module(Window w);





#endif // COMMUNICATION_H

