#include <stdio.h>
#include <qcursor.h>
#include <X11/X.h>
#include <X11/Xos.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "dat.h"
#include "fns.h"

#include "client.h"

int
nobuttons(XButtonEvent *e){
    int state;

    state = (e->state & AllButtonMask);
    return (e->type == ButtonRelease) && (state & (state - 1)) == 0;
}

int grab(Window w, int mask, Cursor curs, int t){
    int status;

    if (t == 0)
        t = timestamp();
    status = XGrabPointer(dpy, w, False, mask,
        GrabModeAsync, GrabModeAsync, None, curs, t);
    return status;
}

void ungrab(XButtonEvent *e){
    XEvent ev;

    if (!nobuttons(e))
        for (;;) {
            XMaskEvent(dpy, ButtonMask | ButtonMotionMask, &ev);
            if (ev.type == MotionNotify)
                continue;
            e = &ev.xbutton;
            if (nobuttons(e))
                break;
        }
    XUngrabPointer(dpy, e->time);
    curtime = e->time;
}


void sweepcalc(Client *c, int x, int y){
    int dx, dy, min_dx, min_dy; //  sx, sy;

    dx = x - c->x;
    dy = y - c->y;
//    sx = sy = 1;
    if (dx < 0) {
        x += dx;
        dx = -dx;
//        sx = -1;
    }
    if (dy < 0) {
        y += dy;
        dy = -dy;
//        sy = -1;
    }

    if (!c->trans){
      dx -= 2*BORDER;
      dy -= 2*BORDER+TITLEBAR_HEIGHT;
    }
    else{
      dx -= 2*BORDER;
      dy -= 2*BORDER;
    }

    if (dx < c->min_dx)
      dx = c->min_dx;
    if (dy < c->min_dy)
      dy = c->min_dy;

    if (c->size.flags & PResizeInc) {
        dx = c->min_dx + (dx-c->min_dx)/c->size.width_inc*c->size.width_inc;
        dy = c->min_dy + (dy-c->min_dy)/c->size.height_inc*c->size.height_inc;
    }

    if (c->size.flags & PMaxSize) {
        if (dx > c->size.max_width)
            dx = c->size.max_width;
        if (dy > c->size.max_height)
            dy = c->size.max_height;
    }
    if (!c->trans){
      c->dx = dx + 2*BORDER;
      c->dy = dy + 2*BORDER + TITLEBAR_HEIGHT;
    }
    else{
      c->dx = dx + 2*BORDER;
      c->dy = dx + 2*BORDER;    
    }
}  /* end sweepcalc */

void resizecalc(Client *c, int x, int y){
    int dx, dy, min_dx, min_dy; //  sx, sy;

    dx = c->dx2 + x - c->x;
    dy = c->dy2 + y - c->y;
//    sx = sy = 1;
    if (dx < 0) {
        x += dx;
        dx = -dx;
//        sx = -1;
    }
    if (dy < 0) {
        y += dy;
        dy = -dy;
//        sy = -1;
    }

    if (!c->trans){
      dx -= 2*BORDER;
      dy -= 2*BORDER+TITLEBAR_HEIGHT;
    }
    else{
      dx -= 2*BORDER;
      dy -= 2*BORDER;
    }

    if (dx < c->min_dx)
      dx = c->min_dx;
    if (dy < c->min_dy)
      dy = c->min_dy;

    if (c->size.flags & PResizeInc) {
        dx = c->min_dx + (dx-c->min_dx)/c->size.width_inc*c->size.width_inc;
        dy = c->min_dy + (dy-c->min_dy)/c->size.height_inc*c->size.height_inc;
    }

    if (c->size.flags & PMaxSize) {
        if (dx > c->size.max_width)
            dx = c->size.max_width;
        if (dy > c->size.max_height)
            dy = c->size.max_height;
    }
    if (!c->trans){
      c->dx = dx + 2*BORDER;
      c->dy = dy + 2*BORDER + TITLEBAR_HEIGHT;
    }
    else{
      c->dx = dx + 2*BORDER;
      c->dy = dx + 2*BORDER;    
    }
}  /* end resizecalc */

void dragcalc(Client* c, int x, int y) {
    c->x = x;
    c->y = y;
}

void drawbound(Client* c){
    int x, y, dx, dy;

    x = c->x;
    y = c->y;
    dx = c->dx;
    dy = c->dy;
    if (dx < 0) {
        x += dx;
        dx = -dx;
    }
    if (dy < 0) {
        y += dy;
        dy = -dy;
    }
    if (dx <= 2 || dy <= 2)
        return;
    XDrawRectangle(dpy, root, gc, x, y, dx-1, dy-1);
    XDrawRectangle(dpy, root, gc, x+1, y+1, dx-3, dy-3);
}

int sweepdrag(Client* c, XButtonEvent *e0,
	      void (*recalc)( Client *, int, int) ){
	      
    XEvent ev;
    int status;
    int cx, cy, rx, ry;
    int ox, oy, odx, ody;
    struct timeval t;
    XButtonEvent *e;

    getmouse(&cx, &cy);
    if (e0) {
        c->x = cx = e0->x;
        c->y = cy = e0->y;
        recalc(c, cx, cy);
    }
    ox = c->x;
    oy = c->y;
    odx = c->dx;
    ody = c->dy;
//    if (!c->trans){
//      c->x -= BORDER;
//      c->y -= BORDER+TITLEBAR_HEIGHT;
//      c->dx += 2*BORDER;
//      c->dy += 2*BORDER+TITLEBAR_HEIGHT;
//    }
//    else{
//      c->x -= BORDER;
//      c->y -= BORDER;
//      c->dx += 2*BORDER;
//      c->dy += 2*BORDER;
//    }
    XGrabServer(dpy);
    drawbound(c);
    t.tv_sec = 0;
    t.tv_usec = 50*1000;
     for (;;) {
        if (XCheckMaskEvent(dpy, ButtonMask, &ev) == 0) {
            getmouse(&rx, &ry);
            if (rx == cx && ry == cy)
                continue;
            drawbound(c);
            recalc(c, ox=ox+rx-cx, oy=oy+ry-cy);
            cx = rx;
            cy = ry;
            drawbound(c);
            XFlush(dpy);
            select(0, 0, 0, 0, &t);
            continue;
        }
        e = &ev.xbutton;
        switch (ev.type) {
        case ButtonPress:
        case ButtonRelease:
            drawbound(c);
            ungrab(e);
            XUngrabServer(dpy);
             if (e->button == Button3 && c->init)
                 goto bad;
//            recalc(c, ev.xbutton.x, ev.xbutton.y);
            if (c->dx < 0) {
                c->x += c->dx;
                c->dx = -c->dx;
            }
            if (c->dy < 0) {
                c->y += c->dy;
                c->dy = -c->dy;
            }
//	    if (!c->trans){
//	      c->x += BORDER;
//	      c->y += BORDER+TITLEBAR_HEIGHT;
//	      c->dx -= 2*BORDER;
//	      c->dy -= 2*BORDER+TITLEBAR_HEIGHT;
//	    }
//	    else {
//	      c->x += BORDER;
//	      c->y += BORDER;
//	      c->dx -= 2*BORDER;
//	      c->dy -= 2*BORDER;
//	    }
            if (c->dx < 4 || c->dy < 4 || c->dx < c->min_dx || c->dy < c->min_dy)
                goto bad;
            return 1;
        }
    }
bad:
    c->x = ox;          // this section will probably fail miserably
    c->y = oy;
    c->dx = odx;
    c->dy = ody;
    return 0;
}

int sweep(Client *c){
    XEvent ev;
    int status;
    XButtonEvent *e;


    status = grab(root, ButtonMask, crossCursor.handle(), 0);
    if (status != GrabSuccess) {
      fprintf(stderr, "sweep: Cannot grab >:-<, aborted. \n");
        return 0;
    }

    XMaskEvent(dpy, ButtonMask, &ev);
    e = &ev.xbutton;
//    if (e->button == Button3) {
//      ungrab(e);
//      return 0;
//    }
//    if (c->size.flags & (PMinSize|PBaseSize))
//        setmouse(e->x+c->min_dx, e->y+c->min_dy);
    XChangeActivePointerGrab(dpy, ButtonMask, sizeAllCursor.handle(), e->time);
    // das None daruber muss auch der cursor sein wie bei grab!!! (Matthias?)
    // jedes legt noch schnell ein Ei, und dann kommt der Tod herbei (Brian)
    return sweepdrag(c, e, sweepcalc);
}


int drag(Client *c){
    XEvent ev;
    int status;

    status = grab(root, ButtonMask, None, 0);
    if (status != GrabSuccess) {
      //graberror("drag", status); /* */
        return 0;
    }

    if (c->init){
        setmouse(c->x, c->y);
    }
    else{
        getmouse(&c->x, &c->y);     /* start at current mouse pos */
    }
    
    return sweepdrag(c, 0, dragcalc);

}  /* end drag */

void resizedrag(Client *c){
  int odx, ody;

    if (c == 0)
        return;
    c->dx2 = c->dx;
    c->dy2 = c->dy;
    XChangeActivePointerGrab(dpy, ButtonMask, sizeFDiagCursor.handle(), 0);
    sweepdrag(c,0,resizecalc);
    active(c);
    XRaiseWindow(dpy, c->parent_window);
      c->setGeometry(c->x , c->y ,
		     c->dx , c->dy);
      
    
    if (c->dx == c->dx2 && c->dy == c->dy2)
      sendconfig(c);
    else
      {
	if (c->trans != None) 
	  XMoveResizeWindow(dpy, c->window, (BORDER), (BORDER), c->dx - 2*BORDER, c->dy - 2*BORDER);
	else
	  XMoveResizeWindow(dpy, c->window, (BORDER), (BORDER) + TITLEBAR_HEIGHT,
			    c->dx - 2*BORDER, c->dy - 2*BORDER - TITLEBAR_HEIGHT);
      }
}

void getmouse(int *x, int *y){
    Window dw1, dw2;
    int t1, t2;
    unsigned int t3;

    XQueryPointer(dpy, root, &dw1, &dw2, x, y, &t1, &t2, &t3);
}

void setmouse(int x, int y){
    XWarpPointer(dpy, None, root, None, None, None, None, x, y);
}
