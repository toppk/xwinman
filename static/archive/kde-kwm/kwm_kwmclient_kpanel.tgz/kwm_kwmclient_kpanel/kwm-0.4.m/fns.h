/* Portions Copyright (c) 1994 David Hogan, see README for licence details */

#include <X11/extensions/shape.h>

class Client;

void gravitate(Client* c, int invert);
void withdraw(Client *c);
void cleanup();
void cmapfocus(Client *c);
void setwindowlabel(Client *c);
void getwindowtrans(Client * c);
void getcmaps(Client *c);
void setshape(Client* c);

void active(Client *c);
void nofocus();
Client * getclient(Window w, int create);
void rmclient(Client *c);
void fatal(char *s);
int handler(Display *d, XErrorEvent *e);
int grab(Window w, int mask, Cursor curs, int t);
void ungrab(XButtonEvent *e);
void sweepcalc(Client *c, int x, int y);
void resizecalc(Client *c, int x, int y);
void dragcalc(Client* c, int x, int y);
void drawbound(Client* c);
int sweep(Client *c);
int drag(Client *c);
void resizedrag(Client *c);
void getmouse(int *x, int *y);
void setmouse(int x, int y);
void initkwm(int argc, char* argv[]);
void usage();
void sendcmessage(Window w, Atom a, long x);
Time timestamp();
void sendconfig(Client* c);
void scanwins();
void configurereq(XConfigureRequestEvent *e);
void mapreq(XMapRequestEvent *e);
void unmap(XUnmapEvent *e);
void circulatereq(XCirculateRequestEvent *e);
void newwindow(XCreateWindowEvent *e);
void destroywin(Window w);
void clientmesg(XClientMessageEvent *e);
void cmap(XColormapEvent *e);
void property(XPropertyEvent *e);
void reparent(XReparentEvent *e);
void shapenotify(XShapeEvent *e);
void enter(XCrossingEvent *e);
void sighandler(int);
void open();
void initdevel();
int manage(Client*  c, int mapped);
int _getprop(Window w, Atom a, Atom type, long len, unsigned char **p);
char * getprop(Window w, Atom a);
int getiprop(Window w, Atom a);
void setwindowstate(Client *c, int state);
int getwindowstate(Window w, int* state);
void getwindowproto(Client *c);
void move(Client *c);
void hidec(Client *c);
void unhide(int n, int map);
void unhidec(Client *c, int map);
void renamec(Client *c, char* name);
void reshape(Client *c);

int sweepdrag(Client* c, XButtonEvent *e0, void (*recalc)( Client *, int, int) );

