/* Copyright (c) 1997 Brian Cooper */
/* Portions Copyright (c) 1994 David Hogan, see README for licence details */

#ifndef DAT_H
#define DAT_H

#define BORDER     4
#define BUTTON_SIZE    16
#define TITLEBAR_HEIGHT 20
#define CORNER          20
#define MAXHIDDEN   32
#define B3FIXED     5


#define AllButtonMask   (Button1Mask|Button2Mask|Button3Mask \
            |Button4Mask|Button5Mask)
#define ButtonMask  (ButtonPressMask|ButtonReleaseMask)
#define MenuMask    (ButtonMask|ButtonMotionMask|ExposureMask)
#define MenuGrabMask    (ButtonMask|ButtonMotionMask|StructureNotifyMask)


#define hidden(c)       ((c)->state == IconicState)
#define withdrawn(c)    ((c)->state == WithdrawnState)
#define normalstate(c)       ((c)->state == NormalState)

/* c->proto */
#define Pdelete     1
#define Ptakefocus  2

extern int          currentVD;

/* kwm.c */
extern Display      *dpy;
extern int          screen;
extern Window       root;
extern Colormap     def_cmap;
extern int          initting;
extern GC           gc;
extern XFontStruct  *font;
extern int          nostalgia;
extern Atom         wm_state;
extern Atom         _9wm_hold_mode;
extern Atom         wm_protocols;
extern Atom         wm_delete;
extern Atom         wm_take_focus;
extern Atom         wm_colormaps;
extern unsigned long    black9;
extern unsigned long    white9;
extern Bool         shape;
extern char         *termprog;
extern char         *shell;
extern char         *version[];
extern int          min_cmaps;
extern int          curtime;


/* cursor.c */
extern Cursor       target;
extern Cursor       sweep0;
extern Cursor       boxcurs;
extern Cursor       arrow;

/* error.c */
extern int          ignore_badwindow;

#endif // DAT_H
