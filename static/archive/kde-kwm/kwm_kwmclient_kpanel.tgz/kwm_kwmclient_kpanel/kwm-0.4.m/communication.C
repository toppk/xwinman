// communication.C
//
// Running proposal for a communication
// between kwm and modules like kpanel
//
// Part of the KDE project.
//
// Copyright (C) 1997 Matthias Ettrich
//

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include <X11/X.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <qlist.h>

#include "dat.h"
#include "fns.h"

#include "communication.h"

extern Window root;

Atom kwm_add_window;
Atom kwm_remove_window;
Atom kwm_un_minimize_window;
Atom kwm_register_module;
Atom kwm_unregister_module;
Atom kwm_command;

QList <Window> *kwmcom_module_windows = NULL;


void kwmcom_init(){
  kwmcom_module_windows = new QList <Window>;
  kwm_add_window = XInternAtom(dpy, "KWM_ADD_WINDOW", False);
  kwm_remove_window = XInternAtom(dpy, "KWM_REMOVE_WINDOW", False);
  kwm_un_minimize_window = XInternAtom(dpy, "KWM_UN_MINIMIZE_WINDOW", False);
  kwm_register_module = XInternAtom(dpy, "KWM_REGISTER_MODULE", False);
  kwm_unregister_module = XInternAtom(dpy, "KWM_UNREGISTER_MODULE", False);
  kwm_command = XInternAtom(dpy, "KWM_COMMAND", False);
}

void kwmcom_send_to_modules(Atom a, long a1, long a2, 
			    long a3, long a4, long a5){
  XEvent ev;
  int status;
  long mask;
  memset(&ev, 0, sizeof(ev));
  ev.xclient.type = ClientMessage;
  ev.xclient.message_type = a;
  ev.xclient.format = 32;
  
  ev.xclient.data.l[0]=a1;
  ev.xclient.data.l[1]=a2;
  ev.xclient.data.l[2]=a3;
  ev.xclient.data.l[3]=a4;
  ev.xclient.data.l[4]=a5;

  mask = 0L;
  
  QListIterator <Window> it(*kwmcom_module_windows);
  it.toFirst();
  while ( it.current() != 0L ){
    ev.xclient.window = *it.current();
    if (ev.xclient.window == root)
      mask = SubstructureRedirectMask;        /* magic! */
    status = XSendEvent(dpy, ev.xclient.window, False, mask, &ev);
    if (status == 0){
      fprintf(stderr, "kwm: kwmcom_send_window_cmessage failed\n");
      kwmcom_unregister_module(ev.xclient.window);
    }
    ++it;
  }
  XSync(dpy, False);
}

void kwmcom_send_to_modules(Atom a, char* s){
  XEvent ev;
  int status;
  long mask;
  memset(&ev, 0, sizeof(ev));
  ev.xclient.type = ClientMessage;
  ev.xclient.message_type = a;
  ev.xclient.format = 32;
  
  int i;
  for (i=0;i<19 && s[i];i++)
    ev.xclient.data.b[i]=s[i];

  mask = 0L;
  
  QListIterator <Window> it(*kwmcom_module_windows);
  it.toFirst();
  while ( it.current() != 0L ){
    ev.xclient.window = *it.current();
    if (ev.xclient.window == root)
      mask = SubstructureRedirectMask;        /* magic! */
    status = XSendEvent(dpy, ev.xclient.window, False, mask, &ev);
    if (status == 0){
      fprintf(stderr, "kwm: kwmcom_send_window_cmessage failed\n");
      kwmcom_unregister_module(ev.xclient.window);
    }
    ++it;
  }
  XSync(dpy, False);
}



void kwmcom_register_module(Window w){
  Window * w2 = new Window;
  *w2 = w;
  kwmcom_module_windows->append(w2);
}

void kwmcom_unregister_module(Window w){
  Window *w2;
  QListIterator <Window> it(*kwmcom_module_windows);
  it.toFirst();
  while ( (w2 = it.current()) != 0L ){
    if (*w2 == w){
      kwmcom_module_windows->remove(kwmcom_module_windows->find(w2));
      delete w2;
      return;
    }
    ++it;
  }
}


