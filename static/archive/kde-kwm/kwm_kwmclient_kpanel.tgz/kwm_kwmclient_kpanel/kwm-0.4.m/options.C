#include "options.h"

#include <qdialog.h>
#include <qlabel.h>
#include <qlined.h>
#include <qpushbt.h>
#include <qchkbox.h>
#include <qradiobt.h>
#include <qbttngrp.h>
#include <qlcdnum.h>
#include <qscrbar.h>
#include <qmenubar.h>
#include <qrect.h>

#include <qpainter.h>
#include <qpixmap.h>
#include <qstring.h>
#include <qdrawutl.h>
#include <qwindefs.h>
#include <qbitmap.h>

#include "Kconfig.h"

#include <stdlib.h>
#include <stdio.h>


   QCheckBox *aButton;
   QCheckBox *bButton;
   QCheckBox *cButton;
   QCheckBox *dButton;
   QCheckBox *eButton;
   QCheckBox *fButton;

   QComboBox *aType;   
   QComboBox *bType;   
   QComboBox *cType;   
   QComboBox *dType;   
   QComboBox *eType;   
   QComboBox *fType;   

   int ABUTTON;
   int BBUTTON;
   int CBUTTON;
   int DBUTTON;
   int EBUTTON;
   int FBUTTON;

extern KConfig *config;

TitleOptions::TitleOptions( QWidget *parent, const char *name)
    : QDialog( parent, name)
{ 
    QLabel *activecL    = new QLabel( this, "activecLabel" );
    QLabel *inactivecL    = new QLabel( this, "inactivecLabel" );
    QLabel *leftButtonsL    = new QLabel( this, "leftButtonsLabel" );
    QLabel *rightButtonsL    = new QLabel( this, "rightButtonsLabel" );
    aButton     = new QCheckBox(  this, "aButton" );
    bButton     = new QCheckBox(  this, "bButton" );
    cButton     = new QCheckBox(  this, "cButton" );
    dButton     = new QCheckBox(  this, "dButton" );
    eButton     = new QCheckBox(  this, "eButton" );
    fButton     = new QCheckBox(  this, "fButton" );
    aType       = new QComboBox(  this, "aType" );
    bType       = new QComboBox(  this, "bType" );
    cType       = new QComboBox(  this, "cType" );
    dType       = new QComboBox(  this, "dType" );
    eType       = new QComboBox(  this, "eType" );
    fType       = new QComboBox(  this, "fType" );
    QPushButton *defaultButton   = new QPushButton( this, "default" );
    QPushButton *applyButton     = new QPushButton( this, "apply" );
    QPushButton *cancelButton    = new QPushButton( this, "cancel" );
    
setName("Titlebar Options");

    activecL->setGeometry( 10, 5, 100, 20 );
    activecL->setAutoResize( TRUE );
    activecL->setText( " Active Colors : UNDER CONSTRUCTION" );
	   
    inactivecL->setGeometry( 10, 60, 100, 20 );
    inactivecL->setAutoResize( TRUE );
    inactivecL->setText( " Inactive Colors : UNDER CONSTRUCTION" );

    QFrame *separator = new QFrame( this, "separatorLine" );
    separator->setFrameStyle( QFrame::HLine | QFrame::Sunken );
    separator->setGeometry( 5, 115, 300, 4 );
	       
    leftButtonsL->setGeometry( 10, 120, 100, 20 );
    leftButtonsL->setAutoResize( TRUE );
    leftButtonsL->setText( " Left Buttons " );
 
    aButton->setGeometry( 10, 145, 80, 20 );
    aButton->setAutoResize( TRUE );
    aButton->setText( "Button A" );
    connect( aButton, SIGNAL(clicked()), SLOT(aClicked()) );

    aType->setGeometry( 10 + aButton->width() + 10, 142, 120, 20 );
    aType->insertItem( "(Un)-Maximize" , MAXIMIZE );
    aType->insertItem( "Minimize" , MINIMIZE);
    aType->insertItem( "Close" , CLOSE );
    aType->insertItem( "Sticky" , STICKY);
    connect( aType, SIGNAL(activated(int)),SLOT(comboBoxItemActivated(int)) );
    
    bButton->setGeometry( 10, 165, 80, 20 );
    bButton->setAutoResize( TRUE );
    bButton->setText( "Button B" );
    connect( bButton, SIGNAL(clicked()),SLOT(bClicked()) );
 
    bType->setGeometry( 10 + aButton->width() + 10, 162, aType->width(), aType->height() );
    bType->insertItem( "(Un)-Maximize" , MAXIMIZE);
    bType->insertItem( "Minimize" , MINIMIZE);
    bType->insertItem( "Close" , CLOSE);
    bType->insertItem( "Sticky" , STICKY);
    connect( bType, SIGNAL(activated(int)),SLOT(comboBoxItemActivated(int)) );
    
    cButton->setGeometry( 10, 185, 80, 20 );
    cButton->setAutoResize( TRUE );
    cButton->setText( "Button C" );
    connect( cButton, SIGNAL(clicked()),SLOT(cClicked()) );
 
    cType->setGeometry( 10 + aButton->width() + 10, 182, aType->width(), aType->height() );
    cType->insertItem( "(Un)-Maximize" , MAXIMIZE);
    cType->insertItem( "Minimize" , MINIMIZE);
    cType->insertItem( "Close" , CLOSE);
    cType->insertItem( "Sticky" , STICKY);
    connect( cType, SIGNAL(activated(int)),SLOT(comboBoxItemActivated(int)) );
    
    QFrame *separator2 = new QFrame( this, "separatorLine2" );
    separator2->setFrameStyle( QFrame::HLine | QFrame::Sunken );
    separator2->setGeometry( 5, 205, 300, 4 );
	       
    rightButtonsL->setGeometry( 10, 210, 100, 20 );
    rightButtonsL->setAutoResize( TRUE );
    rightButtonsL->setText( " Right Buttons " );
	   
    dButton->setGeometry( 10, 230, 80, 20 );
    dButton->setAutoResize( TRUE );
    dButton->setText( "Button D" );
    connect( dButton, SIGNAL(clicked()),SLOT(dClicked()) );
 
    dType->setGeometry( 10 + aButton->width() + 10, 227, aType->width(), aType->height() );
    dType->insertItem( "(Un)-Maximize" , MAXIMIZE);
    dType->insertItem( "Minimize" , MINIMIZE);
    dType->insertItem( "Close" , CLOSE);
    dType->insertItem( "Sticky" , STICKY);
    connect( dType, SIGNAL(activated(int)),SLOT(comboBoxItemActivated(int)) );
    
    eButton->setGeometry( 10, 250, 80, 20 );
    eButton->setAutoResize( TRUE );    
    eButton->setText( "Button E" );
    connect( eButton, SIGNAL(clicked()),SLOT(eClicked()) );
 
    eType->setGeometry( 10 + aButton->width() + 10, 247, aType->width(), aType->height() );
    eType->insertItem( "(Un)-Maximize" , MAXIMIZE);
    eType->insertItem( "Minimize" , MINIMIZE);
    eType->insertItem( "Close" , CLOSE);
    eType->insertItem( "Sticky" , STICKY);
    connect( eType, SIGNAL(activated(int)),SLOT(comboBoxItemActivated(int)) );
    
    fButton->setGeometry( 10, 270, 80, 20 );
    fButton->setAutoResize( TRUE );
    fButton->setText( "Button F" );
    connect( fButton, SIGNAL(clicked()),SLOT(fClicked()) );
 
    fType->setGeometry( 10 + aButton->width() + 10, 267, aType->width(), aType->height() );
    fType->insertItem( "(Un)-Maximize" , MAXIMIZE);
    fType->insertItem( "Minimize" , MINIMIZE);
    fType->insertItem( "Close" , CLOSE);
    fType->insertItem( "Sticky" , STICKY);
    connect( fType, SIGNAL(activated(int)),SLOT(comboBoxItemActivated(int)) );
    
    QFrame *separator3 = new QFrame( this, "separatorLine3" );
    separator3->setFrameStyle( QFrame::HLine | QFrame::Sunken );
    separator3->setGeometry( 5, 290, 300, 4 );
		    
    defaultButton->setAutoResize( TRUE );
    defaultButton->setText( "Default" );
    defaultButton->setGeometry( 5, 385, defaultButton->width(), defaultButton->height() );
    connect( defaultButton, SIGNAL(clicked()), SLOT(doDefault()) );

    applyButton->setAutoResize( TRUE );
    applyButton->setText( "Apply" );
    applyButton->setGeometry( 150 - applyButton->width()/2, 385, applyButton->width(), applyButton->height() );
    connect( applyButton, SIGNAL(clicked()), SLOT(doApply()) );

    cancelButton->setAutoResize( TRUE );
    cancelButton->setText( "Cancel" );
    cancelButton->setDefault( TRUE );
    cancelButton->setGeometry( 295 - cancelButton->width(), 385, cancelButton->width(), cancelButton->height() );
    connect( cancelButton, SIGNAL(clicked()), SLOT(doCancel()) );

    sframe = new SampleFrame(this,"SampleFrame");
    sframe->setGeometry(5,300,300,71);
    sframe->show();

    adjustSize();
    
};  /* end TitleOptions::TitleOptions */

void TitleOptions::comboBoxItemActivated(int dummyfornow)
{

  sframe->changeSample();
  
};  /* end TitleOptions::comboBoxItemActivated */

void TitleOptions::doDefault(){

  aType->setCurrentItem( CLOSE );
  bType->setCurrentItem( STICKY );
  cType->setCurrentItem( MAXIMIZE );
  dType->setCurrentItem( MAXIMIZE );
  eType->setCurrentItem( MINIMIZE );
  fType->setCurrentItem( MAXIMIZE );
  
  aButton->setChecked( TRUE );
  bButton->setChecked( TRUE );
  cButton->setChecked( FALSE );
  dButton->setChecked( FALSE );
  eButton->setChecked( TRUE );
  fButton->setChecked( TRUE );
  
  sframe->changeSample();
   
}  /* end TitleOptions::doDefault */

void TitleOptions::doApply(){
if(!config) {
  fprintf(stderr,"Null KConfig\n");
  done(-1);
}
   config->setGroup("Titlebar");
   if( aButton->isChecked() ){
     if( aType->currentItem() == MAXIMIZE )
       config->writeEntry("ButtonA","Maximize");
     else if( aType->currentItem() == MINIMIZE )
       config->writeEntry("ButtonA","Minimize");
     else if( aType->currentItem() == CLOSE )
       config->writeEntry("ButtonA","Close");
     else if( aType->currentItem() == STICKY )
       config->writeEntry("ButtonA","Sticky");
   }
   else
     config->writeEntry("ButtonA","Off");
   
   if( bButton->isChecked() ){
     if( bType->currentItem() == MAXIMIZE )
       config->writeEntry("ButtonB","Maximize");
     else if( bType->currentItem() == MINIMIZE )
       config->writeEntry("ButtonB","Minimize");
     else if( bType->currentItem() == CLOSE )
       config->writeEntry("ButtonB","Close");
     else if( bType->currentItem() == STICKY )
       config->writeEntry("ButtonB","Sticky");
   }
   else
     config->writeEntry("ButtonB","Off");
   
   if( cButton->isChecked() ){
     if( cType->currentItem() == MAXIMIZE )
       config->writeEntry("ButtonC","Maximize");
     else if( cType->currentItem() == MINIMIZE )
       config->writeEntry("ButtonC","Minimize");
     else if( cType->currentItem() == CLOSE )
       config->writeEntry("ButtonC","Close");
     else if( cType->currentItem() == STICKY )
       config->writeEntry("ButtonC","Sticky");
   }
   else
     config->writeEntry("ButtonC","Off");
   
   if( dButton->isChecked() ){
     if( dType->currentItem() == MAXIMIZE )
       config->writeEntry("ButtonD","Maximize");
     else if( dType->currentItem() == MINIMIZE )
       config->writeEntry("ButtonD","Minimize");
     else if( dType->currentItem() == CLOSE )
       config->writeEntry("ButtonD","Close");
     else if( dType->currentItem() == STICKY )
       config->writeEntry("ButtonD","Sticky");
   }
   else
     config->writeEntry("ButtonD","Off");
   
   if( eButton->isChecked() ){
     if( eType->currentItem() == MAXIMIZE )
       config->writeEntry("ButtonE","Maximize");
     else if( eType->currentItem() == MINIMIZE )
       config->writeEntry("ButtonE","Minimize");
     else if( eType->currentItem() == CLOSE )
       config->writeEntry("ButtonE","Close");
     else if( eType->currentItem() == STICKY )
       config->writeEntry("ButtonE","Sticky");
   }
   else
     config->writeEntry("ButtonE","Off");
     
   if( fButton->isChecked() ){
     if( fType->currentItem() == MAXIMIZE )
       config->writeEntry("ButtonF","Maximize");
     else if( fType->currentItem() == MINIMIZE )
       config->writeEntry("ButtonF","Minimize");
     else if( fType->currentItem() == CLOSE )
       config->writeEntry("ButtonF","Close");
     else if( fType->currentItem() == STICKY )
       config->writeEntry("ButtonF","Sticky");
   }
   else
     config->writeEntry("ButtonF","Off");
   
   done(1);
   
}  /* end TitleOptions::doApply */

void TitleOptions::doCancel(){

   done(0);   // Make this more rigorous
   
}  /* end TitleOptions::doApply */


void TitleOptions::aClicked()
{
   // If we are turning off A button, B must also be off
   if ( !aButton->isChecked() ){
     if( bButton->isChecked() ){
       bButton->setChecked( FALSE );
       bClicked();
       // by returning here reduce flicker by letting B update sample
       return;
     }
   }
   
   sframe->changeSample();

}  /* end TitleOptions::aClicked */

void TitleOptions::bClicked()
{
   if( !aButton->isChecked() && bButton->isChecked() ){
     bButton->setChecked( FALSE );
     return;
   }
     
   // If we are turning off B button, C must also be off
   if ( !bButton->isChecked() ){
     if( cButton->isChecked() ){
       cButton->setChecked( FALSE );
       cClicked();
       // by returning here reduce flicker by letting C update sample
       return;
     }
   }
     
   sframe->changeSample();
   
}  /* end TitleOptions::bClicked */

void TitleOptions::cClicked()
{
   if( !bButton->isChecked() && cButton->isChecked() ){
     cButton->setChecked( FALSE );
     return;
   }
     
   sframe->changeSample();
   
}  /* end TitleOptions::cClicked */

void TitleOptions::dClicked()
{
   if( (dButton->isChecked())  && (!eButton->isChecked()) ){
     dButton->setChecked( FALSE );
     return;
   }

   sframe->changeSample();
   
}  /* end TitleOptions::dClicked */

void TitleOptions::eClicked()
{
   // If we are turning off E button, D must also be off
   if ( !eButton->isChecked() ){
     if( dButton->isChecked() ){
       dButton->setChecked( FALSE );
       dClicked();
       return;
     }
   }

   if( (eButton->isChecked())  && (!fButton->isChecked()) ){
     eButton->setChecked( FALSE );
     return;
   }

   sframe->changeSample();
   
}  /* end TitleOptions::eClicked */

void TitleOptions::fClicked()
{
   // If we are turning off F button, E must also be off
   if ( !fButton->isChecked() ){
     if( eButton->isChecked() ){
       eButton->setChecked( FALSE );
       eClicked();
       return;
     }
   }

   sframe->changeSample();
   
}  /* end TitleOptions::eClicked */

SampleFrame::SampleFrame( QWidget *parent, const char *name)
    : QFrame( parent, name)
{
    setFrameStyle( QFrame::WinPanel | QFrame::Sunken );
    setBackgroundColor(white);

    activeSample = new SampleClient(this, "activesample", TRUE);
    activeSample->setGeometry(5,5,290,4*2+20);
    
    inactiveSample = new SampleClient(this, "inactivesample", FALSE);
    inactiveSample->setGeometry(5,10 + 4*2 +20,290,4*2+20);

}  /* end SampleFrame::SampleFrame */

void SampleFrame::changeSample(){

    if (activeSample) delete activeSample;
    if (inactiveSample) delete inactiveSample;
    
    activeSample = new SampleClient(this, "activesample", TRUE);
    activeSample->setGeometry(5,5,290,4*2+20);
    
    inactiveSample = new SampleClient(this, "inactivesample", FALSE);
    inactiveSample->setGeometry(5,10 + 4*2 +20,290,4*2+20);

    activeSample->show();
    inactiveSample->show();
    
}  /* end SampleFrame::changeSample */

SampleClient::SampleClient( QWidget *parent, const char *name, bool is_active)
    : QFrame( parent, name)
{
  static QColorGroup active_grp( black, QColor(0, 0, 128),
				white, lightGray.dark(), gray,
				white, white );
  static QColorGroup inactive_grp( black, gray,
				white, lightGray.dark(), gray,
				black, white );

 setFrameStyle( QFrame::WinPanel | QFrame::Raised );
  
  int rleft = 4 + 2;
  int rright = 290 - 4 - 2;
  
  if(aButton->isChecked()){
    rleft += 16;
    QPushButton *ab = new QPushButton(this,"aB");
    ab->setGeometry(4,6,16,16);
    ab->setPixmap(getBitmap(aType));
  }
  if(bButton->isChecked()){
    rleft += 16;
    QPushButton *bb = new QPushButton(this,"bB");
    bb->setGeometry(20,6,16,16);
    bb->setPixmap(getBitmap(bType));
  }
  if(cButton->isChecked()){
    rleft += 16;
    QPushButton *cb = new QPushButton(this,"cB");
    cb->setGeometry(36,6,16,16);
    cb->setPixmap(getBitmap(cType));
  }
  if(dButton->isChecked()){
    rright -= 16;
    QPushButton *db = new QPushButton(this,"dB");
    db->setGeometry(238,6,16,16);
    db->setPixmap(getBitmap(dType));
  }
  if(eButton->isChecked()){
    rright -= 16;
    QPushButton *eb = new QPushButton(this,"eB");
    eb->setGeometry(254,6,16,16);
    eb->setPixmap(getBitmap(eType));
  }
  if(fButton->isChecked()){
    rright -= 16;
    QPushButton *fb = new QPushButton(this,"fB");
    fb->setGeometry(270,6,16,16);
    fb->setPixmap(getBitmap(fType));
  }
    
  
  QLabel *title = new QLabel(this,"titlerect");
    title->setGeometry(rleft,4,rright - rleft,20);
    title->setFont(QFont("Helvetica", 12, QFont::Bold));
    title->setAlignment( AlignCenter );
  if(is_active){
    title->setPalette( QPalette(active_grp,active_grp,active_grp) );
    title->setText(" Sample Active Window");
  }
  else{
    title->setPalette( QPalette(inactive_grp,inactive_grp,inactive_grp) );
    title->setText(" Sample Inactive Window");
  }

}  /* end SampleClient::SampleClient */

QBitmap SampleClient::getBitmap( QComboBox *funcType ){

  QString s = getenv("KDEDIR");
  s += "/lib/pics/";
  
  switch ( funcType->currentItem() ){
    case MAXIMIZE:
      return QBitmap::QBitmap(s + "maximize.xbm");
      break;
    case MINIMIZE:
      return QBitmap::QBitmap(s + "minimize.xbm");
      break;
    case CLOSE:
      return QBitmap::QBitmap(s + "close.xbm");
      break;
    case STICKY:
      return QBitmap::QBitmap(s + "pinup.xbm");
      break;
    default:
      fprintf(stderr,"Button Function type non-existent\n");
      break;
  }  /* end switch */
}  /* end SampleClient::getBitmap */
