#ifndef DEVEL_H
#define DEVEL_H
// Some Global variables and defines for turning on and off options

#define TRANSPARENT 0
#define OPAQUE      1

#define W95BUTTONS          0
#define REVW95BUTTONS       1
#define CROSSBUTTONS        2
#define TAJBUTTONS          3
#define XONLEFTBUTTONS      4

#define MARKOSPACING        0
#define NONMARKOSPACING     1

extern int WindowMoveType;
extern int buttonGroup;
extern int buttonSpacing;
extern int BUTTON_SEPARATION;
extern int TITLEBUTTON_SEPARATION;
extern int TITLEWINDOW_SEPARATION;

#endif // DEVEL_H
