#include <stdio.h>
#include <stdlib.h>
#include <X11/X.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include "dat.h"
#include "fns.h"

int     ignore_badwindow;

void fatal(char *s){
    fprintf(stderr, "kwm: ");
    perror(s);
    fprintf(stderr, "\n");
    exit(1);
}

int handler(Display *d, XErrorEvent *e){
    char msg[80], req[80], number[80];

    if (initting && (e->request_code == X_ChangeWindowAttributes) && (e->error_code == BadAccess)) {
        fprintf(stderr, "kwm: it looks like there's already a window manager running;  kwm not started\n");
        exit(1);
    }

    if (ignore_badwindow && (e->error_code == BadWindow || e->error_code == BadColor))
        return 0;

    XGetErrorText(d, e->error_code, msg, sizeof(msg));
    sprintf(number, "%d", e->request_code);
    XGetErrorDatabaseText(d, "XRequest", number, "<unknown>", req, sizeof(req));

    fprintf(stderr, "kwm: %s(0x%x): %s\n", req, e->resourceid, msg);

    if (initting) {
        fprintf(stderr, "kwm: failure during initialisation; aborting\n");
        exit(1);
    }
    return 0;
}




