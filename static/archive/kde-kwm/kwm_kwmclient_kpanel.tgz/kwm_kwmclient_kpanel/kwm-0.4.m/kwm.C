#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <errno.h>
#include <X11/X.h>
#include <X11/Xos.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/extensions/shape.h>

#include "dat.h"
#include "fns.h"
#include "patchlevel.h"
#include "devel.h"

#include "client.h"

// Matthias
#include "communication.h" 
#include "main.h"
extern wmMenuWidget *m; 


char    *version[] = 
{
    "kwm: version 0.4 Copyright (c) 1996, 1997 Brian Cooper \n"
    "     based on version 0.1 Copyright (c) 1996 Matthias Ettrich \n"
    "     Parts derived from 9wm 1.1 Copyright (c) 1994 David Hogan\n"
    "     No warranty. Please see the README's\n",0
};


int             screen;
Display * dpy;
Window          root;
Colormap        def_cmap;
int             initting;
GC              gc;
unsigned long   black9;
unsigned long   white9;
XFontStruct     *font;
char            **myargv;
char            *termprog;
Bool            shape;
int             shape_event;
int             min_cmaps;
int             curtime;
int             signalled;

// no longer needed (Matthias)
// Atom        exit_kwm;
// Atom        restart_kwm;
Atom        wm_state;
Atom        wm_change_state;
Atom        wm_protocols;
Atom        wm_delete;
Atom        wm_take_focus;
Atom        wm_colormaps;
Atom        _kwm_running;

void    usage(), sighandler(int);

char    *fontlist[] = {
    "lucm.latin1.9",
    "blit",
    "9x15bold",
    "lucidasanstypewriter-12",
    "fixed",
    0,
};


void initkwm(int argc, char* argv[]){
    int i, status, do_exit, do_restart, dummy;
    unsigned long mask;
    XEvent ev;
    XGCValues gv;
    XSetWindowAttributes attr;
    char *fname;

    myargv = argv;          /* for restart */

    do_exit = do_restart = 0;
    font = 0;
    fname = 0;
    for (i = 1; i < argc; i++)
        if (strcmp(argv[i], "-font") == 0 && i+1<argc) {
            i++;
            fname = argv[i];
        }
        else if (strcmp(argv[i], "-term") == 0 && i+1<argc)
            termprog = argv[++i];
        else if (strcmp(argv[i], "-version") == 0) {
            fprintf(stderr, "%s", version[0]);
            if (PATCHLEVEL > 0)
                fprintf(stderr, "patch level %d", PATCHLEVEL);
            putc('\n', stderr);
            exit(0);
        }
        else if (argv[i][0] == '-')
            usage();
        else
            break;
// no longer needed (Matthias)
//     for (; i < argc; i++)
//         if (strcmp(argv[i], "exit") == 0)
//             do_exit++;
//         else if (strcmp(argv[i], "restart") == 0)
//             do_restart++;
//         else
//             usage();

//     if (do_exit && do_restart)
//         usage();
     

    /*
      Matthias
    dpy = XOpenDisplay("");
    */ 
    if (dpy == 0)
        fatal("can't open display");
    screen = DefaultScreen(dpy);
    root = RootWindow(dpy, screen);
    def_cmap = DefaultColormap(dpy, screen);
    min_cmaps = MinCmapsOfScreen(ScreenOfDisplay(dpy, screen));

    initting = 1;
    XSetErrorHandler(handler);
    if (signal(SIGTERM, sighandler) == SIG_IGN)
        signal(SIGTERM, SIG_IGN);
    if (signal(SIGINT, sighandler) == SIG_IGN)
        signal(SIGINT, SIG_IGN);
    if (signal(SIGHUP, sighandler) == SIG_IGN)
        signal(SIGHUP, SIG_IGN);

// no longer needed (Matthias)
//     exit_kwm = XInternAtom(dpy, "KWM_EXIT", False);
//     restart_kwm = XInternAtom(dpy, "KWM_RESTART", False);

    curtime = -1;       /* don't care */
//     if (do_exit) {
//         sendcmessage(root, exit_kwm, 0L);
//         XSync(dpy, False);
//         exit(0);
//     }
//     if (do_restart) {
//         sendcmessage(root, restart_kwm, 0L);
//         XSync(dpy, False);
//         exit(0);
//     }

    wm_state = XInternAtom(dpy, "WM_STATE", False);
    wm_change_state = XInternAtom(dpy, "WM_CHANGE_STATE", False);
    wm_protocols = XInternAtom(dpy, "WM_PROTOCOLS", False);
    wm_delete = XInternAtom(dpy, "WM_DELETE_WINDOW", False);
    wm_take_focus = XInternAtom(dpy, "WM_TAKE_FOCUS", False);
    wm_colormaps = XInternAtom(dpy, "WM_COLORMAP_WINDOWS", False);
    _kwm_running = XInternAtom(dpy, "_KWM_RUNNING", False);

    black9 = BlackPixel(dpy, screen);
    white9 = WhitePixel(dpy, screen);

    kwmcom_init(); // Matthias

    if (fname != 0)
        if ((font = XLoadQueryFont(dpy, fname)) == 0)
            fprintf(stderr, "kwm: warning: can't load font %s\n", fname);

    if (font == 0) {
        i = 0;
        for (;;) {
            fname = fontlist[i++];
            if (fname == 0) {
                fprintf(stderr, "kwm: can't find a font\n");
                exit(1);
            }
            font = XLoadQueryFont(dpy, fname);
            if (font != 0)
                break;
        }
    }

    gv.foreground = black9^white9;
    gv.background = white9;
    gv.font = font->fid;
    gv.function = GXxor;
    gv.line_width = 0;
    gv.subwindow_mode = IncludeInferiors;
    mask = GCForeground | GCBackground | GCFunction | GCFont | GCLineWidth
        | GCSubwindowMode;
    gc = XCreateGC(dpy, root, mask, &gv);


#ifdef  SHAPE
    shape = XShapeQueryExtension(dpy, &shape_event, &dummy);
#endif


    XSelectInput(dpy, root, 
		 ButtonPressMask | ButtonReleaseMask |
		 PropertyChangeMask |
		 ColormapChangeMask |
 		 SubstructureRedirectMask |
 		 SubstructureNotifyMask 
 		 );


    XSync(dpy, False);


    XSync(dpy, False);
    initting = 0;

    nofocus();
    scanwins();
}


void usage() {
    fprintf(stderr, "usage: kwm [-grey] [-version] [-font fname] [-term prog] [exit|restart]\n");
    exit(1);
}

void sendcmessage(Window w, Atom a, long x){
    XEvent ev;
    int status;
    long mask;

    memset(&ev, 0, sizeof(ev));
    ev.xclient.type = ClientMessage;
    ev.xclient.window = w;
    ev.xclient.message_type = a;
    ev.xclient.format = 32;
    ev.xclient.data.l[0] = x;
    ev.xclient.data.l[1] = timestamp();
    mask = 0L;
    if (w == root)
        mask = SubstructureRedirectMask;        /* magic! */
    status = XSendEvent(dpy, w, False, mask, &ev);
    if (status == 0)
        fprintf(stderr, "kwm: sendcmessage failed\n");
}

Time timestamp(){
    XEvent ev;

    if (curtime == CurrentTime) {
        XChangeProperty(dpy, root, _kwm_running, _kwm_running, 8,
                PropModeAppend, (unsigned char *)"", 0);
        XMaskEvent(dpy, PropertyChangeMask, &ev);
        curtime = ev.xproperty.time;
    }
    return curtime;
}

void sendconfig(Client* c) {
    XConfigureEvent ce;

fprintf(stderr,"friggin' sendconfig.\n");

    ce.type = ConfigureNotify;
    ce.event = c->window;
    ce.window = c->window;

if (!c->already_managed){
  fprintf(stderr,"Hey, this one's not managed!\n");
  return;
}

    if(!c->trans){
      ce.x = c->x + BORDER;
      ce.y = c->y + BORDER + TITLEBAR_HEIGHT;
      ce.width = c->dx - 2*BORDER;
      ce.height = c->dy - 2*BORDER - TITLEBAR_HEIGHT;
    }
    else{
      ce.x = c->x + BORDER;
      ce.y = c->y + BORDER;
      ce.width = c->dx - 2*BORDER;
      ce.height = c->dy - 2*BORDER;
    }
    ce.border_width = c->border;
    ce.above = None;
    ce.override_redirect = 0;
    XSendEvent(dpy, c->window, False, StructureNotifyMask, (XEvent*)&ce);
}

void scanwins() {
    unsigned int i, nwins;
    Client *c;
    Window dw1, dw2, *wins;
    XWindowAttributes attr;

    XQueryTree(dpy, root, &dw1, &dw2, &wins, &nwins);
    for (i = 0; i < nwins; i++) {
        XGetWindowAttributes(dpy, wins[i], &attr);
        if (attr.override_redirect )
            continue;
        c = getclient(wins[i], 1);
        if (c != 0 && c->window == wins[i]) {
            c->x = attr.x;     
            c->y = attr.y;
            c->dx = attr.width;  // manage readjusts these.
            c->dy = attr.height; // probably this should also be in manage()
            c->border = attr.border_width;
            if (attr.map_state == IsViewable)
                manage(c, 1);
        }
    }
    XFree((void *) wins);   /* cast is to shut stoopid compiler up */
}

void configurereq(XConfigureRequestEvent *e) {
    XWindowChanges wc;
    XConfigureEvent ce;
    Client *c;
fprintf(stderr,"configurereq\n");
    /* we don't set curtime as nothing here uses it */
    c = getclient(e->window, 0);  
    if (c) {                    // client already exists for this window
        gravitate(c, 1);
        if (e->value_mask & CWX)
            c->x = e->x;
        if (e->value_mask & CWY)
            c->y = e->y;
      if(!c->trans){
        if (e->value_mask & CWWidth)
            c->dx = e->width + 2*BORDER;
        if (e->value_mask & CWHeight)
            c->dy = e->height + 2*BORDER + TITLEBAR_HEIGHT;
        if (e->value_mask & CWBorderWidth)
            c->border = e->border_width;
       }
       else{
//      if (e->value_mask & CWX)
//            c->x = e->x - BORDER;
//        if (e->value_mask & CWY)
//            c->y = e->y - BORDER;
        if (e->value_mask & CWWidth)
            c->dx = e->width + 2*BORDER;
        if (e->value_mask & CWHeight)
            c->dy = e->height + 2*BORDER;
        if (e->value_mask & CWBorderWidth)
            c->border = e->border_width;
	}
        gravitate(c, 0);
        if (c->parent_window != root && c->window == e->window) {

            wc.x = c->x;
            wc.y = c->y;

            wc.width = c->dx;
            wc.height = c->dy;
            wc.border_width = 1;
            wc.sibling = e->above;
            wc.stack_mode = e->detail;
            XConfigureWindow(dpy, e->parent, e->value_mask, &wc);
            sendconfig(c);
        }
    }
else
  fprintf(stderr,"configurereq for window w/ no client\n");
  
    if (c && c->init) {
        wc.x = BORDER;
	if(!c->trans)
          wc.y = BORDER+TITLEBAR_HEIGHT;
	else
	  wc.y = BORDER;
    }
    else {
        wc.x = e->x;
        wc.y = e->y;
    }
    
    wc.width = e->width;
    wc.height = e->height;
    wc.border_width = 0; 

    wc.sibling = e->above;
    wc.stack_mode = e->detail;
    e->value_mask |= CWBorderWidth;

    XConfigureWindow(dpy, e->window, e->value_mask, &wc);
}

void mapreq(XMapRequestEvent *e){
    Client *c;
    XWindowAttributes attr;

fprintf(stderr,"mapreq\n");
    curtime = CurrentTime;
    c = getclient(e->window, 0);
    if (c == 0 || c->window != e->window) {
        fprintf(stderr, "kwm: bogus mapreq %x %x\n", c, e->window);
        return;
    }

    switch (c->state) {
    case WithdrawnState:
    printf("mapreq...WithdrawnState\n");
        if (!c->already_managed) {


        XGetWindowAttributes(dpy, e->window, &attr);
            c->x = attr.x;     
            c->y = attr.y;
            c->dx = attr.width;  // manage readjusts these.
            c->dy = attr.height; // probably this should also be in manage()

            if (!manage(c, 0))
                return;
            break;
	}
	if (c->trans)
	  XReparentWindow(dpy, c->window, c->parent_window, (BORDER), (BORDER));
	else
	  XReparentWindow(dpy, c->window, c->parent_window, (BORDER), (BORDER) + 
			  TITLEBAR_HEIGHT);
	XAddToSaveSet(dpy, c->window);
	
        /* fall through... */
    case NormalState:
        XMapRaised(dpy, c->parent_window);
        XMapWindow(dpy, c->window);
        setwindowstate(c, NormalState);
        break;
    case IconicState:
        unhidec(c, 1);
        break;
    }
}


void unmap(XUnmapEvent *e){
    Client *c;

    curtime = CurrentTime;
    c = getclient(e->window, 0);
    if (c) {
        switch (c->state) {
        case IconicState:
            if (e->send_event) {
                unhidec(c, 0);
                withdraw(c);
            }
            break;
        case NormalState:
            if (c == current)
                nofocus();
            if (!c->reparenting)
                withdraw(c);
            break;
        }
        c->reparenting = 0;
    }
}

void circulatereq(XCirculateRequestEvent *e){
    fprintf(stderr, "It must be the warlock Krill!\n");  /* :-) */
}

void newwindow(XCreateWindowEvent *e){
    Client *c;
    XWindowAttributes attr;
    int n=1, order;
    
    printf("newwindow\n");
    /* we don't set curtime as nothing here uses it ???  */
    if (e->override_redirect){
        return;
    }

    c = getclient(e->window, 1);

    if (c && e->window == c->parent_window){
      if (c->already_got_create_event){
	// this hack means that the window and the client are already destroyed (Matthias)
	rmclient(c);
	return;
      }
      c->already_got_create_event = TRUE;
    }

    XGetWindowAttributes(dpy, c->window, &attr);

    if (c && c->window == e->window) {
    printf("newwindow II\n");
        c->x = attr.x;
        c->y = attr.y;
        c->dx = attr.width;
        c->dy = attr.height;
        c->border = attr.border_width;
            if (attr.map_state == IsViewable){
#ifdef SHAPE
              /* don't try to manage if the window is non-rectangular */
              XShapeGetRectangles(dpy, c->window, ShapeBounding, &n, &order);
#endif
              if ( n==1 ) manage(c, 1);
	    }
      if (!c->already_managed) fprintf(stderr,"Not Managing newwindow II\n");
    }
}  /* end newwindow */

void destroywin(Window w){
    Client *c, **l;

//fprintf(stderr,"destroy\n");
    curtime = CurrentTime;
    c = getclient(w, 0);
    if (c == 0 || c->window != w){
        return;
    }

    if (!c->already_got_create_event){
      c->already_got_create_event = TRUE;
      return;
    }

    rmclient(c);

    /* flush any errors generated by the window's sudden demise */
    ignore_badwindow = 1;
    XSync(dpy, False);
    ignore_badwindow = 0;
    
}

void clientmesg(XClientMessageEvent *e){
    Client *c;

    curtime = CurrentTime;

    // no longer needed (Matthias)
//     if (e->window == root && e->message_type == exit_kwm) {
//         cleanup();
//         exit(0);
//     }
//     if (e->window == root && e->message_type == restart_kwm) {
//         fprintf(stderr, "*** kwm restarting ***\n");
//         cleanup();
//         execvp(myargv[0], myargv);
//         perror("kwm: exec failed");
//         exit(1);
//     }
    if (e->message_type == wm_change_state) {
        c = getclient(e->window, 0);
        if (e->format == 32 && e->data.l[0] == IconicState && c != 0) {
            if (normalstate(c))
                hidec(c);
        }
        else
            fprintf(stderr, "kwm: WM_CHANGE_STATE: format %d data %d w 0x%x\n",
                e->format, e->data.l[0], e->window);
        return;
    }

    // Matthias
    if (e->message_type == kwm_register_module){
      kwmcom_register_module(e->window);
      Client *c;
      for (c = clients; c; c = c->next){
	if (c->window && c->id){
	  fprintf(stderr, "Send add_window mit window %d und id %d \n",
		  c->window, -c->id);
	  kwmcom_send_to_modules(kwm_add_window, -c->id, c->window); 
	}
      }
      return;
    }
    // Matthias
    if (e->message_type == kwm_unregister_module){
      kwmcom_unregister_module(e->window);
      return;
    }
    // Matthias
    if (e->message_type == kwm_un_minimize_window){
      fprintf(stderr, "got un_minimize_window\n");
      Client *c;
      fprintf(stderr, "look for client %ld \n", -e->data.l[0]);
      for (c = clients; c; c = c->next){
	if (c->id == -e->data.l[0]){
	  fprintf(stderr, "client fount and unminimize\n");
	  c->unMinimize();
	}
      }
      return;
    }
    // Matthias 
    if (e->message_type == kwm_command){
      QString com = e->data.b;
      if (com == "desktop1")
	m->vdRequest(1);
      else if (com == "desktop2")
	m->vdRequest(2);
      else if (com == "desktop3")
	m->vdRequest(3);
      else if (com == "desktop4")
	m->vdRequest(4);
      else if (com == "restart"){
        cleanup();
        execvp(myargv[0], myargv);
        perror("kwm: exec failed");
        exit(1);
      }
      else if (com == "exit"){
        cleanup();
        exit(0);
      }
      return;
    }


    fprintf(stderr, "kwm: strange ClientMessage, type 0x%x window 0x%x\n",
	    e->message_type, e->window);
}


void cmap(XColormapEvent *e){
  Client *c;
  int i;
  
  /* we don't set curtime as nothing here uses it */
  if (e->c_new){
    c = getclient(e->window, 0);
    if (c) {
      c->cmap = e->colormap;
      if (c == current)
	cmapfocus(c);
    }
    else
      for (c = clients; c; c = c->next)
	for (i = 0; i < c->ncmapwins; i++)
	  if (c->cmapwins[i] == e->window) {
	    c->wmcmaps[i] = e->colormap;
	    if (c == current)
	      cmapfocus(c);
	    return;
	  }
  }
}

void property(XPropertyEvent *e){
    Atom a;
    int del;
    Client *c;

    /* we don't set curtime as nothing here uses it */
    a = e->atom;
    del = (e->state == PropertyDelete);
    c = getclient(e->window, 0);
    if (c == 0)
        return;

    switch (a) {
    case XA_WM_ICON_NAME:
        if (c->iconname != 0)
            XFree((char*) c->iconname);
        c->iconname = getprop(c->window, XA_WM_ICON_NAME);
        setwindowlabel(c);
        renamec(c, c->label);
        return;
    case XA_WM_NAME:
        if (c->name != 0)
            XFree((char*) c->name);
        c->name = getprop(c->window, XA_WM_NAME);
        setwindowlabel(c);
        renamec(c, c->label);
        return;
    case XA_WM_TRANSIENT_FOR:
        getwindowtrans(c);
        return;
    }
    if (a == wm_colormaps) {
        getcmaps(c);
        if (c == current)
            cmapfocus(c);
    }
}

void reparent(XReparentEvent *e){
    Client *c;
    XWindowAttributes attr;
    
    printf("reparent\n");
    if (e->event != root || e->override_redirect)
        return;
    if (e->parent == root) {
        c = getclient(e->window, 1);
        if (c != 0 && (c->dx == 0 || c->dy == 0)) {
            XGetWindowAttributes(dpy, c->window, &attr);
            c->x = attr.x;
            c->y = attr.y;
            c->dx = attr.width;
            c->dy = attr.height;
            c->border = attr.border_width;
	    manage(c,1);
        }
    }
    else {
        c = getclient(e->window, 0);
        if (c != 0 && (!c->already_managed || withdrawn(c))) 
            rmclient(c);
    }
}  /* end reparent */

#ifdef  SHAPE
void shapenotify(XShapeEvent *e){
    Client *c;

    c = getclient(e->window, 0);
    if (c == 0)
        return;

    setshape(c);
}
#endif

void enter(XCrossingEvent *e){
    Client *c;

    curtime = e->time;

    c = getclient(e->window, 0);

    if (c != 0 && c != current && c->state != WithdrawnState) {
      active(c);
    }
}

void sighandler(int) {
    cleanup();
    fprintf(stderr, "kwm: exiting on signal\n");
}


