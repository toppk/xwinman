// kwmclient
//
// sends KWM_COMMANDs to kwm via the 
// running proposal for a communication
// between kwm and modules like kpanel
//
// Part of the KDE project.
//
// Copyright (C) 1997 Matthias Ettrich
//

#include <stdlib.h>
#include <stdio.h>

#include <qapp.h>

#include "kwmcom.h"


int main( int argc, char **argv )
{
    QApplication a (argc, argv);

    if ( argc != 2 )
    {
      printf("\nSyntax:\n");
      printf("./kwmclient COMMAND \n");
      printf("At present kwm understands the following commands:\n");
      printf("exit, restart, desktop1, desktop2, desktop3, desktop4\n");
      printf("\n(c) Matthias Ettrich, 1997\nPart of the KDE Project\n\n");
      return 0;
    }
    
    kwmcom_init(qt_xdisplay(), 0);
    kwmcom_send_to_kwm(kwm_command, argv[1]);
    return 0;
}
