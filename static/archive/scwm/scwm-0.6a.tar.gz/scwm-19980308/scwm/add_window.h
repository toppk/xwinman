/* $Id: add_window.h,v 1.2 1997/11/13 22:41:05 gjb Exp $
 * add_window.h
 */


#ifndef ADD_WINDOW_H
#define ADD_WINDOW_H

ScwmWindow *AddWindow(Window w);

void GrabButtonWithModifiers(int button, int modifier, ScwmWindow *sw);

void UngrabButtonWithModifiers(int button, int modifier, ScwmWindow *sw);

void GetWindowSizeHints(ScwmWindow * tmp);

#endif

/* Local Variables: */
/* tab-width: 8 */
/* c-basic-offset: 2 */
/* End: */
