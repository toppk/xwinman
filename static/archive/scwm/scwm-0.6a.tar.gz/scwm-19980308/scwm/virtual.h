/* $Id: virtual.h,v 1.2 1998/02/27 06:02:00 gjb Exp $
 * virtual.h
 *
 */

#ifndef VIRTUAL_H_
#define VIRTUAL_H_


#ifndef NON_VIRTUAL
void checkPanFrames();
void raisePanFrames();
#endif

#endif
