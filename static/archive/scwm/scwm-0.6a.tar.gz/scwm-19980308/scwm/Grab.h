/* $Id: Grab.h,v 1.2 1997/11/13 22:41:05 gjb Exp $ */

#ifndef _GRAB_H
#define _GRAB_H

void XGrabServer_withSemaphore(Display * disp);

void XUngrabServer_withSemaphore(Display * disp);

#endif

/* Local Variables: */
/* tab-width: 8 */
/* c-basic-offset: 2 */
/* End: */
