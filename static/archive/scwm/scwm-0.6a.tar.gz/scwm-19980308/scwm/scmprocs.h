/* $Id: scmprocs.h,v 1.4 1997/11/13 22:41:11 gjb Exp $ */

#ifndef SCMPROCS_H
#define SCMPROCS_H

void init_scwm_procs(void);

#endif /* SCMPROCS_H */

/* Local Variables: */
/* tab-width: 8 */
/* c-basic-offset: 2 */
/* End: */
