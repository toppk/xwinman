/* $Id: ICCCM.h,v 1.2 1997/11/13 22:41:05 gjb Exp $ */

#ifndef ICCCM_H
#define ICCCM_H

void  send_clientmessage(Display * disp, Window w, Atom a, Time timestamp);

#endif

/* Local Variables: */
/* tab-width: 8 */
/* c-basic-offset: 2 */
/* End: */
