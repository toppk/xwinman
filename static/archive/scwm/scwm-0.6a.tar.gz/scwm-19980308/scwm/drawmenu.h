/* $Id: drawmenu.h,v 1.3 1998/02/26 02:21:22 mstachow Exp $
 * drawmenu.h
 * By Greg J. Badros -- Nov 22, 1997
 */

#ifndef DRAWMENU_H
#define DRAWMENU_H

#include "scwmmenu.h"

void PaintMenuItem(Window w, DynamicMenu *pmd, MenuItemInMenu *pmiim);
void ConstructDynamicMenu(DynamicMenu *pmd);
void PaintDynamicMenu(DynamicMenu *pmd, XEvent *pxe);
void menu_font_update();

#endif
