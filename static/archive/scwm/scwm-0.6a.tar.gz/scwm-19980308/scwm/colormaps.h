/* $Id: colormaps.h,v 1.2 1997/12/16 22:46:03 gjb Exp $
 * colormaps.h
 */

#ifndef COLORMAPS_H
#define COLORMAPS_H

#include "window.h"

void HandleColormapNotify(void);
void ReInstallActiveColormap(void);
void InstallWindowColormaps(ScwmWindow * tmp);
void InstallRootColormap(void);
void UninstallRootColormap(void);
void FetchWmColormapWindows(ScwmWindow * tmp);

#endif COLORMAPS_H
