/* $Id: util.h,v 1.6 1997/11/13 22:41:12 gjb Exp $
 * util.h
 */
#ifndef UTIL_H
#define UTIL_H

void redraw_titlebars(ScwmDecor * fl, int extra_height);
void redraw_borders(ScwmDecor *fl) ;
void refresh_common(Window win_or_root);
SCM call_thunk_with_message_handler(SCM thunk);

#endif	/* UTIL_H */

/* Local Variables: */
/* tab-width: 8 */
/* c-basic-offset: 2 */
/* End: */
