#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/time.h>
#include <X11/Xlib.h>
#include <X11/xpm.h>
#include "cursor.h"

Display* display;
Window w;

void Usage();
void CreateCursor();
Bool CreateLogoPixmap(Pixmap& pix, XpmAttributes& attr);
void SetExpiryTimer(long sec);
void EventLoop(Pixmap& pix, XpmAttributes& attr);
void ExpireBanner(int sig);

int main(int argc, char **argv)
{
  long expiry = 5;           // expiry time of logo

  /*
   * Analize command line options.
   */
  if (argc > 2)
    Usage();
  if (argc == 2) {
    if (strcmp(argv[1], "-h") == 0)
      Usage();
    else
      expiry = atoi(argv[1]);
  }

  /*
   * Open display.
   */
  if ((display = XOpenDisplay(NULL)) == NULL) {
    fprintf(stderr, "qvbanner: Can't open display\n");
    exit(1);
  }

  /*
   * Grab X server so that other windows aren't mapped on this.
   */
  XGrabServer(display);

  /*
   * Create whole screen window.
   */
  XSetWindowAttributes attributes;
  unsigned long valueMask;

  attributes.event_mask = ExposureMask;
  attributes.background_pixel = BlackPixel(display, 0);
  attributes.override_redirect = True;
  valueMask = CWBackPixel | CWEventMask | CWOverrideRedirect;

  w = XCreateWindow(display, RootWindow(display, 0),
		    0, 0, DisplayWidth(display, 0), DisplayHeight(display, 0),
		    0, CopyFromParent, InputOutput, CopyFromParent,
		    valueMask, &attributes);

  CreateCursor();

  /*
   * Map window on top.
   */
  XMapRaised(display, w);
  XFlush(display);

  /*
   * Create logo pixmap.
   */
  XpmAttributes attr;
  Pixmap pix;

  if (!CreateLogoPixmap(pix, attr)) {
    XCloseDisplay(display);
    exit(1);
  }

  SetExpiryTimer(expiry);

  EventLoop(pix, attr);
}

void Usage()
{
  fprintf(stderr, "usage: qvbanner [-h] [expiry_time(sec)]\n");
  exit(1);
}

/*
 * CreateCursor --
 *   Create transparent cursor.
 */
void CreateCursor()
{
  Pixmap pixCursor, pixMask;
  XColor black, dummyColor;
  Cursor cursor;

  pixCursor = XCreateBitmapFromData(display, w, curbm_bits,
				    cursor_width, cursor_height);
  pixMask = XCreateBitmapFromData(display, w, maskbm_bits,
				  cursor_width, cursor_height);

  XAllocNamedColor(display, DefaultColormap(display, 0), "black",
		   &black, &dummyColor);
  cursor = XCreatePixmapCursor(display, pixCursor, pixMask, &black, &black,
			       0, 0);
  XDefineCursor(display, w, cursor);
}

/*
 * CreateLogoPixmap --
 *   Create logo pixmap from file.
 */
Bool CreateLogoPixmap(Pixmap& pix, XpmAttributes& attr)
{
  attr.valuemask = XpmColormap | XpmDepth | XpmCloseness;
  attr.colormap = DefaultColormap(display, 0);
  attr.depth = DefaultDepth(display, 0);
  attr.closeness = 65535;
  
  int error;

  if ((error = XpmReadFileToPixmap(display, w, LOGO, &pix, NULL, &attr))
      == XpmSuccess) {
    return True;
  }

  switch (error) {
  case XpmOpenFailed:
    fprintf(stderr, "qvbanner: can't find pixmap '%s'\n", LOGO);
    break;

  case XpmFileInvalid:
    fprintf(stderr, "qvbanner: '%s' isn't valid pixmap file\n", LOGO);
    break;

  case XpmColorFailed:
    fprintf(stderr, "qvbanner: too many colors in '%s'\n", LOGO);
    break;

  default:
    fprintf(stderr, "qvbanner: pixmap error in '%s'", LOGO);
  }

  return False;
}

/*
 * SetExpiryTimer --
 *   Set expiry timer.
 */
void SetExpiryTimer(long sec)
{
  struct itimerval itv;

  itv.it_value.tv_sec = sec;
  itv.it_value.tv_usec = 0;
  itv.it_interval.tv_sec = 0;
  itv.it_interval.tv_usec = 0;
  setitimer(ITIMER_REAL, &itv, NULL);

  signal(SIGALRM, ExpireBanner);
}

/*
 * EventLoop --
 *   Event loop.
 */
void EventLoop(Pixmap& pix, XpmAttributes& attr)
{
  XEvent ev;
  GC gc = XCreateGC(display, w, 0, 0);
  unsigned int dWidth = DisplayWidth(display, 0);
  unsigned int dHeight = DisplayHeight(display, 0);

  while (1) {
    XNextEvent(display, &ev);
    switch (ev.type) {
    case Expose:
      XCopyArea(display, pix, w, gc, 0, 0, attr.width, attr.height,
		(dWidth-attr.width)/2, (dHeight-attr.height)/2);
      break;
    }
  }
}

/*
 * ExpireBanner --
 *   Exit banner.
 */
void ExpireBanner(int sig)
{
  XUngrabServer(display);

  XCloseDisplay(display);
  exit(0);
}
