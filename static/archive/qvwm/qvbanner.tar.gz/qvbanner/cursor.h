#define cursor_width 1
#define cursor_height 1

static char curbm_bits[] = {0x00};
static char maskbm_bits[] = {0x00};
