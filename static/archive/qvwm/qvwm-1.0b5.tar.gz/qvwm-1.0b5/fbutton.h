#ifndef _FBUTTON_H_
#define _FBUTTON_H_

#include "button.h"

class Qvwm;

/*
 * FrameButton class
 */
class FrameButton : public Button {
protected:
  Pixmap pix;
  Qvwm* qvWm;                 // pointer to Qvwm that this button belong to

  static const int BUTTON_WIDTH = 12;
  static const int BUTTON_HEIGHT = 10;

public:
  static Pixmap pixButton[4];

  // Frame button name
  enum ButtonName { MINIMIZE, MAXIMIZE, CLOSE, RESTORE };

public:
  FrameButton(Qvwm* qvWm, Window parent, Rect rc, Pixmap pix)
    : Button(parent, rc), pix(pix), qvWm(qvWm) {}
  ~FrameButton() {}

  void SetPixmap(Pixmap p) { pix = p; }

  void DrawButton();
  virtual void ExecButtonFunc(ButtonState bs) = 0;
  void Button1Press();

  static void CreateFrameButtonPixmap();
};

class FrameButton1 : public FrameButton {
public:
  FrameButton1(Qvwm* qvWm, Window parent, Rect rc, Pixmap pix)
  : FrameButton(qvWm, parent, rc, pix) {}

  void ExecButtonFunc(ButtonState bs);
};

class FrameButton2 : public FrameButton {
public:
  FrameButton2(Qvwm* qvWm, Window parent, Rect rc, Pixmap pix)
    : FrameButton(qvWm, parent, rc, pix) {}
  void ExecButtonFunc(ButtonState bs);
};

class FrameButton3 : public FrameButton {
public:
  FrameButton3(Qvwm* qvWm, Window parent, Rect rc, Pixmap pix)
    : FrameButton(qvWm, parent, rc, pix) {}
  void ExecButtonFunc(ButtonState bs);
};

#endif // _FBUTTON_H_
