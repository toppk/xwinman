#include <stdio.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Xlocale.h>
#include <X11/xpm.h>
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "menu.h"
#include "util.h"
#include "taskbar.h"
#include "qvwmrc.h"

/*
 * InRect --
 *   Return True if the point is in a given rectangle.
 */
Bool InRect(Point pt, Rect rc)
{
  if (pt.x < rc.x)
    return False;
  if (pt.x >= rc.x+(int)rc.width)
    return False;
  if (pt.y < rc.y)
    return False;
  if (pt.y >= rc.y+(int)rc.height)
    return False;

  return True;
}

/*
 * IsDoubleClick --
 *   Return True if the click is decided as double click from time and space.
 */
Bool IsDoubleClick(Time prevTime, Time clickTime, Point prevPt, Point clickPt)
{
  Rect prevRc;

  if (clickTime - prevTime > (unsigned int)DoubleClickTime)
    return False;

  prevRc = Rect(prevPt.x-DoubleClickRange, prevPt.y-DoubleClickRange,
		prevPt.x+DoubleClickRange, prevPt.y+DoubleClickRange);
  if (!InRect(clickPt, prevRc))
    return False;

  return True;
}

/*
 * GetOriginNum --
 *   Return the number of elements in fOrigin.
 */
int GetOriginNum(MenuOrigin* fOrigin)
{
  int num = 0;

  while (fOrigin[num].func != Q_END)
    num++;

  return num;
}

/*
 * CreatePixmapFromFile --
 *   Create a pixmap from the file in PIXDIR.
 */
Bool CreatePixmapFromFile(char* file, Pixmap& pix, Pixmap& mask, GC& gc)
{
  XpmAttributes attr;
  XGCValues gcv;
  char* filename;
  
  attr.valuemask = XpmColormap | XpmDepth;
  attr.colormap = colormap;
  attr.depth = depth;
  
  filename = new char[strlen(PIXDIR)+strlen(file)+2];
  sprintf(filename, "%s/%s", PIXDIR, file);
  
  if (XpmReadFileToPixmap(display, root, filename, &pix, &mask, &attr)
                                                              != XpmSuccess) {
    pix = 0;
    QvwmError("Can't find file '%s'", filename);
    delete [] filename;
    return False;
  }

  gcv.clip_mask = mask;
  gc = XCreateGC(display, root, GCClipMask, &gcv);
  
  delete [] filename;
  return True;
}

/*
 * GetDisplayArea --
 *   Devide screen to 4 areas of up, down, left and right, and return the
 *   position where a given point belongs to.
 */
Taskbar::TaskbarPos GetDisplayArea(Point pt)
{
  
  Rect rcRoot = rootQvwm->GetRect();
  int x1, x2;
  int y1, y2;

  x1 = int(double(rcRoot.width - 1) / (rcRoot.height - 1) * pt.y);
  x2 = (rcRoot.width - 1) - x1;

  if (x2 < pt.x && pt.x < x1)
    return Taskbar::BOTTOM;
  else if (x1 < pt.x && pt.x < x2)
    return Taskbar::TOP;

  y1 = int(double(rcRoot.height - 1) / (rcRoot.width - 1) * pt.x);
  y2 = (rcRoot.height - 1) - y1;

  if (y1 < pt.y && pt.y < y2)
    return Taskbar::LEFT;
  else if (y2 < pt.y && pt.y < y1)
    return Taskbar::RIGHT;

  return Taskbar::BOTTOM;
}

/*
 * GetFixName --
 *   Abbreviate the name by attatching '...' at the end if it is too long.
 *   For example, 'kterm@orestes.is.s.u-tokyo.ac.jp' is 'kterm@orest...'.
 */
char* GetFixName(XFontSet& fs, char* name, unsigned int width)
{
  int len, dotWidth, curWidth;
  char* str;
  XRectangle ink, log;

  len = strlen(name);
  str = new char[len+4];

  if ((curWidth = XmbTextExtents(fs, name, len, &ink, &log)) > (int)width) {
    dotWidth = XmbTextExtents(fs, "...", 3, &ink, &log);

    if (curWidth < ((int)width-dotWidth)*2) {
      while (XmbTextExtents(fs, name, len, &ink, &log) > (int)width-dotWidth)
	if (--len == 0) {
	  strcpy(str, "...");
	  return str;
	}
    }
    else {
      len = 0;
      while (XmbTextExtents(fs, name, len, &ink, &log) < (int)width-dotWidth)
	len++;
      len--;
    }

    strncpy(str, name, len);
    str[len] = '\0';
    strcat(str, "...");
  }
  else
    strcpy(str, name);

  return str;
}

/*
 * ExecShortCutKey --
 *   Execute the function of shortcut key.
 */
void ExecShortCutKey(int num, ShortCutKey sck[], XKeyEvent* ev, Menu* menu)
{
  for (int i = 0; i < num; i++)
    if (ev->keycode == XKeysymToKeycode(display, sck[i].sym) &&
	ev->state == sck[i].mod) {
      menu->ExecFunction(sck[i].func, 0);
      return;
    }
}

/*
 * max --
 *   return maximum.
 */
int max(int x, int y)
{
  return (x > y) ? x : y;
}

/*
 * MappedNotOverride --
 *   Return True if the window attribute doesn't include override_redirect.
 */
Bool MappedNotOverride(Window w)
{
  XWindowAttributes attr;

  if(!XGetWindowAttributes(display, w, &attr))
    return False;

  return ((attr.map_state != IsUnmapped) && !(attr.override_redirect));
}
