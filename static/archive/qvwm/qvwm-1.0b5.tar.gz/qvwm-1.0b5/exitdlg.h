#ifndef _EXITDLG_H_
#define _EXITDLG_H_

// Resource ID
#define IDR_EXIT_SAVE   100
#define IDR_EXIT_NOSAVE 101
#define IDR_RESTART     102
#define IDR_ANOTHER     103
#define IDS_1           200
#define IDB_HELP        300

const int ExitDlgWidth = 385;
const int ExitDlgHeight = 184;

class Qvwm;

extern void ExitDlg(Qvwm* qvWm);

#endif // _EXITDLG_H_
