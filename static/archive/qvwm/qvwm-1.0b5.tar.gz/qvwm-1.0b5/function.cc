#include <stdio.h>
#include <unistd.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/xpm.h>
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "menu.h"
#include "startmenu.h"
#include "fbutton.h"
#include "parse.h"
#include "events.h"
#include "switch.h"
#include "qvwmrc.h"
#include "exitdlg.h"
#include "paging.h"

/*
 * ExecFunction --
 *   Execute qvwm function.
 */
void Menu::ExecFunction(FuncNumber fn, int num)
{
  Point fPt;
  XEvent ev;
  int pFocus;
  int borderWidth = 0;
  Rect rect;

  switch (fn) {
  /*
   * Do nothing.
   */
  case Q_NONE:
    break;

  /*
   * Extract the menu.
   */
  case Q_DIR:
    switch (fDir) {
    /*
     * To right side.
     */
    case RIGHT:
      fPt.x = rc.x + rc.width - 7;
      if (fPt.x+next[num]->rc.width > rcScreen.width-1) {
	fPt.x = rc.x - next[num]->rc.width + MenuFrameWidth;
	fDir = LEFT;
      }
      break;

    /*
     * To left side.
     */
    case LEFT:
      fPt.x = rc.x-next[num]->rc.width+MenuFrameWidth;
      if (fPt.x+(int)next[num]->rc.width < 0) {
	fPt.x = rc.x + rc.width - 7;
	fDir = RIGHT;
      }
      break;
    }
    fPt.y = rc.y + CalcItemYPos(num) - MenuFrameWidth;
    if (fPt.y+next[num]->rc.height > rcScreen.height-1)
      fPt.y = fPt.y + iHeight - next[num]->rc.height + MenuFrameWidth*2;

    child = next[num];
    child->MapMenu(fPt.x, fPt.y);
    break;

  /*
   * Execute the external command.
   */
  case Q_EXEC:
    if (!fork())
      if (execl("/bin/sh", "bin/sh", "-c", exec[num], NULL) == -1) {
	QvwmError("Can't execute '%s'", exec[num]);
	exit(1);
      }
    break;

  /*
   * Restore the window pos & size.
   */
  case Q_RESTORE:
    if (qvWm->CheckStatus(MAXIMIZE_WINDOW) &&
	!qvWm->CheckStatus(MINIMIZE_WINDOW))
      qvWm->fButton[1]->SetPixmap(FrameButton::pixButton[FrameButton::MAXIMIZE]);
    qvWm->RestoreWindow();

    /*
     * After mapped, give the focus to qvWm.
     */
    rootQvwm->SetFocus();
    qvWm->SetFocus();
    qvWm->RaiseWindow(True);
    break;

  /*
   * Move the window.
   */
  case Q_MOVE:
    rect = qvWm->GetRect();
    pressPt = Point(rect.x+rect.width/2, rect.y+Qvwm::TITLE_HEIGHT/2);
    XWarpPointer(display, None, root, 0, 0, 0, 0, pressPt.x, pressPt.y);

    XSync(display, 0);
    while (XPending(display) > 0) {
      XNextEvent(display, &ev);
      if (ev.type == Expose)
	ExposeProc(ev.xany.window);
    }

    qvWm->MoveWindow();
    break;

  /*
   * Resize the window.
   */
  case Q_RESIZE:
    rect = qvWm->GetRect();
    pressPt = Point(rect.x+rect.width-2, rect.y+rect.height-2);
    XWarpPointer(display, None, root, 0, 0, 0, 0, pressPt.x, pressPt.y);

    XSync(display, 0);
    while (XPending(display) > 0) {
      XNextEvent(display, &ev);
      if (ev.type == Expose)
	ExposeProc(ev.xany.window);
    }

    qvWm->ResizeWindow(Qvwm::RIGHTBOTTOM);
    break;

  /*
   * Minimize the window.
   */
  case Q_MINIMIZE:
    qvWm->MinimizeWindow();
    break;

  /*
   * Maximize the window.
   */
  case Q_MAXIMIZE:
    qvWm->fButton[1]->SetPixmap(FrameButton::pixButton[FrameButton::RESTORE]);
    qvWm->MaximizeWindow();
    rootQvwm->SetFocus();
    qvWm->SetFocus();
    qvWm->RaiseWindow(True);
    break;

  /*
   * Close the window.
   */
  case Q_CLOSE:
    qvWm->FetchWMProtocols();
    if (qvWm->CheckFlags(WM_DELETE_WINDOW))
      qvWm->CloseWindow();
    else
      qvWm->KillClient();
    break;

  /*
   * Kill the application.
   */
  case Q_KILL:
    qvWm->KillClient();
    break;

  /*
   * Exit qvwm.
   */
  case Q_EXIT:
    if (!UseExitDialog)
      Qvwm::FinishQvwm(False);
    else
      ExitDlg(qvWm);
    break;

  /*
   * Move taskbar to the bottom of screen.
   */
  case Q_BOTTOM:
    taskBar->MoveTaskbar(Taskbar::BOTTOM);
    break;

  /*
   * Move taskbar to the top of screen.
   */
  case Q_TOP:
    taskBar->MoveTaskbar(Taskbar::TOP);
    break;

  /*
   * Move taskbar to the left of screen.
   */
  case Q_LEFT:
    taskBar->MoveTaskbar(Taskbar::LEFT);
    break;

  /*
   * Move taskbar to the right of screen.
   */
  case Q_RIGHT:
    taskBar->MoveTaskbar(Taskbar::RIGHT);
    break;

  /*
   * Restart qvwm.
   */
  case Q_RESTART:
    XSync(display, 0);
    while (XPending(display) != 0) {
      XNextEvent(display, &ev);
      DispatchEvent(&ev);
    }

    Qvwm::FinishQvwm(True);
    InitState();
    ParseQvwmrc(NULL);
    InitQvwm();
    break;

  /*
   * Switch the window to next window in focus stack.
   */
  case Q_CHANGEWINDOW:
    Qvwm::RollFocus();
    break;

  /*
   * Switch the task to another task with the task switcher.
   */
  case Q_SWITCHTASK:
    if (taskSwitcher == NULL)
      taskSwitcher = new TaskSwitcher();
    taskSwitcher->SwitchTask();
    break;

  /*
   * Popup the start menu.
   */
  case Q_POPUPSTARTMENU:
    if (startMenu == NULL)
      startMenu = new StartMenu(StartMenuOrigin);

    if (!startMenu->CheckMapped()) {
      rootQvwm->SetFocus();
      startMenu->MapMenu();
    }
    break;

  /*
   * Popup the menu.
   */
  case Q_POPUPMENU:
    if (!CheckMapped()) {
      if (qvWm->CheckFlags(BORDER))
	borderWidth = Qvwm::BORDER_WIDTH;
      rect = qvWm->GetRect();
      MapMenu(rect.x+borderWidth, rect.y+borderWidth+Qvwm::TITLE_HEIGHT);
    }
    break;

  /*
   * Popdown one menu.
   */
  case Q_POPDOWNMENU:
    // Erasemenu only one menu.
    UnmapMenu();
    break;

  /*
   * Popdown all menu.
   */
  case Q_POPDOWNALLMENU:
    if (Qvwm::focusQvwm->CheckMenuMapped())
      Qvwm::focusQvwm->UnmapMenu();
    if (startMenu != NULL && startMenu->CheckMapped())
      startMenu->UnmapMenu();
    break;

  /*
   * Move the focus of menu up.
   */
  case Q_UPFOCUS:
    if (iFocus == -1) {
      iFocus = nitems - 1;
      while (func[iFocus] == Q_SEPARATOR)
	if (--iFocus == -1)
	  return;
    }
    else {
      pFocus = iFocus;

      do {
	if (--iFocus == -1)
	  iFocus = nitems - 1;
      } while (func[iFocus] == Q_SEPARATOR);

      SetMenuFocus(pFocus);
    }
    SetMenuFocus(iFocus);
    break;
    
  /*
   * Move the focus of menu down.
   */
  case Q_DOWNFOCUS:
    if (iFocus == -1) {
      iFocus = 0;
      while (func[iFocus] == Q_SEPARATOR)
	if (++iFocus == nitems)
	  return;
    }
    else {
      pFocus = iFocus;

      do {
	if (++iFocus == nitems)
	  iFocus = 0;
      } while (func[iFocus] == Q_SEPARATOR);

      SetMenuFocus(pFocus);
    }
    SetMenuFocus(iFocus);
    break;

  /*
   * Move the focus of menu right.
   */
  case Q_RIGHTFOCUS:
    if (fDir == RIGHT) {
      if (func[iFocus] == Q_DIR) {
	ExecFunction(Q_DIR, iFocus);
	child->ExecFunction(Q_DOWNFOCUS, 0);
      }
    }
    else {
      if (parent != NULL)
	UnmapMenu();
    }
    break;

  /*
   * Move the focus of menu left.
   */
  case Q_LEFTFOCUS:
    if (fDir == LEFT) {
      if (func[iFocus] == Q_DIR) {
	ExecFunction(Q_DIR, iFocus);
	child->ExecFunction(Q_DOWNFOCUS, 0);
      }
    }
    else {
      if (parent != NULL)
	UnmapMenu();
    }
    break;
    
  /*
   * Execute the function of the menu item.
   */
  case Q_ACTION:
    if (IsSelectable(func[iFocus])) {
      pFocus = iFocus;
      if (func[iFocus] != Q_DIR) {
	if (qvWm->CheckMenuMapped())
	  qvWm->ctrlMenu->UnmapMenu();
	if (startMenu != NULL && startMenu->CheckMapped())
	  startMenu->UnmapMenu();
      }
      ExecFunction(func[pFocus], pFocus);
    }
    break;

  /*
   * Switch to left virtual page.
   */
  case Q_LEFTPAGING:
    {
      Rect rcRoot = rootQvwm->GetRect();

      paging->origin.x -= rcRoot.width;
      paging->PagingAllWindows();
    }
    break;

  /*
   * Switch to right virtual page.
   */
  case Q_RIGHTPAGING:
    {
      Rect rcRoot = rootQvwm->GetRect();

      paging->origin.x += rcRoot.width;
      paging->PagingAllWindows();
    }
    break;

  /*
   * Switch to up virtual page.
   */
  case Q_UPPAGING:
    {
      Rect rcRoot = rootQvwm->GetRect();

      paging->origin.y -= rcRoot.height;
      paging->PagingAllWindows();
    }
    break;

  /*
   * Switch to down virtual page.
   */
  case Q_DOWNPAGING:
    {
      Rect rcRoot = rootQvwm->GetRect();

      paging->origin.y += rcRoot.height;
      paging->PagingAllWindows();
    }
    break;
  }
}

/*
 * IsSelectable --
 *   Return True if the menu item is selectable.
 */
Bool Menu::IsSelectable(FuncNumber fn)
{
  switch (fn) {
  case Q_NONE:
    return False;

  case Q_RESTORE:
    if (qvWm->CheckStatus(MINIMIZE_WINDOW | MAXIMIZE_WINDOW))
      return True;
    return False;

  case Q_MOVE:
  case Q_RESIZE:
    if (qvWm->CheckStatus(MAXIMIZE_WINDOW))
      return False;
    return True;

  case Q_MINIMIZE:
    if (qvWm->CheckStatus(MINIMIZE_WINDOW))
      return False;
    return True;

  case Q_MAXIMIZE:
    if (qvWm->CheckStatus(MAXIMIZE_WINDOW) &&
	!qvWm->CheckStatus(MINIMIZE_WINDOW))
      return False;
    return True;

  default:
    return True;
  }
}
