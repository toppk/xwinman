#include <stdio.h>
#include <time.h>
#include <sys/time.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "events.h"
#include "taskbar.h"
#include "fbutton.h"
#include "tbutton.h"
#include "qvwmrc.h"
#include "paging.h"

/*
 * MoveWindow --
 *   Move the window with mouse or keyboard.
 */
void Qvwm::MoveWindow()
{
  XEvent ev;
  Rect oldRc, newRc;
  Point newPt, junkPt;
  Window junkRoot, junkChild;
  unsigned int junkBW, junkDepth, mask;

  XGrabKeyboard(display, root, True, GrabModeAsync, GrabModeAsync,
		CurrentTime);
  if (ClickToFocus)
    XSetInputFocus(display, root, RevertToParent, CurrentTime);
  if (!OpaqueMove)
    XGrabServer(display);

  XQueryPointer(display, frame, &junkRoot, &junkChild, &newPt.x, &newPt.y,
		&junkPt.x, &junkPt.y, &mask);

  XGetGeometry(display, frame, &junkRoot, &oldRc.x, &oldRc.y, &oldRc.width,
	       &oldRc.height, &junkBW, &junkDepth);
  newRc = oldRc;

  if (!OpaqueMove)
    XDrawRectangle(display, root, gcXor, newRc.x, newRc.y, newRc.width,
		   newRc.height);

  while (1) {
    XNextEvent(display, &ev);
    switch (ev.type) {
    case KeyPress:
      switch (XKeycodeToKeysym(display, ev.xkey.keycode, 0)) {
      case XK_Up:
	newPt.y -= MOVEMENT;
	break;

      case XK_Down:
	newPt.y += MOVEMENT;
	break;

      case XK_Right:
	newPt.x += MOVEMENT;
	break;

      case XK_Left:
	newPt.x -= MOVEMENT;
	break;

      case XK_Return:
	goto decide;
      }
      XWarpPointer(display, None, root, 0, 0, 0, 0, newPt.x, newPt.y);
      // to be continued to next case statement

    case MotionNotify:
      junkPt = Point(ev.xbutton.x_root, ev.xbutton.y_root);
      paging->HandlePaging(junkPt);

      if (!OpaqueMove)
	XDrawRectangle(display, root, gcXor, newRc.x, newRc.y, newRc.width,
		       newRc.height);

      XQueryPointer(display, frame, &junkRoot, &junkChild, &newPt.x, &newPt.y,
		    &junkPt.x, &junkPt.y, &mask);
      newRc.x = oldRc.x + newPt.x - pressPt.x;
      newRc.y = oldRc.y + newPt.y - pressPt.y;

      if (OpaqueMove)
	XMoveWindow(display, frame, newRc.x, newRc.y);
      else 
	XDrawRectangle(display, root, gcXor, newRc.x, newRc.y, newRc.width,
		       newRc.height);

      break;

    case ButtonRelease:
      goto decide;

    case ButtonPress:
      XAllowEvents(display, ReplayPointer, CurrentTime);
      break;

    case Expose:
      ExposeProc(ev.xexpose.window);
      break;
    }
  }

 decide:
  if (!OpaqueMove) {
    XDrawRectangle(display, root, gcXor, newRc.x, newRc.y, newRc.width,
		   newRc.height);
    XUngrabServer(display);
  }

  if (ClickToFocus)
    XSetInputFocus(display, wOrig, RevertToParent, CurrentTime);
  XUngrabKeyboard(display, CurrentTime);

  XMoveWindow(display, frame, newRc.x, newRc.y);
  newRc.x += paging->origin.x;
  newRc.y += paging->origin.y;
  ConfigureNewRc(newRc);
  
  taskBar->RaiseTaskbar();
}

/*
 * ResizeWindow --
 *   Resize the window with mouse or keyboard.
 */
void Qvwm::ResizeWindow(PositionName pos)
{
  RectPt resize;                  // amount of change
  XEvent ev;
  Rect oldRc, newRc;
  Point newPt, junkPt;
  Window junkRoot, junkChild;
  unsigned int junkBW, junkDepth, mask;
  int width_inc = hints.width_inc;
  int height_inc = hints.height_inc;

  XGrabKeyboard(display, root, True, GrabModeAsync, GrabModeAsync,
		CurrentTime);
  if (ClickToFocus)
    XSetInputFocus(display, root, RevertToParent, CurrentTime);
  if (!OpaqueMove)
    XGrabServer(display);
  
  XQueryPointer(display, frame, &junkRoot, &junkChild, &newPt.x, &newPt.y,
		&junkPt.x, &junkPt.y, &mask);

  XGetGeometry(display, frame, &junkRoot, &oldRc.x, &oldRc.y, &oldRc.width,
	       &oldRc.height, &junkBW, &junkDepth);
  newRc = oldRc;

  if (!OpaqueMove)
    XDrawRectangle(display, root, gcXor, newRc.x, newRc.y, newRc.width,
		   newRc.height);

  while (1) {
    XNextEvent(display, &ev);
    switch (ev.type) {
    case KeyPress:
      switch (XKeycodeToKeysym(display, ev.xkey.keycode, 0)) {
      case XK_Up:
	if (pos == LEFT) {
	  pos = LEFTTOP;
	  newPt.y = oldRc.y;
	  pressPt.y = oldRc.y;
	}
	else if (pos == RIGHT) {
	  pos = RIGHTTOP;
	  newPt.y = oldRc.y;
	  pressPt.y = oldRc.y;
	}
	else
	  newPt.y -= MOVEMENT;
	break;
      case XK_Down:
	if (pos == LEFT) {
	  pos = LEFTBOTTOM;
	  newPt.y = oldRc.y + oldRc.height;
	  pressPt.y = oldRc.y + oldRc.height;
	}
	else if (pos == RIGHT) {
	  pos = RIGHTBOTTOM;
	  newPt.y = oldRc.y + oldRc.height;
	  pressPt.y = oldRc.y + oldRc.height;
	}
	else
	  newPt.y += MOVEMENT;
	break;
      case XK_Right:
	if (pos == TOP) {
	  pos = RIGHTTOP;
	  newPt.x = oldRc.x + oldRc.width;
	  pressPt.x = oldRc.x + oldRc.width;
	}
	else if (pos == BOTTOM) {
	  pos = RIGHTBOTTOM;
	  newPt.x = oldRc.x + oldRc.width;
	  pressPt.x = oldRc.x + oldRc.width;
	}
	else
	  newPt.x += MOVEMENT;
	break;
      case XK_Left:
	if (pos == TOP) {
	  pos = LEFTTOP;
	  newPt.x = oldRc.x;
	  pressPt.x = oldRc.x;
	}
	else if (pos == BOTTOM) {
	  pos = LEFTBOTTOM;
	  newPt.x = oldRc.x;
	  pressPt.x = oldRc.x;
	}
	else
	  newPt.x -= MOVEMENT;
	break;
      case XK_Return:
	goto decide;
      }
      XWarpPointer(display, None, root, 0, 0, 0, 0, newPt.x, newPt.y);
      // continue

    case MotionNotify:
      if (!OpaqueMove)
	XDrawRectangle(display, root, gcXor, newRc.x, newRc.y, newRc.width,
		       newRc.height);

      resize = RectPt(0, 0, 0, 0);
      XQueryPointer(display, frame, &junkRoot, &junkChild, &newPt.x, &newPt.y,
		    &junkPt.x, &junkPt.y, &mask);

      switch (pos) {
      case LEFT:
	resize.left = (newPt.x - pressPt.x)/width_inc*width_inc;
	break;

      case RIGHT:
	resize.right = (newPt.x - pressPt.x)/width_inc*width_inc;
	break;

      case TOP:
	resize.top = (newPt.y - pressPt.y)/height_inc*height_inc;
	break;

      case BOTTOM:
	resize.bottom = (newPt.y - pressPt.y)/height_inc*height_inc;
	break;

      case LEFTTOP:
	resize.left = (newPt.x - pressPt.x)/width_inc*width_inc;
	resize.top = (newPt.y - pressPt.y)/height_inc*height_inc;
	break;

      case RIGHTTOP:
	resize.right = (newPt.x - pressPt.x)/width_inc*width_inc;
	resize.top = (newPt.y - pressPt.y)/height_inc*height_inc;
	break;

      case LEFTBOTTOM:
	resize.left = (newPt.x - pressPt.x)/width_inc*width_inc;
	resize.bottom = (newPt.y - pressPt.y)/height_inc*height_inc;
	break;

      case RIGHTBOTTOM:
	resize.right = (newPt.x - pressPt.x)/width_inc*width_inc;
	resize.bottom = (newPt.y - pressPt.y)/height_inc*height_inc;
	break;
      }
      
      newRc.x = oldRc.x + resize.left;
      newRc.y = oldRc.y + resize.top;
      newRc.width = oldRc.width - resize.left + resize.right;
      newRc.height = oldRc.height - resize.top + resize.bottom;
      
      /*
       * Check minimum limit of size.
       */
      if ((signed)newRc.width-(BORDER_WIDTH+2)*2 <= 0)
	newRc.width = 1 + (BORDER_WIDTH + 2) * 2;
      else if ((signed)newRc.width-(BORDER_WIDTH+2)*2 < hints.min_width)
	newRc.width = hints.min_width + (BORDER_WIDTH + 2) * 2;
      if ((signed)newRc.height-(BORDER_WIDTH*2+TITLE_HEIGHT+5) <= 0)
	newRc.height = 1 + BORDER_WIDTH * 2 + TITLE_HEIGHT + 5;
      else if ((signed)newRc.height-(BORDER_WIDTH*2+TITLE_HEIGHT+5)
	       < hints.min_height)
	newRc.height = hints.min_height + BORDER_WIDTH * 2 + TITLE_HEIGHT + 5;
      
      /*
       * Check maximum limit of size.
       */
      if ((int)newRc.width-(BORDER_WIDTH+2)*2 > hints.max_width)
	newRc.width = hints.max_width + (BORDER_WIDTH + 2) * 2;
      if ((int)newRc.height-(BORDER_WIDTH*2+TITLE_HEIGHT+5) > hints.max_height)
	newRc.height = hints.max_height + BORDER_WIDTH * 2 + TITLE_HEIGHT + 5;
      
      if (OpaqueMove) {
	newRc.x += paging->origin.x;
	newRc.y += paging->origin.y;
	ConfigureNewRc(newRc);
	RedrawWindow();
      }
      else
	XDrawRectangle(display, root, gcXor, newRc.x, newRc.y, newRc.width,
		       newRc.height);

      break;
      
    case ButtonRelease:
      goto decide;

    case ButtonPress:
      XAllowEvents(display, ReplayPointer, CurrentTime);
      break;

    case Expose:
      ExposeProc(ev.xexpose.window);
      break;
    }
  }

 decide:
  if (!OpaqueMove) {
    XDrawRectangle(display, root, gcXor, newRc.x, newRc.y, newRc.width,
		   newRc.height);
    XUngrabServer(display);
  }

  if (ClickToFocus)
    XSetInputFocus(display, wOrig, RevertToParent, CurrentTime);
  XUngrabKeyboard(display, CurrentTime);
  
  if (!OpaqueMove) {
    newRc.x += paging->origin.x;
    newRc.y += paging->origin.y;
  }
  ConfigureNewRc(newRc);
  RedrawWindow();
  
  taskBar->RaiseTaskbar();
}

/*
 * MaximizeWindow --
 *   Maximize the window.
 */
void Qvwm::MaximizeWindow()
{
  Window junkRoot;
  unsigned int junkBW, junkDepth;
  Rect srcRc, destRc, rect;

  XGetGeometry(display, frame, &junkRoot, &srcRc.x, &srcRc.y,
	       &srcRc.width, &srcRc.height, &junkBW, &junkDepth);

  if (CheckStatus(MINIMIZE_WINDOW)) {
    /*
     * min -> max
     */
    SetStateProperty(NormalState);

    srcRc = tButton->GetRect();
    rect = taskBar->GetRect();
    srcRc.x += rect.x;
    srcRc.y += rect.y;
  }
  else {
    /*
     * normal -> max
     */
    srcRc = rc;
    srcRc.x -= paging->origin.x;
    srcRc.y -= paging->origin.y;
    bFlags = flags;
  }

  destRc = GetFixSize(rcScreen, hints.max_width, hints.max_height,
		      hints.width_inc, hints.height_inc, hints.base_width,
		      hints.base_height);
  rc = destRc;
  rc.x += paging->origin.x;
  rc.y += paging->origin.y;

  bOrigRc = rcOrig;

  ResetFlags(BORDER);

  SetStatus(MAXIMIZE_WINDOW);
  ResetStatus(MINIMIZE_WINDOW);

  MotionTitlebar(srcRc, destRc);
  RedrawWindow();
  MapWindows();
  SetFocus();
  RaiseWindow(True);
}

/*
 * MinimizeWindow --
 *   Minimize the window.
 */
void Qvwm::MinimizeWindow()
{
  Rect srcRc, destRc, rect;

  if (CheckStatus(MAXIMIZE_WINDOW)) {
    /*
     * max->min
     */
    srcRc = GetFixSize(rcScreen, hints.max_width, hints.max_height,
		       hints.width_inc, hints.height_inc, hints.base_width,
		       hints.base_height);
  }
  else {
    /*
     * normal->min
     */
    srcRc = rc;
    srcRc.x -= paging->origin.x;
    srcRc.y -= paging->origin.y;
    bFlags = flags;
  }

  destRc = tButton->GetRect();
  rect = taskBar->GetRect();
  destRc.x += rect.x;
  destRc.y += rect.y;

  SetStatus(MINIMIZE_WINDOW);
  SetStateProperty(IconicState);

  MotionTitlebar(srcRc, destRc);

  if (ClickToFocus)
    ChangeFocus();
  UnmapWindows();
}

/*
 * RestoreWindow --
 *   Restore the window to previous state.
 */
void Qvwm::RestoreWindow()
{
  Rect srcRc, destRc, rect;

  if (CheckStatus(MINIMIZE_WINDOW) && CheckStatus(MAXIMIZE_WINDOW)) {
    /*
     * min -> max
     */
    ResetStatus(MINIMIZE_WINDOW);
    SetStateProperty(NormalState);

    srcRc = tButton->GetRect();
    rect = taskBar->GetRect();
    srcRc.x += rect.x;
    srcRc.y += rect.y;
    destRc = GetFixSize(rcScreen, hints.max_width, hints.max_height,
		    hints.width_inc, hints.height_inc, hints.base_width,
		    hints.base_height);
    rc = destRc;
    rc.x += paging->origin.x;
    rc.y += paging->origin.y;

    ResetFlags(BORDER);
  }
  else if (CheckStatus(MINIMIZE_WINDOW)) {
    /*
     * min -> normal
     */
    ResetStatus(MAXIMIZE_WINDOW | MINIMIZE_WINDOW);
    SetStateProperty(NormalState);

    srcRc = tButton->GetRect();
    rect = taskBar->GetRect();
    srcRc.x += rect.x;
    srcRc.y += rect.y;
    flags = bFlags;
    CalcWindowPos(rcOrig);

    destRc = rc;
    destRc.x -= paging->origin.x;
    destRc.y -= paging->origin.y;
  }
  else if (CheckStatus(MAXIMIZE_WINDOW)) {
    /*
     * max -> normal
     */
    ResetStatus(MAXIMIZE_WINDOW | MINIMIZE_WINDOW);

    srcRc = GetFixSize(rcScreen, hints.max_width, hints.max_height,
		       hints.width_inc, hints.height_inc, hints.base_width,
		       hints.base_height);
    flags = bFlags;
    rcOrig = bOrigRc;
    CalcWindowPos(rcOrig);

    destRc = rc;
    destRc.x -= paging->origin.x;
    destRc.y -= paging->origin.y;
  }

  MotionTitlebar(srcRc, destRc);
  RedrawWindow();
  MapWindows();
  SetFocus();
  RaiseWindow(True);
}

/*
 * RedrawWindow --
 *   Redraw the window decoration.
 */
void Qvwm::RedrawWindow()
{
  Rect rcParent, rcTitle, rcCorner[4], rcSide[4], rcCtrl, rcButton[3];

  CalcFramePos(rc, &rcParent, &rcTitle, rcCorner, rcSide, &rcCtrl, rcButton);

  XMoveResizeWindow(display, frame, rc.x-paging->origin.x,
		    rc.y-paging->origin.y, rc.width, rc.height);
  XMoveResizeWindow(display, parent, rcParent.x, rcParent.y, rcParent.width,
		    rcParent.height);
  XMoveResizeWindow(display, wOrig, 0, 0, rcParent.width, rcParent.height);
  if (CheckFlags(BORDER)) {
    for (int i = 0; i < 4; i++) {
      XMoveResizeWindow(display, side[i], rcSide[i].x, rcSide[i].y,
			rcSide[i].width, rcSide[i].height);
      XMoveWindow(display, corner[i], rcCorner[i].x, rcCorner[i].y);
    }
  }
  if (CheckFlags(TITLE)) {
    XMoveWindow(display, ctrl, rcCtrl.x, rcCtrl.y);
    for (int i = 0; i < 3; i++)
      fButton[i]->MoveResizeButton(rcButton[i]);
    XMoveResizeWindow(display, title, rcTitle.x, rcTitle.y, rcTitle.width,
		      rcTitle.height);
  }

  ConfigureNewRc(rc);
}

/*
 * MotionTitlebar --
 *   Move the titlebar to dest slowly.
 */
void Qvwm::MotionTitlebar(Rect src, Rect dest)
{
  Window motionBarWin;
  double incX, incY, incWidth;
  Point titlePt;
  XSetWindowAttributes attributes;
  unsigned long valueMask;
  XEvent ev;
  XRectangle ink, log;
  int i;

  XSync(display, 0);

  attributes.save_under = True;
  attributes.background_pixel = blue;
  valueMask = CWSaveUnder | CWBackPixel;

  /*
   * Create a motion title bar.
   */
  motionBarWin = XCreateWindow(display, root, src.x, src.y,
			       src.width, TITLE_HEIGHT, 0, CopyFromParent,
			       InputOutput, CopyFromParent, 
			       valueMask, &attributes);

  /*
   * Calculate title name position.
   */
  XmbTextExtents(fsTitle, name, strlen(name), &ink, &log);
  titlePt.x = TaskbarButton::SIMBOL_WIDTH + 4;
  titlePt.y = (TITLE_HEIGHT-log.height)/2 + log.y;
  
  XMapRaised(display, motionBarWin);

  incX = (double)(dest.x - src.x) / TitlebarMotionSpeed;
  incY = (double)(dest.y - src.y) / TitlebarMotionSpeed;
  incWidth = (double)((int)dest.width - (int)src.width) / TitlebarMotionSpeed;

  /*
   * Move the titlebar slowly.
   */
  for (i = 1; i < TitlebarMotionSpeed; i++) {
    XMoveResizeWindow(display, motionBarWin,
		      src.x+(int)(incX*i), src.y+(int)(incY*i),
		      src.width+(unsigned int)(incWidth*i), TITLE_HEIGHT);

    XSetForeground(display, gc, white);
    XmbDrawString(display, motionBarWin, fsTitle, gc, titlePt.x, titlePt.y,
		  name, strlen(name));
    XSetClipOrigin(display, gcLogo, 2, 1);
    XCopyArea(display, GetIconPixmap(), motionBarWin, GetIconGC(), 0, 0,
	      TaskbarButton::SIMBOL_WIDTH, TaskbarButton::SIMBOL_HEIGHT, 2, 1);
  }

  XDestroyWindow(display, motionBarWin);
  XSync(display, 0);

  while (XCheckWindowEvent(display, motionBarWin, ExposureMask, &ev))
    ;
}

/*
 * GetFixSize --
 *   Adjust the position and the size of the window according to the window
 *   property.
 */
Rect Qvwm::GetFixSize(Rect rc, int max_width, int max_height, int width_inc,
		      int height_inc, int base_width, int base_height)
{
  /*
   * When the maximum size is smaller than the screen size.
   */
  if (max_width+(BORDER_WIDTH+2)*2 < (int)rcScreen.width)
    rc.width = max_width + (BORDER_WIDTH+2)*2;
  if (max_height+BORDER_WIDTH*2+TITLE_HEIGHT+5 < (int)rcScreen.height)
    rc.height = max_height + BORDER_WIDTH*2+TITLE_HEIGHT+5;

  /*
   * Adjust the window size to base_size+incr*i.
   */
  rc.width = (rc.width-base_width)/width_inc*width_inc+base_width;
  rc.height = (rc.height-base_height)/height_inc*height_inc+base_height;

  return rc;
}
