#ifndef _MISC_H_
#define _MISC_H_

const int MAX_NAME = 200;
const int MAX_WINDOW_WIDTH = 32767;
const int MAX_WINDOW_HEIGHT = 32767;

/*
 * Cursor name
 */
enum CursorName {
  SYS, X_RESIZE, Y_RESIZE, RD_RESIZE, LD_RESIZE, WAIT
};

/*
 * Point class
 */
class Point {
public:
  int x, y;

public:
  Point() {}
  Point(int x, int y) : x(x), y(y) {}
};

/*
 * Rect class
 */
class Rect {
public:
  int x, y;
  unsigned int width, height;

public:
  Rect() {}
  Rect(int x, int y, int width, int height)
    : x(x), y(y), width(width), height(height) {}
};

/*
 * RectPt class
 */
class RectPt {
public:
  int left, top, right, bottom;

public:
  RectPt() {}
  RectPt(int left, int top, int right, int bottom)
    : left(left), top(top), right(right), bottom(bottom) {}
};

/*
 * Dim class
 */
class Dim {
public:
  unsigned int width, height;

public:
  Dim() {}
  Dim(unsigned int width, unsigned int height)
    : width(width), height(height) {}
};

#endif // _MISC_H_
