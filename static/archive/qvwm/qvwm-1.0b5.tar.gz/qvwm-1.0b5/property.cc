#include <stdio.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "tbutton.h"
#include "qvwmrc.h"

Hash<unsigned long>* Qvwm::attrHashTable;

Pixmap FixIconPixmap(Pixmap origPix, unsigned int width, unsigned int height,
		     int size, unsigned int depth, unsigned long fore,
		     unsigned long back);

/*
 * SetProperty --
 *   Set window property.
 */
void Qvwm::SetProperty(Atom atom)
{
  XTextProperty xtp;
  char** cl;
  int n;
  Pixmap pixIcon;
  GC gcIcon;

  switch (atom) {
  case XA_WM_NAME:
    if (XGetWMName(display, wOrig, &xtp) != 0) {
      XmbTextPropertyToTextList(display, &xtp, &cl, &n);
      name = cl[0];
    }
    else
      name = "Untitled";

    DrawTitle();
    break;

  case XA_WM_ICON_NAME:
    if (XGetWMIconName(display, wOrig, &xtp) != 0) {
      XmbTextPropertyToTextList(display, &xtp, &cl, &n);
      tButton->SetName(cl[0]);
    }
    else
      tButton->SetName("Untitled");

    tButton->DrawButton();
    break;

  case XA_WM_HINTS:
    GetFixedIcon(pixLarge, gcLarge, 32);

    GetFixedIcon(pixIcon, gcIcon, 16);
    tButton->SetPixmap(pixIcon);
    tButton->SetGC(gcIcon);
    tButton->DrawButton();
    break;

  case XA_WM_NORMAL_HINTS:
    GetWindowSizeHints();
    break;

  default:
    if (atom == _XA_WM_PROTOCOLS)
      FetchWMProtocols();
    else if (atom == _XA_WM_COLORMAP_WINDOWS) {
      FetchWMColormapWindows();
      InstallWindowColormaps();
    }
  }
}

/*
 * GetWindowClassHints --
 *
 */
void Qvwm::GetWindowClassHints()
{
  unsigned long* wFlags;

  XGetClassHint(display, wOrig, &classHints);

#ifdef DEBUG
  printf("class: %s(%s)\n", classHints.res_name, classHints.res_class);
#endif

  if (classHints.res_name != NULL) {
    if ((wFlags = attrHashTable->GetHashItem(classHints.res_name))) {
      flags = *wFlags;
      return;
    }
  }

  if (classHints.res_class != NULL) {
    if ((wFlags = attrHashTable->GetHashItem(classHints.res_class))) {
      flags = *wFlags;
      return;
    }
  }

  // Default flags
  flags = TITLE | BORDER | CTRL_MENU | BUTTON1 | BUTTON2 | BUTTON3;
}

/*
 * GetWindowSizeHints --
 *   Get window size hints.
 */
void Qvwm::GetWindowSizeHints()
{
  long supplied;

  if (!XGetWMNormalHints(display, wOrig, &hints, &supplied))
    hints.flags = 0;
  
  if (hints.flags & PResizeInc) {
    if (hints.width_inc == 0)
      hints.width_inc = 1;
    if (hints.height_inc == 0)
      hints.height_inc = 1;
  }
  else {
    hints.width_inc = 1;
    hints.height_inc = 1;
  }
  
  if (!(hints.flags & PBaseSize)) {
    if (hints.flags & PMinSize) {
      hints.base_width = hints.min_width;
      hints.base_height = hints.min_height;
    }
    else {
      hints.base_width = 0;
      hints.base_height = 0;
    }
  }
  
  if (!(hints.flags & PMinSize)) {
    hints.min_width = hints.base_width;
    hints.min_height = hints.base_height;
  }
    
  if (!(hints.flags & PMaxSize)) {
    hints.max_width = MAX_WINDOW_WIDTH;
    hints.max_height = MAX_WINDOW_HEIGHT;
  }
    
  if (!(hints.flags & PWinGravity)) {
    hints.win_gravity = NorthWestGravity;
    hints.flags |= PWinGravity;
  }
}

/*
 * GetGravityOffset --
 *   Get the offset needed in the gravity.
 */
Point Qvwm::GetGravityOffset()
{
  static Point GravityOffset[11] = 
    { Point(-1, -1),             // ForgetGravity
      Point( 0,  0),             // NorthWestGravity
      Point(-1,  0),             // NorthGravity
      Point(-2,  0),             // NorthEaseGravity
      Point( 0, -1),             // WestGravity
      Point(-1, -1),             // CenterGravity
      Point(-2, -1),             // EastGravity
      Point( 0, -2),             // SouthWestGravity
      Point(-1, -2),             // SouthGravity
      Point(-2, -2),             // SouthEastGravity
      Point(-1, -1)};            // StaticGravity
  int g = NorthWestGravity;
  Point gravity;

  if (hints.flags & PWinGravity)
    g = hints.win_gravity;

  if (g < ForgetGravity || g > StaticGravity)
    gravity = Point(0, 0);
  else
    gravity = GravityOffset[g];

  return gravity;
}
  
/*
 * FetchWMProtocols --
 */
void Qvwm::FetchWMProtocols()
{
  Atom *protocols, *ap;
  int i, n;
  Atom atype;
  int aformat;
  unsigned long bytes_remain, nitems;
  
  if (XGetWMProtocols(display, wOrig, &protocols, &n)) {
    ap = protocols;
    for (i = 0; i < n; i++) {
      if (*ap == (Atom)_XA_WM_DELETE_WINDOW)
	SetFlags(WM_DELETE_WINDOW);
      ap++;
    }
    if (protocols)
      XFree(protocols);
  }
  else {
    if ((XGetWindowProperty(display, wOrig, _XA_WM_PROTOCOLS, 0L, 10L, False,
			    _XA_WM_PROTOCOLS, &atype, &aformat, &nitems,
			    &bytes_remain, (unsigned char **)&protocols))
	== Success) {
      ap = protocols;
      for (i = 0; i < (int)nitems; i++) {
	if (*ap == (Atom)_XA_WM_DELETE_WINDOW)
	  SetFlags(WM_DELETE_WINDOW);
	ap++;
      }
      if (protocols)
	XFree(protocols);
    }
  }
}

/*
 * GetFixedIcon --
 *   Get icon whose size becomes 16 or 32.
 */
void Qvwm::GetFixedIcon(Pixmap& pix, GC& gc, int size)
{
  XWMHints* wmHints;
  Window junkRoot;
  Rect rect;
  unsigned int junkBW, pixDepth;
  Pixmap mask;
  XGCValues gcv;

  wmHints = XGetWMHints(display, wOrig);

  if (wmHints == NULL || !(wmHints->flags & IconPixmapHint)) {
    if (size == 16) {
      pix = pixLogo;
      gc = gcLogo;
    }
    else if (size == 32) {
      pix = pixLargeLogo;
      gc = gcLargeLogo;
    }
  }
  else {
    XGetGeometry(display, wmHints->icon_pixmap, &junkRoot, &rect.x, &rect.y,
		 &rect.width, &rect.height, &junkBW, &pixDepth);
   
    pix = FixIconPixmap(wmHints->icon_pixmap, rect.width, rect.height, size,
			depth, IconForeColor, IconBackColor);

    if (wmHints->flags & IconMaskHint) {
      mask = FixIconPixmap(wmHints->icon_mask, rect.width, rect.height, size,
			   1, 1, 0);
      gcv.clip_mask = mask;
      gc = XCreateGC(display, root, GCClipMask, &gcv);
    }
    else
      gc = XCreateGC(display, root, 0, 0);
  }

  XFree(wmHints);
}

/*
 * FixIconPixmap --
 *   Adjust icon pixmap size.
 */
Pixmap FixIconPixmap(Pixmap origPix, unsigned int width, unsigned int height,
		     int size, unsigned int depth, unsigned long fore,
		     unsigned long back)
{
  XImage *srcImage, *destImage;
  char* data = new char[size*size*depth/8];
  Point pt;
  unsigned long pixel;
  Pixmap pix;
  GC gc;

  srcImage = XGetImage(display, origPix, 0, 0, width, height, AllPlanes,
		       XYPixmap);
  destImage = XCreateImage(display, DefaultVisual(display, screen), depth,
			   XYPixmap, 0, data, size, size, 8, 0);

  for (int x = 0; x < size; x++) {
    pt.x = (int)((double)width / size * x);
    for (int y = 0; y < size; y++) {
      pt.y = (int)((double)height / size * y);

      pixel = XGetPixel(srcImage, pt.x, pt.y);
      if (pixel == 0)
	XPutPixel(destImage, x, y, back);
      else
	XPutPixel(destImage, x, y, fore);
    }
  }

  pix = XCreatePixmap(display, root, size, size, depth);
  gc = XCreateGC(display, pix, 0, 0);
  XPutImage(display, pix, gc, destImage, 0, 0, 0, 0, size, size);

  XFreeGC(display, gc);
  XDestroyImage(srcImage);
  XDestroyImage(destImage);

  return pix;
}

void Qvwm::SetStateProperty(int state)
{
  unsigned long data[2];
  
  data[0] = (unsigned long)state;
  data[1] = (unsigned long)tButton->GetFrameWin();
  
  XChangeProperty(display, wOrig, _XA_WM_STATE, _XA_WM_STATE, 32, 
		  PropModeReplace, (unsigned char *)data, 2);
}
