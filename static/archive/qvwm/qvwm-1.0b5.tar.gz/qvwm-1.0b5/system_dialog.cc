#include <string.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "main.h"
#include "misc.h"
#include "system_dialog.h"
#include "radio_button.h"
#include "radio_set.h"
#include "string_button.h"

SystemDialog::SystemDialog(Rect rc, char* name, DialogRes* dr, int drNum)
: Dialog(rc, name)
{
  XSetWindowAttributes attributes;
  unsigned long valueMask;
  
  attributes.background_pixel = gray;
  attributes.override_redirect = True;
  attributes.event_mask = ExposureMask;
  valueMask = CWBackPixel | CWOverrideRedirect | CWEventMask;

  parent = XCreateWindow(display, root,
			 rc.x-3, rc.y-4-TITLE_HEIGHT/2,
			 rc.width+6, rc.height+9+TITLE_HEIGHT,
			 0, CopyFromParent, InputOutput, CopyFromParent,
			 valueMask, &attributes);

  valueMask = CWEventMask;

  title = XCreateWindow(display, parent,
			3, 3, rc.width, TITLE_HEIGHT,
			0, CopyFromParent, InputOutput, CopyFromParent,
			valueMask, &attributes);

  XReparentWindow(display, frame, parent, 3, 6+TITLE_HEIGHT);

  CreateDialogResource(dr, drNum);
}

SystemDialog::~SystemDialog()
{
  int i;

  for (i = 0; i < sbNum; i++)
    delete sb[i];
  delete [] sb;

  for (i = 0; i < rsNum; i++)
    delete rs[i];
  delete [] rs;

  for (i = 0; i < stNum; i++)
    delete st[i];
  delete [] st;

  for (i = 0; i < ipNum; i++)
    delete ip[i];
  delete [] ip;

  XUnmapWindow(display, frame);
  XReparentWindow(display, frame, root, 0, 0);
  XDestroyWindow(display, parent);
}

/*
 * CreateDialogResource --
 *   Create resources for system dialog.
 */
void SystemDialog::CreateDialogResource(DialogRes* dr, int drNum)
{
  RadioButton** rb;
  int i, nRb = 0, nSb = 0, nRs = 0, nSt = 0, nIp = 0;

  sbNum = rsNum = stNum = ipNum = 0;

  for (i = 0; i < drNum; i++)
    switch (dr[i].kind) {
    case STRINGBUTTON:
      sbNum++;
      break;

    case RADIOSET:
      rsNum++;
      break;

    case STATICTEXT:
      stNum++;
      break;

    case ICONPIXMAP:
      ipNum++;
      break;
    }

  if (sbNum != 0)
    sb = new StringButton*[sbNum];
  if (rsNum != 0)
    rs = new RadioSet*[rsNum];
  if (stNum != 0)
    st = new StaticText*[stNum];
  if (ipNum != 0)
    ip = new IconPixmap*[ipNum];

  rb = new RadioButton*[drNum];

  for (i = 0; i < drNum; i++) {
    switch (dr[i].kind) {
    case STRINGBUTTON:
      sb[nSb++] = new StringButton(frame, dr[i].rc, dr[i].str, dr[i].fs,
				   dr[i].rid);
      break;
      
    case RADIOBUTTON:
      rb[nRb++] = new RadioButton(frame, Point(dr[i].rc.x, dr[i].rc.y),
				  dr[i].str, dr[i].fs, dr[i].rid);
      break;

    case RADIOSET:
      rs[nRs++] = new RadioSet(rb, nRb, dr[i].rid, dr[i].initId);
      nRb = 0;
      break;

    case STATICTEXT:
      st[nSt++] = new StaticText(Point(dr[i].rc.x, dr[i].rc.y), dr[i].str,
				 dr[i].fs);
      break;

    case ICONPIXMAP:
      XSetClipOrigin(display, dr[i].gc, dr[i].rc.x, dr[i].rc.y);
      ip[nIp++] = new IconPixmap(dr[i].rc, dr[i].pix, dr[i].gc);
      break;
    }
  }
}

void SystemDialog::MapDialog()
{
  int i;

  XMapRaised(display, parent);
  XMapWindow(display, title);

  Dialog::MapDialog();

  for (i = 0; i < sbNum; i++)
    sb[i]->MapButton();
  for (i = 0; i < rsNum; i++)
    rs[i]->MapRadioButtons();
}

/*
 * DrawDialog --
 *   Draw the dialog frame.
 */
void SystemDialog::DrawDialog()
{
  XPoint xp[3];
  int width, height;

  width = rc.width + 6;
  height = rc.height + 9 + TITLE_HEIGHT;

  xp[0].x = width - 1;
  xp[0].y = 0;
  xp[1].x = width - 1;
  xp[1].y = height - 1;
  xp[2].x = 0;
  xp[2].y = height - 1;

  XSetForeground(display, ::gc, black);
  XDrawLines(display, parent, ::gc, xp, 3, CoordModeOrigin);

  xp[0].x = width - 3;
  xp[0].y = 1;
  xp[1].x = 1;
  xp[1].y = 1;
  xp[2].x = 1;
  xp[2].y = height - 3;

  XSetForeground(display, ::gc, white);
  XDrawLines(display, parent, ::gc, xp, 3, CoordModeOrigin);
  
  xp[0].x = width - 2;
  xp[0].y = 1;
  xp[1].x = width - 2;
  xp[1].y = height - 2;
  xp[2].x = 1;
  xp[2].y = height - 2;

  XSetForeground(display, ::gc, darkGray);
  XDrawLines(display, parent, ::gc, xp, 3, CoordModeOrigin);
}  

/*
 * DrawTitle --
 *   Draw the title.
 */
void SystemDialog::DrawTitle()
{
  XRectangle ink, log;
  Point ptTitle;

  XSetWindowBackground(display, title, blue);
  XClearWindow(display, title);

  XmbTextExtents(fsTitle, name, strlen(name), &ink, &log);
  ptTitle.x = 4;
  ptTitle.y = (TITLE_HEIGHT-log.height)/2 - log.y;
  
  XSetForeground(display, ::gc, white);
  XmbDrawString(display, title, fsTitle, ::gc, ptTitle.x, ptTitle.y,
		name, strlen(name));
}  

/*
 * GetSelectableRB --
 *   Get selectable radio set.
 */
ResourceId SystemDialog::GetSelectedRB(ResourceId idRadioSet)
{
  for (int i = 0; i < rsNum; i++)
    if (rs[i]->GetResId() == idRadioSet)
      return rs[i]->GetFocusRB();

  return NO_ID;
}

/*
 * DrawClientWin --
 *   Draw client window.
 */
void SystemDialog::DrawClientWin()
{
  int i;
  XRectangle ink, log;

  /*
   * Draw texts.
   */
  for (i = 0; i < stNum; i++) {
    XmbTextExtents(st[i]->fs, st[i]->text, strlen(st[i]->text), &ink, &log);
    XSetForeground(display, ::gc, black);
    XmbDrawString(display, frame, st[i]->fs, ::gc, st[i]->pt.x,
		  st[i]->pt.y-log.y, st[i]->text, strlen(st[i]->text));
  }

  /*
   * Draw icon pixmaps.
   */
  for (i = 0; i < ipNum; i++)
    XCopyArea(display, ip[i]->pix, frame, ip[i]->gc, 0, 0,
	      ip[i]->rc.width, ip[i]->rc.height, ip[i]->rc.x, ip[i]->rc.y);
}

/*
 * Exposure --
 *   Process expose event.
 */
void SystemDialog::Exposure(Window win)
{
  StringButton* sb;
  RadioButton* rb;

  if (XFindContext(display, win, Button::context, (caddr_t*)&sb) == XCSUCCESS)
    sb->DrawButton();
  else if (XFindContext(display, win, RadioButton::context, (caddr_t*)&rb)
                                                                 == XCSUCCESS)
    rb->DrawButton(True);
  else {
    if (win == parent)
      DrawDialog();
    else if (win == title)
      DrawTitle();
    else if (win == frame)
      DrawClientWin();
  }
}

/*
 * Button1Press --
 *   Process the press of button1(mouse left button).
 */
ResourceId SystemDialog::Button1Press(Window win)
{
  StringButton* sb;
  RadioButton* rb;

  if (XFindContext(display, win, Button::context, (caddr_t*)&sb)
                                                               == XCSUCCESS) {
    sb->Button1Press();
    if (sb->IsTriggered())
      return sb->GetResId();
  }
  else if (XFindContext(display, win, RadioButton::context, (caddr_t*)&rb)
	                                                        == XCSUCCESS)
    rb->Button1Press();

  return NO_ID;
}
