#ifndef _UTIL_H_
#define _UTIL_H_

#include "taskbar.h"

/*
 * Qvwm function number.
 */
enum FuncNumber {
  Q_NONE,
  Q_SEPARATOR,
  Q_END,
  Q_DIR,
  Q_EXEC,
  Q_RESTORE,
  Q_MOVE,
  Q_RESIZE,
  Q_MINIMIZE,
  Q_MAXIMIZE,
  Q_CLOSE,
  Q_KILL,
  Q_EXIT,
  Q_BOTTOM,
  Q_TOP,
  Q_LEFT,
  Q_RIGHT,
  Q_RESTART,
  Q_CHANGEWINDOW,
  Q_SWITCHTASK,
  Q_POPUPSTARTMENU,
  Q_POPUPMENU,
  Q_POPDOWNMENU,
  Q_POPDOWNALLMENU,
  Q_UPFOCUS,
  Q_DOWNFOCUS,
  Q_RIGHTFOCUS,
  Q_LEFTFOCUS,
  Q_ACTION,
  Q_LEFTPAGING,
  Q_RIGHTPAGING,
  Q_UPPAGING,
  Q_DOWNPAGING,
};

/*
 * The origin of menu.
 */
struct MenuOrigin {
  char* name;
  char* file;
  FuncNumber func;
  char* exec;
  MenuOrigin* next;
};

/*
 * ShortCutKey.
 */
struct ShortCutKey {
  KeySym sym;                     // symbol
  unsigned int mod;               // modifier
  FuncNumber func;                // function
};

/*
 * Fontset and fontname.
 */
struct FsNameSet {
  XFontSet* fs;
  char** fontname;
};

/*
 * Attribute bit and the name.
 */
struct AttrNameSet {
  char* name;
  unsigned long flag;
};

/*
 * Size and bitmask from GetGeometry().
 */
class InternGeom {
public:
  int x, y;
  unsigned int width, height;
  int bitmask;

public:
  InternGeom() {}
  InternGeom(int x, int y, unsigned int width, unsigned int height, int bmask)
    : x(x), y(y), width(width), height(height), bitmask(bmask) {}
};

class Menu;

extern Bool InRect(Point pt, Rect rc);
extern Bool IsDoubleClick(Time prevTime, Time clickTime, Point prevPt,
			  Point clickPt);
extern int GetOriginNum(MenuOrigin* fOrigin);
extern Bool CreatePixmapFromFile(char* file, Pixmap& pix, Pixmap& mask,
				 GC& gc);
extern Taskbar::TaskbarPos GetDisplayArea(Point pt);
extern char* GetFixName(XFontSet& fs, char* name, unsigned int width);
extern void ExecShortCutKey(int num, ShortCutKey sck[], XKeyEvent* ev,
			    Menu* menu);
extern int max(int x, int y);
extern Bool MappedNotOverride(Window w);

#endif // _UTIL_H_
