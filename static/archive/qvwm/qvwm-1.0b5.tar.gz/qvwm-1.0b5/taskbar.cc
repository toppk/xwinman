#include <stdio.h>
#include <string.h>
#include <time.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "taskbar.h"
#include "tbutton.h"
#include "sbutton.h"
#include "startmenu.h"
#include "events.h"
#include "icon.h"
#include "paging.h"
#include "pager.h"
#include "qvwmrc.h"

Taskbar::Taskbar(Qvwm* qvWm)
{
  XSetWindowAttributes attributes;
  unsigned long valueMask;
  Dim dRoot(DisplayWidth(display, screen), DisplayHeight(display, screen));

  rc[BOTTOM] = Rect(0, dRoot.height-BASE_HEIGHT, dRoot.width, BASE_HEIGHT);
  rc[TOP] = Rect(0, 0, dRoot.width, BASE_HEIGHT);
  rc[LEFT] = Rect(0, 0, BASE_WIDTH, dRoot.height);
  rc[RIGHT] = Rect(dRoot.width-BASE_WIDTH, 0, BASE_WIDTH, dRoot.height);

  /*
   * Create taskbar.
   */
  attributes.background_pixel = gray;
  attributes.override_redirect = True;
  attributes.event_mask = ExposureMask | ButtonPressMask | ButtonReleaseMask |
                          Button1MotionMask;
  valueMask = CWBackPixel | CWOverrideRedirect | CWEventMask;

  frame = XCreateWindow(display, root,
			-10, -10, 10, 10,
			0, CopyFromParent, InputOutput, CopyFromParent,
			valueMask, &attributes);

  attributes.event_mask = ButtonPressMask | ButtonReleaseMask |
                          Button1MotionMask;
  attributes.background_pixel = gray;
  attributes.cursor = cursor[SYS];
  valueMask = CWBackPixel | CWCursor | CWEventMask;

  w = XCreateWindow(display, frame,
		    0, 0, 10, 10,
		    0, CopyFromParent, InputOutput, CopyFromParent,
		    valueMask, &attributes);

  /*
   * Create clock.
   */
  attributes.event_mask = ExposureMask;
  valueMask = CWBackPixel | CWEventMask;

  clock = XCreateWindow(display, w,
			0, 0, CLOCK_WIDTH, CLOCK_HEIGHT,
			0, CopyFromParent, InputOutput, CopyFromParent,
			valueMask, &attributes);
  
  XSaveContext(display, frame, Qvwm::context, (caddr_t)qvWm);
  XSaveContext(display, w, Qvwm::context, (caddr_t)qvWm);
  XSaveContext(display, clock, Qvwm::context, (caddr_t)qvWm);
}

Taskbar::~Taskbar()
{
  XDestroyWindow(display, frame);

  XDeleteContext(display, frame, Qvwm::context);
  XDeleteContext(display, clock, Qvwm::context);
}

/*
 * MapTaskbar --
 *   Map the taskbar.
 */
void Taskbar::MapTaskbar()
{
  XMapRaised(display, frame);
  XMapWindow(display, w);
  rootQvwm->tButton->MapButton();         // Start menu
  XMapWindow(display, clock);

  paging->RaisePagingBelt();
}

/*
 * UnmapTaskbar --
 *   Unmap the taskbar.
 */
void Taskbar::UnmapTaskbar()
{
  XUnmapWindow(display, frame);
}

/*
 * MoveTaskbar --
 *   Move the taskbar to the tp position.
 */
void Taskbar::MoveTaskbar(TaskbarPos tp)
{
  Rect rcRoot = rootQvwm->GetRect();

  pos = tp;

  XMoveResizeWindow(display, frame, rc[pos].x, rc[pos].y, rc[pos].width,
		    rc[pos].height);

  switch (pos) {
  case BOTTOM:
    XDefineCursor(display, frame, cursor[Y_RESIZE]);
    XMoveResizeWindow(display, w, 0, 4, rc[BOTTOM].width,
		      rc[BOTTOM].height-4);

    TaskbarButton::TButtonRc.x = 2;
    TaskbarButton::TButtonRc.y = 0;

    rcScreen = Rect(0, 0, rcRoot.width, rcRoot.height-rc[BOTTOM].height);
    buttonArea = rcRoot.width - (StartButton::BUTTON_WIDTH + CLOCK_WIDTH + 8);

    XMoveWindow(display, clock, rcScreen.width-CLOCK_WIDTH-3, 0);
    break;

  case TOP:
    XDefineCursor(display, frame, cursor[Y_RESIZE]);
    XMoveResizeWindow(display, w, 0, 0, rc[TOP].width, rc[TOP].height-4);

    TaskbarButton::TButtonRc.x = 2;
    TaskbarButton::TButtonRc.y = 2;

    rcScreen = Rect(0, rc[TOP].height,
		    rcRoot.width, rcRoot.height-rc[TOP].height);
    buttonArea = rcRoot.width - (StartButton::BUTTON_WIDTH + CLOCK_WIDTH + 8);

    XMoveWindow(display, clock, rc[TOP].width-CLOCK_WIDTH-3, 2);
    break;

  case LEFT:
    XDefineCursor(display, frame, cursor[X_RESIZE]);
    XMoveResizeWindow(display, w, 0, 0, rc[LEFT].width-4, rc[LEFT].height);

    TaskbarButton::TButtonRc.x = 2;
    TaskbarButton::TButtonRc.y = 2;

    rcScreen = Rect(rc[LEFT].width, 0,
		    rcRoot.width-rc[LEFT].width, rcRoot.height);

    if (rc[LEFT].width < StartButton::BUTTON_WIDTH+CLOCK_WIDTH+19) {
      XMoveWindow(display, clock,
		  (rc[LEFT].width - 2 -CLOCK_WIDTH) / 2,
		  rc[LEFT].height - CLOCK_HEIGHT - 6);
      buttonArea = rcRoot.height - (TaskbarButton::TButtonRc.y
				    + TaskbarButton::BUTTON_HEIGHT
				    + TaskbarButton::BETWEEN_SPACE
				    + CLOCK_HEIGHT + 6);
    }
    else {
      XMoveWindow(display, clock,
		  StartButton::BUTTON_WIDTH + 11, TaskbarButton::TButtonRc.y);
      buttonArea = rcRoot.height - (TaskbarButton::TButtonRc.y
				    + TaskbarButton::BUTTON_HEIGHT
				    + TaskbarButton::BETWEEN_SPACE);
    }
    break;

  case RIGHT:
    XDefineCursor(display, frame, cursor[X_RESIZE]);
    XMoveResizeWindow(display, w, 4, 0, rc[RIGHT].width-4, rc[RIGHT].height);

    TaskbarButton::TButtonRc.x = 0;
    TaskbarButton::TButtonRc.y = 2;

    rcScreen = Rect(0, 0, rcRoot.width-rc[RIGHT].width, rcRoot.height);
    if (rc[RIGHT].width < StartButton::BUTTON_WIDTH+CLOCK_WIDTH+19) {
      XMoveWindow(display, clock,
		  (rc[RIGHT].width - 2 - CLOCK_WIDTH) / 2,
		  rc[RIGHT].height - CLOCK_HEIGHT - 6);
      buttonArea = rcRoot.height - (TaskbarButton::TButtonRc.y
				    + TaskbarButton::BUTTON_HEIGHT
				    + TaskbarButton::BETWEEN_SPACE
				    + CLOCK_HEIGHT + 6);
    }
    else {
      XMoveWindow(display, clock,
		  StartButton::BUTTON_WIDTH + 11, TaskbarButton::TButtonRc.y);
      buttonArea = rcRoot.height - (TaskbarButton::TButtonRc.y
				    + TaskbarButton::BUTTON_HEIGHT
				    + TaskbarButton::BETWEEN_SPACE);
    }
    break;
  }

  TaskbarButton::RedrawAllTaskbarButtons();
  Qvwm::RecalcAllWindows();
  Icon::RedrawAllIcons();
  if (UsePager)
    pager->RecalcPager();

  paging->RaisePagingBelt();
}

/*
 * MoveTaskbar --
 *   Drag the taskbar to move.
 */
void Taskbar::MoveTaskbar()
{
  XEvent ev;
  Window junkRoot, junkChild;
  Point rootPt, junkPt;
  unsigned int mask;
  Rect rcRoot = rootQvwm->GetRect();

  /*
   * There is parts that cannot let taskbar to move.
   */
  switch (pos) {
  case BOTTOM:
    if (pressPt.y == (int)rcRoot.height-1 || pressPt.y == (int)rcRoot.height-2)
      return;
    break;

  case TOP:
    if (pressPt.y == 0 || pressPt.y == 1)
      return;
    break;

  case LEFT:
    if (pressPt.x == 0 || pressPt.x == 1)
      return;
    break;

  case RIGHT:
    if (pressPt.x == (int)rcRoot.width-1 || pressPt.x == (int)rcRoot.width-2)
      return;
    break;
  }
  
  if (!OpaqueMove) {
    XGrabServer(display);
    XDrawRectangle(display, root, gcXor, rc[pos].x, rc[pos].y, rc[pos].width,
		   rc[pos].height);
  }

  while (1) {
    XNextEvent(display, &ev);
    switch (ev.type) {
    case MotionNotify:
      if (!OpaqueMove)
	XDrawRectangle(display, root, gcXor, rc[pos].x, rc[pos].y,
		       rc[pos].width, rc[pos].height);

      XQueryPointer(display, root, &junkRoot, &junkChild, &rootPt.x, &rootPt.y,
		    &junkPt.x, &junkPt.y, &mask);
      pos = GetDisplayArea(rootPt);

      if (OpaqueMove)
	MoveTaskbar(pos);
      else
	XDrawRectangle(display, root, gcXor, rc[pos].x, rc[pos].y,
		       rc[pos].width, rc[pos].height);
      break;

    case ButtonRelease:
      if (!OpaqueMove) {
	XDrawRectangle(display, root, gcXor, rc[pos].x, rc[pos].y,
		       rc[pos].width, rc[pos].height);
	XUngrabServer(display);
      }

      XQueryPointer(display, root, &junkRoot, &junkChild, &rootPt.x, &rootPt.y,
		    &junkPt.x, &junkPt.y, &mask);
      MoveTaskbar(GetDisplayArea(rootPt));
      return;
      
    case Expose:
      ExposeProc(ev.xexpose.window);
      break;
    }
  }
}  

/*
 * ResizeTaskbar --
 *   Resize the taskbar.
 */
void Taskbar::ResizeTaskbar()
{
  RectPt resize;
  XEvent ev;
  Rect newRc = rc[pos], oldRc = rc[pos];
  Window junkRoot, junkChild;
  Point rootPt, junkPt;
  unsigned int mask;
  Rect rcRoot = rootQvwm->GetRect();

  if (!OpaqueMove) {
    XGrabServer(display);
    XDrawRectangle(display, root, gcXor,
		   newRc.x, newRc.y, newRc.width, newRc.height);
  }

  while (1) {
    XNextEvent(display, &ev);
    switch (ev.type) {
    case MotionNotify:
      if (!OpaqueMove)
	XDrawRectangle(display, root, gcXor,
		       newRc.x, newRc.y, newRc.width, newRc.height);

      resize = RectPt(0, 0, 0, 0);
      XQueryPointer(display, frame, &junkRoot, &junkChild,
		    &rootPt.x, &rootPt.y, &junkPt.x, &junkPt.y, &mask);

      switch (pos) {
      case BOTTOM:
	resize.top = rootPt.y - pressPt.y;
	break;

      case TOP:
	resize.bottom = rootPt.y - pressPt.y;
	break;

      case LEFT:
	resize.right = rootPt.x - pressPt.x;
	break;

      case RIGHT:
	resize.left = rootPt.x - pressPt.x;
	break;
      }
      
      newRc.x = oldRc.x + resize.left;
      newRc.y = oldRc.y + resize.top;
      newRc.width = oldRc.width - resize.left + resize.right;
      newRc.height = oldRc.height - resize.top + resize.bottom;
      
      /*
       * Adjust.
       */
      switch (pos) {
      case BOTTOM:
      case TOP:
	if (newRc.height > rcRoot.height/2)
	  newRc.height = rcRoot.height / 2;
	newRc.height = newRc.height / INC_HEIGHT * INC_HEIGHT + 3;
	if (newRc.height < 6)
	  newRc.height = 6;
	break;

      case LEFT:
      case RIGHT:
	if (newRc.width > rcRoot.width/2)
	  newRc.width = rcRoot.width / 2;
	if (newRc.width < 6)
	  newRc.width = 6;
	break;
      }
      
      if (pos == BOTTOM)
	newRc.y = rcRoot.height - newRc.height;
      if (pos == RIGHT)
	newRc.x = rcRoot.width - newRc.width;
      
      if (OpaqueMove) {
	rc[pos] = newRc;
	MoveTaskbar(pos);
      }
      else 
	XDrawRectangle(display, root, gcXor,
		       newRc.x, newRc.y, newRc.width, newRc.height);
      break;
      
    case ButtonRelease:
      if (!OpaqueMove) {
	XDrawRectangle(display, root, gcXor,
		       newRc.x, newRc.y, newRc.width, newRc.height);
	XUngrabServer(display);
      }

      rc[pos] = newRc;
      MoveTaskbar(pos);
      return;

    case Expose:
      ExposeProc(ev.xexpose.window);
      break;
    }
  }
}  

/*
 * RaiseTaskbar --
 *   Raise the taskbar.
 */
void Taskbar::RaiseTaskbar()
{
  XRaiseWindow(display, frame);

  paging->RaisePagingBelt();
}

/*
 * DrawTaskbar --
 *   Draw the taskbar.
 */
void Taskbar::DrawTaskbar()
{
  Window win[2];
  int nwindows = 0;

  switch (pos) {
  case BOTTOM:
    XSetForeground(display, gc, white);
    XDrawLine(display, frame, gc, rc[BOTTOM].x, 1, rc[BOTTOM].width-1, 1);
    break;

  case TOP:
    XSetForeground(display, gc, darkGray);
    XDrawLine(display, frame, gc, rc[TOP].x, rc[TOP].height-2,
	      rc[TOP].width-1, rc[TOP].height-2);
    XSetForeground(display, gc, black);
    XDrawLine(display, frame, gc, rc[TOP].x, rc[TOP].height-1,
	      rc[TOP].width-1, rc[TOP].height-1);
    break;

  case LEFT:
    XSetForeground(display, gc, darkGray);
    XDrawLine(display, frame, gc, rc[LEFT].width-2, rc[LEFT].y,
	      rc[LEFT].width-2, rc[LEFT].height-1);
    XSetForeground(display, gc, black);
    XDrawLine(display, frame, gc, rc[LEFT].width-1, rc[LEFT].y,
	      rc[LEFT].width-1, rc[LEFT].height-1);
    break;

  case RIGHT:
    XSetForeground(display, gc, white);
    XDrawLine(display, frame, gc, 1, rc[RIGHT].y, 1, rc[RIGHT].height-1);
    break;
  }

  if (startMenu != NULL && startMenu->CheckMapped())
    win[nwindows++] = startMenu->GetFrameWin();
  else if (Qvwm::focusQvwm->CheckMenuMapped())
    win[nwindows++] = Qvwm::focusQvwm->ctrlMenu->GetFrameWin();
  win[nwindows++] = frame;

  XRestackWindows(display, win, nwindows);
}

/*
 * DrawClock --
 *   Draw the clock in the right or bottom side.
 */
void Taskbar::DrawClock()
{
  XPoint xp[3];
  time_t tm;
  char *tmStr, str[5];
  Point pt;
  XRectangle ink, log;

  xp[0].x = CLOCK_WIDTH - 2;
  xp[0].y = 0;
  xp[1].x = 0;
  xp[1].y = 0;
  xp[2].x = 0;
  xp[2].y = CLOCK_HEIGHT - 2;

  XSetForeground(display, gc, darkGray);
  XDrawLines(display, clock, gc, xp, 3, CoordModeOrigin);

  xp[0].x = CLOCK_WIDTH - 1;
  xp[0].y = 0;
  xp[1].x = CLOCK_WIDTH - 1;
  xp[1].y = CLOCK_HEIGHT - 1;
  xp[2].x = 0;
  xp[2].y = CLOCK_HEIGHT - 1;

  XSetForeground(display, gc, white);
  XDrawLines(display, clock, gc, xp, 3, CoordModeOrigin);

  time(&tm);
  tmStr = ctime(&tm);
  strncpy(str, &tmStr[11], 5);

  XmbTextExtents(fsTaskbar, str, 5, &ink, &log);
  pt.x = (CLOCK_WIDTH - log.width) / 2 - log.x;
  pt.y = (CLOCK_HEIGHT - log.height) / 2 - log.y;

  XSetForeground(display, gc, black);
  XSetBackground(display, gc, gray);
  XmbDrawImageString(display, clock, fsTaskbar, gc, pt.x, pt.y, str, 5);
}

/*
 * Exposure --
 *   Process expose event.
 */
void Taskbar::Exposure(Window win)
{
  if (win == frame)
    DrawTaskbar();
  else if (win == clock)
    DrawClock();
}

/*
 * Button1Motion --
 *   Process drag.
 */
void Taskbar::Button1Motion(Window win)
{
  if (win == w)
    MoveTaskbar();
  else if (win == frame)
    ResizeTaskbar();
}
