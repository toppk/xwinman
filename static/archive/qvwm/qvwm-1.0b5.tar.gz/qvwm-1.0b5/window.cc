#include <stdio.h>
#include <signal.h>
#include <sys/time.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "main.h"
#include "qvwm.h"
#include "misc.h"
#include "util.h"
#include "fbutton.h"
#include "tbutton.h"
#include "menu.h"
#include "qvwmrc.h"

void Qvwm::MapWindows()
{
  mapped = True;

  XMapRaised(display, frame);

  if (CheckFlags(BORDER)) {
    for (int i = 0; i < 4; i++) {
      XMapWindow(display, side[i]);
      XMapWindow(display, corner[i]);
    }
  }
  else {
    for (int i = 0; i < 4; i++) {
      XUnmapWindow(display, side[i]);
      XUnmapWindow(display, corner[i]);
    }
  }

  if (CheckFlags(TITLE)) {
    XMapRaised(display, title);
    if (CheckFlags(CTRL_MENU))
      XMapWindow(display, ctrl);
    else
      XUnmapWindow(display, ctrl);
    if (CheckFlags(BUTTON1))
      fButton[0]->MapButton();
    else
      fButton[0]->UnmapButton();
    if (CheckFlags(BUTTON2))
      fButton[1]->MapButton();
    else
      fButton[1]->UnmapButton();
    if (CheckFlags(BUTTON3) || CheckFlags(WM_DELETE_WINDOW)) {
      SetFlags(BUTTON3);
      fButton[2]->MapButton();
    }
    else
      fButton[2]->UnmapButton();
  }
  else
    XUnmapWindow(display, title);

  XMapRaised(display, parent);
  XMapWindow(display, wOrig);

  taskBar->RaiseTaskbar();
}

void Qvwm::UnmapWindows()
{
  /*
   * Unmap all menus.
   */
  if (CheckMenuMapped())
    ctrlMenu->UnmapMenu();

  mapped = False;

  XUnmapWindow(display, frame);
}

void Qvwm::RaiseWindow(Bool soon)
{
  struct itimerval itv;

  if (this == rootQvwm)
    return;

  if (!soon && AutoRaise) {
    itv.it_value.tv_sec = 0;
    itv.it_value.tv_usec = AutoRaiseDelay*1000;
    itv.it_interval.tv_sec = 0;
    itv.it_interval.tv_usec = 0;
    setitimer(ITIMER_REAL, &itv, NULL);
  }
  else {
    if (CheckMapped()) {
      XRaiseWindow(display, frame);
      taskBar->RaiseTaskbar();
    }
  }
}
