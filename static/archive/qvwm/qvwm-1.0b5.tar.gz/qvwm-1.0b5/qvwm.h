#ifndef _QVWM_H_
#define _QVWM_H_

#include "main.h"
#include "misc.h"
#include "util.h"
#include "menu.h"
#include "hash.h"

/*
 * Frame attributes
 */
#define TITLE             (1 << 0)
#define BORDER            (1 << 1)
#define CTRL_MENU         (1 << 2)
#define BUTTON1           (1 << 3)
#define BUTTON2           (1 << 4)
#define BUTTON3           (1 << 5)
#define TRANSIENT         (1 << 6)
#define WM_DELETE_WINDOW  (1 << 7)
#define DIALOG            (1 << 8)
#define STICKY            (1 << 9)
#define NOFOCUS           (1 << 10)

/*
 * Window status
 */
#define MINIMIZE_WINDOW  (1L << 0)
#define MAXIMIZE_WINDOW  (1L << 1)

class FrameButton;
class TaskbarButton;

/*
 * Qvwm class
 */
class Qvwm {
friend class TaskSwitcher;
private:
  Qvwm* next;
  Qvwm* prev;
  Qvwm* preFocus;                // FocusQvwm before get focus

  Window wOrig;                  // Original window 
  Rect rcOrig;                   // Original window position
  unsigned int bwOrig;           // Original border width 

  Window frame;                  // Frame window (child of root window) 
  Window parent;                 // Parent window of original window 
  Window corner[4];              // Corner window 
  Window side[4];                // Side border window 
  Window title;                  // Title window 
  Window ctrl;                   // Control menu window 
  Rect rc;                       // Frame position
  unsigned long flags;           // Frame attributes (with title etc.) 
  unsigned long bFlags;          // Frame attributes (backup when maximize)
  unsigned int status;           // Window status (maximize etc.) 
  Bool mapped;                   // Flag if this window is mapped
  char* name;                    // Window name 
  Pixmap pixLarge;               // Large icon pixmap for task switcher
  GC gcLarge;
  XSizeHints hints;
  XClassHint classHints;

  Window* cmapWins;              // Colormap window list
  int nCmapWins;                 // # of elements of the list

  // Temporary
  Time menuClickTime;            // Previous left click time of menu button 
  Time titleClickTime;           // Previous left click time of titlebar 
  Rect bOrigRc;                  // Original window position backup

  static Bool umReserved;        // Ctrl menu unmap reserved flag

  static const int BUTTON_WIDTH = 16;      // frame button width
  static const int BUTTON_HEIGHT = 14;     // frame button height
  static const int MOVEMENT = 13;

public:
  FrameButton* fButton[3];       // Frame button (minimize etc.) 
  TaskbarButton* tButton;        // Taskbar button 
  Menu* ctrlMenu;                // Control popup menu 

  static Qvwm* lastQvwm;
  static Qvwm* focusQvwm;
  static XContext context;
  static Hash<unsigned long>* attrHashTable;

  static const int TITLE_HEIGHT = BUTTON_HEIGHT + 4;
  static const int BORDER_WIDTH = 4;

  // frame position name
  enum PositionName { LEFT, RIGHT, TOP, BOTTOM,
		      LEFTTOP, RIGHTTOP, LEFTBOTTOM, RIGHTBOTTOM };

private:
  void CreateFrame(Rect rect);
  void CreateParent(Rect rect);
  void CreateSides(Rect rect[]);
  void CreateCorners(Rect rect[]);  
  void CreateTitle(Rect rect);
  void CreateCtrlButton(Rect rect);
  void ChangeOrigWindow();

  void MotionTitlebar(Rect src, Rect dest);
  Rect GetFixSize(Rect rc, int max_width, int max_height, int width_inc,
		  int height_inc, int base_width, int base_height);

  void DrawTitle();
  void DrawCtrlMenuMark();
  void DrawFrame();
  void RedrawWindow();
  void CalcWindowPos(Rect base);
  void CalcFramePos(Rect frameRc, Rect* parentRc, Rect* titleRc,
		    Rect cornerRc[], Rect sideRc[], Rect* ctrlRc,
		    Rect buttonRc[]);

  void ResetFocus() { tButton->ResetFocus(); }

  void GrabKeys();
  void GrabRootKeys();
  void UngrabRootKeys();

  void FetchWMColormapWindows();
  void GetWindowClassHints();
  void GetWindowSizeHints();
  Point GetGravityOffset();
  void GetFixedIcon(Pixmap& pix, GC& gc, int size);

  void ConfigureNewRc(Rect newRc);

public:
  Qvwm(Window w, Bool usrPos);
  Qvwm(Window root);
  ~Qvwm();

  Qvwm* GetNext() const { return next; }
  Window GetFrameWin() const { return frame; }
  Window GetWin() const { return wOrig; }
  Bool CheckStatus(unsigned long kind) const { return status & kind; }
  void SetStatus(unsigned long kind) { status |= kind; }
  void ResetStatus(unsigned long kind) { status &= ~kind; }
  Bool CheckFlags(unsigned int kind) const { return flags & kind; }
  void SetFlags(unsigned int kind) { flags |= kind; }
  void ResetFlags(unsigned int kind) { flags &= ~kind; }
  unsigned int GetOrigBW() const { return bwOrig; }
  void SetName(char* str) { name = str; }
  char* GetName() const { return name; }
  Bool CheckMapped() const { return mapped; }
  void ResetMapped() { mapped = False; }
  Bool CheckMenuMapped() const { return ctrlMenu->CheckMapped(); }
  Bool CheckFocus() const { return (this == focusQvwm); }
  Pixmap GetIconPixmap() const { return tButton->GetPixmap(); }
  GC GetIconGC() const { return tButton->GetGC(); }
  Rect GetRect() const { return rc; }
  int GetNumCmapWins() const { return nCmapWins; }

  void MapWindows();
  void UnmapWindows();
  void RaiseWindow(Bool soon);
  void CloseWindow() { SendMessage(_XA_WM_DELETE_WINDOW); }

  void MapMenu(int x, int y) { ctrlMenu->MapMenu(x, y); }
  void UnmapMenu() { ctrlMenu->UnmapMenu(); }

  void SetFocus();
  void ChangeFocus();
  void PushFocusStack();
  Qvwm* GetNextFocus();
  static void RollFocus();

  void MoveWindow();
  void ResizeWindow(PositionName pos);
  void MaximizeWindow();
  void MinimizeWindow();
  void RestoreWindow();

  void ExecFunction(FuncNumber fn);

  void SendMessage(Atom atom);
  void KillClient();

  void SetProperty(Atom atom);
  void FetchWMProtocols();
  void SetStateProperty(int state);

  void Configure(XConfigureRequestEvent* cre);
  void SendConfigureEvent();

  void AdjustPage();

  void InstallWindowColormaps();

  void Exposure(Window win);
  void Button1Press(Window win, Time clickTime);
  void Button1Release();
  void Button3Release(Window win, Point rootPt);
  void Button1Motion(Window win);

  static Qvwm* LookInList(Window w);
  static void CaptureAllWindows();
  static void FinishQvwm(Bool reStart);
  static void RecalcAllWindows();
  static void ChangeFocusToCursor();

};

#endif // _QVWM_H_ 
