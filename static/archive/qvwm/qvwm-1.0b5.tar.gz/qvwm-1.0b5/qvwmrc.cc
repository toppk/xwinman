#include <stdio.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include "main.h"
#include "taskbar.h"
#include "util.h"
#include "parse.h"
#include "qvwmrc.h"
#include "qvwm.h"

/*
 * Default values
 */
int DoubleClickTime                 = 400;
int DoubleClickRange                = 5;
int TitlebarMotionSpeed             = 100;
int MenuDelayTime                   = 500;
int PagingResistance                = 200;
int PagingMovement                  = 100;
int PagingBeltSize                  = 1;
Point TopLeftPage(0, 0);
Dim PagingSize(1, 1);
InternGeom PagerGeometry(0, 0, 48, 48, 0);
Taskbar::TaskbarPos TaskbarPosition = Taskbar::BOTTOM;
char* WallPaper                     = "Windows95";
unsigned long IconForeColor         = 0;
unsigned long IconBackColor         = 1;
char* StartButtonTitle              = "Start";
char* LocaleName                    = "";
Bool UseBoldFont                    = False;
Bool UseExitDialog                  = True;
Bool UsePager                       = False;
Bool OpaqueMove                     = True;
Bool ClickToFocus                   = True;
Bool AutoRaise                      = False;
int AutoRaiseDelay                  = 500;

/*
 * Default fonts
 */
char* TitleFont       = "-*-*-medium-r-normal--14-*";
char* TaskbarFont     = "-*-*-medium-r-normal--14-*";
char* TaskbarBoldFont = "-*-*-medium-r-normal--14-*";
char* CascadeMenuFont = "-*-*-medium-r-normal--14-*";
char* CtrlMenuFont    = "-*-*-medium-r-normal--14-*";
char* StartMenuFont   = "-*-*-medium-r-normal--14-*";
char* IconFont        = "-*-*-medium-r-normal--14-*";

/*
 * Default start menu
 */
MenuOrigin StartMenuTemplate[] =
  {{"Exit qvwm            ", "exit.xpm", Q_EXIT, "", NULL},
   {"",                      "",         Q_END,  "", NULL}};

/*
 * Default control menu
 */
MenuOrigin CtrlMenuTemplate[] =
  {{"Restore      ", "", Q_RESTORE,   "", NULL},
   {"Move",          "", Q_MOVE,      "", NULL},
   {"Resize",        "", Q_RESIZE,    "", NULL},
   {"Minimize",      "", Q_MINIMIZE,  "", NULL},
   {"Maximize",      "", Q_MAXIMIZE,  "", NULL},
   {"",              "", Q_SEPARATOR, "", NULL},
   {"Close",         "", Q_CLOSE,     "", NULL},
   {"Kill",          "", Q_KILL,      "", NULL},
   {"",              "", Q_END,       "", NULL}};

MenuOrigin DesktopMenuTemplate[] =
  {{"DESKTOP", "", Q_NONE, "", NULL},
   {"",        "", Q_END,  "", NULL}};

MenuOrigin* StartMenuOrigin = StartMenuTemplate;
MenuOrigin* CtrlMenuOrigin = CtrlMenuTemplate;
MenuOrigin* DesktopMenuOrigin = DesktopMenuTemplate;

/*
 * Table for used variables
 */
FuncTable funcTable[] =
  {{"QVWM_SEPARATOR", Q_SEPARATOR},
   {"QVWM_RESTORE",   Q_RESTORE},
   {"QVWM_MOVE",      Q_MOVE},
   {"QVWM_RESIZE",    Q_RESIZE},
   {"QVWM_MINIMIZE",  Q_MINIMIZE},
   {"QVWM_MAXIMIZE",  Q_MAXIMIZE},
   {"QVWM_CLOSE",     Q_CLOSE},
   {"QVWM_KILL",      Q_KILL},
   {"QVWM_EXIT",      Q_EXIT},
   {"QVWM_BOTTOM",    Q_BOTTOM},
   {"QVWM_TOP",       Q_TOP},
   {"QVWM_LEFT",      Q_LEFT},
   {"QVWM_RIGHT",     Q_RIGHT},
   {"QVWM_RESTART",   Q_RESTART}};

VariableTable varTable[] =
  {{"DoubleClickTime",      F_NATURAL,  &DoubleClickTime},
   {"DoubleClickRange",     F_NATURAL,  &DoubleClickRange},
   {"TitlebarMotionSpeed",  F_NATURAL,  &TitlebarMotionSpeed},
   {"MenuDelayTime",        F_NATURAL,  &MenuDelayTime},
   {"PagingResistance",     F_NATURAL,  &PagingResistance},
   {"PagingMovement",       F_NATURAL,  &PagingMovement},
   {"PagingBeltSize",       F_NATURAL,  &PagingBeltSize},
   {"TopLeftPage",          F_OFFSET,   &TopLeftPage},
   {"PagingSize",           F_SIZE,     &PagingSize},
   {"PagerGeometry",        F_GEOMETRY, &PagerGeometry},
   {"TaskbarPosition",      F_TASKBAR,  &TaskbarPosition},
   {"AutoRaiseDelay",       F_NATURAL,  &AutoRaiseDelay},
   {"IconForeColor",        F_COLOR,    &IconForeColor},
   {"IconBackColor",        F_COLOR,    &IconBackColor},
   {"WallPaper",            F_STRING,   &WallPaper},
   {"StartButtonTitle",     F_STRING,   &StartButtonTitle},
   {"LocaleName",           F_STRING,   &LocaleName},
   {"UseBoldFont",          F_BOOL,     &UseBoldFont},
   {"UseExitDialog",        F_BOOL,     &UseExitDialog},
   {"UsePager",             F_BOOL,     &UsePager},
   {"OpaqueMove",           F_BOOL,     &OpaqueMove},
   {"ClickToFocus",         F_BOOL,     &ClickToFocus},
   {"AutoRaise",            F_BOOL,     &AutoRaise},
   {"TitleFont",            F_STRING,   &TitleFont},
   {"TaskbarFont",          F_STRING,   &TaskbarFont},
   {"TaskbarBoldFont",      F_STRING,   &TaskbarBoldFont},
   {"CascadeMenuFont",      F_STRING,   &CascadeMenuFont},
   {"CtrlMenuFont",         F_STRING,   &CtrlMenuFont},
   {"StartMenuFont",        F_STRING,   &StartMenuFont},
   {"IconFont",             F_STRING,   &IconFont}};

/*
 * Table for fontset variable and font name.
 */
FsNameSet fsSet[] =
  {{&fsTitle,       &TitleFont},
   {&fsTaskbar,     &TaskbarFont},
   {&fsBoldTaskbar, &TaskbarBoldFont},
   {&fsCascadeMenu, &CascadeMenuFont},
   {&fsCtrlMenu,    &CtrlMenuFont},
   {&fsStartMenu,   &StartMenuFont},
   {&fsIcon,        &IconFont}};

/*
 * Table for short cut keys.
 */
ShortCutKey scKey[] =
  {{XK_F4,     Mod1Mask,    Q_CLOSE},
   {XK_Escape, ControlMask, Q_POPUPSTARTMENU},
   {XK_Escape, Mod1Mask,    Q_CHANGEWINDOW},
   {XK_Tab,    Mod1Mask,    Q_SWITCHTASK},
   {XK_space,  Mod1Mask,    Q_POPUPMENU},
   {XK_Left,   ControlMask, Q_LEFTPAGING},
   {XK_Right,  ControlMask, Q_RIGHTPAGING},
   {XK_Up,     ControlMask, Q_UPPAGING},
   {XK_Down,   ControlMask, Q_DOWNPAGING}};

ShortCutKey scRootKey[] =
  {{XK_Escape, ControlMask, Q_POPUPSTARTMENU},
   {XK_Escape, Mod1Mask,    Q_CHANGEWINDOW},
   {XK_Tab,    Mod1Mask,    Q_SWITCHTASK},
   {XK_F4,     Mod1Mask,    Q_EXIT},
   {XK_Left,   ControlMask, Q_LEFTPAGING},
   {XK_Right,  ControlMask, Q_RIGHTPAGING},
   {XK_Up,     ControlMask, Q_UPPAGING},
   {XK_Down,   ControlMask, Q_DOWNPAGING}};

ShortCutKey scMenuKey[] =
  {{XK_Escape, 0,           Q_POPDOWNMENU},
   {XK_Alt_L,  0,           Q_POPDOWNALLMENU},
   {XK_Alt_R,  0,           Q_POPDOWNALLMENU},
   {XK_Meta_L, 0,           Q_POPDOWNALLMENU},
   {XK_Meta_R, 0,           Q_POPDOWNALLMENU},
   {XK_Up,     0,           Q_UPFOCUS},
   {XK_Down,   0,           Q_DOWNFOCUS},
   {XK_Right,  0,           Q_RIGHTFOCUS},
   {XK_Left,   0,           Q_LEFTFOCUS},
   {XK_Return, 0,           Q_ACTION}};

AttrNameSet attrSet[] =
  {{"STICKY",  STICKY},
   {"NOFOCUS", NOFOCUS}};

const int FuncTableSize = sizeof(funcTable)/sizeof(FuncTable);
const int VarTableSize = sizeof(varTable)/sizeof(VariableTable);
const int FsNum = sizeof(fsSet)/sizeof(FsNameSet);
const int SCKeyNum = sizeof(scKey)/sizeof(ShortCutKey);
const int SCRootKeyNum = sizeof(scRootKey)/sizeof(ShortCutKey);
const int SCMenuKeyNum = sizeof(scMenuKey)/sizeof(ShortCutKey);
const int AttrNum = sizeof(attrSet)/sizeof(AttrNameSet);
