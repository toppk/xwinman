#ifndef _RADIO_BUTTON_H_
#define _RADIO_BUTTON_H_

#include "resource.h"

#define RADIO_PUSH     (1 << 0)
#define RADIO_CHECK    (1 << 1)

class RadioSet;

/*
 * RadioButton class
 */
class RadioButton {
private:
  Window frame;                      // radio button frame
  Point pt;                          // position
  unsigned int status;               // status
  char* name;                        // right text of radio button
  XFontSet& fs;
  ResourceId rid;

  int rbY, rnY;
  Rect fRc;

  RadioSet* rs;

  static const int BUTTON_SIZE = 12;
  static const int CHECK_SIZE = 4;

public:
  static XContext context;

  static Pixmap pixRadio[3];
  static GC gcRadio[3];

public:
  RadioButton(Window parent, Point pt, char* name, XFontSet& fs,
	      ResourceId rid);
  ~RadioButton();
  void SetStatus(unsigned int st) { status |= st; }
  void SetRS(RadioSet* set) { rs = set; }
  ResourceId GetResId() { return rid; }
  
  void MapButton();
  void DrawButton(Bool all);
  void Button1Press();

  static void CreateRadioButtonPixmap();
};

#endif // _RADIO_BUTTON_H_
