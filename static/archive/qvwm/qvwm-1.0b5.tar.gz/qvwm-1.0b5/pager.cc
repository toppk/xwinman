#include <stdio.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "events.h"
#include "pager.h"
#include "paging.h"

Pager::Pager(InternGeom geom) : geom(geom)
{
  XSetWindowAttributes attributes;
  unsigned long valueMask;

  /*
   * If width or height is 0, set default value.
   */
  if (geom.width == 0)
    geom.width = 48;
  if (geom.height == 0)
    geom.height = 48;

  /*
   * Adjust pager size.
   */
  rc.width = geom.width / paging->rcVirt.width * paging->rcVirt.width;
  rc.height = geom.height / paging->rcVirt.height * paging->rcVirt.height;

  AdjustPagerPos();

  /*
   * Create the frame window for pager.
   */
  attributes.background_pixel = gray;
  attributes.override_redirect = True;
  attributes.event_mask = ExposureMask;
  valueMask = CWBackPixel | CWEventMask | CWOverrideRedirect;
  
  frame = XCreateWindow(display, root,
			rc.x, rc.y, rc.width+6, rc.height+14,
			0, CopyFromParent, InputOutput, CopyFromParent,
			valueMask, &attributes);
  
  /*
   * Create the title window.
   */
  attributes.background_pixel = blue;
  attributes.event_mask = ButtonPressMask | ButtonReleaseMask |
                          Button1MotionMask;
  valueMask = CWBackPixel | CWEventMask;
  
  title = XCreateWindow(display, frame,
			3, 3, rc.width, 6,
			0, CopyFromParent, InputOutput, CopyFromParent,
			valueMask, &attributes);
  
  /*
   * Create the window for the miniature of whole virtual screen.
   */
  attributes.background_pixel = gray;
  attributes.event_mask = ButtonPressMask | ExposureMask;
  valueMask = CWBackPixel | CWEventMask;
  
  pager = XCreateWindow(display, frame,
			3, 11, rc.width, rc.height,
			0, CopyFromParent, InputOutput, CopyFromParent,
			valueMask, &attributes);
  
  pageSize = Dim(rc.width / paging->rcVirt.width,
		 rc.height / paging->rcVirt.height);
  
  /*
   * Create the window standing for current page.
   */
  attributes.background_pixel = darkGray;
  attributes.event_mask = ButtonPressMask | ButtonReleaseMask |
                          Button3MotionMask;
  valueMask = CWBackPixel | CWEventMask;
  
  visual = XCreateWindow(display, pager,
			 0, 0, pageSize.width-2, pageSize.height-2,
			 0, CopyFromParent, InputOutput, CopyFromParent,
			 valueMask, &attributes);
  
  XMapWindow(display, frame);
  XMapWindow(display, title);
  XMapWindow(display, pager);
  XMapWindow(display, visual);
  
  DrawVisualPage();
}

Pager::~Pager()
{
  XDestroyWindow(display, frame);
}

/*
 * IsPagerWindow --
 *   Return True if the window is pager window.
 */
Bool Pager::IsPagerWindows(Window win)
{
  if (win == pager || win == visual || win == frame || win == title)
    return True;
  else
    return False;
}

void Pager::AdjustPagerPos()
{
  if (geom.bitmask & XNegative)
    rc.x = rcScreen.x + rcScreen.width - (rc.width+6) - geom.x;
  else
    rc.x = geom.x;
  if (geom.bitmask & YNegative)
    rc.y = rcScreen.y + rcScreen.height - (rc.height+14) - geom.y;
  else
    rc.y = geom.y;
}

/*
 * RecalcPager --
 *   Recalc the position of pager according to rcScreen and move the pager.
 */
void Pager::RecalcPager()
{
  AdjustPagerPos();
  XMoveWindow(display, frame, rc.x, rc.y);
}

/*
 * DrawPager --
 *   Draw pager.
 */
void Pager::DrawPager()
{
  int i;

  for (i = 1; i < (int)paging->rcVirt.width; i++) {
    XSetForeground(display, gc, darkGray);
    XDrawLine(display, pager, gc,
	      pageSize.width*i-1, 1, pageSize.width*i-1, rc.height-2);
    XSetForeground(display, gc, white);
    XDrawLine(display, pager, gc,
	      pageSize.width*i, 1, pageSize.width*i, rc.height-2);
  }
  for (i = 1; i < (int)paging->rcVirt.height; i++) {
    XSetForeground(display, gc, darkGray);
    XDrawLine(display, pager, gc,
	      1, pageSize.height*i-1, rc.width-2, pageSize.height*i-1);
    XSetForeground(display, gc, white);
    XDrawLine(display, pager, gc,
	      1, pageSize.height*i, rc.width-2, pageSize.height*i);
  }
}

/*
 * DrawVisualPage --
 *   Draw area standing for visual page.
 */
void Pager::DrawVisualPage()
{
  Rect rcRoot = rootQvwm->GetRect();
  Point ptVisual;

  ptVisual.x = (paging->origin.x - paging->rcVirt.x * rcRoot.width)
    * rc.width / (rcRoot.width * paging->rcVirt.width) + 1;
  ptVisual.y = (paging->origin.y - paging->rcVirt.y * rcRoot.height)
    * rc.height / (rcRoot.height * paging->rcVirt.height) + 1;
  
  XMoveWindow(display, visual, ptVisual.x, ptVisual.y);
}

/*
 * DrawFrame --
 *   Draw pager frame.
 */
void Pager::DrawFrame()
{
  XPoint xp[3];

  xp[0].x = (rc.width+6) - 1;
  xp[0].y = 0;
  xp[1].x = (rc.width+6) - 1;
  xp[1].y = (rc.height+14) - 1;
  xp[2].x = 0;
  xp[2].y = (rc.height+14) - 1;

  XSetForeground(display, ::gc, black);
  XDrawLines(display, frame, ::gc, xp, 3, CoordModeOrigin);

  xp[0].x = (rc.width+6) - 3;
  xp[0].y = 1;
  xp[1].x = 1;
  xp[1].y = 1;
  xp[2].x = 1;
  xp[2].y = (rc.height+14) - 3;

  XSetForeground(display, ::gc, white);
  XDrawLines(display, frame, ::gc, xp, 3, CoordModeOrigin);
  
  xp[0].x = (rc.width+6) - 2;
  xp[0].y = 1;
  xp[1].x = (rc.width+6) - 2;
  xp[1].y = (rc.height+14) - 2;
  xp[2].x = 1;
  xp[2].y = (rc.height+14) - 2;

  XSetForeground(display, ::gc, darkGray);
  XDrawLines(display, frame, ::gc, xp, 3, CoordModeOrigin);
}

/*
 * Button1Press --
 *   Process the press of button1(mouse left button).
 */
void Pager::Button1Press(Window win)
{
  Window junkRoot, junkChild;
  Point ptJunk;
  unsigned int mask;

  XRaiseWindow(display, frame);

  if (win == pager || win == visual) {
    /*
     * Move the current page to the clicked area.
     */
    Point ptPage, ptWin;
    Rect rcRoot = rootQvwm->GetRect();

    XQueryPointer(display, pager, &junkRoot, &junkChild, &ptJunk.x, &ptJunk.y,
		  &ptWin.x, &ptWin.y, &mask);

    ptPage.x = ptWin.x * paging->rcVirt.width / rc.width;
    ptPage.y = ptWin.y * paging->rcVirt.height / rc.height;
    
    paging->origin.x = (ptPage.x + paging->rcVirt.x) * rcRoot.width;
    paging->origin.y = (ptPage.y + paging->rcVirt.y) * rcRoot.height;

    paging->PagingAllWindows();
  }
  else if (win == title) {
    /*
     * Move the pager.
     */
    XEvent ev;
    Point ptOld, ptNew;

    XQueryPointer(display, frame, &junkRoot, &junkChild, &ptOld.x, &ptOld.y,
		  &ptJunk.x, &ptJunk.y, &mask);

    while (1) {
      XNextEvent(display, &ev);
      switch (ev.type) {
      case MotionNotify:
	XQueryPointer(display, frame, &junkRoot, &junkChild, &ptNew.x,
		      &ptNew.y, &ptJunk.x, &ptJunk.y, &mask);
	rc.x += ptNew.x - ptOld.x;
	rc.y += ptNew.y - ptOld.y;
	ptOld = ptNew;
	XMoveWindow(display, frame, rc.x, rc.y);
	break;

      case ButtonRelease:
	return;

      case Expose:
	ExposeProc(ev.xexpose.window);
	break;
      }
    }
  }
}

/*
 * Button3Press --
 *   Process the press of button3(mouse right button).
 *   You can move the visual page, or the current screen freely.
 */
void Pager::Button3Press()
{
  XEvent ev;
  Window junkRoot, junkChild;
  Point ptJunk;
  unsigned int mask;
  Point ptOld, ptNew;
  Rect rcRoot = rootQvwm->GetRect();
  
  XRaiseWindow(display, pager);

  XQueryPointer(display, pager, &junkRoot, &junkChild, &ptJunk.x,
		&ptJunk.y, &ptOld.x, &ptOld.y, &mask);

  while (1) {
    XNextEvent(display, &ev);
    switch (ev.type) {
    case MotionNotify:
      XQueryPointer(display, pager, &junkRoot, &junkChild, &ptJunk.x,
		    &ptJunk.y, &ptNew.x, &ptNew.y, &mask);
      paging->origin.x += (ptNew.x-ptOld.x)
	* (rcRoot.width * paging->rcVirt.width / rc.width);
      paging->origin.y += (ptNew.y-ptOld.y)
	* (rcRoot.height * paging->rcVirt.height / rc.height);
      ptOld = ptNew;
      paging->PagingAllWindows();
      break;
      
    case ButtonRelease:
      return;

    case Expose:
      ExposeProc(ev.xexpose.window);
      break;
    }
  }
}
