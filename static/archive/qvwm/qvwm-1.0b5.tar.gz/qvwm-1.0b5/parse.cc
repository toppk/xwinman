#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xlocale.h>
#include "main.h"
#include "util.h"
#include "taskbar.h"
#include "icon.h"
#include "parse.h"
#include "hash.h"
#include "qvwmrc.h"
#include "qvwm.h"

Hash<MenuItem>* hashTable;
Hash<FuncNumber>* funcHashTable;
Hash<VariableTable>* varHashTable;

extern FILE* yyin;
extern int yyparse();
extern int line;

void CreateShortCut(MenuItem* mItem);
void CreateAttrHash(unsigned long attr, MenuItem* fItem);
void SetFont();

/*
 * ParseQvwmrc --
 *   Parse '.qvwmrc', 'system.qvwmrc', etc.
 */
void ParseQvwmrc(char* rcFileName)
{
  char *home, *rcPath;
  int i;

  /*
   * Initializa hash table.
   */
  hashTable = new Hash<MenuItem>(HashTableSize);

  funcHashTable = new Hash<FuncNumber>(HashTableSize);
  for (i = 0; i < FuncTableSize; i++)
    funcHashTable->SetHashItem(funcTable[i].name, &funcTable[i].num);

  varHashTable = new Hash<VariableTable>(HashTableSize);
  for (i = 0; i < VarTableSize; i++)
    varHashTable->SetHashItem(varTable[i].name, &varTable[i]);

  Qvwm::attrHashTable = new Hash<unsigned long>(HashTableSize);

  if (rcFileName != NULL) {
    if ((yyin = fopen(rcFileName, "r")) != NULL) {
      yyparse();
      fclose(yyin);
    }
    else {
      QvwmError("Can't open rcfile '%s'", rcFileName);
      SetFont();
    }

    delete hashTable;
    delete funcHashTable;
    delete varHashTable;

    return;
  }

  home = getenv("HOME");
  rcPath = new char[strlen(home)+9];
  sprintf(rcPath, "%s/.qvwmrc", home);

  if ((yyin = fopen(rcPath, "r")) != NULL) {
    yyparse();
    fclose(yyin);
  }
  else {
    delete [] rcPath;
    rcPath = new char[strlen(QVWMDIR)+15];
    sprintf(rcPath, "%s/system.qvwmrc", QVWMDIR);

    if ((yyin = fopen(rcPath, "r")) != NULL) {
      yyparse();
      fclose(yyin);
    }
    else {
      QvwmError("Can't open file '%s'", rcPath);
      SetFont();
    }
  }

  delete [] rcPath;
  delete hashTable;
  delete funcHashTable;
  delete varHashTable;
}

/*
 * AssignVariable --
 *   Assign a value to string variable.
 */
void AssignVariable(char* var, char* str)
{
  VariableTable* vItem;

  if ((vItem = varHashTable->GetHashItem(var))) {
    switch (vItem->attr) {
    case F_STRING:
      {
	char** sVal = (char **)vItem->var;
	*sVal = str;
      }
      break;

    case F_NATURAL:
      {
	int val;

	if ((val = atoi(str)) > 0) {
	  int* nVal = (int *)vItem->var;
	  *nVal = val;
	}
	else
	  QvwmError("%d: '%s' is invalid value", line, str);
      }
      break;
	
    case F_COLOR:
      {
	XColor color;

	if (XParseColor(display, colormap, str, &color) != 0) {
	  XAllocColor(display, colormap, &color);
	  unsigned long* pVal = (unsigned long *)vItem->var;
	  *pVal = color.pixel;
	}
	else
	  QvwmError("%d: '%s' is invalid color", line, str);
      }
      break;

    case F_BOOL:
      {
	int* nVal = (int *)vItem->var;

	if (strcmp(str, "True") == 0)
	  *nVal = 1;
	else if (strcmp(str, "False") == 0)
	  *nVal = 0;
	else
	  QvwmError("%d: '%s' is not boolean", line, str);
      }
      break;

    case F_TASKBAR:
      {
	Taskbar::TaskbarPos* tVal = (Taskbar::TaskbarPos *)vItem->var;

	if (strcmp(str, "Bottom") == 0)
	  *tVal = Taskbar::BOTTOM;
	else if (strcmp(str, "Top") == 0)
	  *tVal = Taskbar::TOP;
	else if (strcmp(str, "Left") == 0)
	*tVal = Taskbar::LEFT;
	else if (strcmp(str, "Right") == 0)
	  *tVal = Taskbar::RIGHT;
      }
      break;

    case F_GEOMETRY:
      {
	InternGeom* iVal = (InternGeom *)vItem->var;

	iVal->bitmask = XParseGeometry(str,
				       &iVal->x, &iVal->y,
				       &iVal->width, &iVal->height);
      }
      break;

    case F_OFFSET:
      {
	Point* pVal = (Point *)vItem->var;
	unsigned int dummy;
	
	XParseGeometry(str, &pVal->x, &pVal->y, &dummy, &dummy);
      }
      break;
      
    case F_SIZE:
      {
	Dim* dVal = (Dim *)vItem->var;
	int dummy;

	XParseGeometry(str, &dummy, &dummy, &dVal->width, &dVal->height);
      }
      break;
    }
  }
  else
    QvwmError("%d: '%s' is unknown variable", line, var);
}

/*
 * MakeExecItem --
 *
 */
MenuRes* MakeExecItem(char* name, char* file, char* exec)
{
  MenuRes* fRes = new MenuRes;

  fRes->name = name;
  fRes->file = file;
  fRes->func = Q_EXEC;
  fRes->exec = exec;
  fRes->child = "";

  return fRes;
}

/*
 * MakeDirItem --
 *
 */
MenuRes* MakeDirItem(char* name, char* file, char* next)
{
  MenuRes* fRes = new MenuRes;

  fRes->name = name;
  fRes->file = file;
  fRes->func = Q_DIR;
  fRes->exec = "";
  fRes->child = next;

  return fRes;
}

/*
 * MakeFuncItem --
 */
MenuRes* MakeFuncItem(char* name, char* file, char* func)
{
  MenuRes* fRes = new MenuRes;
  FuncNumber* fNum;

  fRes->name = name;
  fRes->file = file;
  if ((fNum = funcHashTable->GetHashItem(func)) != NULL)
    fRes->func = *fNum;
  else
    fRes->func = Q_NONE;
  fRes->exec = "";
  fRes->child = "";

  return fRes;
}

/*
 * MakeClassItem --
 *
 */
MenuRes* MakeClassItem(char* name)
{
  MenuRes* fRes = new MenuRes;

  fRes->name = name;
  fRes->file = "";
  fRes->func = Q_NONE;
  fRes->exec = "";
  fRes->child = "";

  return fRes;
}

/*
 * MakeItemList --
 *   Create the list of MenuRes(the content of menu).
 */
ItemList* MakeItemList(MenuRes* fRes, ItemList* fResList)
{
  ItemList* itemList = new ItemList;
  MenuRes* fr;
  
  itemList->item = fRes;

  if (fResList == NULL) {
    fr = new MenuRes;
    fr->func = Q_END;

    fResList = new ItemList;
    fResList->item = fr;
    fResList->next = NULL;

    itemList->next = fResList;
  }
  else
    itemList->next = fResList;

  return itemList;
}

/*
 * HashMenu --
 *   Insert the folder in hash table.
 */
void HashMenu(char* menuName, ItemList* itemList)
{
  MenuOrigin* mOrigin;
  char** child;
  MenuItem* mItem;
  int nitems;
  int i;

  if (itemList == NULL) {
    nitems = 2;

    mOrigin = new MenuOrigin[2];
    child = new char*[2];

    mOrigin[0].name = "(None) ";
    mOrigin[0].func = Q_NONE;
    mOrigin[1].name = "";
    mOrigin[1].func = Q_END;
    for (i = 0; i < 2; i++) {
      mOrigin[i].file = "";
      mOrigin[i].exec = "";
      mOrigin[i].next = NULL;
      child[i] = "";
    }
  }
  else {
    nitems = GetItemNum(itemList);

    mOrigin = new MenuOrigin[nitems];
    child = new char*[nitems];

    for (i = 0; i < nitems; i++) {
      mOrigin[i].name = itemList->item->name;
      mOrigin[i].file = itemList->item->file;
      mOrigin[i].func = itemList->item->func;
      mOrigin[i].exec = itemList->item->exec;
      mOrigin[i].next = NULL;
      child[i] = itemList->item->child;
      
      itemList = itemList->next;
    }
    
    if (strcmp(menuName, "StartMenu") == 0)
      StartMenuOrigin = mOrigin;
  }
    
  mItem = new MenuItem;

  mItem->nitems = nitems;
  mItem->fOrg = mOrigin;
  mItem->child = child;
  
  hashTable->SetHashItem(menuName, mItem);
}

/*
 * MakeAllMenuOrigins --
 *   Complete MenuOrigin.
 */
void MakeAllMenuOrigins()
{
  MenuItem* fItem;

  /*
   * Create menus.
   */
  if ((fItem = hashTable->GetHashItem("StartMenu")) != NULL) {
    StartMenuOrigin = fItem->fOrg;
    MakeMenuOrigin(fItem);
  }

  if ((fItem = hashTable->GetHashItem("CtrlMenu")) != NULL) {
    CtrlMenuOrigin = fItem->fOrg;
    MakeMenuOrigin(fItem);
  }

  if ((fItem = hashTable->GetHashItem("DesktopMenu")) != NULL) {
    CtrlMenuOrigin = fItem->fOrg;
    MakeMenuOrigin(fItem);
  }

  // Set fonts BEFORE make icons.
  SetFont();

  /*
   * Create shortcut.
   */
  if ((fItem = hashTable->GetHashItem("ShortCut")) != NULL)
    CreateShortCut(fItem);

  /*
   * Create frame attributes.
   */
  for (int i = 0; i < AttrNum; i++)
    if ((fItem = hashTable->GetHashItem(attrSet[i].name)) != NULL)
      CreateAttrHash(attrSet[i].flag, fItem);
}

/*
 * MakeMenuOrigin --
 *   Compensate next of MenuOrigin with hash table recursively.
 */
void MakeMenuOrigin(MenuItem* fItem)
{
  MenuItem* hItem;

  for (int i = 0; i < fItem->nitems-1; i++)
    if (fItem->fOrg[i].func == Q_DIR) {
      if ((hItem = hashTable->GetHashItem(fItem->child[i])) == NULL)
	fItem->fOrg[i].func = Q_NONE;
      else {
	fItem->fOrg[i].next = hItem->fOrg;
	MakeMenuOrigin(hItem);
      }
    }
}

/*
 * CreateShortCut --
 *   Create shortcut icons.
 */
void CreateShortCut(MenuItem* fItem)
{
  Icon* tmpIcon;
  Pixmap pix, mask;
  GC gc;
  MenuOrigin fOrigin;

  for (int i = 0; i < fItem->nitems-1; i++) {
    fOrigin = fItem->fOrg[i];

    if (fOrigin.func != Q_EXEC) {
      QvwmError("'%s': 3rd token in ShortCut section must be execute file.",
		fOrigin.name);
      continue;
    }

    if (strcmp(fOrigin.file, "") == 0) {
      pix = Icon::pixIcon;
      mask = Icon::maskIcon;
    }
    else {
      if (!CreatePixmapFromFile(fOrigin.file, pix, mask, gc)) {
	pix = Icon::pixIcon;
	mask = Icon::maskIcon;
      }
    }
    
    tmpIcon = new Icon(pix, mask, fOrigin.name, fOrigin.exec);
    tmpIcon->MapIcon();
  }
}  

/*
 * CreateAttrHash --
 *   Create a hash for frame attributes.
 */
void CreateAttrHash(unsigned long attr, MenuItem* fItem)
{
  MenuOrigin fOrigin;

  for (int i = 0; i < fItem->nitems-1; i++) {
    fOrigin = fItem->fOrg[i];

    unsigned long* flags;
    if ((flags = Qvwm::attrHashTable->GetHashItem(fOrigin.name)))
      *flags |= attr;
    else {
      flags = new unsigned long;
      *flags = attr;
      Qvwm::attrHashTable->SetHashItem(fOrigin.name, flags);
    }
  }
}

/*
 * SetFont --
 *   Set fonts.
 */
void SetFont()
{
  if (setlocale(LC_ALL, LocaleName) == NULL)
    QvwmError("Can't set the locale");

  char **miss, *def;
  int nMiss;

  for (int i = 0; i < FsNum; i++) {
    *fsSet[i].fs = XCreateFontSet(display, *fsSet[i].fontname, &miss, &nMiss,
				  &def);
    if (*fsSet[i].fs == NULL) {
      QvwmError("Can't find font '%s'", *fsSet[i].fontname);
      exit(1);
    }
  }
}

/*
 * GetItemNum --
 *   Return the number of element of ItemList.
 */
int GetItemNum(ItemList* itemList)
{
  int num = 0;

  while (itemList != NULL) {
    num++;
    itemList = itemList->next;
  }

  return num;
}

/*
 * IsFunction
 *   Return True if text is a function. The identifier beginning with 'QVWM_'
 *   is an internal function.
 */
Bool IsFunction(char* text)
{
  char prefix[6];

  strncpy(prefix, text, 5);
  prefix[5] = '\0';

  if (strcmp(prefix, "QVWM_") == 0)
    return True;
  else
    return False;
}

/*
 * IsAttribute --
 *   Return True if text is an attribute.
 */
Bool IsAttribute(char* text)
{
  for (int i = 0; i < AttrNum; i++)
    if (strcmp(text, attrSet[i].name) == 0)
      return True;

  return False;
}
