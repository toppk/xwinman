#include <stdio.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/xpm.h>
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "menu.h"
#include "util.h"
#include "startmenu.h"
#include "bitmaps/menu0.xpm"
#include "bitmaps/menu1.xpm"
#include "bitmaps/next0.xpm"
#include "bitmaps/next1.xpm"

XContext Menu::context;
Menu::MenuDir Menu::fDir;
Pixmap Menu::pixMenu[2];
GC Menu::gcMenu[2];
Pixmap Menu::pixWhiteNext, Menu::pixBlackNext;
GC Menu::gcNext;
Menu* Menu::delayMenu = NULL;
int Menu::delayMenuNum;

Menu::Menu(Qvwm* qvWm, MenuOrigin* fOrigin, int fBetween, int iHeight,
	   int iBetween, int paWidth, Rect pixRc, XFontSet& fs,
	   Menu* parent)
: fBetween(fBetween), iHeight(iHeight), iBetween(iBetween),
  paWidth(paWidth), pixRc(pixRc), parent(parent), fs(fs), qvWm(qvWm)
{
  int width, maxWidth = 0;
  int i, sep = 0;
  XSetWindowAttributes attributes;
  unsigned long valueMask;
  Rect rect;
  Pixmap mask;
  XRectangle ink, log;

  nitems = GetOriginNum(fOrigin);

  item = new Window[nitems];
  pix = new Pixmap[nitems];
  gc = new GC[nitems];
  name = new char*[nitems];
  func = new FuncNumber[nitems];
  exec = new char*[nitems];
  next = new Menu*[nitems];

  for (i = 0; i < nitems; i++) {
    func[i] = fOrigin[i].func;
    exec[i] = fOrigin[i].exec;

    name[i] = fOrigin[i].name;
    if (func[i] != Q_SEPARATOR) {
      width = XmbTextExtents(fs, name[i], strlen(name[i]), &ink, &log);
      if (width > maxWidth)
	maxWidth = width;
    }

    if (fOrigin[i].func == Q_DIR) {
      next[i] = new Menu(qvWm, fOrigin[i].next, fBetween, iHeight, iBetween,
			 paWidth, pixRc, fs, this);
      if (strcmp(fOrigin[i].file, "") == 0) {
	/*
	 * Default pixmap and GC of QDir
	 */
	pix[i] = pixMenu[0];
	gc[i] = gcMenu[0];
      }
      else
	CreatePixmapFromFile(fOrigin[i].file, pix[i], mask, gc[i]);
    }
    else {
      next[i] = NULL;
      if (strcmp(fOrigin[i].file, "") == 0) {
	/*
         * Default pixmap and GC of other than QDir
	 */
	pix[i] = pixMenu[1];
	gc[i] = gcMenu[1];
      }
      else
	CreatePixmapFromFile(fOrigin[i].file, pix[i], mask, gc[i]);
    }
  }

  rc.width = paWidth + maxWidth + MenuFrameWidth*2 + 24;

  iFocus = -1;            // no focus
  mapped = False;
  child = NULL;

  /*
   * Create frame window.
   */
  attributes.save_under = DoesSaveUnders(ScreenOfDisplay(display, screen));
  attributes.background_pixel = gray;
  attributes.event_mask = ButtonPressMask | ButtonReleaseMask | KeyPressMask |
                          ExposureMask;
  valueMask = CWSaveUnder | CWBackPixel | CWEventMask;
  
  frame = XCreateWindow(display, root,
			0, 0, 10, 10, 0,
			CopyFromParent, InputOutput, CopyFromParent,
			valueMask, &attributes);

  valueMask = CWBackPixel | CWEventMask;

  /*
   * Create item windows for menu.
   */
  for (i = 0; i < nitems; i++) {
    if (func[i] != Q_SEPARATOR) {
      attributes.event_mask = ButtonPressMask | ButtonReleaseMask |
	                      EnterWindowMask | LeaveWindowMask |
			      OwnerGrabButtonMask | ExposureMask;
      rect.y = MenuFrameWidth + fBetween + (i-sep)*(iHeight+iBetween)
	       + sep*SeparatorHeight;
      rect.height = iHeight;
    }
    else {
      attributes.event_mask = OwnerGrabButtonMask | ExposureMask;
      rect.y = MenuFrameWidth + fBetween + (i-sep)*(iHeight+iBetween)
               + sep*SeparatorHeight;
      rect.height = SeparatorHeight;
      sep++;
    }

    rect.x = MenuFrameWidth;
    rect.width = rc.width - MenuFrameWidth*2;

    item[i] = XCreateWindow(display, frame, rect.x, rect.y,
			    rect.width, rect.height, 0,
			    CopyFromParent, InputOutput, CopyFromParent,
			    valueMask, &attributes);
  }

  rc.height = (nitems-sep)*(iHeight+iBetween) + sep*SeparatorHeight
              + MenuFrameWidth*2;

  XResizeWindow(display, frame, rc.width, rc.height);

  XSaveContext(display, frame, context, (caddr_t)this);
  for (i = 0; i < nitems; i++)
    XSaveContext(display, item[i], context, (caddr_t)this);    
}

Menu::~Menu()
{
  delete [] item;
  delete [] pix;
  delete [] gc;
  delete [] name;

  for (int i = 0; i < nitems; i++)
    delete next[i];
}

/*
 * MapMenu --
 *   Map menu.
 */
void Menu::MapMenu(int x, int y)
{
  mapped = True;
  rc.x = x;
  rc.y = y;
  
  XMoveWindow(display, frame, x, y);
  XMapRaised(display, frame);
  XMapSubwindows(display, frame);

  /*
   * Take off the focus from the window when any menus are shown.
   */
  if (qvWm->CheckMapped()) {
    if (qvWm != rootQvwm)
      for (int i = 1; i < 4; i++)
	XGrabButton(display, i, 0, qvWm->GetWin(), True, ButtonPressMask,
		    GrabModeSync, GrabModeAsync, None, cursor[0]);

    XSetInputFocus(display, frame, RevertToParent, CurrentTime);
  }
}

/*
 * UnmapMenu --
 *   Unmap menu.
 */
void Menu::UnmapMenu()
{
  int i;

  mapped = False;
  iFocus = -1;

  if (child != NULL)
    child->UnmapMenu();

  /*
   * Yield the focus.
   */
  if (qvWm->CheckMapped()) {
    if (qvWm != rootQvwm)
      for (i = 1; i < 4; i++)
	XUngrabButton(display, i, 0, qvWm->GetWin());

    /*
     * Yield the focus to the parent, if any.
     */
    if (parent != NULL)
      XSetInputFocus(display, parent->frame, RevertToParent, CurrentTime);
    else {
      if (qvWm == rootQvwm)
	XSetInputFocus(display, taskBar->GetFrameWin(), RevertToParent,
		       CurrentTime);
      else
	XSetInputFocus(display, qvWm->GetWin(), RevertToParent, CurrentTime);
    }
  }

  XUnmapWindow(display, frame);

  if (parent != NULL)
    parent->child = NULL;
}

/*
 * DrawMenu --
 *   Draw menu.
 */
void Menu::DrawMenu(Window win)
{
  int i;

  if (win == frame)
    DrawFrame();
  else {
    for (i = 0; i < nitems; i++)
      if (win == item[i]) {
	if (func[i] != Q_SEPARATOR)
	  SetMenuFocus(i);
	else
	  DrawSeparator(i);
      }
  }
}

/*
 * DrawFrame --
 *   Draw frame.
 */
void Menu::DrawFrame()
{
  XPoint xp[3];

  xp[0].x = rc.width - 1;
  xp[0].y = 0;
  xp[1].x = rc.width - 1;
  xp[1].y = rc.height - 1;
  xp[2].x = 0;
  xp[2].y = rc.height - 1;

  XSetForeground(display, ::gc, black);
  XDrawLines(display, frame, ::gc, xp, 3, CoordModeOrigin);

  xp[0].x = rc.width - 3;
  xp[0].y = 1;
  xp[1].x = 1;
  xp[1].y = 1;
  xp[2].x = 1;
  xp[2].y = rc.height - 3;

  XSetForeground(display, ::gc, white);
  XDrawLines(display, frame, ::gc, xp, 3, CoordModeOrigin);
  
  xp[0].x = rc.width - 2;
  xp[0].y = 1;
  xp[1].x = rc.width - 2;
  xp[1].y = rc.height - 2;
  xp[2].x = 1;
  xp[2].y = rc.height - 2;

  XSetForeground(display, ::gc, darkGray);
  XDrawLines(display, frame, ::gc, xp, 3, CoordModeOrigin);
}

/*
 * DrawSeparator --
 *   Draw the separator.
 */
void Menu::DrawSeparator(int num)
{
  XSetForeground(display, ::gc, darkGray);
  XDrawLine(display, item[num], ::gc, 0, 2, rc.width-1, 2);

  XSetForeground(display, ::gc, white);
  XDrawLine(display, item[num], ::gc, 0, 3, rc.width-1, 3);
}

/*
 * DrawMenuContents --
 *   Draw the contents of the menu.
 */
void Menu::DrawMenuContents(int num)
{
  XRectangle ink, log;
  int y;

  /*
   * Draw the menu text.
   */
  XmbTextExtents(fs, name[num], strlen(name[num]), &ink, &log);
  y = (iHeight-log.height)/2 - log.y;

  if (num == iFocus) {
    if (IsSelectable(func[num])) {
      XSetForeground(display, ::gc, white);
      XmbDrawString(display, item[num], fs, ::gc, paWidth, y,
		    name[num], strlen(name[num]));
    }
    else {
      XSetForeground(display, ::gc, darkGray);
      XmbDrawString(display, item[num], fs, ::gc, paWidth, y,
		    name[num], strlen(name[num]));
    }

    if (func[num] == Q_DIR) {
      XSetClipOrigin(display, gcNext, rc.width-14, iHeight/2-4);
      XCopyArea(display, pixWhiteNext, item[num], gcNext,
		0, 0, 4, 7, rc.width-14, iHeight/2-4);
    }
  }
  else {
    if (IsSelectable(func[num])) {
      XSetForeground(display, ::gc, black);
      XmbDrawString(display, item[num], fs, ::gc, paWidth, y,
		    name[num], strlen(name[num]));
    }
    else {
      XSetForeground(display, ::gc, white);
      XmbDrawString(display, item[num], fs, ::gc, paWidth+1, y+1,
		    name[num], strlen(name[num]));
      XSetForeground(display, ::gc, darkGray);
      XmbDrawString(display, item[num], fs, ::gc, paWidth, y,
		    name[num], strlen(name[num]));
    }

    if (func[num] == Q_DIR) {
      XSetClipOrigin(display, gcNext, rc.width-14, iHeight/2-4);
      XCopyArea(display, pixBlackNext, item[num],
		gcNext, 0, 0, 4, 7, rc.width-14, iHeight/2-4);
    }
  }

  /*
   * Draw the menu pixmap, if neccesary.
   */
  if (pix[num] && func[num] != Q_NONE) {
    XSetClipOrigin(display, gc[num], pixRc.x, 0);
    XCopyArea(display, pix[num], item[num], gc[num], 0, 0, pixRc.width,
	      pixRc.height, pixRc.x, pixRc.y);
  }
}

/*
 * SetMenuFocus --
 *   Give the focus to the menu item, and redraw.
 */
void Menu::SetMenuFocus(int num)
{
  if (num == iFocus)
    XSetWindowBackground(display, item[num], blue);
  else
    XSetWindowBackground(display, item[num], gray);

  XClearWindow(display, item[num]);

  DrawMenuContents(num);
}

/*
 * FindItem --
 *   Find the menu item corresponding to given window.
 */
int Menu::FindItem(Window win)
{
  for (int i = 0; i < nitems; i++)
    if (win == item[i])
      return i;

  return -1;
}

/*
 * CalcItemYPos --
 *   Calculate y position of the menu item.
 */
int Menu::CalcItemYPos(int num)
{
  int y = MenuFrameWidth+fBetween;
  
  for (int i = 0; i < num; i++)
    if (func[i] != Q_SEPARATOR)
      y += iHeight+iBetween;
    else
      y += SeparatorHeight+iBetween;

  return y;
}

/*
 * GetFixedMenuPos --
 *   Adjust the menu position.
 */
Point Menu::GetFixedMenuPos(Point pt)
{
  Rect rcRoot = rootQvwm->GetRect();

  if (pt.x+rc.width > rcRoot.width-1)
    pt.x = pt.x - rc.width;
  if (pt.y+rc.height > rcRoot.height-1)
    pt.y = rcRoot.height - rc.height;

  return pt;
}

/*
 * Enter --
 *   Process enter event.
 */
void Menu::Enter(Window win)
{
  int num, pFocus;

  if (iFocus != -1) {
    pFocus = iFocus;
    iFocus = -1;
    SetMenuFocus(pFocus);
    if (child != NULL)
      child->UnmapMenu();
  }

  num = FindItem(win);
  iFocus = num;
  SetMenuFocus(num);

  /*
   * Delay that child menu is extract.
   */
  if (func[num] == Q_DIR) {
    delayMenu = this;
    delayMenuNum = num;
  }
}

/*
 * Leave --
 *   Process leave event.
 */
void Menu::Leave(Window win, Point rootPt)
{
  int num;

  num = FindItem(win);

  if (child != NULL) {
    if (!InRect(rootPt, child->rc)) {
      if (iFocus != num && iFocus != -1)
	num = iFocus;
      iFocus = -1;
      SetMenuFocus(num);
      child->UnmapMenu();
    }
  }
  else {
    if (iFocus != num && iFocus != -1)
      num = iFocus;
    iFocus = -1;
    SetMenuFocus(num);
  }

  delayMenu = NULL;
}

/*
 * Button1Press --
 *   Process the press of button1(mouse left button).
 */
void Menu::Button1Press(Window win) 
{
  int num;

  num = FindItem(win);

  if (func[num] == Q_DIR)
    ExecFunction(Q_DIR, num);

  delayMenu = NULL;
}

/*
 * Button1Release --
 *   Process the release of button1(mouse left button).
 */
void Menu::Button1Release(Window win)
{
  int num;

  num = FindItem(win);

  if (IsSelectable(func[num])) {
    /*
     * Erase all menus.
     */
    if (func[num] != Q_DIR) {
      if (qvWm->CheckMenuMapped())
	qvWm->ctrlMenu->UnmapMenu();
      if (startMenu != NULL && startMenu->CheckMapped())
	startMenu->UnmapMenu();
    }
    ExecFunction(func[num], num);
  }
}

/*
 * CreateMenuPixmap --
 *   Create the pixmaps for menu.
 */
void Menu::CreateMenuPixmap()
{
  XpmAttributes attr;
  Pixmap mask;
  XGCValues gcv;

  attr.valuemask = XpmColormap | XpmDepth;
  attr.colormap = colormap;
  attr.depth = depth;

  XpmCreatePixmapFromData(display, root, menu0, &pixMenu[0], &mask, &attr);
  gcv.clip_mask = mask;
  gcMenu[0] = XCreateGC(display, root, GCClipMask, &gcv);

  XpmCreatePixmapFromData(display, root, menu1, &pixMenu[1], &mask, &attr);
  gcv.clip_mask = mask;
  gcMenu[1] = XCreateGC(display, root, GCClipMask, &gcv);

  XpmCreatePixmapFromData(display, root, next0, &pixBlackNext, &mask, &attr);
  gcv.clip_mask = mask;
  gcNext = XCreateGC(display, root, GCClipMask, &gcv);

  XpmCreatePixmapFromData(display, root, next1, &pixWhiteNext, &mask, &attr);
}
