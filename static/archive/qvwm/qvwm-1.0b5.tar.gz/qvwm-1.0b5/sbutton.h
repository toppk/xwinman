#ifndef _SBUTTON_H_
#define _SBUTTON_H_

#include "tbutton.h"

/*
 * StartButton class
 */
class StartButton : public TaskbarButton {
private:
  void FillBackground();
  void DrawName();

public:
  const unsigned int BUTTON_WIDTH = 62;

public:
  StartButton(Qvwm* qvWm);
  ~StartButton() {}
  
  void ExecButtonFunc(ButtonState state) {}
  void Button1Press();
  void Button3Release() {}
};

#endif // _SBUTTON_H_
