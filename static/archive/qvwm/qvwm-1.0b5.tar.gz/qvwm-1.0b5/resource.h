#ifndef _RESOURCE_H_
#define _RESOURCE_H_

#include "misc.h"

// Predefine
#define NO_ID     -1
#define ID_OK     0
#define ID_CANCEL 1

typedef int ResourceId;

enum ItemKind {
  STRINGBUTTON,
  RADIOBUTTON,
  RADIOSET,
  STATICTEXT,
  ICONPIXMAP,
};

struct DialogRes {
  ItemKind kind;
  int rid;
  Rect rc;
  char* str;
  XFontSet& fs;
  int initId;
  Pixmap pix;
  GC gc;
};

class StaticText {
public:
  Point pt;
  char* text;
  XFontSet& fs;
  
public:
  StaticText(Point pt, char* str, XFontSet& fs) : pt(pt), text(str), fs(fs) {}
};

class IconPixmap {
public:
  Rect rc;
  Pixmap pix;
  GC gc;

public:
  IconPixmap(Rect rc, Pixmap pix, GC gc) : rc(rc), pix(pix), gc(gc) {}
};

#endif // _RESOURCE_H_
