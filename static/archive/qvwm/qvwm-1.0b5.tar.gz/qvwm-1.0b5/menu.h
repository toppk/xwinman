#ifndef _MENU_H_
#define _MENU_H_

#include "misc.h"
#include "util.h"

class Qvwm;
class MenuOrigin;

/*
 * Menu class
 */
class Menu {
protected:
  Window frame;
  Rect rc;                   // menu pos & size
  int fBetween;              // gap between top(bottom) item and frame
  Window* item;              // menu items
  int iFocus;                // focus item number
  int nitems;                // item number
  int iHeight;               // height of item
  int iBetween;              // gap between items
  int paWidth;               // width from left edge to text of item
  Pixmap* pix;
  GC* gc;
  Rect pixRc;                // pixmap pos & size
  char **name;
  FuncNumber* func;          // function number
  char **exec;               // exec command
  struct Menu **next;
  struct Menu* parent;       // parent of this menu
  Bool mapped;               // flag if this menu is mapped
  struct Menu* child;        // menu extracted from this menu
  XFontSet& fs;
  Qvwm* qvWm;

  static Pixmap pixMenu[2];
  static GC gcMenu[2];
  static Pixmap pixWhiteNext, pixBlackNext;
  static GC gcNext;

  static const int SeparatorHeight = 9;
  static const int MenuFrameWidth = 3;

public:
  // direction of menu extraction
  enum MenuDir { RIGHT, LEFT };

  static XContext context;
  static MenuDir fDir;          // orientation of menu extraction
  static Menu* delayMenu;       // parent of menu whose extraction is delayed
  static int delayMenuNum;      // number of menu whose extraction is delayed

private:
  void DrawFrame();
  void DrawSeparator(int num);
  void DrawMenuContents(int num);

public:
  Menu(Qvwm* qvWm, MenuOrigin* fOrigin, int fBetween, int iHeight,
       int iBetween, int paWidth, Rect pixRc, XFontSet& fs, Menu* parent);
  virtual ~Menu();
  Window GetFrameWin() const { return frame; }
  Bool CheckMapped() const { return mapped; }
  int GetItemNum() const { return nitems; }
  void SetRect(Rect rect) { rc = rect; }
  Rect GetRect() const { return rc; }
  
  virtual void MapMenu(int x, int y);
  virtual void UnmapMenu();
  virtual void DrawMenu(Window win);
  void SetMenuFocus(int num);
  virtual int FindItem(Window win);
  int CalcItemYPos(int num);
  Point GetFixedMenuPos(Point pt);
  void Enter(Window win);
  void Leave(Window win, Point rootPt);
  void Button1Press(Window win);
  void Button1Release(Window win);
  void ExecFunction(FuncNumber fn, int i);
  Bool IsSelectable(FuncNumber fn);

  static void CreateMenuPixmap();
};

#endif // _MENU_H_
