%{
#include <stdio.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "main.h"
#include "parse.h"

extern int line;
extern int yylex();
extern int yyerror(char* error);
%}

%union {
  char* str;
  MenuRes* mRes;
  ItemList* iList;
}

%token <str> MENU ATTR VAR STRING FUNC

%type <mRes> item, attr
%type <iList> items, attrs

%%

qvwmrc:	   unit				{ MakeAllMenuOrigins(); }
	 |				{ MakeAllMenuOrigins(); }
	 ;

unit:	   rc				
	 | rc unit
	 ;

rc:	   variable
         | session
	 ;

variable:  VAR '=' STRING		{ AssignVariable($1, $3); }
         | VAR '=' VAR			{ AssignVariable($1, $3); }
	 ;

session:   MENU			        { HashMenu($1, NULL); }
	 | MENU items			{ HashMenu($1, $2); }
         | ATTR				{ HashMenu($1, NULL); }
         | ATTR attrs			{ HashMenu($1, $2); }
	 ;

items:	   item				{ $$ = MakeItemList($1, NULL); }
	 | item items			{ $$ = MakeItemList($1, $2); }
	 ;

item:	   STRING STRING STRING		{ $$ = MakeExecItem($1, $2, $3); }
	 | STRING STRING VAR		{ $$ = MakeDirItem($1, $2, $3); }
	 | STRING STRING FUNC		{ $$ = MakeFuncItem($1, $2, $3); }
	 ;

attrs:	   attr				{ $$ = MakeItemList($1, NULL); }
	 | attr ',' attrs		{ $$ = MakeItemList($1, $3); }
	 ;

attr:	   STRING			{ $$ = MakeClassItem($1); }
	 ;

%%
int yyerror(char* error)
{
  QvwmError("%d: %s", line, error);
  exit(1);
}
