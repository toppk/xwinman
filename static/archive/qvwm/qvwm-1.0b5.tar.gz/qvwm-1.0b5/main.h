#ifndef _MAIN_H_
#define _MAIN_H_

#ifdef DEBUG
# define Assert(ex) {if(!(ex)){fprintf(stderr,"Assertion failed: file \"%s\", line %d\n", __FILE__, __LINE__);Qvwm::FinishQvwm(False);}}
#else
# define Assert(ex)
#endif

class Qvwm;
class Rect;

extern Display* display;
extern int screen;
extern unsigned int depth;
extern Colormap colormap;
extern Window root;
extern Qvwm* rootQvwm;
extern Rect rcScreen;
extern GC gc, gcXor, gcLogo, gcLargeLogo, gcTile, gcTileMask, gcDash;
extern Pixmap pixLogo, pixLargeLogo;
extern Cursor cursor[6];
extern XFontSet fsTitle, fsTaskbar, fsBoldTaskbar, fsIcon;
extern XFontSet fsCtrlMenu, fsCascadeMenu, fsStartMenu;
extern unsigned long gray, darkGray, blue, green, black, white;

extern Atom _XA_WM_CHANGE_STATE;
extern Atom _XA_WM_STATE;
extern Atom _XA_WM_COLORMAP_WINDOWS;
extern Atom _XA_WM_PROTOCOLS;
extern Atom _XA_WM_TAKE_FOCUS;
extern Atom _XA_WM_DELETE_WINDOW;
extern Atom _XA_WM_DESKTOP;
extern Atom _XA_WM_ICON_SIZE;

class Taskbar;
class StartMenu;
class TaskSwitcher;
class Paging;
class Pager;

extern Taskbar* taskBar;
extern StartMenu* startMenu;
extern TaskSwitcher* taskSwitcher;
extern Paging* paging;
extern Pager* pager;

extern void InitState();
extern void InitQvwm();
extern void QvwmError(const char* fmt, ...);

#endif // _MAIN_H_
