#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "fbutton.h"
#include "paging.h"

/*
 * Configure --
 *   Change window position and size according to cre.
 */
void Qvwm::Configure(XConfigureRequestEvent* cre)
{
  Qvwm* tmpQvwm;
  XWindowChanges xwc;
  int borderWidth = 0, titleHeight = 0;

  if (cre->value_mask & CWStackMode) {
    if ((cre->value_mask & CWSibling) &&
	XFindContext(display, cre->above, Qvwm::context, (caddr_t *)&tmpQvwm)
	== XCSUCCESS)
      xwc.sibling = tmpQvwm->frame;
    else
      xwc.sibling = cre->above;
    
    xwc.stack_mode = cre->detail;
    XConfigureWindow(display, frame,
		     cre->value_mask & (CWSibling | CWStackMode), &xwc);
  }

  if (cre->value_mask & CWBorderWidth)
    bwOrig = cre->border_width;

  if (CheckFlags(BORDER))
    borderWidth = BORDER_WIDTH;
  if (CheckFlags(TITLE))
    titleHeight = TITLE_HEIGHT;

  if (cre->value_mask & CWX) {
    rcOrig.x = cre->x - (borderWidth + 2) + paging->origin.x;
    rc.x = rcOrig.x;
  }
  if (cre->value_mask & CWY) {
    rcOrig.y = cre->y - (borderWidth + titleHeight + 3) + paging->origin.y;
    rc.y = rcOrig.y;
  }
  if (cre->value_mask & CWWidth) {
    rcOrig.width = cre->width;
    rc.width = cre->width + (borderWidth+2)*2;
  }
  if (cre->value_mask & CWHeight) {
    rcOrig.height = cre->height;
    rc.height = cre->height + borderWidth*2 + titleHeight + 5;
  }

  fButton[1]->SetState(Button::NORMAL);
  fButton[1]->SetPixmap(FrameButton::pixButton[FrameButton::MAXIMIZE]);
  ResetStatus(MAXIMIZE_WINDOW | MINIMIZE_WINDOW);

  RedrawWindow();
}

/*
 * ConfigureNewRc --
 *   Change original window according to newRc (frame rc).
 */
void Qvwm::ConfigureNewRc(Rect newRc)
{
  int borderWidth = 0, titleHeight = 0;
  Point gravity;
  Rect rect;

  rc = newRc;

  if (CheckFlags(BORDER))
    borderWidth = BORDER_WIDTH;
  if (CheckFlags(TITLE))
    titleHeight = TITLE_HEIGHT;

  gravity = GetGravityOffset();

  rcOrig.x = newRc.x - rcScreen.x - (borderWidth+2-bwOrig)*gravity.x;
  rcOrig.y = newRc.y - rcScreen.y;
  if (gravity.y == -1)
    rcOrig.y += borderWidth + titleHeight + 3 - bwOrig;
  else if (gravity.y == -2)
    rcOrig.y += borderWidth*2 + titleHeight + 5 - bwOrig*2;

  rcOrig.width = newRc.width - (borderWidth+2)*2;
  rcOrig.height = newRc.height - (titleHeight+borderWidth*2+5);

  /*
   * Adjust taskbar position.
   */
  switch (taskBar->GetPos()) {
  case Taskbar::BOTTOM:
    // South??Gravity
    if (gravity.y == -2 &&
	rcOrig.y+rcOrig.height+bwOrig == rcScreen.height-1) {
      rect = taskBar->GetRect();
      rcOrig.y += rect.height;
    }
    break;

  case Taskbar::TOP:
    // North??Gravity
    if (gravity.y == 0 && rcOrig.y-bwOrig == 0) {
      rect = taskBar->GetRect();
      rcOrig.y -= rect.height;
    }
    else if (gravity.y == -2 &&
	     rcOrig.y+rcOrig.height+bwOrig == rcScreen.height-1) {
      rect = taskBar->GetRect();
      rcOrig.y += rect.height;
    }
    break;

  case Taskbar::LEFT:
    // ??WestGravity
    if (gravity.x == 0 && rcOrig.x-bwOrig == 0) {
      rect = taskBar->GetRect();
      rcOrig.x -= rect.width;
    }
    else if (gravity.x == -2 &&
	     rcOrig.x+rcOrig.width+bwOrig == rcScreen.width-1) {
      rect = taskBar->GetRect();
      rcOrig.x += rect.width;
    }
    break;

  case Taskbar::RIGHT:
    // ??EastGravity
    if (gravity.x == -2 && rcOrig.x+rcOrig.width+bwOrig == rcScreen.width-1) {
      rect = taskBar->GetRect();
      rcOrig.x += rect.width;
    }
    break;
  }

  SendConfigureEvent();
}

/*
 * SendConfigureEvent --
 *   Send event to the window whose position and size changed.
 */
void Qvwm::SendConfigureEvent()
{
  XEvent clientEvent;
  int borderWidth = 0, titleHeight = 0;

  if (CheckFlags(BORDER))
    borderWidth = BORDER_WIDTH;
  if (CheckFlags(TITLE))
    titleHeight = TITLE_HEIGHT;

  clientEvent.type = ConfigureNotify;
  clientEvent.xconfigure.display = display;
  clientEvent.xconfigure.event = wOrig;
  clientEvent.xconfigure.window = wOrig;
      
  clientEvent.xconfigure.x = rc.x + borderWidth+2 - paging->origin.x;
  clientEvent.xconfigure.y = rc.y + titleHeight+borderWidth+3
                              - paging->origin.y;
  clientEvent.xconfigure.width = rc.width - (borderWidth+2)*2;
  clientEvent.xconfigure.height = rc.height - (titleHeight+borderWidth*2+5);

  clientEvent.xconfigure.border_width = 0;
  clientEvent.xconfigure.above = frame;
  clientEvent.xconfigure.override_redirect = False;
  
  XSendEvent(display, wOrig, False, StructureNotifyMask, &clientEvent);
}
