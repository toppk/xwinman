#ifndef _PAGING_H_
#define _PAGING_H_

#include "misc.h"

/*
 * Paging class
 */
class Paging {
private:
  Window side[4];

public:
  Point origin;             // left-top point in logical coordinates
  Rect rcVirt;              // size and top-left page of virtual page

public:
  Paging(unsigned int beltSize, Point topLeft, Dim size);
  ~Paging();

  Bool IsPagingBelt(Window win);

  void HandlePaging(Point pt);
  void PagingProc(Window win);
  void PagingProc(Point pt);
  void PagingAllWindows();
  void MapSides();
  void RaisePagingBelt();
};

#endif // _PAGING_H_
