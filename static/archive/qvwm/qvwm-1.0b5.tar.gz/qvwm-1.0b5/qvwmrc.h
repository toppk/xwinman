#ifndef _QVWMRC_H_
#define _QVWMRC_H_

#include "misc.h"
#include "util.h"
#include "taskbar.h"

const int HashTableSize = 50;
extern const int FuncTableSize;
extern const int VarTableSize;
extern const int FsNum;
extern const int SCKeyNum;
extern const int SCRootKeyNum;
extern const int SCMenuKeyNum;
extern const int AttrNum;

class FuncTable;
class VariableTable;

extern int DoubleClickTime;
extern int DoubleClickRange;
extern int TitlebarMotionSpeed;
extern int MenuDelayTime;
extern int PagingResistance;
extern int PagingMovement;
extern int PagingBeltSize;
extern Point TopLeftPage;
extern Dim PagingSize;
extern InternGeom PagerGeometry;
extern Taskbar::TaskbarPos TaskbarPosition;
extern int AutoRaiseDelay;
extern unsigned long IconForeColor, IconBackColor;
extern char* WallPaper;
extern char* StartButtonTitle;
extern char* LocaleName;
extern Bool UseBoldFont;
extern Bool UseExitDialog;
extern Bool UsePager;
extern Bool OpaqueMove;
extern Bool ClickToFocus;
extern Bool AutoRaise;
extern char *TitleFont, *TaskbarFont, *TaskbarBoldFont, *CascadeMenuFont;
extern char *CtrlMenuFont, *StartMenuFont, *IconFont;
extern MenuOrigin* StartMenuOrigin;
extern MenuOrigin* CtrlMenuOrigin;
extern MenuOrigin* DesktopMenuOrigin;
extern MenuOrigin StartMenuTemplate[];
extern MenuOrigin CtrlMenuTemplate[];
extern MenuOrigin DesktopMenuTemplate[];

extern FuncTable funcTable[];
extern VariableTable varTable[];
extern FsNameSet fsSet[];

extern ShortCutKey scKey[];
extern ShortCutKey scRootKey[];
extern ShortCutKey scMenuKey[];

extern AttrNameSet attrSet[];

#endif // _QVWMRC_H_
