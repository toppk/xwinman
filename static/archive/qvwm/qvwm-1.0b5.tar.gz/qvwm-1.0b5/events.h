#ifndef _EVENTS_H_
#define _EVENTS_H_

class Point;

extern Point pressPt, prevPt;

extern void MainLoop();
extern void DispatchEvent(XEvent* ev);
extern void ExposeProc(Window w);

#endif // _EVENTS_H_
