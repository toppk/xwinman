#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/xpm.h>
#include <X11/extensions/shape.h>
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "icon.h"
#include "util.h"
#include "events.h"
#include "startmenu.h"
#include "qvwmrc.h"
#include "bitmaps/icon.xpm"

Icon* Icon::firstIcon;
Icon* Icon::lastIcon;
Icon* Icon::focusIcon;
XContext Icon::context;
Pixmap Icon::pixIcon, Icon::maskIcon;

Icon::Icon(Pixmap pix, Pixmap mask, char* name, char* exec)
: pix(pix), mask(mask), name(name), exec(exec)
{
  XSetWindowAttributes attributes;
  unsigned long valueMask;
  XRectangle ink, log;

  /*
   * Create icon window.
   */
  attributes.event_mask = ExposureMask;
  attributes.background_pixel = green;
  attributes.override_redirect = True;
  valueMask = CWBackPixel | CWOverrideRedirect | CWEventMask;

  w = XCreateWindow(display, root,
		    -ICON_AREA, -ICON_AREA, ICON_AREA, ICON_AREA,
		    0, CopyFromParent, InputOutput, CopyFromParent,
		    valueMask, &attributes);

  /*
   * Create icon wapper window.
   */
  attributes.event_mask = ButtonPressMask | ButtonReleaseMask |
                          Button1MotionMask;
  valueMask = CWOverrideRedirect | CWEventMask;

  XmbTextExtents(fsIcon, name, strlen(name), &ink, &log);
  wrap = XCreateWindow(display, root, -ICON_AREA, -ICON_AREA, ICON_AREA,
		       ICON_SIZE+6+log.height, 0, CopyFromParent, InputOnly,
		       CopyFromParent, valueMask, &attributes);
  
  XSaveContext(display, w, context, (caddr_t)this);
  XSaveContext(display, wrap, context, (caddr_t)this);

  /*
   * Add icon in icon list
   */
  if (lastIcon == NULL) {
    firstIcon = this;
    prev = NULL;
  }
  else {
    lastIcon->next = this;
    prev = lastIcon;
  }
  next = NULL;
  lastIcon = this;
}

Icon::~Icon()
{
  XDeleteContext(display, w, context);
  XDeleteContext(display, wrap, context);
  XDestroyWindow(display, w);
  XDestroyWindow(display, wrap);

  /*
   * Remove icon in icon list.
   */
  if (this == focusIcon)
    focusIcon = NULL;

  if (prev == NULL)
    firstIcon = next;
  else
    prev->next = next;
  if (next == NULL)
    lastIcon = prev;
  else
    next->prev = prev;
}

/*
 * MapIcon --
 *   Map icon itself and the wrapper.
 */
void Icon::MapIcon()
{
  XMapWindow(display, wrap);
  XLowerWindow(display, wrap);
  XMapWindow(display, w);
  XLowerWindow(display, w);
}

/*
 * unmapIcon --
 *   Unmap icon itself and the wrapper.
 */
void Icon::UnmapIcon()
{
  XUnmapWindow(display, w);
  XUnmapWindow(display, wrap);
}

/*
 * DrawIcon --
 *   Draw icon pixmap and icon name.
 */
void Icon::DrawIcon(Bool focus)
{
  Rect rect;
  char* str;
  Pixmap shapeMask;
  GC gcShape;
  XRectangle ink, log;

  /*
   * Draw icon pixmap.
   */
  if (pix) {
    XCopyArea(display, pix, w, gc, 0, 0, ICON_SIZE, ICON_SIZE, 21, 2);

    if (focus)
      XFillRectangle(display, w, gcTileMask, 21, 2, ICON_SIZE, ICON_SIZE);
  }

  /*
   * Draw icon name.
   */
  str = GetFixName(fsIcon, name, ICON_AREA);
  XmbTextExtents(fsIcon, str, strlen(str), &ink, &log);
  rect.width = log.width;
  rect.height = log.height;
  rect.x = (ICON_AREA - rect.width) / 2;
  rect.y = 2 + ICON_SIZE + 4;

  /*
   * Transparentize(?) parts other than icon pixmap and name.
   */
  shapeMask = XCreatePixmap(display, w, ICON_AREA, ICON_AREA, 1);
  gcShape = XCreateGC(display, shapeMask, 0, 0);

  // First, transparentize the whole (pixel value 0 is transparent).
  XSetForeground(display, gcShape, 0);
  XFillRectangle(display, shapeMask, gcShape, 0, 0, ICON_AREA, ICON_AREA);

  // Opaque icon pixmap.
  XSetForeground(display, gcShape, 1);
  XSetBackground(display, gcShape, 0);
  XCopyPlane(display, mask, shapeMask, gcShape, 0, 0, ICON_SIZE, ICON_SIZE,
	    21, 2, 1);

  // Opaque icon name.
  XSetForeground(display, gcShape, 1);
  XFillRectangle(display, shapeMask, gcShape, rect.x, rect.y, rect.width,
		 rect.height);

  XShapeCombineMask(display, w, ShapeBounding, 0, 0, shapeMask, ShapeSet);

  XFreePixmap(display, shapeMask);
  XFreeGC(display, gcShape);

  if (focus)
    XSetForeground(display, gc, blue);
  else
    XSetForeground(display, gc, green);
    
  XFillRectangle(display, w, gc, rect.x, rect.y, rect.width, rect.height);

  XmbTextExtents(fsIcon, str, strlen(str), &ink, &log);
  XSetForeground(display, gc, white);
  XmbDrawString(display, w, fsIcon, gc, rect.x, rect.y-log.y,
		str, strlen(str));

  delete [] str;
}

/*
 * Button1Press --
 *   Process press of button1 (mouse left button)
 */
void Icon::Button1Press(Time clickTime)
{
  XEvent ev;
  Point oldPt, newPt, junkPt;
  Window junkRoot, junkChild;
  unsigned int mask;

  /*
   * First, unmap all menus and move focus to root window.
   */
  if (Qvwm::focusQvwm->CheckMenuMapped())
    Qvwm::focusQvwm->UnmapMenu();
  if (startMenu != NULL && startMenu->CheckMapped())
    startMenu->UnmapMenu();

  rootQvwm->SetFocus();

  /*
   * If double click, execute the function.
   */
  if (IsDoubleClick(iconClickTime, clickTime, prevPt, pressPt)) {
    if (!fork())
      if (execl("/bin/sh", "bin/sh", "-c", exec, NULL) == -1) {
	QvwmError("Can't execute '%s'", exec);
	exit(1);
      }
    focusIcon = NULL;
    DrawIcon(False);
    return;
  }
  else {
    focusIcon = this;
    DrawIcon(True);
  }

  iconClickTime = clickTime;

  /*
   * Process icon movement.
   */
  XQueryPointer(display, w, &junkRoot, &junkChild, &oldPt.x, &oldPt.y,
		&junkPt.x, &junkPt.y, &mask);
  
  while (1) {
    XNextEvent(display, &ev);
    switch (ev.type) {
    case Expose:
      DrawIcon(True);
      break;
    case MotionNotify:
      XQueryPointer(display, w, &junkRoot, &junkChild, &newPt.x, &newPt.y,
		    &junkPt.x, &junkPt.y, &mask);
      rc.x += newPt.x - oldPt.x;
      rc.y += newPt.y - oldPt.y;

      oldPt = newPt;
      XMoveWindow(display, w, rc.x, rc.y);
      XMoveWindow(display, wrap, rc.x, rc.y);
      break;

    case ButtonRelease:
      return;
    }
  }
}

/*
 * RedrawAllIcons --
 *   Redraw all icons in icon list.
 */
void Icon::RedrawAllIcons()
{
  Icon* tmpIcon = firstIcon;
  int count = 0;
  int iconColumnNum;

  iconColumnNum = rcScreen.height / ICON_AREA;

  while (tmpIcon != NULL) {
    tmpIcon->rc.x = rcScreen.x + ICON_AREA*(count/iconColumnNum);
    tmpIcon->rc.y = rcScreen.y + ICON_AREA*(count%iconColumnNum);
    count++;

    XMoveWindow(display, tmpIcon->w, tmpIcon->rc.x, tmpIcon->rc.y);
    XMoveWindow(display, tmpIcon->wrap, tmpIcon->rc.x, tmpIcon->rc.y);

    tmpIcon = tmpIcon->next;
  }
}

/*
 * CreateIconPixmap --
 *   Create default icon pixmap.
 */
void Icon::CreateIconPixmap()
{
  XpmAttributes attr;

  attr.valuemask = XpmColormap | XpmDepth;
  attr.colormap = colormap;
  attr.depth = depth;

  XpmCreatePixmapFromData(display, root, icon, &pixIcon, &maskIcon, &attr);
}
