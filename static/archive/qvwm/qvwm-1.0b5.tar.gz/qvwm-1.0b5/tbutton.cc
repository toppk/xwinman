#include <stdio.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "main.h"
#include "misc.h"
#include "util.h"
#include "qvwm.h"
#include "tbutton.h"
#include "sbutton.h"
#include "taskbar.h"
#include "startmenu.h"
#include "qvwmrc.h"
#include "paging.h"

Rect TaskbarButton::TButtonRc(0, 0, 160, TaskbarButton::BUTTON_HEIGHT);
XFontSet* TaskbarButton::fsb;

TaskbarButton::TaskbarButton(Qvwm* qvWm, Rect rc, Pixmap pix, GC gc,
			     char *name)
: Button(taskBar->w, rc), focus(False), qvWm(qvWm), pix(pix), gc(gc),
  name(name), shortname(name)
{
}

TaskbarButton::~TaskbarButton()
{
  if (pix != pixLogo) {
    XFreePixmap(display, pix);
    XFreeGC(display, gc);
  }
}

/*
 * MapButton --
 *   Map taskbar button.
 */
void TaskbarButton::MapButton()
{
  if (!qvWm->CheckFlags(TRANSIENT)) {
    RedrawAllTaskbarButtons();
    Button::MapButton();
  }
}

/*
 * UnmapButton --
 *   Unmap taskbar button.
 */
void TaskbarButton::UnmapButton()
{
  if (!qvWm->CheckFlags(TRANSIENT)) {
    Button::UnmapButton();
    RedrawAllTaskbarButtons();
  }
}

/*
 * DrawButton --
 *   Draw taskbar button.
 */
void TaskbarButton::DrawButton()
{
  /*
   * No button for the transient window.
   */
  if (qvWm->CheckFlags(TRANSIENT))
    return;

  FillBackground();
  Button::DrawButton();

  if (CheckState(PUSH) && focus) {
    XSetForeground(display, ::gc, white);
    XDrawLine(display, frame, ::gc, 2, 2, rc.width, 2);
  }

  /*
   * Draw the pixmap of the taskbar button.
   */
  if (state == PUSH) {
    XSetClipOrigin(display, gc, 4, 4);
    XCopyArea(display, pix, frame, gc, 0, 0, SIMBOL_WIDTH, SIMBOL_HEIGHT,
	      4, 4);
  }
  else {
    XSetClipOrigin(display, gc, 4, 3);
    XCopyArea(display, pix, frame, gc, 0, 0, SIMBOL_WIDTH, SIMBOL_HEIGHT,
	      4, 3);
  }

  // Draw the title of the taskbar button.
  DrawName();
}

/*
 * FillBackground --
 *   Paint the background of taskbar button gray or tile pattern.
 */
void TaskbarButton::FillBackground()
{
  if (CheckState(PUSH) && focus)
    XFillRectangle(display, frame, gcTile, 2, 3, rc.width-4, rc.height-5);
  else {
    XSetForeground(display, ::gc, gray);
    XFillRectangle(display, frame, ::gc, 2, 2, rc.width-4, TButtonRc.height-4);
  }
}

/*
 * DrawName --
 *   Draw the text taskbar button.
 */
void TaskbarButton::DrawName()
{
  if (qvWm->CheckFlags(TRANSIENT))
    return;

  XRectangle ink, log;
  int y;

  shortname = GetFixName(fsTaskbar, name, rc.width-24);

  XmbTextExtents(fsTaskbar, shortname, strlen(shortname), &ink, &log);
  y = (BUTTON_HEIGHT - log.height) / 2 - log.y;

  if (CheckState(PUSH)) {
    if (UseBoldFont && focus) {
      XSetForeground(display, ::gc, black);
      XmbDrawString(display, frame, *fsb, ::gc, 22, y+1,
		    shortname, strlen(shortname));
    }
    else {
      XSetForeground(display, ::gc, black);
      XmbDrawString(display, frame, fsTaskbar, ::gc, 22, y+1,
		    shortname, strlen(shortname));
      if (focus)
	XmbDrawString(display, frame, fsTaskbar, ::gc, 23, y+1,
		      shortname, strlen(shortname));
    }
  }
  else {
    if (UseBoldFont && focus) {
      XSetForeground(display, ::gc, black);
      XmbDrawString(display, frame, *fsb, ::gc, 22, y,
		    shortname, strlen(shortname));
    }
    else {
      XSetForeground(display, ::gc, black);
      XmbDrawString(display, frame, fsTaskbar, ::gc, 22, y,
		    shortname, strlen(shortname));
      if (focus)
	XmbDrawString(display, frame, fsTaskbar, ::gc, 23, y,
		      shortname, strlen(shortname));
    }
  }
}

/*
 * Button1Press --
 *   Process the press of button1(mouse left button).
 */
void TaskbarButton::Button1Press()
{
  if (Qvwm::focusQvwm->CheckMapped())
    Qvwm::focusQvwm->UnmapMenu();
  if (startMenu != NULL && startMenu->CheckMapped())
    startMenu->UnmapMenu();
  
  if (!qvWm->CheckFocus())
    Button::Button1Press();
}

/*
 * ExecButtonFunc --
 *   Give the focus to the taskbar button and the corresponding window.
 */
void TaskbarButton::ExecButtonFunc(ButtonState bs)
{
  if (bs == PUSH) {
    if (qvWm->CheckStatus(MINIMIZE_WINDOW))
      qvWm->RestoreWindow();
    else {
      qvWm->SetFocus();
      qvWm->RaiseWindow(True);
      qvWm->AdjustPage();
    }

    /*
     * When button is released, state is set to NORMAL in default.
     * So state sets to PUSH here.
     */
    if (qvWm->CheckFlags(NOFOCUS))
      state = NORMAL;
    else
      state = PUSH;
  }
}
  
/*
 * Button3Release --
 *   Process the release of button3(mouse right button).
 */
void TaskbarButton::Button3Release()
{
  Window junkRoot, junkChild;
  Point pt, junkPt;
  unsigned int mask;
  Bool noFocus = False;

  /*
   * When button3 is released, map menu if start menu isn't mapped.
   */
  if (startMenu == NULL || !startMenu->CheckMapped()) {
    if (Qvwm::focusQvwm->CheckMenuMapped())
      Qvwm::focusQvwm->UnmapMenu();

    /*
     * Temporarily, give the focus.
     */
    if (qvWm->CheckFlags(NOFOCUS)) {
      qvWm->ResetFlags(NOFOCUS);
      noFocus = True;
    }
    
    qvWm->SetFocus();
    qvWm->RaiseWindow(True);
    qvWm->AdjustPage();

    XQueryPointer(display, root, &junkRoot, &junkChild, &pt.x, &pt.y,
		  &junkPt.x, &junkPt.y, &mask);

    pt = qvWm->ctrlMenu->GetFixedMenuPos(pt);
    qvWm->MapMenu(pt.x, pt.y);

    if (noFocus)
      qvWm->SetFlags(NOFOCUS);
  }
}

/*
 * RedrawAllTaskbarButtons --
 *   Redraw all taskbar buttons.
 */
void TaskbarButton::RedrawAllTaskbarButtons()
{
  Qvwm* tmpQvwm = rootQvwm;
  unsigned int buttonWidth;
  int row, col;
  int buttonNum = 0, count = 0;
  Taskbar::TaskbarPos pos;
  int x, y;

  XMoveWindow(display, rootQvwm->tButton->frame, TButtonRc.x, TButtonRc.y);

  pos = taskBar->GetPos();

  /*
   * Taskbar buttons are unvisible when the taskbar is shown minimumly.
   */
  if (taskBar->rc[pos].height == 6)
    TButtonRc.y = -10000;
  if (taskBar->rc[pos].width == 6)
    TButtonRc.x = -10000;

  /*
   * Adjust the position and the size of the start button.
   */
  rootQvwm->tButton->rc.x = TButtonRc.x;
  rootQvwm->tButton->rc.y = TButtonRc.y;
  if (taskBar->rc[pos].width > StartButton::BUTTON_WIDTH+6)
    rootQvwm->tButton->rc.width = StartButton::BUTTON_WIDTH;
  else {
    rootQvwm->tButton->rc.width = taskBar->rc[pos].width - 6;
    if (rootQvwm->tButton->rc.width == 0)
      rootQvwm->tButton->rc.width = 1;
  }

  XMoveResizeWindow(display, rootQvwm->tButton->frame,
		    rootQvwm->tButton->rc.x, rootQvwm->tButton->rc.y,
		    rootQvwm->tButton->rc.width, rootQvwm->tButton->rc.height);

  /*
   * Count the number of taskbar buttons.
   */
  while ((tmpQvwm = tmpQvwm->GetNext()) != NULL)
    if (!tmpQvwm->CheckFlags(TRANSIENT) &&
	(tmpQvwm->CheckMapped() || tmpQvwm->CheckStatus(MINIMIZE_WINDOW)))
      buttonNum++;
     
  if (buttonNum == 0)
    return;

  /*
   * According to taskbar position, determine the way arranging buttons.
   */
  switch (pos) {
  case Taskbar::BOTTOM:
  case Taskbar::TOP:
    col = taskBar->rc[pos].height / (TButtonRc.height + BETWEEN_SPACE);
    buttonWidth = taskBar->buttonArea*col / buttonNum - BETWEEN_SPACE;
    if (buttonWidth > TButtonRc.width)
      buttonWidth = TButtonRc.width;
    if (buttonWidth == 0)
      buttonWidth = 1;
    row = taskBar->buttonArea / buttonWidth;
    break;

  case Taskbar::LEFT:
  case Taskbar::RIGHT:
    row = (buttonNum * (TButtonRc.height + BETWEEN_SPACE) - 1)
              / taskBar->buttonArea + 1;
    buttonWidth = (taskBar->rc[pos].width - 5) / row - BETWEEN_SPACE;
    if (buttonWidth == 0)
      buttonWidth = 1;
    break;
  }

  /*
   * Reposition all taskbar buttons.
   */
  tmpQvwm = rootQvwm;

  while ((tmpQvwm = tmpQvwm->GetNext()) != NULL) {
    if (tmpQvwm->CheckFlags(TRANSIENT) ||
	(!tmpQvwm->CheckMapped() && !tmpQvwm->CheckStatus(MINIMIZE_WINDOW)))
      continue;

    TaskbarButton* tb = tmpQvwm->tButton;

    switch (taskBar->pos) {
    case Taskbar::BOTTOM:
    case Taskbar::TOP:
      x = TButtonRc.x + StartButton::BUTTON_WIDTH + 4
	  + (buttonWidth + BETWEEN_SPACE) * (count % row);
      y = TButtonRc.y + (count / row) * (TButtonRc.height + BETWEEN_SPACE);
      tb->rc = Rect(x, y, buttonWidth, TButtonRc.height);
      break;

    case Taskbar::LEFT:
    case Taskbar::RIGHT:
      x = TButtonRc.x + (count % row) * (buttonWidth + BETWEEN_SPACE);
      y = TButtonRc.y + BUTTON_HEIGHT + BETWEEN_SPACE
	   + (TButtonRc.height + BETWEEN_SPACE) * (count / row);
      tb->rc = Rect(x, y, buttonWidth, TButtonRc.height);
      break;
    }
    count++;

    XMoveResizeWindow(display, tb->frame,
		      tb->rc.x, tb->rc.y, tb->rc.width, tb->rc.height);

    tb->shortname = GetFixName(fsTaskbar, tb->name, tb->rc.width-24);
  }
}                         
