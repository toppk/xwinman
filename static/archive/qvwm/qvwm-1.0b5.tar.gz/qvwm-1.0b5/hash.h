#ifndef _HASH_H_
#define _HASH_H_

#include <stdio.h>
#include <stdlib.h>

/*
 * HashItem class --
 *   Element of hash.
 */
template <class T>
class HashItem {
private:
  char* key;                     // hash key
  T* item;                       // hash element
  HashItem<T>* ptr;              // pointer to next element
public:
  HashItem(char* key, T* item, HashItem<T>* ptr)
    : key(key), item(item), ptr(ptr) {}

  char* GetKey() const { return key; }
  T* GetItem() const { return item; }
  HashItem<T>* GetPtr() const { return ptr; }
};

/*
 * Hash class
 */
template <class T>
class Hash {
private:
  HashItem<T>** table;            // hash table
  int size;                       // hash table size

public:
  Hash(int size) : size(size) {
    table = new HashItem<T>*[size];
    
    for (int i = 0; i < size; i++)
      table[i] = 0;
  }
  ~Hash() {
    HashItem<T> *item, *pItem;

    for (int i = 0; i < size; i++) {
      item = table[i];
      while (item != NULL) {
	pItem = item->GetPtr();
	delete item;
	item = pItem;
      }
    }
    delete table;
  }
  /*
   * SetHashItem --
   *   Set item in hash table with key.
   */
  void SetHashItem(char* key, T* item) {
    int n = strlen(key);
    int keyNum;

    keyNum = abs((key[0]-'A')+(key[n/2-1]-'A')*26+(key[n-2]-'A')*26*26) % size;

    table[keyNum] = new HashItem<T>(key, item, table[keyNum]);
  }
  /*
   * GetHashItem --
   *   Get item corresponding to key from hash table.
   */
  T* GetHashItem(char* key) {
    int n = strlen(key);
    int keyNum;
    HashItem<T>* hashItem;
    
    keyNum = abs((key[0]-'A')+(key[n/2-1]-'A')*26+(key[n-2]-'A')*26*26)
              % size;
    
    hashItem = table[keyNum];
    
    while (hashItem != NULL) {
      if (strcmp(hashItem->GetKey(), key) == 0)
	return hashItem->GetItem();
      hashItem = hashItem->GetPtr();
    }

    // no match
    return NULL;
  }
};

#endif // _HASH_H_
