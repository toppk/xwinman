typedef union {
  char* str;
  MenuRes* mRes;
  ItemList* iList;
} YYSTYPE;
#define	MENU	258
#define	ATTR	259
#define	VAR	260
#define	STRING	261
#define	FUNC	262


extern YYSTYPE yylval;
