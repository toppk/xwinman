#ifndef _PAGER_H_
#define _PAGER_H_

#include "misc.h"
#include "util.h"

/*
 * Pager class
 */
class Pager {
  Window frame;
  Window title;
  Window pager;             // window standing for whole page
  Window visual;            // window standing for current page
  Rect rc;                  // real size and position of pager
  InternGeom geom;          // specified size, position and bitmask of pager
  Dim pageSize;             // size of one page in pager

public:
  Pager(InternGeom geom);
  ~Pager();

  Window GetFrameWin() const { return frame; }
  Window GetPagerWin() const { return pager; }
  Window GetVisualWin() const { return visual; }

  Bool IsPagerWindows(Window win);
  void AdjustPagerPos();
  void RecalcPager();

  void DrawPager();
  void DrawVisualPage();
  void DrawFrame();
  void Button1Press(Window win);
  void Button3Press();
};

#endif // _PAGER_H_
