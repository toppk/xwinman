#include <string.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include "main.h"
#include "qvwm.h"
#include "switch.h"
#include "qvwmrc.h"

TaskSwitcher::TaskSwitcher()
{
  XSetWindowAttributes attributes;
  unsigned long valueMask;
  
  /*
   * Create frame window.
   */
  attributes.background_pixel = gray;
  attributes.override_redirect = True;
  attributes.event_mask = KeyPressMask | KeyReleaseMask | ExposureMask;
  valueMask = CWBackPixel | CWOverrideRedirect | CWEventMask;

  frame = XCreateWindow(display, root, 0, 0, 10, 10, 0,
			CopyFromParent, InputOutput, CopyFromParent,
			valueMask, &attributes);

  /*
   * Create the window displaying title name.
   */
  valueMask = CWBackPixel;

  titleFrame = XCreateWindow(display, frame, 14, 0, 322, 24, 0,
			     CopyFromParent, InputOutput, CopyFromParent,
			     valueMask, &attributes);

  title = XCreateWindow(display, titleFrame, 2, 2, 318, 20, 0,
			CopyFromParent, InputOutput, CopyFromParent,
			valueMask, &attributes);
}

TaskSwitcher::~TaskSwitcher()
{
  XDestroyWindow(display, frame);
}

/*
 * SwitchTask --
 *   Display task switcher and switch focus window.
 */
void TaskSwitcher::SwitchTask()
{
  Qvwm* tmpQvwm = Qvwm::focusQvwm;
  int winNum = 0;

  while (tmpQvwm != NULL) {
    if (tmpQvwm != rootQvwm)
      winNum++;
    tmpQvwm = tmpQvwm->preFocus;
  }

  if (winNum == 0 || winNum == 1)
    return;

  int col = (winNum+6) / 7;

  Rect rcRoot = rootQvwm->GetRect();

  rc = Rect((rcRoot.width - BASE_WIDTH) / 2,
	    (rcRoot.height - BASE_HEIGHT - col*43) / 2,
	    BASE_WIDTH,
	    BASE_HEIGHT + col*43);

  XMoveResizeWindow(display, frame, rc.x, rc.y, rc.width, rc.height);
  XMoveWindow(display, titleFrame, 14, 29+col*43);

  XMapWindow(display, titleFrame);
  XMapWindow(display, title);
  XMapRaised(display, frame);

  XSetInputFocus(display, frame, RevertToParent, CurrentTime);

  tmpQvwm = Qvwm::focusQvwm->GetNextFocus();

  XEvent ev;
  int winNumber = 1;

  XGrabServer(display);

  while (1) {
    XNextEvent(display, &ev);
    switch (ev.type) {
    case Expose:
      DrawTaskSwitcher();
      DrawTitle(tmpQvwm->name);
      DrawPixmaps(winNum);
      DrawRect(winNumber, winNum);

      while (XCheckWindowEvent(display, ev.xexpose.window, ExposureMask, &ev))
	;
      break;

    case KeyPress:
      if (ev.xkey.keycode == XKeysymToKeycode(display, XK_Tab) &&
	  ev.xkey.state == Mod1Mask) {
	tmpQvwm = tmpQvwm->GetNextFocus();
	DrawTitle(tmpQvwm->name);

	winNumber = (winNumber+1) % winNum;
	DrawRect(winNumber, winNum);
      }
      break;

    case KeyRelease:
      if (ev.xkey.keycode == XKeysymToKeycode(display, XK_Alt_L) ||
	  ev.xkey.keycode == XKeysymToKeycode(display, XK_Alt_R) ||
	  ev.xkey.keycode == XKeysymToKeycode(display, XK_Meta_L) ||
	  ev.xkey.keycode == XKeysymToKeycode(display, XK_Meta_R)) {
	XUnmapWindow(display, frame);
	XUngrabServer(display);

	if (tmpQvwm == Qvwm::focusQvwm) {
	  if (ClickToFocus)
	    XSetInputFocus(display, tmpQvwm->wOrig, RevertToParent,
			   CurrentTime);
	  else
	    XSetInputFocus(display, root, RevertToParent, CurrentTime);
	}
	else {
	  tmpQvwm->SetFocus();
	  tmpQvwm->RaiseWindow(True);
	  tmpQvwm->AdjustPage();
	}
	return;
      }
    }
  }
}

/*
 * DrawTaskSwitcher --
 *   Draw task switcher.
 */
void TaskSwitcher::DrawTaskSwitcher()
{
  XPoint xp[3];
  
  xp[0].x = rc.width - 2;
  xp[0].y = 0;
  xp[1].x = 0;
  xp[1].y = 0;
  xp[2].x = 0;
  xp[2].y = rc.height - 1;
  
  XSetForeground(display, gc, gray);
  XDrawLines(display, frame, gc, xp, 3, CoordModeOrigin);
  
  xp[0].x = rc.width - 1;
  xp[0].y = 0;
  xp[1].x = rc.width - 1;
  xp[1].y = rc.height - 1;
  xp[2].x = 0;
  xp[2].y = rc.height - 1;
  
  XSetForeground(display, gc, black);
  XDrawLines(display, frame, gc, xp, 3, CoordModeOrigin);
  
  xp[0].x = rc.width - 3;
  xp[0].y = 1;
  xp[1].x = 1;
  xp[1].y = 1;
  xp[2].x = 1;
  xp[2].y = rc.height - 2;
  
  XSetForeground(display, gc, white);
  XDrawLines(display, frame, gc, xp, 3, CoordModeOrigin);
  
  xp[0].x = rc.width - 2;
  xp[0].y = 1;
  xp[1].x = rc.width - 2;
  xp[1].y = rc.height - 2;
  xp[2].x = 1;
  xp[2].y = rc.height - 2;
  
  XSetForeground(display, gc, darkGray);
  XDrawLines(display, frame, gc, xp, 3, CoordModeOrigin);
  
  /*
   * The frame of title area.
   */
  xp[0].x = TITLE_WIDTH - 2;
  xp[0].y = 0;
  xp[1].x = 0;
  xp[1].y = 0;
  xp[2].x = 0;
  xp[2].y = TITLE_HEIGHT - 1;

  XSetForeground(display, gc, darkGray);
  XDrawLines(display, titleFrame, gc, xp, 3, CoordModeOrigin);
  
  xp[0].x = TITLE_WIDTH - 1;
  xp[0].y = 0;
  xp[1].x = TITLE_WIDTH - 1;
  xp[1].y = TITLE_HEIGHT - 1;
  xp[2].x = 0;
  xp[2].y = TITLE_HEIGHT - 1;
  
  XSetForeground(display, gc, white);
  XDrawLines(display, titleFrame, gc, xp, 3, CoordModeOrigin);
  
  xp[0].x = TITLE_WIDTH - 3;
  xp[0].y = 1;
  xp[1].x = 1;
  xp[1].y = 1;
  xp[2].x = 1;
  xp[2].y = TITLE_HEIGHT - 2;
  
  XSetForeground(display, gc, black);
  XDrawLines(display, titleFrame, gc, xp, 3, CoordModeOrigin);
  
  xp[0].x = TITLE_WIDTH - 2;
  xp[0].y = 1;
  xp[1].x = TITLE_WIDTH - 2;
  xp[1].y = TITLE_HEIGHT - 2;
  xp[2].x = 1;
  xp[2].y = TITLE_HEIGHT - 2;
  
  XSetForeground(display, gc, gray);
  XDrawLines(display, titleFrame, gc, xp, 3, CoordModeOrigin);
}

/*
 * DrawTitle --
 *   Draw title name.
 */
void TaskSwitcher::DrawTitle(char* name)
{
  XRectangle ink, log;
  Point pt;

  XSetBackground(display, gc, gray);
  XClearWindow(display, title);

  XmbTextExtents(fsTitle, name, strlen(name), &ink, &log);
  pt.x = 2 - log.x;
  pt.y = (TITLE_HEIGHT - log.height) / 2 - log.y;

  XSetForeground(display, gc, black);
  XmbDrawString(display, title, fsTitle, gc, pt.x, pt.y, name, strlen(name));
}

/*
 * DrawRect --
 *   Draw the rectangle which indicates that the window is selected.
 */
void TaskSwitcher::DrawRect(int winNumber, int winNum)
{
  int base;
  Rect rect(0, 0, 42, 42);

  if (winNum < 7) {
    base = (BASE_WIDTH - winNum * 43 - 3) / 2 + 3;
    rect.x = base + ((winNumber+winNum-1) % winNum) * 43 + 1;
    rect.y = 19 + 1;
  }
  else {
    base = 26;
    if (winNumber == 0) {
      rect.x = base + ((winNum-1) % 7) * 43 + 1;
      rect.y = 19 + ((winNum-1) / 7) * 43 + 1;
    }
    else {
      rect.x = base + ((winNumber+6) % 7) * 43 + 1;
      rect.y = 19 + ((winNumber-1) / 7) * 43 + 1;
    }
  }

  /*
   * Erase the previous rectangle.
   */
  XSetForeground(display, gc, gray);
  XSetLineAttributes(display, gc, 2, LineSolid, CapButt, JoinMiter);
  XDrawRectangle(display, frame, gc, rect.x, rect.y, rect.width, rect.height);

  /*
   * Draw new rectangle.
   */
  rect.x = base + (winNumber % 7) * 43 + 1;
  rect.y = 19 + (winNumber / 7) * 43 + 1;

  XSetForeground(display, gc, blue);
  XDrawRectangle(display, frame, gc, rect.x, rect.y, rect.width, rect.height);

  /*
   * Restore line thickness.
   */
  XSetLineAttributes(display, gc, 1, LineSolid, CapButt, JoinMiter);
}

/*
 * DrawPixmaps --
 *   Draw pixmaps which indicate windows.
 */
void TaskSwitcher::DrawPixmaps(int winNum)
{
  Qvwm* tmpQvwm = Qvwm::focusQvwm;
  int base = 26, num = 0;
  Point pt;

  if (winNum < 7)
    base = (BASE_WIDTH - winNum * 43 - 3) / 2 + 3;

  if (Qvwm::focusQvwm == rootQvwm)
    tmpQvwm = Qvwm::focusQvwm->preFocus;

  while (num < winNum) {
    pt.x = base + (num % 7) * 43 + 5;
    pt.y = 19 + (num / 7) * 43 + 5;

    XSetClipOrigin(display, tmpQvwm->gcLarge, pt.x, pt.y);
    XCopyArea(display, tmpQvwm->pixLarge, frame, tmpQvwm->gcLarge, 0, 0,
	      32, 32, pt.x, pt.y);
    
    tmpQvwm = tmpQvwm->GetNextFocus();
    num++;
  }
}
