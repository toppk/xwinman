#include <stdio.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "util.h"
#include "fbutton.h"
#include "tbutton.h"
#include "sbutton.h"
#include "menu.h"
#include "startmenu.h"
#include "events.h"
#include "taskbar.h"
#include "icon.h"
#include "qvwmrc.h"
#include "switch.h"
#include "paging.h"
#include "pager.h"

Bool Qvwm::umReserved = False;
XContext Qvwm::context;
Qvwm* Qvwm::lastQvwm;

int FinishErrorHandler(Display* display, XErrorEvent* ev);

/*
 * Qvwm class constructor --
 *   Position the window at that point if usrPos is True;
 *   otherwise, the position of the window obeys a given rule.
 */
Qvwm::Qvwm(Window w, Bool usrPos)
: wOrig(w)
{
  static int initPos = 50;

  status = 0;
  nCmapWins = 0;

  XGrabServer(display);

  XTextProperty xtp;
  char** cl;
  char* iconName;
  int n;

  /*
   * Get the window name.
   */
  if (XGetWMName(display, w, &xtp) != 0) {
    XmbTextPropertyToTextList(display, &xtp, &cl, &n);
    name = cl[0];
  }
  else
    name = "Untitled";

  /*
   * Get the icon name.
   */
  if (XGetWMIconName(display, w, &xtp) != 0) {
    XmbTextPropertyToTextList(display, &xtp, &cl, &n);
    iconName = cl[0];
  }
  else
    iconName = "Untitled";

  /*
   * Get class hint.
   */
  GetWindowClassHints();

  /*
   * Set frame attribute.
   */
  Window transientFor;

  SetFlags(BORDER | TITLE | CTRL_MENU | BUTTON1 | BUTTON2 | BUTTON3);
  if (XGetTransientForHint(display, w, &transientFor)) {
    SetFlags(TRANSIENT);
    ResetFlags(CTRL_MENU | BUTTON1 | BUTTON2 | BUTTON3);
  }
  else
    ResetFlags(TRANSIENT);

  FetchWMProtocols();
  GetWindowSizeHints();
  
  /*
   * Preserve original border width and set border width to 0.
   */
  XWindowAttributes attr;

  XGetWindowAttributes(display, w, &attr);
  bwOrig = attr.border_width;
  XSetWindowBorderWidth(display, w, 0);

  /*
   * Calculate the window position.
   */
  if (usrPos || flags & TRANSIENT || hints.flags & USPosition) {
    rcOrig = Rect(attr.x+paging->origin.x, attr.y+paging->origin.y,
		  attr.width, attr.height);
    CalcWindowPos(rcOrig);
  }
  else {
    rc.x = initPos + rcScreen.x + paging->origin.x;
    rc.y = initPos + rcScreen.y + paging->origin.y;
    initPos += 50;
    if (initPos > (int)rcScreen.height/3)
      initPos = 50;

    rcOrig = Rect(rc.x, rc.y, attr.width, attr.height);

    if (CheckFlags(DIALOG)) {
      rc.width = attr.width + 3*2;
      rc.height = attr.height + TITLE_HEIGHT + 3*2 + 3;
    }
    else {
      rc.width = attr.width + (BORDER_WIDTH+2)*2;
      rc.height = attr.height + TITLE_HEIGHT + BORDER_WIDTH*2 + 5;
    }
  }

  Rect rcParent, rcTitle, rcCorner[4], rcSide[4], rcCtrl, rcButton[3];

  CalcFramePos(rc, &rcParent, &rcTitle, rcCorner, rcSide, &rcCtrl,
	       rcButton);

  CreateFrame(rc);
  CreateParent(rcParent);
  CreateSides(rcSide);
  CreateCorners(rcCorner);  
  CreateTitle(rcTitle);
  CreateCtrlButton(rcCtrl);

  /*
   * Create three kinds of frame button.
   */
  fButton[0] = new FrameButton1(this, title, rcButton[0],
				FrameButton::pixButton[0]);
  fButton[1] = new FrameButton2(this, title, rcButton[1],
				FrameButton::pixButton[1]);
  fButton[2] = new FrameButton3(this, title, rcButton[2],
				FrameButton::pixButton[2]);
  
  Pixmap pix;
  GC gc;

  GetFixedIcon(pixLarge, gcLarge, 32);
  GetFixedIcon(pix, gc, 16);

  Rect rect(-50, -50, 50, 50);
  tButton = new TaskbarButton(this, rect, pix, gc, iconName);

  rect = Rect(0, 0, 0, 0);
  ctrlMenu = new Menu(this, CtrlMenuOrigin, 0, 16, 0, 14, rect, fsCtrlMenu,
		      NULL);

  ChangeOrigWindow();

  /*
   * Add qvwm in qvwm list.
   */
  lastQvwm->next = this;
  prev = lastQvwm;
  next = NULL;
  lastQvwm = this;

  GrabKeys();

  XUngrabServer(display);
}

/*
 * Qvwm class constructor --
 *   For only root window.
 */
Qvwm::Qvwm(Window root) : wOrig(root), frame(root)
{
  Rect rect(0, 0, BUTTON_WIDTH, BUTTON_HEIGHT);

  rc = Rect(0, 0,
	    DisplayWidth(display, screen), DisplayHeight(display, screen));

  next = prev = NULL;
  preFocus = NULL;
  mapped = True;
  flags = 0L;
  name = "qvwm root";

  taskBar = new Taskbar(this);

  tButton = new StartButton(this);

  rect = Rect(0, 0, 0, 0);
  ctrlMenu = new Menu(this, DesktopMenuOrigin, 0, 16, 0, 14, rect, fsCtrlMenu,
		      NULL);

  XSaveContext(display, root, context, (caddr_t)this);
}

Qvwm::~Qvwm()
{
  int i;

  if (this != rootQvwm) {
    XDeleteContext(display, frame, context);
    XDeleteContext(display, parent, context);
    XDeleteContext(display, wOrig, context);
    XDeleteContext(display, title, context);
    for (i = 0; i < 4; i++) {
      XDeleteContext(display, corner[i], context);
      XDeleteContext(display, side[i], context);
    }
    XDeleteContext(display, ctrl, context);

    /*
     * Delete frame buttons before the parent window(frame) is destroyed.
     */
    for (i = 0; i < 3; i++)
      delete fButton[i];
    delete tButton;
    delete ctrlMenu;

    XDestroyWindow(display, frame);
  }

  /*
   * Remove this qvwm from qvwm list.
   */
  if (prev != NULL)
    prev->next = next;
  if (next == NULL)
    lastQvwm = prev;
  else
    next->prev = prev;
}

/*
 * ChangeOrigWindow --
 *   Change parent and attributes of original window.
 */
void Qvwm::ChangeOrigWindow()
{
  XSetWindowAttributes attributes;
  unsigned long valueMask;

  XReparentWindow(display, wOrig, parent, 0, 0);

  attributes.event_mask = StructureNotifyMask | PropertyChangeMask |
                          VisibilityChangeMask | EnterWindowMask |
			  LeaveWindowMask | ColormapChangeMask;
  attributes.do_not_propagate_mask = ButtonPressMask | ButtonReleaseMask;
  valueMask = CWEventMask | CWDontPropagate;

  XChangeWindowAttributes(display, wOrig, valueMask, &attributes);

  XSaveContext(display, wOrig, context, (caddr_t)this);
  XAddToSaveSet(display, wOrig);

  SetStateProperty(NormalState);
}

/*
 * GrabKeys --
 *   Grab keys of window.
 */
void Qvwm::GrabKeys()
{
  for (int i = 0; i < SCKeyNum; i++)
    XGrabKey(display, XKeysymToKeycode(display, scKey[i].sym), scKey[i].mod,
	     frame, True, GrabModeAsync, GrabModeAsync);
}

/*
 * GrabRootKeys --
 *   Grab keys of root window.
 */
void Qvwm::GrabRootKeys()
{
  for (int i = 0; i < SCRootKeyNum; i++)
    XGrabKey(display, XKeysymToKeycode(display, scRootKey[i].sym),
	     scRootKey[i].mod, root, True, GrabModeAsync, GrabModeAsync);
}

/*
 * UngrabRootKeys --
 *   Ungrab keys of root window.
 */
void Qvwm::UngrabRootKeys()
{
  for (int i = 0; i < SCRootKeyNum; i++)
    XUngrabKey(display, XKeysymToKeycode(display, scRootKey[i].sym),
	     scRootKey[i].mod, root);
}

/*
 * ExecFunction --
 *   Execute the function.
 */
void Qvwm::ExecFunction(FuncNumber fn)
{
  ctrlMenu->ExecFunction(fn, 0);
}

/*
 * SendMessage --
 *   Send the messeage to this window.
 */
void Qvwm::SendMessage(Atom atom)
{
  XClientMessageEvent cev;

  cev.type = ClientMessage;
  cev.window = wOrig;
  cev.message_type = _XA_WM_PROTOCOLS;
  cev.format = 32;
  cev.data.l[0] = atom;
  cev.data.l[1] = CurrentTime;

  XSendEvent(display, wOrig, False, 0L, (XEvent *)&cev);
}

/*
 * KillClient --
 *   Kill the client program forcely.
 */
void Qvwm::KillClient()
{
  XKillClient(display, wOrig);
}

/*
 * AdjustPage --
 *   Switch to the page where the window center point exists.
 */
void Qvwm::AdjustPage()
{
  if (this == rootQvwm)
    return;

  Rect rect = GetRect();
  Point ptCenter(rect.x+rect.width/2, rect.y+rect.height/2);
  Rect rcRoot = rootQvwm->GetRect();
  
  if (ptCenter.x >= 0)
    ptCenter.x =  ptCenter.x / rcRoot.width * rcRoot.width;
  else
    ptCenter.x = (ptCenter.x / rcRoot.width - 1) * rcRoot.width;

  if (ptCenter.y >= 0)
    ptCenter.y = ptCenter.y / rcRoot.height * rcRoot.height;
  else 
    ptCenter.y = (ptCenter.y / rcRoot.height - 1) * rcRoot.height;
  
  paging->PagingProc(ptCenter);
}

/*
 * Exposure --
 *   Process exposure event.
 */
void Qvwm::Exposure(Window win)
{
  if (win == frame)
    DrawFrame();
  else if (win == ctrl)
    DrawCtrlMenuMark();
  else if (win == title)
    DrawTitle();
  else 
    taskBar->Exposure(win);
}

/*
 * Button1Press --
 *   Process the press of button1(mouse left button).
 */
void Qvwm::Button1Press(Window win, Time clickTime)
{
  int borderWidth = 0;

  if (win == ctrl) {
    /*
     * Double click.
     */
    if (IsDoubleClick(menuClickTime, clickTime, prevPt, pressPt)) {
      ExecFunction(Q_KILL);
    }
    else {
      if (CheckMenuMapped())
	umReserved = True;
      else {
	if (focusQvwm->CheckMenuMapped())
	  focusQvwm->UnmapMenu();
	if (startMenu != NULL && startMenu->CheckMapped())
	  startMenu->UnmapMenu();

	if (!CheckFocus()) {
	  SetFocus();
	  RaiseWindow(True);
	}

	if (CheckFlags(BORDER))
	  borderWidth = BORDER_WIDTH;
	ctrlMenu->MapMenu(rc.x-paging->origin.x+borderWidth,
			  rc.y-paging->origin.y+borderWidth+TITLE_HEIGHT);
      }
    }
    menuClickTime = clickTime;
  }
  else {
    if (focusQvwm->CheckMenuMapped())
      focusQvwm->UnmapMenu();
    if (startMenu != NULL && startMenu->CheckMapped())
      startMenu->UnmapMenu();
    
    SetFocus();
    RaiseWindow(True);

    /*
     * Title bar.
     */
    if (win == title) {
      /*
       * When double click.
       */
      if (IsDoubleClick(titleClickTime, clickTime, prevPt, pressPt)) {
	fButton[1]->SetState(Button::NORMAL);
	if (CheckStatus(MAXIMIZE_WINDOW)) {
	  /*
	   * Restore if maximun window.
	   */
	  fButton[1]->SetPixmap(FrameButton::pixButton[FrameButton::MAXIMIZE]);
	  RestoreWindow();
	}
	else {
	  /*
	   * Maximize if normal window.
	   */
	  fButton[1]->SetPixmap(FrameButton::pixButton[FrameButton::RESTORE]);
	  MaximizeWindow();
	}
      }
      titleClickTime = clickTime;

      if (!ClickToFocus)
	XRaiseWindow(display, frame);
    }
  }
}

/*
 * Button1Release --
 *   Process the release of button1(mouse left button).
 */
void Qvwm::Button1Release()
{
  /*
   * Unmap control menu if the menu is shown and menu button is pressed.
   */
  if (umReserved) {
    ctrlMenu->UnmapMenu();
    umReserved = False;
  }
}    

/*
 * Button3Release --
 *   Process the release of button3(mouse right button).
 */
void Qvwm::Button3Release(Window win, Point rootPt)
{
  Point pt;

  if (win == title || win == ctrl) {
    /*
     * Unmap all menus.
     */
    if (focusQvwm->CheckMenuMapped())
      focusQvwm->UnmapMenu();
    if (startMenu != NULL && startMenu->CheckMapped())
      startMenu->UnmapMenu();
    
    if (!CheckFocus()) {
      SetFocus();
      RaiseWindow(True);
    }

    pt = ctrlMenu->GetFixedMenuPos(rootPt);
    ctrlMenu->MapMenu(pt.x, pt.y);
  }
}

/*
 * Button1Motion --
 *   Move or resize according to mouse movement.
 */
void Qvwm::Button1Motion(Window win)
{
  if (win == title && !CheckStatus(MAXIMIZE_WINDOW))
    MoveWindow();
  else if (win == side[0])
    ResizeWindow(LEFT);
  else if (win == side[1])
    ResizeWindow(RIGHT);
  else if (win == side[2])
    ResizeWindow(TOP);
  else if (win == side[3])
    ResizeWindow(BOTTOM);
  else if (win == corner[0])
    ResizeWindow(LEFTTOP);
  else if (win == corner[1])
    ResizeWindow(RIGHTTOP);
  else if (win == corner[2])
    ResizeWindow(LEFTBOTTOM);
  else if (win == corner[3])
    ResizeWindow(RIGHTBOTTOM);
  else 
    taskBar->Button1Motion(win);
}

/*
 * LookInList -- 
 *   Return the pointer if the window exists in qvwm list;
 *   otherwise, return NULL.
 */
Qvwm* Qvwm::LookInList(Window w)
{
  Qvwm *tmpQvwm = rootQvwm;

  while ((tmpQvwm = tmpQvwm->next) != NULL)
    if (w == tmpQvwm->wOrig)
      break;

  return tmpQvwm;
}

/*
 * CaptureAllWindows --
 *   Decorate all windows.
 */
void Qvwm::CaptureAllWindows()
{
  Qvwm* qvWm;
  Window junkRoot, junkParent, *children;
  unsigned int nChildren;
  XEvent ev;

  if (!XQueryTree(display, root, &junkRoot, &junkParent, &children,
		  &nChildren))
    return;

  for (int i = 0; i < (int)nChildren; i++) {
    if (children[i] && MappedNotOverride(children[i])) {
      XUnmapWindow(display, children[i]);
      qvWm = new Qvwm(children[i], True);
      qvWm->MapWindows();
      qvWm->tButton->MapButton();
    }
  }

  /*
   * Process all event.
   */
  while (XPending(display) > 0) {
    XNextEvent(display, &ev);
    DispatchEvent(&ev);
  }

  ChangeFocusToCursor();

  if (nChildren)
    XFree(children);
}      

/*
 * FinishQvwm --
 *   Free all resources and finish qvwm.
 */
void Qvwm::FinishQvwm(Bool reStart)
{
  Qvwm *qvWm, *nextQvwm = rootQvwm->next;
  Icon *icon = Icon::firstIcon, *pIcon;

  XSync(display, 0);
  XSetErrorHandler(FinishErrorHandler);

  while ((qvWm = nextQvwm) != NULL) {
    if (qvWm->mapped)
      qvWm->UnmapWindows();
      
    XReparentWindow(display, qvWm->wOrig, root,
		    qvWm->rcOrig.x, qvWm->rcOrig.y);
    XSetWindowBorderWidth(display, qvWm->wOrig, qvWm->bwOrig);
    qvWm->SetStateProperty(NormalState);

    nextQvwm = qvWm->next;         // preserve ptr to next before destroy
    delete qvWm;
  }
  delete rootQvwm;

  delete taskBar;
  delete startMenu;
  delete taskSwitcher;
  delete paging;
  delete pager;

  while (icon != NULL) {
    pIcon = icon->GetNext();
    delete icon;
    icon = pIcon;
  }

  if (!reStart) {
    XSetInputFocus(display, PointerRoot,  RevertToPointerRoot, CurrentTime);
    XUndefineCursor(display, root);

    XCloseDisplay(display);
    exit(0);
  }
}

/*
 * FinishErrorHandler --
 *   Jump to here when error happens in FinishQvwm. This error is ignored.
 */
int FinishErrorHandler(Display* display, XErrorEvent* ev)
{
  return 0;
}
