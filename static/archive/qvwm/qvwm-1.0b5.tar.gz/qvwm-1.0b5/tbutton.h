#ifndef _TBUTTON_H_
#define _TBUTTON_H_

#include "button.h"

class Qvwm;

/*
 * TaskbarButton
 */
class TaskbarButton : public Button {
private:
  Pixmap pix;                      // pixmap of the left side
  GC gc;                           // GC for pixmap
  char* shortname;                 // short title fitted to button size
  Bool focus;
  Qvwm* qvWm;                      // ptr to corresponding qvwm

protected:
  char* name;                      // taskbar button title

public:
  static Rect TButtonRc;           // the size of taskbar button at that time
  static XFontSet* fsb;            // ref to bold font set

  static const int BETWEEN_SPACE = 3;    // space between tbuttons
  static const int SIMBOL_WIDTH = 16;    // pixmap size
  static const int SIMBOL_HEIGHT = 16;
  static const int BUTTON_HEIGHT = 22;   // tbutton height

private:
  virtual void FillBackground();
  virtual void DrawName();

public:
  TaskbarButton(Qvwm* qvWm, Rect rc, Pixmap pix, GC gc, char *name);
  ~TaskbarButton();

  void SetName(char* str) { name = str; }
  Bool CheckFocus() const { return focus; }
  void SetFocus() { focus = True; }
  void ResetFocus() { focus = False; }
  Pixmap GetPixmap() const { return pix; }
  void SetPixmap(Pixmap p) { pix = p; }
  GC GetGC() const { return gc; }
  void SetGC(GC g) { gc = g; }

  virtual void DrawButton();
  virtual void MapButton();
  virtual void UnmapButton();
  virtual void ExecButtonFunc(ButtonState bs);
  virtual void Button1Press();
  virtual void Button3Release();

  static void RedrawAllTaskbarButtons();
};

#endif // _TBUTTON_H_
