#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <sys/time.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/cursorfont.h>
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "qvwmrc.h"
#include "paging.h"
#include "pager.h"

Paging::Paging(unsigned int beltSize, Point topLeft, Dim size)
: origin(Point(0, 0)), rcVirt(topLeft.x, topLeft.y, size.width, size.height)
{
  XSetWindowAttributes attributes;
  unsigned long valueMask;
  Cursor cs;
  Rect rcRoot = rootQvwm->GetRect();
  unsigned int fontCursor[4] = {XC_bottom_side, XC_top_side, 
				XC_left_side, XC_right_side};
  Rect rcPaging[4] = {Rect(0, rcRoot.height-beltSize, rcRoot.width, beltSize),
                      Rect(0, 0, rcRoot.width, beltSize),
		      Rect(0, 0, beltSize, rcRoot.height),
		      Rect(rcRoot.width-beltSize, 0, beltSize, rcRoot.height)};

  /*
   * Create transparent, long and slender windows in the 4 edges of screen
   * for paging.
   */
  attributes.override_redirect = True;
  attributes.event_mask = EnterWindowMask | LeaveWindowMask;
  valueMask = CWEventMask | CWOverrideRedirect;

  for (int i = 0; i < 4; i++) {
    side[i] = XCreateWindow(display, root,
			    rcPaging[i].x, rcPaging[i].y,
			    rcPaging[i].width, rcPaging[i].height,
			    0, CopyFromParent, InputOnly, CopyFromParent,
			    valueMask, &attributes);

    cs = XCreateFontCursor(display, fontCursor[i]);
    XDefineCursor(display, side[i], cs);
  }

  MapSides();
}

Paging::~Paging()
{
  for (int i = 0; i < 4; i++)
    XDestroyWindow(display, side[i]);
}

/*
 * IsPagingBelt --
 *   Return True if the window is one of transparent windows for paging.
 */
Bool Paging::IsPagingBelt(Window win)
{
  if (win == side[0] || win == side[1] || win == side[2] || win == side[3])
    return True;
  else
    return False;
}

/*
 * HandlePaging --
 *   Do paging if the cursor is in screen edge and if paging resistance
 *   time was expired.
 */
void Paging::HandlePaging(Point pt)
{      
  /*
   * Return unless in the area where paging can be done.
   */
  Rect rcRoot = rootQvwm->GetRect();
  Rect rect(PagingBeltSize,
	    PagingBeltSize,
	    rcRoot.width - PagingBeltSize * 2,
	    rcRoot.height - PagingBeltSize * 2);

  if (InRect(pt, rect))
    return;

  /*
   * Agter wait for PagingResistance ms without any events, do paging.
   */
  XEvent ev;
/*
  int fd = ConnectionNumber(display);
  fd_set fds;
  timeval tm;

  FD_ZERO(&fds);
  FD_SET(fd, &fds);

  tm.tv_sec = PagingResistance / 1000;
  tm.tv_usec = (PagingResistance * 1000) % 1000000;

  while (True) {
    if (select(fd+1, &fds, 0, 0, &tm) == 0) {
      PagingProc(side[GetDisplayArea(pt)]);
      break;
    }
    else {
      if (XCheckTypedEvent(display, LeaveNotify, &ev) ||
	  XCheckTypedEvent(display, EnterNotify, &ev))
	break;
    }
  }
*/
  int ticks = 0;

  while (ticks < PagingResistance) {
    ticks += 10;
    usleep(10);

    if (XCheckMaskEvent(display, LeaveWindowMask | EnterWindowMask, &ev))
      return;
  }
  PagingProc(side[GetDisplayArea(pt)]);
}

/*
 * PagingProc --
 *   Do paging to the direction of win.
 */
void Paging::PagingProc(Window win)
{
  int dx = 0, dy = 0;
  Rect rcRoot = rootQvwm->GetRect();
  Window junkRoot, junkChild;
  Point rootPt, junkPt;
  unsigned int mask;

  if (win == side[2])
    dx = -(PagingMovement * rcRoot.width / 100);
  else if (win == side[3])
    dx = PagingMovement * rcRoot.width / 100;
  else if (win == side[1])
    dy = -(PagingMovement * rcRoot.height / 100);
  else if (win == side[0])
    dy = PagingMovement * rcRoot.height / 100;

  origin.x += dx;
  origin.y += dy;

  PagingAllWindows();

  XQueryPointer(display, root, &junkRoot, &junkChild, &rootPt.x, &rootPt.y,
		&junkPt.x, &junkPt.y, &mask);
  Point pt(rootPt.x-dx, rootPt.y-dy);

  if (pt.x < PagingBeltSize)
    pt.x = PagingBeltSize;
  else if (pt.x > (int)rcRoot.width-PagingBeltSize-1)
    pt.x = (int)rcRoot.width - PagingBeltSize - 1;
  if (pt.y < PagingBeltSize)
    pt.y = PagingBeltSize;
  else if (pt.y > (int)rcRoot.height-PagingBeltSize-1)
    pt.y = (int)rcRoot.height - PagingBeltSize - 1;

  XWarpPointer(display, None, root, 0, 0, 0, 0, pt.x, pt.y);
}

/*
 * PagingProc --
 *   Do paging to the position of pt.
 */
void Paging::PagingProc(Point pt)
{
  origin = pt;
  PagingAllWindows();
}

/*
 * PagingAllWindows --
 *   Move all windows according to paging movement.
 */
void Paging::PagingAllWindows()
{
  Qvwm* qvWm = rootQvwm; 
  Rect rect;

  MapSides();

  while ((qvWm = qvWm->GetNext()) != NULL) {
    if (qvWm->CheckFlags(STICKY))
      continue;
    rect = qvWm->GetRect();
    XMoveWindow(display, qvWm->GetFrameWin(),
		rect.x-origin.x, rect.y-origin.y);
    qvWm->SendConfigureEvent();
  }

  if (UsePager)
    pager->DrawVisualPage();
}

void Paging::MapSides()
{
  Rect rcRoot = rootQvwm->GetRect();

  // Left side
  if (origin.x > rcVirt.x*(int)rcRoot.width)
    XMapWindow(display, side[2]);
  else {
    origin.x = rcVirt.x * (int)rcRoot.width;
    XUnmapWindow(display, side[2]);
  }

  // Right side
  if (origin.x < (rcVirt.x+(int)rcVirt.width-1)*(int)rcRoot.width)
    XMapWindow(display, side[3]);
  else {
    origin.x = (rcVirt.x + rcVirt.width - 1) * (int)rcRoot.width;
    XUnmapWindow(display, side[3]);
  }

  // Bottom side
  if (origin.y > rcVirt.y*(int)rcRoot.height)
    XMapWindow(display, side[1]);
  else {
    origin.y = rcVirt.y * (int)rcRoot.height;
    XUnmapWindow(display, side[1]);
  }

  // Top side
  if (origin.y < (rcVirt.y+(int)rcVirt.height-1)*(int)rcRoot.height)
    XMapWindow(display, side[0]);
  else {
    origin.y = (rcVirt.y + rcVirt.height - 1) * (int)rcRoot.height;
    XUnmapWindow(display, side[0]);
  }
}

/*
 * RaisePagingBelt --
 *   Raise transparent windows for paging.
 */
void Paging::RaisePagingBelt()
{
  for (int i = 0; i < 4; i++)
    XRaiseWindow(display, side[i]);
}
