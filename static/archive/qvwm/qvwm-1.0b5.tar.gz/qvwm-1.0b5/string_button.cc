#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "main.h"
#include "resource.h"
#include "string_button.h"

StringButton::StringButton(Window parent, Rect rc, char* str, XFontSet& fs,
			   ResourceId rid)
: Button(parent, rc), str(str), fs(fs), rid(rid)
{
  triggered = False;
}

/*
 * DrawButton --
 *   Draw button according to state.
 */
void StringButton::DrawButton()
{
  Point pt;
  XRectangle ink, log;

  XmbTextExtents(fs, str, strlen(str), &ink, &log);
  pt.x = (rc.width-log.width)/2 - log.x;
  pt.y = (rc.height-log.height)/2 - log.y;

  if (state == PUSH) {
    XSetForeground(display, ::gc, black);
    XSetBackground(display, ::gc, gray);
    XmbDrawImageString(display, frame, fs, ::gc, pt.x, pt.y+1, str,
		       strlen(str));
  }
  else {
    XSetForeground(display, ::gc, black);
    XSetBackground(display, ::gc, gray);
    XmbDrawImageString(display, frame, fs, ::gc, pt.x, pt.y, str,
		       strlen(str));
  }

  Button::DrawButton();
}

/*
 * ExecButtonFunc --
 *   Execute button function.
 */
void StringButton::ExecButtonFunc(ButtonState bs)
{
  if (bs == PUSH)
    triggered = True;
  else
    triggered = False;
}
