#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <signal.h>
#include <sys/wait.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xlocale.h>
#include <X11/Xresource.h>
#include <X11/Xproto.h>
#include <X11/xpm.h>
#ifdef DEBUG
#include <X11/Xmu/Error.h>
#endif
#include "misc.h"
#include "qvwm.h"
#include "fbutton.h"
#include "tbutton.h"
#include "taskbar.h"
#include "menu.h"
#include "util.h"
#include "startmenu.h"
#include "events.h"
#include "parse.h"
#include "icon.h"
#include "main.h"
#include "qvwmrc.h"
#include "switch.h"
#include "radio_button.h"
#include "paging.h"
#include "pager.h"
#include "ver.h"
#include "bitmaps/logo.xpm"
#include "bitmaps/logo2.xpm"
#include "bitmaps/tile0.xpm"
#include "bitmaps/tile1.xbm"
#include "bitmaps/curbm0.xbm"
#include "bitmaps/curbm1.xbm"
#include "bitmaps/curbm2.xbm"
#include "bitmaps/curbm3.xbm"
#include "bitmaps/curbm4.xbm"
#include "bitmaps/curbm5.xbm"
#include "bitmaps/maskbm0.xbm"
#include "bitmaps/maskbm1.xbm"
#include "bitmaps/maskbm2.xbm"
#include "bitmaps/maskbm3.xbm"
#include "bitmaps/maskbm4.xbm"
#include "bitmaps/maskbm5.xbm"

static char* displayName = NULL;     /* Display name */
static char* rcFileName = NULL;      /* Rc file name */
Display* display;                    /* Display structure */
int screen;                          /* Default screen */
unsigned int depth;                  /* Default depth */
Colormap colormap;                   /* Default colormap */
Window root;                         /* Root window */
Qvwm* rootQvwm;                      /* Virtual qvwm for root window */
Rect rcScreen;                       /* Screen size (not include taskbar) */
GC gc, gcXor, gcLogo, gcLargeLogo, gcTile, gcTileMask, gcDash;
Pixmap pixLogo, pixLargeLogo;        /* Pixmaps for logo */
Cursor cursor[6];
XFontSet fsTitle, fsTaskbar, fsBoldTaskbar, fsIcon;
XFontSet fsCtrlMenu, fsCascadeMenu, fsStartMenu;
unsigned long gray, darkGray, blue, green, black, white;

/*
 * Internal atoms.
 */
Atom _XA_WM_CHANGE_STATE;
Atom _XA_WM_STATE;
Atom _XA_WM_COLORMAP_WINDOWS;
Atom _XA_WM_PROTOCOLS;
Atom _XA_WM_TAKE_FOCUS;
Atom _XA_WM_DELETE_WINDOW;
Atom _XA_WM_DESKTOP;
Atom _XA_WM_ICON_SIZE;

Taskbar* taskBar;
StartMenu* startMenu;
TaskSwitcher* taskSwitcher = NULL;
Paging* paging;
Pager* pager;

/*
 * Local function prototype declaration.
 */
void AnalizeOptions(int argc, char** argv);
void SetGC();
void SetColor();
unsigned long CreatePixel(unsigned short red, unsigned short green,
			  unsigned short blue);
void CreateTilePattern();
void CreateLogoMarkPixmap();
void CreateCursor();
void CreateInternAtom();
void SetWallPaper();
int CatchRedirectError(Display* display, XErrorEvent *ev);
int CatchFatalError(Display *display);
int QvwmErrorHandler(Display* display, XErrorEvent* ev);
void TrapSignal(int sig);
void TrapChild(int sig);
void TrapAlarm(int sig);

int main(int argc, char** argv)
{
  AnalizeOptions(argc, argv);

  /*
   * Open the display.
   */
  if ((display = XOpenDisplay(displayName)) == NULL) {
    QvwmError("Can't open display %s", XDisplayName(displayName));
    exit(1);
  }

  /*
   * Set system defaults.
   */
  screen = DefaultScreen(display);
  root = RootWindow(display, screen);
  depth = DefaultDepth(display, screen);
  colormap = DefaultColormap(display, screen);
  rcScreen = Rect(0,
		  0,
		  DisplayWidth(display, screen),
		  DisplayHeight(display, screen));

  /*
   * Select inputs for window manager.
   */
  XSetErrorHandler(CatchRedirectError);
  XSetIOErrorHandler((XIOErrorHandler)CatchFatalError);
  XSelectInput(display, root, LeaveWindowMask | EnterWindowMask |
	       PropertyChangeMask | SubstructureRedirectMask | KeyPressMask |
	       ButtonPressMask | ButtonReleaseMask);
  XSync(display, 0);
  XSetErrorHandler(NULL);
  
  /*
   * Set signal handlers.
   */
  signal(SIGHUP, TrapSignal);
  signal(SIGINT, TrapSignal);
  signal(SIGQUIT, TrapSignal);
  signal(SIGTERM, TrapSignal);
  signal(SIGSEGV, TrapSignal);
  signal(SIGBUS, TrapSignal);
  signal(SIGFPE, TrapSignal);
  signal(SIGCHLD, TrapChild);
  signal(SIGALRM, TrapAlarm);

  /*
   * Set resources for qvwm.
   */
  SetColor();
  SetGC();
  CreateTilePattern();
  CreateCursor();
  StartMenu::CreateStartMenuPixmap();
  FrameButton::CreateFrameButtonPixmap();
  Menu::CreateMenuPixmap();
  Icon::CreateIconPixmap();
  RadioButton::CreateRadioButtonPixmap();
  CreateLogoMarkPixmap();
  CreateInternAtom();
  
  /*
   * Set contexts.
   */
  Qvwm::context = XUniqueContext();
  Button::context = XUniqueContext();
  Menu::context = XUniqueContext();
  Icon::context = XUniqueContext();
  RadioButton::context = XUniqueContext();
  
  InitState();
  ParseQvwmrc(rcFileName);

  if (XSupportsLocale() == False)
    QvwmError("X does not support the locale");

  InitQvwm();
  MainLoop();
}

/*
 * AnalizeOptions --
 *   Analize command line options.
 */
void AnalizeOptions(int argc, char** argv)
{
  for (int i = 1; i < argc; i++) {
    if (strcmp(argv[i], "-v") == 0) {
      printf("qvwm ver %s\n", Version);
      printf("Copyright (C) 1995-1996 Kourai.\n");
      exit(0);
    }
    else if (strcmp(argv[i], "-display") == 0) {
      i++;
      displayName = argv[i++];
    }
    else if (strcmp(argv[i], "-f") == 0) {
      i++;
      rcFileName = argv[i++];
    }
    else {
      printf("usage: qvwm [-v] [-display display_name] [-f rcfile_name]\n");
      exit(0);
    }
  }
}

/*
 * Initialize qvwm states. (once at start)
 */
void InitState()
{
  Icon::firstIcon = NULL;
  Icon::lastIcon = NULL;
  Icon::focusIcon = NULL;

  startMenu = NULL;
  taskSwitcher = NULL;

  Menu::fDir = Menu::RIGHT;
}

/*
 * Initialize qvwm. (every time restart)
 */
void InitQvwm()
{
  XSetErrorHandler(QvwmErrorHandler);

  TaskbarButton::fsb = UseBoldFont ? &fsBoldTaskbar : &fsTaskbar;

  rootQvwm = new Qvwm(root);
  Qvwm::lastQvwm = rootQvwm;
  Qvwm::focusQvwm = rootQvwm;

  SetWallPaper();

  paging = new Paging(PagingBeltSize, TopLeftPage, PagingSize);
  if (UsePager)
    pager = new Pager(PagerGeometry);

  taskBar->MoveTaskbar(TaskbarPosition);

  Qvwm::CaptureAllWindows();
  Icon::RedrawAllIcons();
  taskBar->MapTaskbar();
}

/*
 * SetColor --
 *   Allocate mininum colors for qvwm.
 */
void SetColor()
{
  black = CreatePixel(0x0000, 0x0000, 0x0000);
  white = CreatePixel(0xffff, 0xffff, 0xffff);
  gray = CreatePixel(0xc0c0, 0xc0c0, 0xc0c0);
  darkGray = CreatePixel(0x8080, 0x8080, 0x8080);
  blue = CreatePixel(0x0000, 0x0000, 0x8080);
  green = CreatePixel(0x0000, 0x8080, 0x8080);
}

/*
 * CreatePixel --
 *   Allocate color from red, green and blue, and get the pixel value.
 */
unsigned long CreatePixel(unsigned short red, unsigned short green,
			  unsigned short blue)
{
  XColor color;

  color.red = red;
  color.green = green;
  color.blue = blue;

  XAllocColor(display, colormap, &color);

  return color.pixel;
}

/*
 * SetGC --
 *   Set GC for normal, xor and dash.
 */
void SetGC()
{
  XGCValues gcv;
  unsigned long gcm;
  char dash[] = {1, 1};
  
  gc = XCreateGC(display, root, 0, 0);

  gcv.function = GXxor;
  gcv.line_width = 4;
  gcv.foreground = darkGray;
  gcv.subwindow_mode = IncludeInferiors;
  gcm = GCFunction | GCLineWidth | GCForeground | GCSubwindowMode;
  gcXor = XCreateGC(display, root, gcm, &gcv);

  gcDash = XCreateGC(display, root, 0, 0);
  XSetDashes(display, gcDash, 0, dash, 2);
  XSetLineAttributes(display, gcDash, 1, LineOnOffDash, CapButt, JoinMiter);
}

/*
 * CreateTilePattern --
 *   Create GC and Mask for tile pattern.
 */
void CreateTilePattern()
{
  XpmAttributes attr;
  Pixmap tile;
  Pixmap mask;
  XGCValues gcv;

  attr.valuemask = XpmColormap | XpmDepth;
  attr.colormap = colormap;
  attr.depth = depth;

  /*
   * Make tile pattern of while & gray.
   */
  XpmCreatePixmapFromData(display, root, tile0, &tile, &mask, &attr);
  gcv.fill_style = FillTiled;
  gcv.tile = tile;
  gcTile = XCreateGC(display, root, GCFillStyle | GCTile, &gcv);

  /* 
   * Make clip mask for tile pattern.
   */
  tile = XCreateBitmapFromData(display, root, tile1_bits, tile1_width,
			       tile1_height);
  gcTileMask = XCreateGC(display, root, 0, 0);
  XSetClipMask(display, gcTileMask, tile);
  XSetClipOrigin(display, gcTileMask, 21, 2);
  XSetForeground(display, gcTileMask, blue);
}

/*
 * CreateCursor --
 *   Create cursors.
 */
void CreateCursor()
{
  Pixmap curPix[6], maskPix[6];
  Point spot[6] = {Point(10, 6), Point(15, 15), Point(14, 15),
		   Point(14, 15), Point(14, 14), Point(15, 15)};
  XColor black, white, dummyColor;
  int i;

  curPix[0] = XCreateBitmapFromData(display, root, curbm0_bits,
				    curbm0_width, curbm0_height);
  maskPix[0] = XCreateBitmapFromData(display, root, maskbm0_bits,
				     maskbm0_width, maskbm0_height);
  curPix[1] = XCreateBitmapFromData(display, root, curbm1_bits,
				    curbm1_width, curbm1_height);
  maskPix[1] = XCreateBitmapFromData(display, root, maskbm1_bits,
				     maskbm1_width, maskbm1_height);
  curPix[2] = XCreateBitmapFromData(display, root, curbm2_bits,
				    curbm2_width, curbm2_height);
  maskPix[2] = XCreateBitmapFromData(display, root, maskbm2_bits,
				     maskbm2_width, maskbm2_height);
  curPix[3] = XCreateBitmapFromData(display, root, curbm3_bits,
				    curbm3_width, curbm3_height);
  maskPix[3] = XCreateBitmapFromData(display, root, maskbm3_bits,
				     maskbm3_width, maskbm3_height);
  curPix[4] = XCreateBitmapFromData(display, root, curbm4_bits,
				    curbm4_width, curbm4_height);
  maskPix[4] = XCreateBitmapFromData(display, root, maskbm4_bits,
				     maskbm4_width, maskbm4_height);
  curPix[5] = XCreateBitmapFromData(display, root, curbm5_bits,
				    curbm5_width, curbm5_height);
  maskPix[5] = XCreateBitmapFromData(display, root, maskbm5_bits,
				     maskbm5_width, maskbm5_height);

  XAllocNamedColor(display, colormap, "black", &black, &dummyColor);
  XAllocNamedColor(display, colormap, "white", &white, &dummyColor);

  for (i = 0; i < 6; i++)
    cursor[i] = XCreatePixmapCursor(display, curPix[i], maskPix[i],
				    &black, &white, spot[i].x, spot[i].y);

  XDefineCursor(display, root, cursor[SYS]);
}

/*
 * CreateInternAtom --
 *   Create internal atoms of window manager.
 */
void CreateInternAtom()
{
  _XA_WM_CHANGE_STATE = XInternAtom(display, "WM_CHANGE_STATE", False);
  _XA_WM_STATE = XInternAtom(display, "WM_STATE", False);
  _XA_WM_COLORMAP_WINDOWS = XInternAtom(display, "WM_COLORMAP_WINDOWS", False);
  _XA_WM_PROTOCOLS = XInternAtom(display, "WM_PROTOCOLS", False);
  _XA_WM_TAKE_FOCUS = XInternAtom(display, "WM_TAKE_FOCUS", False);
  _XA_WM_DELETE_WINDOW = XInternAtom(display, "WM_DELETE_WINDOW", False);
  _XA_WM_DESKTOP = XInternAtom(display, "WM_DESKTOP", False);
  _XA_WM_ICON_SIZE = XInternAtom(display, "WM_ICON_SIZE", False);
}

/*
 * CreateLogoMarkPixmap --
 *   Create pixmaps for logo mark.
 */
void CreateLogoMarkPixmap()
{
  XpmAttributes attr;
  Pixmap mask;
  XGCValues gcv;

  attr.valuemask = XpmColormap | XpmDepth;
  attr.colormap = colormap;
  attr.depth = depth;

  XpmCreatePixmapFromData(display, root, logo, &pixLogo, &mask, &attr);
  gcv.clip_mask = mask;
  gcLogo = XCreateGC(display, root, GCClipMask, &gcv);

  XpmCreatePixmapFromData(display, root, logo2, &pixLargeLogo, &mask, &attr);
  gcv.clip_mask = mask;
  gcLargeLogo = XCreateGC(display, root, GCClipMask, &gcv);
}  

/*
 * SetWallPaper --
 *   Read wall paper(pixmap only), and make it be background of root window.
 */
void SetWallPaper()
{
  XpmAttributes attr;
  Pixmap pix;

  attr.valuemask = XpmColormap | XpmDepth;
  attr.colormap = colormap;
  attr.depth = depth;
  
  if (strcmp(WallPaper, "Windows95") == 0) {
    XSetWindowBackground(display, root, green);
    XClearWindow(display, root);
  }
  else if (strcmp(WallPaper, "") != 0) {
    if (XpmReadFileToPixmap(display, root, WallPaper, &pix, NULL, &attr)
	                                                        != XpmSuccess)
      QvwmError("Can't read pixmap file '%s'", WallPaper);
    else {
      XSetWindowBackgroundPixmap(display, root, pix);
      XClearWindow(display, root);
      XFreePixmap(display, pix);
    }
  }
}

/*
 * CatchRedirectError --
 *   Jump here when another window manager is running.
 */
int CatchRedirectError(Display* display, XErrorEvent *ev)
{
  QvwmError("Another window manager is running");
  exit(1);
}

/*
 * CatchFatalError --
 *   Jump here when an fatal I/O error happens in X server.
 */
int CatchFatalError(Display *display)
{
  QvwmError("Fatal I/O error");

  Qvwm::FinishQvwm(False);
}

/*
 * QvwmErrorHandler --
 *   Jump here when an error happens in X server.
 */
int QvwmErrorHandler(Display *display, XErrorEvent* ev)
{
  if (ev->error_code == BadWindow ||
      ev->error_code == BadDrawable || 
      ev->request_code == X_GetGeometry ||
      ev->request_code == X_GrabButton ||
      ev->request_code == X_SetInputFocus ||
      ev->request_code == X_ChangeWindowAttributes ||
      ev->request_code == X_InstallColormap) {
#ifdef DEBUG
    QvwmError("Ignore error");
    XmuPrintDefaultErrorMessage (display, ev, stderr);
#endif
    return 0;
  }

  QvwmError("Internal error");
  QvwmError(" resource id: %d", ev->resourceid);
  QvwmError(" error code: %d", ev->error_code);
  QvwmError(" request code: %d", ev->request_code);
  QvwmError(" minor code: %d", ev->minor_code);

  return 0;
}

/*
 * TrapSignal --
 *   General signal handler.
 */
void TrapSignal(int sig)
{
  switch (sig) {
  case SIGSEGV:
    QvwmError("Segmentation fault\n");
    break;

  case SIGBUS:
    QvwmError("Bus error\n");
    break;
  }

  Qvwm::FinishQvwm(False);
}

/*
 * TrapChild --
 *   Signal handler for child termination.
 */
void TrapChild(int sig)
{
  wait(NULL);
}

/*
 * TrapAlerm --
 *   Signal handler for timer. This is used for auto raise.
 */
void TrapAlarm(int sig)
{
  if (Qvwm::focusQvwm->CheckMapped() && !Qvwm::focusQvwm->CheckMenuMapped())
    Qvwm::focusQvwm->RaiseWindow(True);

  signal(SIGALRM, TrapAlarm);
}

/*
 * QvwmError --
 *   Display an error in qvwm.
 */
void QvwmError(const char* fmt, ...)
{
  va_list args;
  char buf[256];
  
  va_start(args, fmt);
  
  sprintf(buf, "qvwm: %s\n", fmt);
  vfprintf(stderr, buf, args);

  va_end(args);
}
