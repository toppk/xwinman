#include <X11/Xlib.h>
#include <X11/xpm.h>
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "events.h"
#include "system_dialog.h"
#include "exitdlg.h"
#include "bitmaps/exit2.xpm"

/*
 * ExitDlg --
 *   Process exit dialog.
 */
void ExitDlg(Qvwm* qvWm)
{
  XpmAttributes attr;
  XGCValues gcv;
  Pixmap pixExit, mask;
  GC gcExit;
  SystemDialog* dlg;
  ResourceId id;
  Rect rcRoot = rootQvwm->GetRect();
  Rect rect((rcRoot.width-ExitDlgWidth)/2, (rcRoot.height-ExitDlgHeight)/2,
	    ExitDlgWidth, ExitDlgHeight);

  /*
   * Create pixmap and gc for the exit dialog.
   */
  attr.valuemask = XpmColormap | XpmDepth;
  attr.colormap = colormap;
  attr.depth = depth;

  XpmCreatePixmapFromData(display, root, exit2, &pixExit, &mask, &attr);
  gcv.clip_mask = mask;
  gcExit = XCreateGC(display, root, GCClipMask, &gcv);

  /*
   * Resource for exit dialog.
   */
  DialogRes dr[] =
    {{STATICTEXT, NO_ID, Rect(70, 12, -1, -1),
      "Can I exit in each next ways?", fsTitle},
     {RADIOBUTTON, IDR_EXIT_SAVE, Rect(75, 42, -1, -1),
      "Exit qvwm with saving changes.", fsTitle},
     {RADIOBUTTON, IDR_EXIT_NOSAVE, Rect(75, 63, -1, -1),
      "Exit qvwm without saving changes.", fsTitle},
     {RADIOBUTTON, IDR_RESTART, Rect(75, 84, -1, -1),
      "Restart qvwm.", fsTitle},
     {RADIOBUTTON, IDR_ANOTHER, Rect(75, 105, -1, -1),
      "Start another window manager.", fsTitle},
     {RADIOSET, IDS_1, Rect(-1, -1, -1, -1), "", fsTitle, IDR_EXIT_SAVE},
     {ICONPIXMAP, NO_ID, Rect(21, 17, 32, 32), "", fsTitle, NO_ID,
      pixExit, gcExit},
     {STRINGBUTTON, ID_OK, Rect(84, 148, 88, 23), "Yes", fsTitle},
     {STRINGBUTTON, ID_CANCEL, Rect(179, 148, 88, 23), "No", fsTitle},
     {STRINGBUTTON, IDB_HELP, Rect(274, 148, 88, 23), "Help", fsTitle}};

  dlg = new SystemDialog(rect, "Exit qvwm", dr, 10);
  dlg->MapDialog();
  
  XGrabPointer(display, dlg->GetFrameWin(), True,
	       ButtonPressMask | ButtonReleaseMask, GrabModeAsync,
	       GrabModeAsync, None, None, CurrentTime);

  do {
    id = dlg->EventLoop();
  } while (!(id == ID_OK || id == ID_CANCEL));

  switch (id) {
  case ID_OK:
    switch (dlg->GetSelectedRB(IDS_1)) {
    case IDR_EXIT_SAVE:
    case IDR_EXIT_NOSAVE:
      delete dlg;
      Qvwm::FinishQvwm(False);
      break;

    case IDR_RESTART:
      delete dlg;
      XFreePixmap(display, pixExit);
      XFreeGC(display, gcExit);
      qvWm->ExecFunction(Q_RESTART);
      break;

    case IDR_ANOTHER:
      QvwmError("Not start another window manager for now");
      delete dlg;
      XFreePixmap(display, pixExit);
      XFreeGC(display, gcExit);
      break;
    }
    break;

  case ID_CANCEL:
    delete dlg;
    XFreePixmap(display, pixExit);
    XFreeGC(display, gcExit);
    break;
  }
}
