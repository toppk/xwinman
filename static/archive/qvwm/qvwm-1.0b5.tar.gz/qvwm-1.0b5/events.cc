#include <stdio.h>
#include <time.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/types.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "events.h"
#include "taskbar.h"
#include "fbutton.h"
#include "tbutton.h"
#include "sbutton.h"
#include "startmenu.h"
#include "menu.h"
#include "util.h"
#include "icon.h"
#include "qvwmrc.h"
#include "paging.h"
#include "pager.h"

Qvwm* Qvwm::focusQvwm;
Point pressPt(-100, -100), prevPt;

void EnterNotifyProc(Window w, Point ptRoot);
void LeaveNotifyProc(Window w, Point ptRoot);
void ClientMessageProc(Window w, Atom mesType, long state);
void PropertyNotifyProc(Window w, Atom atom);
extern void ColormapNotifyProc(Window w, Bool newCmap, XColormapEvent* ev);
void ConfigureRequestProc(Window w, XConfigureRequestEvent* cre);
void DestroyNotifyProc(Window w);
void UnmapNotifyProc(Window w);
void MapNotifyProc(Window w);
void MapRequestProc(Window w);
void ButtonPressProc(Window w, unsigned int buttonNum, Time clickTime);
void ButtonReleaseProc(Window w, unsigned int state, Point ptRoot);
void MotionNotifyProc(Window w);
void KeyPressProc(Window w, XKeyEvent* ev);

/*
 * MailLoop --
 *   Wait event and timeout.
 */
void MainLoop()
{  
  XEvent ev;
  int fd = ConnectionNumber(display);
  fd_set fds;
  timeval tm;
  time_t ctm, btm;

  time(&btm);
  btm = btm / 60 * 60;         // adjust by min unit

  while (1) {
    FD_ZERO(&fds);
    FD_SET(fd, &fds);

    while (XPending(display) != 0) {
      XNextEvent(display, &ev);
      DispatchEvent(&ev);
    }

    tm.tv_sec = MenuDelayTime / 1000;
    tm.tv_usec = (MenuDelayTime * 1000) % 1000000;
    if (select(fd+1, &fds, 0, 0, &tm) == 0) {    // timeout
      time(&ctm);
      if (ctm-btm >= 60) {
	btm = ctm / 60 * 60;           // adjust by min unit
	taskBar->DrawClock();
      }

      /*
       * Extract the pointed folder after a while.
       */
      if (Menu::delayMenu != NULL) {
	Menu::delayMenu->ExecFunction(Q_DIR, Menu::delayMenuNum);
	Menu::delayMenu = NULL;
      }
    }
  }
}

/*
 * DispatchEvent --
 *   Call the event procedure according to a event type.
 */
void DispatchEvent(XEvent* ev)
{
  Point ptRoot;
  
  switch (ev->type) {
  case EnterNotify:
    ptRoot = Point(ev->xcrossing.x_root, ev->xcrossing.y_root);
    EnterNotifyProc(ev->xcrossing.window, ptRoot);
    break;

  case LeaveNotify:
    ptRoot = Point(ev->xcrossing.x_root, ev->xcrossing.y_root);
    LeaveNotifyProc(ev->xcrossing.window, ptRoot);
    break;

  case PropertyNotify:
    PropertyNotifyProc(ev->xproperty.window, ev->xproperty.atom);
    break;

  case ClientMessage:
    ClientMessageProc(ev->xclient.window, ev->xclient.message_type,
		       ev->xclient.data.l[0]);
    break;

  case ConfigureRequest:
    ConfigureRequestProc(ev->xconfigure.window, &ev->xconfigurerequest);
    break;

  case ColormapNotify:
    ColormapNotifyProc(ev->xcolormap.window, ev->xcolormap.c_new,
		       (XColormapEvent *)ev);
    break;

  case Expose:
    ExposeProc(ev->xexpose.window);
    break;

  case DestroyNotify:
    DestroyNotifyProc(ev->xdestroywindow.window);
    break;

  case UnmapNotify:
    UnmapNotifyProc(ev->xunmap.window);
    break;

  case MapNotify:
    MapNotifyProc(ev->xmap.window);
    break;

  case MapRequest:
    MapRequestProc(ev->xmaprequest.window);
    break;

  case ButtonPress:
    prevPt = pressPt;
    pressPt = Point(ev->xbutton.x_root, ev->xbutton.y_root);
    ButtonPressProc(ev->xbutton.window, ev->xbutton.button, ev->xbutton.time);
    break;

  case ButtonRelease:
    ptRoot = Point(ev->xbutton.x_root, ev->xbutton.y_root);
    ButtonReleaseProc(ev->xbutton.window, ev->xbutton.state, ptRoot);
    break;

  case MotionNotify:
    MotionNotifyProc(ev->xbutton.window);
    break;

  case KeyPress:
    KeyPressProc(ev->xkey.window, (XKeyEvent*)ev);
    break;
  }
}

/*
 * EnterNotifyProc --
 *   Process EnterNotify event.
 */
void EnterNotifyProc(Window w, Point ptRoot)
{
  XEvent ev;
  Menu* menu;
  Qvwm* qvWm;

  /*
   * Check if there is LeaveNotify event for the window and if so, return.
   */
  if(XCheckTypedWindowEvent(display, w, LeaveNotify, &ev)) {
    if(ev.xcrossing.mode == NotifyNormal &&
       ev.xcrossing.detail != NotifyInferior)
      return;
  }

  if (XFindContext(display, w, Menu::context, (caddr_t*)&menu) == XCSUCCESS)
    menu->Enter(w);
  else if (XFindContext(display, w, Qvwm::context, (caddr_t*)&qvWm)
	                                                       == XCSUCCESS) {
    if (!ClickToFocus)
      if (!Qvwm::focusQvwm->CheckMenuMapped() &&
	  !(startMenu != NULL && startMenu->CheckMapped())) {
	qvWm->SetFocus();
	if (AutoRaise)
	  qvWm->RaiseWindow(False);
      }
  }
  else if (paging->IsPagingBelt(w)) {
    paging->HandlePaging(ptRoot);
  }
}

/*
 * LeaceNotifyProc --
 *   Process LeaveNotify event.
 */
void LeaveNotifyProc(Window w, Point winPt)
{
  Menu* menu;

  if (XFindContext(display, w, Menu::context, (caddr_t*)&menu) == XCSUCCESS)
    menu->Leave(w, winPt);
}

/*
 * ClientMessageProc --
 *   Process ClientMessageNotify event.
 */
void ClientMessageProc(Window w, Atom mesType, long state)
{
  Qvwm* qvWm;
  XSetWindowAttributes attributes;
  unsigned long valueMask;

  if (XFindContext(display, w, Qvwm::context, (caddr_t*)&qvWm) == XCSUCCESS)
    if (mesType == _XA_WM_CHANGE_STATE && state == IconicState)
      qvWm->MinimizeWindow();
}

/*
 * PropertyNotifyProc --
 *   Process PropertyNotify event.
 */
void PropertyNotifyProc(Window w, Atom atom)
{
  Qvwm* qvWm;

  if (XFindContext(display, w, Qvwm::context, (caddr_t*)&qvWm) == XCSUCCESS)
    qvWm->SetProperty(atom);
}    

/*
 * ConfigureRequestProc --
 *   Process ConfigureRequest event.
 */
void ConfigureRequestProc(Window w, XConfigureRequestEvent* cre)
{
  Qvwm* qvWm;
  XWindowChanges xwc;
  unsigned long xwcm;

  if (XFindContext(display, w, Qvwm::context, (caddr_t*)&qvWm) == XCNOENT) {
    xwcm = cre->value_mask & (CWX | CWY | CWWidth | CWHeight | CWBorderWidth);
    xwc.x = cre->x;
    xwc.y = cre->y;
    xwc.width = cre->width;
    xwc.height = cre->height;
    xwc.border_width = cre->border_width;

    XConfigureWindow(display, w, xwcm, &xwc);
  }
  else
    qvWm->Configure(cre);
}

/*
 * ColormapNotifyProc --
 *   Process ColormapNotify event.
 */
void ExposeProc(Window w)
{
  Qvwm* qvWm;
  Button* button;
  Menu* menu;
  Icon* icon;
  XEvent ev;

  if (XFindContext(display, w, Qvwm::context, (caddr_t*)&qvWm) == XCSUCCESS) {
    qvWm->Exposure(w);
    while (XCheckWindowEvent(display, w, ExposureMask, &ev))
      ;
  }
  else if (XFindContext(display, w, Button::context, (caddr_t*)&button)
	                                                        == XCSUCCESS) {
    button->DrawButton();
    while (XCheckWindowEvent(display, w, ExposureMask, &ev))
      ;
  }
  else if (XFindContext(display, w, Menu::context, (caddr_t*)&menu)
	                                                        == XCSUCCESS) {
    menu->DrawMenu(w);
    while (XCheckWindowEvent(display, w, ExposureMask, &ev))
      ;
  }
  else if (XFindContext(display, w, Icon::context, (caddr_t*)&icon)
	                                                        == XCSUCCESS) {
    icon->DrawIcon(icon == Icon::focusIcon);
    while (XCheckWindowEvent(display, w, ExposureMask, &ev))
      ;
  }
  else if (UsePager) {
    if (w == pager->GetFrameWin())
      pager->DrawFrame();
    else if (w == pager->GetPagerWin())
      pager->DrawPager();
  }
}

/*
 * DestroyNotifyProc --
 *   Process DestroyNotify event.
 */
void DestroyNotifyProc(Window w)
{
  Qvwm* qvWm;

  if (XFindContext(display, w, Qvwm::context, (caddr_t*)&qvWm) == XCSUCCESS) {
    qvWm->ResetMapped();
    qvWm->ChangeFocus();
    qvWm->UnmapWindows();
    qvWm->tButton->UnmapButton();
    TaskbarButton::RedrawAllTaskbarButtons();

    delete qvWm;
    if (!ClickToFocus)
      Qvwm::ChangeFocusToCursor();
  }
}

/*
 * unmapNotifyProc --
 *   Process UnmapNotify event.
 */
void UnmapNotifyProc(Window w)
{
  Qvwm* qvWm;
  XEvent dummyEvent;

  if (XFindContext(display, w, Qvwm::context, (caddr_t*)&qvWm) == XCSUCCESS) {
    qvWm->ResetMapped();
    qvWm->ChangeFocus();
    qvWm->UnmapWindows();
    qvWm->tButton->UnmapButton();
    TaskbarButton::RedrawAllTaskbarButtons();
    
    if (XCheckTypedWindowEvent(display, w, DestroyNotify, &dummyEvent)) {
      delete qvWm;
      if (!ClickToFocus)
	Qvwm::ChangeFocusToCursor();
    }
  }
}

/*
 * MapNotifyProc --
 *   Process MapNotify event.
 */
void MapNotifyProc(Window w)
{
  Qvwm* qvWm;

  if (XFindContext(display, w, Qvwm::context, (caddr_t*)&qvWm) == XCSUCCESS) {
    XGrabServer(display);

    if (Qvwm::focusQvwm->CheckMenuMapped())
      Qvwm::focusQvwm->UnmapMenu();
    if (startMenu != NULL && startMenu->CheckMapped())
      startMenu->UnmapMenu();

    qvWm->MapWindows();
    qvWm->tButton->MapButton();

    if (ClickToFocus)
      qvWm->SetFocus();
    else
      Qvwm::ChangeFocusToCursor();
    qvWm->RaiseWindow(True);

    XSync(display, 0);
    XUngrabServer(display);
  }
}

/*
 * MapRequestProc --
 *   Process MapRequest event.
 */
void MapRequestProc(Window w)
{
  Qvwm* qvWm;

  if ((qvWm = Qvwm::LookInList(w)) == NULL)
    qvWm = new Qvwm(w, False);

  qvWm->MapWindows();
  qvWm->tButton->MapButton();
  qvWm->SetFocus();
  qvWm->RaiseWindow(True);
}

/*
 * ButtonPressProc --
 *   Process ButtonPress event.
 */
void ButtonPressProc(Window w, unsigned int buttonNum, Time clickTime)
{
  Qvwm* qvWm;
  Button* button;
  Menu* menu;
  Icon* icon;

  if (buttonNum == Button1) {
    /*
     * Right button.
     */
    if (XFindContext(display, w, Qvwm::context, (caddr_t*)&qvWm) == XCSUCCESS)
      qvWm->Button1Press(w, clickTime);
    else if (XFindContext(display, w, Button::context, (caddr_t*)&button)
	                                                         == XCSUCCESS)
      button->Button1Press();
    else if (XFindContext(display, w, Menu::context, (caddr_t*)&menu)
                                                                 == XCSUCCESS)
      menu->Button1Press(w);
    else if (XFindContext(display, w, Icon::context, (caddr_t*)&icon)
	                                                         == XCSUCCESS)
      icon->Button1Press(clickTime);
    else if (UsePager && pager->IsPagerWindows(w))
      pager->Button1Press(w);
  }
  else if (buttonNum == Button3) {
    /*
     * Left button.
     */
    if (UsePager && w == pager->GetVisualWin())
      pager->Button3Press();
  }

  XAllowEvents(display, ReplayPointer, CurrentTime);
}

/*
 * ButtonReleaseProc --
 *   Process ButtonRelease event.
 */
void ButtonReleaseProc(Window w, unsigned int state, Point rootPt)
{
  Qvwm* qvWm;
  Button* button;
  Menu* menu;

  if (state & Button1Mask) {
    /*
     * Left button.
     */
    if (XFindContext(display, w, Qvwm::context, (caddr_t*)&qvWm) == XCSUCCESS)
      qvWm->Button1Release();
    else if (XFindContext(display, w, Menu::context, (caddr_t*)&menu)
	                                                         == XCSUCCESS)
      menu->Button1Release(w);
  }
  else if (state & Button3Mask) {
    /*
     * Right button.
     */
    if (XFindContext(display, w, Qvwm::context, (caddr_t*)&qvWm) == XCSUCCESS)
      qvWm->Button3Release(w, rootPt);
    else if (XFindContext(display, w, Button::context, (caddr_t*)&button)
	                                                         == XCSUCCESS)
      button->Button3Release();
  }
}

/*
 * MotionNotifyProc --
 *   Process MotionNotify event.
 */
void MotionNotifyProc(Window w)
{
  Qvwm* qvWm;

  /*
   * Ignore MotionNotify when any menus are shown.
   */
  if (Qvwm::focusQvwm->CheckMenuMapped())
    return;
  if (startMenu != NULL && startMenu->CheckMapped())
    return;

  if (XFindContext(display, w, Qvwm::context, (caddr_t*)&qvWm) == XCSUCCESS)
    qvWm->Button1Motion(w);
}

/*
 * KeyPressProc --
 *   Process KeyPress event.
 */
void KeyPressProc(Window w, XKeyEvent* ev)
{
  Menu* menu;
  Qvwm* qvWm;

  if (XFindContext(display, w, Menu::context, (caddr_t*)&menu) == XCSUCCESS)
    ExecShortCutKey(SCMenuKeyNum, scMenuKey, ev, menu);
  else if (w == root)
    ExecShortCutKey(SCRootKeyNum, scRootKey, ev, rootQvwm->ctrlMenu);
  else
    if (XFindContext(display, w, Qvwm::context, (caddr_t*)&qvWm) == XCSUCCESS)
      ExecShortCutKey(SCKeyNum, scKey, ev, qvWm->ctrlMenu);
}
