#ifndef _VER_H_
#define _VER_H_

const char* Version = "1.0b5";

#endif // _VER_H_
