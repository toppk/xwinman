#include <stdio.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "tbutton.h"
#include "taskbar.h"
#include "paging.h"

/*
 * CreateFrame --
 *   Create a frame (most lower base window).
 */
void Qvwm::CreateFrame(Rect rect)
{
  XSetWindowAttributes attributes;
  unsigned long valueMask;

  attributes.event_mask = SubstructureRedirectMask | ButtonPressMask |
                          ButtonReleaseMask | EnterWindowMask |
			  LeaveWindowMask | ExposureMask;
  attributes.background_pixel = gray;
  valueMask = CWBackPixel | CWEventMask;

  frame = XCreateWindow(display, root,
			rect.x-paging->origin.x, rect.y-paging->origin.y,
			rect.width, rect.height,
			0, CopyFromParent, InputOutput, CopyFromParent,
			valueMask, &attributes);
  XSaveContext(display, frame, context, (caddr_t)this);
}

/*
 * CreateParent --
 *   Create a new direct parent window of original window. This window is
 *   the child of frame window.
 */
void Qvwm::CreateParent(Rect rect)
{
  XSetWindowAttributes attributes;
  unsigned long valueMask;

  attributes.event_mask = SubstructureRedirectMask | ButtonPressMask |
                          ButtonReleaseMask | EnterWindowMask |
			  LeaveWindowMask | ExposureMask;
  attributes.background_pixel = darkGray;
  valueMask = CWBackPixel | CWEventMask;

  parent = XCreateWindow(display, frame,
			 rect.x, rect.y, rect.width, rect.height,
			 0, CopyFromParent, InputOutput, CopyFromParent,
			 valueMask, &attributes);
  XSaveContext(display, parent, context, (caddr_t)this);
} 

/*
 * CreateSides --
 *   Create 4 side windows, which are used for resizing the window along
 *   either x or y direction. These windows are the children of frame window.
 */
void Qvwm::CreateSides(Rect rect[])
{
  XSetWindowAttributes attributes;
  unsigned long valueMask;

  attributes.event_mask = ButtonPressMask | ButtonReleaseMask | ExposureMask |
                          EnterWindowMask | LeaveWindowMask |
			  Button1MotionMask;
  attributes.background_pixel = darkGray;
  valueMask = CWBackPixel | CWEventMask;

  for (int i = 0; i < 4; i++) {
    side[i] = XCreateWindow(display, frame,
			    rect[i].x, rect[i].y,
			    rect[i].width, rect[i].height,
			    0, CopyFromParent, InputOnly, CopyFromParent,
			    CWEventMask, &attributes);
    XSaveContext(display, side[i], context, (caddr_t)this);
  }

  /*
   * Set cursor to each side window.
   */
  XDefineCursor(display, side[0], cursor[X_RESIZE]);
  XDefineCursor(display, side[1], cursor[X_RESIZE]);
  XDefineCursor(display, side[2], cursor[Y_RESIZE]);
  XDefineCursor(display, side[3], cursor[Y_RESIZE]);
}

/*
 * CreateCorners --
 *   Create 4 corner windows, which are used for resizing the window freely.
 *   These windows are the children of frame window.
 */
void Qvwm::CreateCorners(Rect rect[])
{
  XSetWindowAttributes attributes;
  unsigned long valueMask;

  attributes.event_mask = ButtonPressMask | ButtonReleaseMask | ExposureMask |
                          EnterWindowMask | LeaveWindowMask |
			  Button1MotionMask;
  attributes.background_pixel = darkGray;
  valueMask = CWBackPixel | CWEventMask;

  for (int i = 0; i < 4; i++) {
    corner[i] = XCreateWindow(display, frame,
			      rect[i].x, rect[i].y,
			      rect[i].width, rect[i].height,
			      0, CopyFromParent, InputOnly, CopyFromParent,
			      CWEventMask, &attributes);
    XSaveContext(display, corner[i], context, (caddr_t)this);
  }

  /*
   * Set cursor to each corner window.
   */
  XDefineCursor(display, corner[0], cursor[RD_RESIZE]);
  XDefineCursor(display, corner[1], cursor[LD_RESIZE]);
  XDefineCursor(display, corner[2], cursor[LD_RESIZE]);
  XDefineCursor(display, corner[3], cursor[RD_RESIZE]);
}

/*
 * CreateTitle --
 *   Create title window, which is the child of frame window.
 */
void Qvwm::CreateTitle(Rect rect)
{
  XSetWindowAttributes attributes;
  unsigned long valueMask;

  attributes.event_mask = ButtonPressMask | ButtonReleaseMask | ExposureMask |
                          EnterWindowMask | LeaveWindowMask |
			  Button1MotionMask;
  attributes.background_pixel = darkGray;
  valueMask = CWBackPixel | CWEventMask;

  title = XCreateWindow(display, frame,
			rect.x, rect.y, rect.width, rect.height,
			0, CopyFromParent, InputOutput, CopyFromParent,
			valueMask, &attributes);
  XSaveContext(display, title, context, (caddr_t)this);
}

/*
 * CreateCtrlBtn --
 *   Create control button window. This is the child of title window.
 */
void Qvwm::CreateCtrlButton(Rect rect)
{
  XSetWindowAttributes attributes;
  unsigned long valueMask;

  attributes.event_mask = ButtonPressMask | ButtonReleaseMask | ExposureMask |
                          EnterWindowMask | LeaveWindowMask |
			  Button1MotionMask | OwnerGrabButtonMask;
  attributes.background_pixel = darkGray;
  valueMask = CWBackPixel | CWEventMask;

  ctrl = XCreateWindow(display, title,
		       rect.x, rect.y, rect.width, rect.height,
		       0, CopyFromParent, InputOutput, CopyFromParent,
		       valueMask, &attributes);
  XSaveContext(display, ctrl, context, (caddr_t)this);
}

/*
 * DrawFrame --
 *   Draw frame window.
 */
void Qvwm::DrawFrame()
{
  XPoint xp[3];
  int borderWidth = 0, titleHeight = 0;

  if (CheckFlags(TITLE))
    titleHeight = TITLE_HEIGHT;

  /*
   * Border (thickness 4)
   */
  if (CheckFlags(BORDER)) {
    borderWidth = BORDER_WIDTH;

    xp[0].x = rc.width - 1;
    xp[0].y = 0;
    xp[1].x = rc.width - 1;
    xp[1].y = rc.height - 1;
    xp[2].x = 0;
    xp[2].y = rc.height - 1;
    
    XSetForeground(display, gc, black);
    XDrawLines(display, frame, gc, xp, 3, CoordModeOrigin);
    
    xp[0].x = rc.width - 3;
    xp[0].y = 1;
    xp[1].x = 1;
    xp[1].y = 1;
    xp[2].x = 1;
    xp[2].y = rc.height - 2;
    
    XSetForeground(display, gc, white);
    XDrawLines(display, frame, gc, xp, 3, CoordModeOrigin);
    
    xp[0].x = rc.width - 2;
    xp[0].y = 1;
    xp[1].x = rc.width - 2;
    xp[1].y = rc.height - 2;
    xp[2].x = 1;
    xp[2].y = rc.height - 2;
    
    XSetForeground(display, gc, darkGray);
    XDrawLines(display, frame, gc, xp, 3, CoordModeOrigin);
  }

  xp[0].x = rc.width - borderWidth - 2;
  xp[0].y = borderWidth + titleHeight + 1;
  xp[1].x = borderWidth;
  xp[1].y = borderWidth + titleHeight + 1;
  xp[2].x = borderWidth;
  xp[2].y = rc.height - borderWidth - 2;
  
  XSetForeground(display, gc, darkGray);
  XDrawLines(display, frame, gc, xp, 3, CoordModeOrigin);
  
  xp[0].x = rc.width - borderWidth - 1;
  xp[0].y = borderWidth + titleHeight + 1;
  xp[1].x = rc.width - borderWidth - 1;
  xp[1].y = rc.height - borderWidth - 1;
  xp[2].x = borderWidth;
  xp[2].y = rc.height - borderWidth - 1;

  XSetForeground(display, gc, white);
  XDrawLines(display, frame, gc, xp, 3, CoordModeOrigin);

  xp[0].x = rc.width - borderWidth - 3;
  xp[0].y = borderWidth + titleHeight + 2;
  xp[1].x = borderWidth + 1;
  xp[1].y = borderWidth + titleHeight + 2;
  xp[2].x = borderWidth + 1;
  xp[2].y = rc.height - borderWidth - 3;

  XSetForeground(display, gc, black);
  XDrawLines(display, frame, gc, xp, 3, CoordModeOrigin);
}

/*
 * CalcFramePos --
 *   Calculate the size of parts from frame window size.
 */
void Qvwm::CalcFramePos(Rect rcFrame, Rect* rcParent, Rect* rcTitle,
			Rect rcCorner[], Rect rcSide[], Rect* rcCtrl,
			Rect rcButton[])
{
  int i;
  int borderWidth = 0, titleHeight = 0;

  if (CheckFlags(BORDER))
    borderWidth = BORDER_WIDTH;
  if (CheckFlags(TITLE))
    titleHeight = TITLE_HEIGHT;
  if (CheckFlags(DIALOG))
    borderWidth = 3;

  /*
   * Parent window pos & size.
   */
  if (CheckFlags(DIALOG)) {
    rcParent->x = 3;
    rcParent->y = titleHeight + 3+3;
    rcParent->width = rcFrame.width - 3*2;
    rcParent->height = rcFrame.height - (titleHeight+3*2+3);
  }
  else {
    rcParent->x = borderWidth+2;
    rcParent->y = borderWidth + titleHeight + 3;
    rcParent->width = rcFrame.width - (borderWidth+2)*2;
    rcParent->height = rcFrame.height - (titleHeight + borderWidth*2 + 5);
  }

  /*
   * Title window pos & size.
   */
  rcTitle->x = borderWidth;
  rcTitle->y = borderWidth;
  rcTitle->width = rcFrame.width - borderWidth*2;
  rcTitle->height = titleHeight;

  /*
   * Corner window pos & size.
   */
  for (i = 0; i < 4; i++) {
    rcCorner[i].width = TITLE_HEIGHT + BORDER_WIDTH;
    rcCorner[i].height = TITLE_HEIGHT + BORDER_WIDTH;
  }
  rcCorner[0].x = rcCorner[2].x = 0;
  rcCorner[0].y = rcCorner[1].y = 0;
  rcCorner[1].x = rcCorner[3].x = rcFrame.width - rcCorner[1].width;
  rcCorner[2].y = rcCorner[3].y = rcFrame.height - rcCorner[2].height;

  /*
   * side window pos & size.
   */
  rcSide[0].x = 0;
  rcSide[0].y = rcSide[1].y = TITLE_HEIGHT + BORDER_WIDTH;
  rcSide[1].x = rcFrame.width - BORDER_WIDTH;
  rcSide[2].x = rcSide[3].x = rcSide[0].y;
  rcSide[2].y = 0;
  rcSide[3].y = rcFrame.height - BORDER_WIDTH;
  rcSide[0].width = rcSide[1].width = BORDER_WIDTH;
  rcSide[0].height = rcSide[1].height = rcFrame.height - rcCorner[0].height*2;
  if (rcSide[0].height == 0)
    rcSide[0].height = rcSide[1].height = 1;
  rcSide[2].width = rcSide[3].width = rcFrame.width - rcCorner[0].width*2;
  if (rcSide[2].width == 0)
    rcSide[2].width = rcSide[3].width = 1;
  rcSide[2].height = rcSide[3].height = BORDER_WIDTH;

  /*
   * Control menu button pos & size.
   */
  rcCtrl->x = 2;
  rcCtrl->y = 1;
  rcCtrl->width = rcCtrl->height = TaskbarButton::SIMBOL_HEIGHT;

  /*
   * Frame Button pos & size.
   */
  rcButton[0].x = rcTitle->width - (BUTTON_WIDTH*3 + 4);
  rcButton[1].x = rcTitle->width - (BUTTON_WIDTH*2 + 4);
  rcButton[2].x = rcTitle->width - (BUTTON_WIDTH + 2);
  for (i = 0; i < 3; i++) {
    rcButton[i].y = 2;
    rcButton[i].width = BUTTON_WIDTH;
    rcButton[i].height = BUTTON_HEIGHT;
  }
}    

/*
 * DrawTitle --
 *   Draw title.
 */
void Qvwm::DrawTitle()
{
  Point titlePt;
  XRectangle ink, log;

  if (this == rootQvwm || !CheckFlags(TITLE))
    return;

  /*
   * Paint the background of title.
   */
  if (CheckFocus())
    XSetWindowBackground(display, title, blue);
  else
    XSetWindowBackground(display, title, darkGray);
  
  XClearWindow(display, title);
  
  DrawCtrlMenuMark();
  
  /*
   * Draw the title text.
   */
  XmbTextExtents(fsTitle, name, strlen(name), &ink, &log);
  if (CheckFlags(CTRL_MENU))
    titlePt.x = TaskbarButton::SIMBOL_WIDTH + 4;
  else
    titlePt.x = 4;
  titlePt.y = (TITLE_HEIGHT-log.height)/2 - log.y;
  
  if (CheckFocus())
    XSetForeground(display, gc, white);
  else
    XSetForeground(display, gc, gray);
  
  XmbDrawString(display, title, fsTitle, gc, titlePt.x, titlePt.y,
		name, strlen(name));
}

/*
 * DrawCtrlMenuMark --
 *   Draw the pixmap of control menu button.
 */
void Qvwm::DrawCtrlMenuMark()
{
  if (!CheckFlags(CTRL_MENU))
    return;

  if (CheckFocus())
    XSetWindowBackground(display, ctrl, blue);
  else
    XSetWindowBackground(display, ctrl, darkGray);
  
  XClearWindow(display, ctrl);
  XSetClipOrigin(display, GetIconGC(), 0, 0);
  XCopyArea(display, GetIconPixmap(), ctrl, GetIconGC(), 0, 0,
	    TaskbarButton::SIMBOL_WIDTH, TaskbarButton::SIMBOL_HEIGHT, 0, 0);
}

/*
 * CalcWindowPos --
 *   Calculate the correct window position.
 */
void Qvwm::CalcWindowPos(Rect base)
{
  Point gravity;
  Rect rect;

  gravity = GetGravityOffset();

  rc.x = base.x + rcScreen.x + (BORDER_WIDTH+2-bwOrig)*gravity.x;
  rc.y = base.y + rcScreen.y;
  if (gravity.y == -1)
    rc.y -= BORDER_WIDTH + TITLE_HEIGHT + 3 - bwOrig;
  else if (gravity.y == -2)
    rc.y -= BORDER_WIDTH*2 + TITLE_HEIGHT + 5 - bwOrig*2;

  switch (taskBar->GetPos()) {
  case Taskbar::BOTTOM:
  case Taskbar::TOP:
    // South??Gravity
    if (gravity.y == -2) {
      rect = taskBar->GetRect();
      rc.y -= rect.height;
    }
    break;
  case Taskbar::LEFT:
  case Taskbar::RIGHT:
    // ??EastGravity
    if (gravity.x == -2) {
      rect = taskBar->GetRect();
      rc.x -= rect.width;
    }
    break;
  }

  if (CheckFlags(DIALOG)) {
    rc.width = base.width + 3*2;
    rc.height = base.height + TITLE_HEIGHT + 3*2+3;
  }
  else {
    rc.width = base.width + (BORDER_WIDTH+2)*2;
    rc.height = base.height + TITLE_HEIGHT + BORDER_WIDTH*2 + 5;
  }
}

/*
 * RecalcAllWindows --
 *   Recalculate the position of all windows.
 */
void Qvwm::RecalcAllWindows()
{
  Qvwm* qvWm = rootQvwm;

  while ((qvWm = qvWm->next) != NULL) {
    if (qvWm->CheckStatus(MAXIMIZE_WINDOW)) {
      XSizeHints hints = qvWm->hints;
      qvWm->rc = qvWm->GetFixSize(rcScreen, hints.max_width, hints.max_height,
				  hints.width_inc, hints.height_inc,
				  hints.base_width, hints.base_height);
      qvWm->RedrawWindow();
    }
    else {
      qvWm->CalcWindowPos(qvWm->rcOrig);
      XMoveWindow(display, qvWm->frame, qvWm->rc.x-paging->origin.x,
		  qvWm->rc.y-paging->origin.y);
    }
  }
}
