#include <string.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "main.h"
#include "misc.h"
#include "dialog.h"

Dialog::Dialog(Rect rc, char* name)
: rc(rc), name(name)
{
  XSetWindowAttributes attributes;
  unsigned long valueMask;
  XTextProperty ct;
  
  attributes.background_pixel = gray;
  attributes.event_mask = ExposureMask;
  valueMask = CWBackPixel | CWEventMask;

  frame = XCreateWindow(display, root, rc.x, rc.y, rc.width, rc.height, 0,
			CopyFromParent, InputOutput, CopyFromParent,
			valueMask, &attributes);
  
  XSetTransientForHint(display, frame, root);

  XmbTextListToTextProperty(display, &name, 1, XCompoundTextStyle, &ct);
  XSetWMName(display, frame, &ct);
}

Dialog::~Dialog()
{
  XDestroyWindow(display, frame);
}

/*
 * MapDialog --
 *   Map dialog.
 */
void Dialog::MapDialog()
{
  XMapRaised(display, frame);
}

/*
 * EventLoop --
 *   Process events when dialog is mapped.
 */
ResourceId Dialog::EventLoop()
{
  XEvent ev;
  ResourceId id;

  while (1) {
    XNextEvent(display, &ev);
    switch (ev.type) {
    case Expose:
      Exposure(ev.xexpose.window);
      break;

    case ButtonPress:
      if (ev.xbutton.button == Button1) {
	id = Button1Press(ev.xbutton.window);
	if (id != NO_ID)
	  return id;
      }
      break;
    }
  }
}

/*
 * Button1Press --
 *   Process press of button1 (mouse left button)
 */
ResourceId Dialog::Button1Press(Window win)
{
  return NO_ID;
}
