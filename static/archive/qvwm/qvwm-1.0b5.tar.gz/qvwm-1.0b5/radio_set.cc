#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "misc.h"
#include "radio_set.h"
#include "radio_button.h"

RadioSet::RadioSet(RadioButton* rb[], int rbNum, ResourceId rid,
		   ResourceId initId)
: rb(rb), num(rbNum), rid(rid)
{
  int i;

  for (i = 0; i < rbNum; i++)
    rb[i]->SetRS(this);

  for (i = 0; i < rbNum; i++) 
    if (rb[i]->GetResId() == initId)
      rbFocus = rb[i];

  rbFocus->SetStatus(RADIO_CHECK);
}

RadioSet::~RadioSet()
{
  for (int i = 0; i < num; i++)
    delete rb[i];
  delete [] rb;
}

/*
 * MapRadioButtons --
 *   Map all radio buttons in this radio set.
 */
void RadioSet::MapRadioButtons()
{
  for (int i = 0; i < num; i++)
    rb[i]->MapButton();
}

/*
 * GetFocusRB --
 *   Get focus radio button in this radio set.
 */
ResourceId RadioSet::GetFocusRB()
{
  for (int i = 0; i < num; i++)
    if (rbFocus == rb[i])
      return rb[i]->GetResId();

  return NO_ID;
}
