#ifndef _ICON_H_
#define _ICON_H_

#include "misc.h"

/*
 * Icon class
 */
class Icon {
private:
  Icon* prev;                  // prev icon in icon list
  Icon* next;                  // next icon in icon list

  Window w;                    // icon window
  Window wrap;                 // window accepting events around icon
  Rect rc;                     // position and size
  Pixmap pix;                  // icon pixmap
  Pixmap mask;                 // icon mask
  char* name;                  // icon name
  char* exec;                  // icon function

  Time iconClickTime;          // click interval when icon executes function
  static Bool moving;          // True if icon is being moved

  static const unsigned int ICON_SIZE = 32;
  static const unsigned int ICON_AREA = 75;

public:
  static Icon* firstIcon;               // first icon in icon list
  static Icon* lastIcon;                // last icon in icon list
  static Icon* focusIcon;               // icon with focus
  static XContext context;
  static Pixmap pixIcon, maskIcon;

public:
  Icon(Pixmap pix, Pixmap mask, char* name, char* exec);
  ~Icon();
  Icon* GetNext() { return next; }

  void MapIcon();
  void UnmapIcon();
  void DrawIcon(Bool focus);
  void Button1Press(Time clickTime);

  static void RedrawAllIcons();
  static void CreateIconPixmap();
};

#endif // _ICON_H_

