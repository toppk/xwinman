#ifndef _PARSE_H_
#define _PARSE_H_

#include "util.h"

enum VarAttribute {
  F_STRING,
  F_NATURAL,
  F_COLOR,
  F_BOOL,
  F_TASKBAR,
  F_GEOMETRY,
  F_OFFSET,
  F_SIZE,
};

struct VariableTable {
  char* name;
  VarAttribute attr;
  void* var;
};

struct FuncTable {
  char* name;
  FuncNumber num;
};

struct MenuRes {
  char* name;
  char* file;
  FuncNumber func;
  char* exec;
  char* child;
};

struct ItemList {
  MenuRes* item;
  ItemList* next;
};

struct MenuItem {
  int nitems;
  MenuOrigin* fOrg;
  char** child;
};

extern void ParseQvwmrc(char* rcFileName);
extern FuncNumber GetFuncNumber(char* func);
extern void AssignVariable(char* var, char* str);
extern MenuRes* MakeExecItem(char* name, char* file, char* exec);
extern MenuRes* MakeDirItem(char* name, char* file, char* next);
extern MenuRes* MakeFuncItem(char* name, char* file, char* func);
extern MenuRes* MakeClassItem(char* name);
extern ItemList* MakeItemList(MenuRes* mRes, ItemList* mResList);
extern void HashMenu(char* menuName, ItemList* itemList);
extern void MakeAllMenuOrigins();
extern void MakeMenuOrigin(MenuItem* mItem);
extern int GetItemNum(ItemList* itemList);
extern Bool IsFunction(char* text);
extern Bool IsAttribute(char* text);

#endif // _PARSE_H_
