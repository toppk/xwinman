#include <stdio.h>
#include <unistd.h>
#ifdef __EMX__
#include <process.h>
#endif
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/xpm.h>
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "menu.h"
#include "startmenu.h"
#include "fbutton.h"
#include "parse.h"
#include "events.h"
#include "switch.h"
#include "qvwmrc.h"
#include "exitdlg.h"
#include "paging.h"
#include "icon.h"

/*
 * ExecFunction --
 *   Execute qvwm function.
 */
void Menu::ExecFunction(FuncNumber fn, int num)
{
  Point ptFrame, pt, ptJunk;
  int pFocus;
  int borderWidth, topBorder, titleHeight, titleEdge;
  Rect rect;
  Window junkRoot, junkChild;
  unsigned int mask;

  ASSERT(num >= 0 && num < nitems);

  switch (fn) {
  /*
   * Do nothing.
   */
  case Q_NONE:
    break;

  /*
   * Extract the menu.
   */
  case Q_DIR:
    switch (fDir) {
    /*
     * To right side.
     */
    case RIGHT:
      ptFrame.x = rc.x + rc.width - 7;
      if (ptFrame.x + next[num]->rc.width > rcScreen.width-1) {
	ptFrame.x = rc.x - next[num]->rc.width + MenuFrameWidth;
	fDir = LEFT;
      }
      break;

    /*
     * To left side.
     */
    case LEFT:
      ptFrame.x = rc.x - next[num]->rc.width+MenuFrameWidth;
      if (ptFrame.x + (int)next[num]->rc.width < 0) {
	ptFrame.x = rc.x + rc.width - 7;
	fDir = RIGHT;
      }
      break;
    }
    ptFrame.y = rc.y + CalcItemYPos(num) - MenuFrameWidth;
    if (ptFrame.y + next[num]->rc.height > rcScreen.height - 1)
      ptFrame.y = ptFrame.y + iHeight - next[num]->rc.height +
	MenuFrameWidth * 2;

    child = next[num];
    child->SetQvwm(qvWm);
    child->MapMenu(ptFrame.x, ptFrame.y);
    break;

  /*
   * Execute the external command.
   */
  case Q_EXEC:
#ifdef __EMX__
    if (spawnl(P_NOWAIT, "cmd.exe", "cmd.exe", "/C", exec[num], NULL) == -1)
      QvwmError("Can't execute '%s'", exec[num]);
#else
    if (!fork()) {
      char cmd[256];

      ASSERT(strlen(exec[num]) + 5 < 256);

      sprintf(cmd, "exec %s", exec[num]);
      if (execl("/bin/sh", "bin/sh", "-c", cmd, NULL) == -1) {
	QvwmError("Can't execute '%s'", exec[num]);
	exit(1);
      }
    }
#endif
    break;

  /*
   * Restore the window pos & size.
   */
  case Q_RESTORE:
    ASSERT(qvWm);
    if (qvWm->CheckStatus(MAXIMIZE_WINDOW) &&
	!qvWm->CheckStatus(MINIMIZE_WINDOW)) {
      ASSERT(qvWm->fButton[1]);
      qvWm->fButton[1]->SetPixmap(FrameButton::pixButton[FrameButton::MAXIMIZE]);
    }
    qvWm->RestoreWindow();

    /*
     * After mapped, give the focus to qvWm.
     */
    rootQvwm->SetFocus();
    qvWm->SetFocus();
    break;

  /*
   * Move the window.
   */
  case Q_MOVE:
    ASSERT(qvWm);
    rect = qvWm->GetRect();
    XDefineCursor(display, root, cursor[MOVE]);
    XQueryPointer(display, root, &junkRoot, &junkChild, &pt.x, &pt.y,
		  &ptJunk.x, &ptJunk.y, &mask);
    qvWm->MoveWindow(pt);
    XDefineCursor(display, root, cursor[SYS]);
    break;

  /*
   * Resize the window.
   */
  case Q_RESIZE:
    ASSERT(qvWm);
    rect = qvWm->GetRect();
    XDefineCursor(display, root, cursor[MOVE]);
    XQueryPointer(display, root, &junkRoot, &junkChild, &pt.x, &pt.y,
		  &ptJunk.x, &ptJunk.y, &mask);
    qvWm->ResizeWindow(Qvwm::RIGHTBOTTOM, pt);
    XDefineCursor(display, root, cursor[SYS]);
    break;

  /*
   * Minimize the window.
   */
  case Q_MINIMIZE:
    ASSERT(qvWm);
    qvWm->MinimizeWindow();
    break;

  /*
   * Maximize the window.
   */
  case Q_MAXIMIZE:
    ASSERT(qvWm);
    ASSERT(qvWm->fButton[1]);
    qvWm->fButton[1]->SetPixmap(FrameButton::pixButton[FrameButton::RESTORE]);
    qvWm->MaximizeWindow();
    rootQvwm->SetFocus();
    qvWm->SetFocus();
    break;

  /*
   * Close the window.
   */
  case Q_CLOSE:
    ASSERT(qvWm);
    qvWm->FetchWMProtocols();
    if (qvWm->CheckFlags(WM_DELETE_WINDOW))
      qvWm->CloseWindow();
    else
      qvWm->KillClient();
    break;

  /*
   * Kill the application.
   */
  case Q_KILL:
    ASSERT(qvWm);
    qvWm->KillClient();
    break;

  /*
   * Exit qvwm.
   */
  case Q_EXIT:
    if (!UseExitDialog)
      Qvwm::FinishQvwm(False);
    else
      ExitDlg(qvWm, ExitDlgItem);
    break;

  /*
   * Move taskbar to the bottom of screen.
   */
  case Q_BOTTOM:
    ASSERT(taskBar);
    taskBar->MoveTaskbar(Taskbar::BOTTOM);
    break;

  /*
   * Move taskbar to the top of screen.
   */
  case Q_TOP:
    ASSERT(taskBar);
    taskBar->MoveTaskbar(Taskbar::TOP);
    break;

  /*
   * Move taskbar to the left of screen.
   */
  case Q_LEFT:
    ASSERT(taskBar);
    taskBar->MoveTaskbar(Taskbar::LEFT);
    break;

  /*
   * Move taskbar to the right of screen.
   */
  case Q_RIGHT:
    ASSERT(taskBar);
    taskBar->MoveTaskbar(Taskbar::RIGHT);
    break;

  /*
   * Restart qvwm.
   */
  case Q_RESTART:
    Qvwm::FinishQvwm(True);
    XCloseDisplay(display);
    execvp(*qvArgv, qvArgv);
    break;

  /*
   * Switch the window to next window in focus stack.
   */
  case Q_CHANGEWINDOW:
    Qvwm::RollFocus();
    break;

  /*
   * Switch the task to another task with the task switcher.
   */
  case Q_SWITCHTASK:
    if (taskSwitcher == NULL)
      taskSwitcher = new TaskSwitcher();
    taskSwitcher->SwitchTask();
    break;

  /*
   * Popup the start menu.
   */
  case Q_POPUPSTARTMENU:
    if (startMenu == NULL) {
      StartMenu::CreateStartMenuPixmap();
      startMenu = new StartMenu(StartMenuItem);
    }

    if (!startMenu->CheckMapped()) {
      rootQvwm->SetFocus();
      startMenu->MapMenu();
    }
    break;

  /*
   * Popup the menu.
   */
  case Q_POPUPMENU:
    if (!CheckMapped()) {
      ASSERT(qvWm);
      qvWm->GetBorderAndTitle(borderWidth, topBorder, titleHeight, titleEdge);
      rect = qvWm->GetRect();
      MapMenu(rect.x + topBorder, rect.y + topBorder + titleHeight);
    }
    break;

  /*
   * Popdown one menu.
   */
  case Q_POPDOWNMENU:
    // Erasemenu only one menu.
    UnmapMenu();
    break;

  /*
   * Popdown all menu.
   */
  case Q_POPDOWNALLMENU:
    Qvwm::UnmapAllMenus();
    break;

  /*
   * Move the focus of menu up.
   */
  case Q_UPFOCUS:
    if (iFocus == -1) {
      iFocus = nitems - 1;
      while (func[iFocus] == Q_SEPARATOR)
	if (--iFocus == -1)
	  return;
    }
    else {
      ASSERT(iFocus >= 0 && iFocus < nitems);
      pFocus = iFocus;

      do {
	if (--iFocus == -1)
	  iFocus = nitems - 1;
      } while (func[iFocus] == Q_SEPARATOR);

      SetMenuFocus(pFocus);
    }
    ASSERT(iFocus >= 0 && iFocus < nitems);
    SetMenuFocus(iFocus);
    break;
    
  /*
   * Move the focus of menu down.
   */
  case Q_DOWNFOCUS:
    if (iFocus == -1) {
      iFocus = 0;
      while (func[iFocus] == Q_SEPARATOR)
	if (++iFocus == nitems)
	  return;
    }
    else {
      ASSERT(iFocus >= 0 && iFocus < nitems);
      pFocus = iFocus;

      do {
	if (++iFocus == nitems)
	  iFocus = 0;
      } while (func[iFocus] == Q_SEPARATOR);

      SetMenuFocus(pFocus);
    }
    ASSERT(iFocus >= 0 && iFocus < nitems);
    SetMenuFocus(iFocus);
    break;

  /*
   * Move the focus of menu right.
   */
  case Q_RIGHTFOCUS:
    if (fDir == RIGHT) {
      ASSERT(iFocus >= 0 && iFocus < nitems);
      if (func[iFocus] == Q_DIR) {
	ExecFunction(Q_DIR, iFocus);
	ASSERT(child);
	child->ExecFunction(Q_DOWNFOCUS, 0);
      }
    }
    else {
      ASSERT(fDir == LEFT);
      if (parent != NULL)
	UnmapMenu();
    }
    break;

  /*
   * Move the focus of menu left.
   */
  case Q_LEFTFOCUS:
    if (fDir == LEFT) {
      ASSERT(iFocus >= 0 && iFocus < nitems);
      if (func[iFocus] == Q_DIR) {
	ExecFunction(Q_DIR, iFocus);
	ASSERT(child);
	child->ExecFunction(Q_DOWNFOCUS, 0);
      }
    }
    else {
      ASSERT(fDir == RIGHT);
      if (parent != NULL)
	UnmapMenu();
    }
    break;
    
  /*
   * Execute the function of the menu item.
   */
  case Q_ACTION:
    ASSERT(iFocus >= 0 && iFocus < nitems);
    if (IsSelectable(func[iFocus])) {
      pFocus = iFocus;
      if (func[iFocus] != Q_DIR)
	Qvwm::UnmapAllMenus();

      ExecFunction(func[pFocus], pFocus);
    }
    break;

  /*
   * Switch to left virtual page.
   */
  case Q_LEFTPAGING:
    {
      Rect rcRoot = rootQvwm->GetRect();
      Point oldOrigin = paging->origin;

      ASSERT(paging);

      paging->origin.x -= rcRoot.width;
      paging->PagingAllWindows(oldOrigin);
    }
    break;

  /*
   * Switch to right virtual page.
   */
  case Q_RIGHTPAGING:
    {
      Rect rcRoot = rootQvwm->GetRect();
      Point oldOrigin = paging->origin;

      ASSERT(paging);

      paging->origin.x += rcRoot.width;
      paging->PagingAllWindows(oldOrigin);
    }
    break;

  /*
   * Switch to up virtual page.
   */
  case Q_UPPAGING:
    {
      Rect rcRoot = rootQvwm->GetRect();
      Point oldOrigin = paging->origin;

      ASSERT(paging);

      paging->origin.y -= rcRoot.height;
      paging->PagingAllWindows(oldOrigin);
    }
    break;

  /*
   * Switch to down virtual page.
   */
  case Q_DOWNPAGING:
    {
      Rect rcRoot = rootQvwm->GetRect();
      Point oldOrigin = paging->origin;

      ASSERT(paging);

      paging->origin.y += rcRoot.height;
      paging->PagingAllWindows(oldOrigin);
    }
    break;

  /*
   * Line up desktop icons
   */ 
  case Q_LINEUP:
    Icon::LineUpAllIcons();
    break;

  case Q_OTHERWM:
    Qvwm::FinishQvwm(True);
    XCloseDisplay(display);
    execlp(OtherWM, OtherWM, NULL);
    break;
  }
}

/*
 * IsSelectable --
 *   Return True if the menu item is selectable.
 */
Bool Menu::IsSelectable(FuncNumber fn)
{
  ASSERT(qvWm);

  switch (fn) {
  case Q_NONE:
    return False;

  case Q_RESTORE:
    if (qvWm->CheckStatus(MINIMIZE_WINDOW | MAXIMIZE_WINDOW))
      return True;
    return False;

  case Q_MOVE:
  case Q_RESIZE:
    if (qvWm->CheckStatus(MINIMIZE_WINDOW | MAXIMIZE_WINDOW))
      return False;
    return True;

  case Q_MINIMIZE:
    if (qvWm->CheckStatus(MINIMIZE_WINDOW) || qvWm->CheckFlags(NOTBUTTON))
      return False;
    return True;

  case Q_MAXIMIZE:
    if (qvWm->CheckStatus(MAXIMIZE_WINDOW) &&
	!qvWm->CheckStatus(MINIMIZE_WINDOW))
      return False;
    return True;

  default:
    return True;
  }
}
