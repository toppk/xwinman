#include <stdio.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "taskbar.h"
#include "tbutton.h"
#include "icon.h"
#include "util.h"
#include "qvwmrc.h"
#include "pager.h"

/*
 * SetFocus --
 *   Take off the focus from current focus window, and set the focus to
 *   this window.
 */
void Qvwm::SetFocus()
{
  int i;

  /*
   * Take off the focus of short cut icon, if any.
   */
  if (Icon::focusIcon != NULL) {
    Icon::focusIcon->DrawIcon(False);
    Icon::focusIcon = NULL;
  }

  /*
   * If this window has already had the focus, return.
   */
  if (this == focusQvwm)
    return;

  if (CheckFlags(NOFOCUS))
    return;

  if (CheckMapped()) {
    /*
     * Ungrab buttons so that the window without focus can get focus by
     * ButtonPress.
     */
    if (this != rootQvwm)
      for (i = 1; i < 4; i++)
	XUngrabButton(display, i, 0, wOrig);
    
    ASSERT(taskBar);

    /*
     * Set the input focus to this window. But if this window is root window,
     * set it to taskbar window.
     */
    if (wOrig == root)
      XSetInputFocus(display, taskBar->GetFrameWin(), RevertToParent,
		     CurrentTime);
    else
      XSetInputFocus(display, wOrig, RevertToParent, CurrentTime);
    
    XSync(display, 0);
    InstallWindowColormaps();
  }

  ASSERT(focusQvwm);

  /*
   * Grab buttons so that the window without focus can get focus by
   * ButtonPress.
   */
  if (focusQvwm->CheckMapped()) {
    if (focusQvwm != rootQvwm) {
      for (i = 1; i < 4; i++)
	XGrabButton(display, i, 0, focusQvwm->wOrig, True, ButtonPressMask,
		    GrabModeSync, GrabModeAsync, None, cursor[SYS]);
    }
  }

  /*
   * Change the focus of taskbar button.
   */
  if (focusQvwm != rootQvwm) {
    ASSERT(focusQvwm->tButton);
    focusQvwm->tButton->ResetFocus();
    if (UsePager) {
      ASSERT(focusQvwm->mini);
      focusQvwm->mini->ResetFocus();
    }
    focusQvwm->tButton->SetState(Button::NORMAL);
    focusQvwm->tButton->DrawButton();
  }
  if  (this != rootQvwm) {
    ASSERT(tButton);
    tButton->SetFocus();
    if (UsePager) {
      ASSERT(mini);
      mini->SetFocus();
    }
    tButton->SetState(Button::PUSH);
    tButton->DrawButton();
  }

  /*
   * Preserve current(old) focusQvwm.
   */
  Qvwm* oldQvwm = focusQvwm;

  PushFocusStack();

  /*
   * Reflect the change to titlebar.
   */
  oldQvwm->DrawTitle();
  DrawTitle();

  if (CheckFlags(WM_TAKE_FOCUS))
    SendMessage(_XA_WM_TAKE_FOCUS);

  /*
   * Grab keys only when root window has the focus.
   */
  if (focusQvwm == rootQvwm)
    GrabRootKeys();
  else
    UngrabRootKeys();

  taskBar->RaiseTaskbar();
}

/*
 * ChangeFocus --
 *   Take off the focus from this window, and give it to another window.
 */
void Qvwm::ChangeFocus()
{
  Qvwm* tmpQvwm = focusQvwm;

  ASSERT(tmpQvwm);

  if (this == focusQvwm) {
    /*
     * Give the focus to the window other than root window, if any.
     */
    if (preFocus == rootQvwm && preFocus->preFocus != NULL)
      tmpQvwm = preFocus->preFocus;
    else
      tmpQvwm = preFocus;
    
    /*
     * Find the window whose is still valid and mapped.
     */
    while (!tmpQvwm->CheckMapped()) {
      tmpQvwm = tmpQvwm->preFocus;
      ASSERT(tmpQvwm);
    }
    
    if (ClickToFocus) {
      tmpQvwm->SetFocus();
      if (tmpQvwm->CheckMapped())
	tmpQvwm->RaiseWindow(True);
      else
	tmpQvwm->RestoreWindow();
    }
    else
      rootQvwm->SetFocus();
    
    // Remove this window from focus stack.
    focusQvwm->preFocus = preFocus;
  }
  else {
    // Remove this window from focus stack.
    while (tmpQvwm->preFocus != NULL) {
      if (tmpQvwm->preFocus == this) {
	tmpQvwm->preFocus = preFocus;
	break;
      }
      tmpQvwm = tmpQvwm->preFocus;
      ASSERT(tmpQvwm);
    }
  }
}

/*
 * RollFocus --
 *   Roll focus stack: that is, the top becomes the bottom, and the second
 *   is the top.
 */
void Qvwm::RollFocus()
{
  Qvwm *tmpQvwm, *preFocusQvwm = focusQvwm;

  ASSERT(focusQvwm);

  /*
   * Do nothing if there is only root window.
   */
  if (focusQvwm == rootQvwm && focusQvwm->preFocus == NULL)
    return;

  /*
   * Give the focus to the window other than root window, if any.
   */
  if (focusQvwm->preFocus == rootQvwm && focusQvwm->preFocus->preFocus != NULL)
    tmpQvwm = focusQvwm->preFocus->preFocus;
  else
    tmpQvwm = focusQvwm->preFocus;

  ASSERT(tmpQvwm);

  tmpQvwm->SetFocus();
  if (tmpQvwm->CheckMapped())
    tmpQvwm->RaiseWindow(True);
  else
    tmpQvwm->RestoreWindow();
  tmpQvwm->AdjustPage();
    
  // Remove the old focus window from focus stack.
  focusQvwm->preFocus = focusQvwm->preFocus->preFocus;

  /*
   * Insert the old focus window in the bottom of focus stack.
   */
  while (tmpQvwm->preFocus != NULL) {
    tmpQvwm = tmpQvwm->preFocus;
    ASSERT(tmpQvwm);
  }
  tmpQvwm->preFocus = preFocusQvwm;
  preFocusQvwm->preFocus = NULL;
}

/*
 * PushFocusStack --
 *   Push this window in the top of focus stack, after remove it if it
 *   exists in focus stack.
 */
void Qvwm::PushFocusStack()
{
  Qvwm* tmpQvwm = focusQvwm;

  ASSERT(focusQvwm);

  /*
   * First, remove this window from focus stack.
   */
  while (tmpQvwm->preFocus != NULL) {
    if (tmpQvwm->preFocus == this) {
      tmpQvwm->preFocus = preFocus;
      break;
    }
    tmpQvwm = tmpQvwm->preFocus;
    ASSERT(tmpQvwm);
  }
  
  /*
   * Insert this window in the top of focus stack.
   */
  preFocus = focusQvwm;              // focusQvwm is focus stack top
  focusQvwm = this;
}

/*
 * GetNextFocus --
 *   Get next focus window in focus stack.
 */
Qvwm* Qvwm::GetNextFocus()
{
  Qvwm* tmpQvwm = preFocus;
  
  if (tmpQvwm == rootQvwm)
    tmpQvwm = tmpQvwm->preFocus;

  if (tmpQvwm == NULL) {
    if (focusQvwm == rootQvwm)
      return focusQvwm->preFocus;
    else {
      ASSERT(focusQvwm);
      return focusQvwm;
    }
  }
  else
    return tmpQvwm;
}

/*
 * ChangeFocusToCursor --
 *   Give the focus to the window where cursor exists.
 */
void Qvwm::ChangeFocusToCursor()
{
  Window junkRoot, junkChild, w;
  Point ptRoot, ptJunk;
  unsigned int mask;
  Qvwm* qvWm;

  XQueryPointer(display, root, &junkRoot, &junkChild, &ptRoot.x, &ptRoot.y,
		&ptJunk.x, &ptJunk.y, &mask);
  XTranslateCoordinates(display, root, root, ptRoot.x, ptRoot.y,
			&ptJunk.x, &ptJunk.y, &w);

  if (XFindContext(display, w, Qvwm::context, (caddr_t *)&qvWm) == XCSUCCESS) {
    qvWm->SetFocus();
    if (ClickToFocus)
      qvWm->RaiseWindow(True);
  }
  else
    rootQvwm->SetFocus();
}
