#include <stdio.h>
#include <string.h>
#include <unistd.h>
#ifdef __EMX__
#include <process.h>
#endif
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/xpm.h>
#ifdef SHAPE
#include <X11/extensions/shape.h>
#endif
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "icon.h"
#include "util.h"
#include "events.h"
#include "startmenu.h"
#include "qvwmrc.h"
#include "bitmaps/icon.xpm"
#include "bitmaps/tile1.xbm"

Icon*		Icon::firstIcon = NULL;
Icon*		Icon::lastIcon  = NULL;
Icon*		Icon::focusIcon = NULL;
XContext	Icon::context;
Pixmap		Icon::pixIcon, Icon::maskIcon;
GC		Icon::gcTileMask = NULL;
Menu*		Icon::ctrlMenu = NULL;

Icon::Icon(Pixmap p, Pixmap msk, char* iconname, char* execname, int x, int y)
: pix(p), mask(msk), name(iconname), exec(execname)
{
  XSetWindowAttributes attributes;
  unsigned long valueMask;
  XRectangle ink, log;

  /*
   * Create icon window.
   */
  attributes.event_mask = ExposureMask;
  attributes.background_pixel = green;
  attributes.override_redirect = True;
  valueMask = CWBackPixel | CWOverrideRedirect | CWEventMask;

  w = XCreateWindow(display, root,
		    -ICON_AREA, -ICON_AREA, ICON_AREA, ICON_AREA,
		    0, CopyFromParent, InputOutput, CopyFromParent,
		    valueMask, &attributes);

  /*
   * Create icon wapper window.
   */
  attributes.event_mask = ButtonPressMask | ButtonReleaseMask |
                          Button1MotionMask;
  valueMask = CWOverrideRedirect | CWEventMask;

  XmbTextExtents(fsIcon, name, strlen(name), &ink, &log);
  wrap = XCreateWindow(display, root,
		       -ICON_AREA, -ICON_AREA,
		       ICON_AREA, ICON_SIZE + 6 + log.height,
		       0, CopyFromParent, InputOnly, CopyFromParent,
		       valueMask, &attributes);
  
  XSaveContext(display, w, context, (caddr_t)this);
  XSaveContext(display, wrap, context, (caddr_t)this);

#ifndef SHAPE
  XGCValues gcv;

  gcv.clip_mask = mask;
  gc = XCreateGC(display, root, GCClipMask, &gcv);
  XSetClipOrigin(display, gc, 21, 2);
#endif

  /*
   * Add icon in icon list
   */
  if (lastIcon == NULL) {
    firstIcon = this;
    prev = NULL;
  }
  else {
    lastIcon->next = this;
    prev = lastIcon;
  }
  next = NULL;
  lastIcon = this;

  rcVirt.x = x;
  rcVirt.y = y;
}

Icon::~Icon()
{
  XDeleteContext(display, w, context);
  XDeleteContext(display, wrap, context);
  XDestroyWindow(display, w);
  XDestroyWindow(display, wrap);

  /*
   * Remove icon in icon list.
   */
  if (this == focusIcon)
    focusIcon = NULL;

  if (prev == NULL)
    firstIcon = next;
  else
    prev->next = next;
  if (next == NULL)
    lastIcon = prev;
  else
    next->prev = prev;
}

/*
 * MapIcon --
 *   Map icon itself and the wrapper.
 */
void Icon::MapIcon()
{
  XMapWindow(display, wrap);
  XLowerWindow(display, wrap);
  XMapWindow(display, w);
  XLowerWindow(display, w);
}

/*
 * unmapIcon --
 *   Unmap icon itself and the wrapper.
 */
void Icon::UnmapIcon()
{
  XUnmapWindow(display, w);
  XUnmapWindow(display, wrap);
}

/*
 * DrawIcon --
 *   Draw icon pixmap and icon name.
 */
void Icon::DrawIcon(Bool focus)
{
  Rect rect;
  char* str;
  Pixmap shapeMask;
  GC gcShape;
  XRectangle ink, log;

  /*
   * Draw icon pixmap.
   */
  if (pix) {
#ifndef SHAPE
    if (!focus) {
      XSetForeground(display, ::gc, green);
      XFillRectangle(display, w, ::gc, 21, 2, ICON_SIZE, ICON_SIZE);
    }
#endif
    XCopyArea(display, pix, w, gc, 0, 0, ICON_SIZE, ICON_SIZE, 21, 2);

    if (focus) {
      if (gcTileMask == NULL)
	CreateIconGC();
      XFillRectangle(display, w, gcTileMask, 21, 2, ICON_SIZE, ICON_SIZE);
    }
  }

  /*
   * Draw icon name.
   */
  str = GetFixName(fsIcon, name, ICON_AREA);
  XmbTextExtents(fsIcon, str, strlen(str), &ink, &log);

  rect.width = log.width;
  rect.height = log.height;
  rect.x = (ICON_AREA - rect.width) / 2;
  rect.y = 2 + ICON_SIZE + 4;

#ifdef SHAPE
  /*
   * Transparentize(?) parts other than icon pixmap and name.
   */
  shapeMask = XCreatePixmap(display, w, ICON_AREA, ICON_AREA, 1);
  gcShape = XCreateGC(display, shapeMask, 0, 0);

  // First, transparentize the whole (pixel value 0 is transparent).
  XSetForeground(display, gcShape, 0);
  XFillRectangle(display, shapeMask, gcShape, 0, 0, ICON_AREA, ICON_AREA);

  XSetForeground(display, gcShape, 1);
  XSetBackground(display, gcShape, 0);

  // Opaque icon pixmap.
  if (mask)
    XCopyPlane(display, mask, shapeMask, gcShape, 0, 0, ICON_SIZE, ICON_SIZE,
	       21, 2, 1);
  else
    XFillRectangle(display, shapeMask, gcShape, 21, 2, ICON_SIZE, ICON_SIZE);

  // Opaque icon name.
  XFillRectangle(display, shapeMask, gcShape, rect.x, rect.y, rect.width,
		 rect.height);

  XShapeCombineMask(display, w, ShapeBounding, 0, 0, shapeMask, ShapeSet);

  XFreePixmap(display, shapeMask);
  XFreeGC(display, gcShape);
#endif // SHAPE

  if (focus)
    XSetForeground(display, ::gc, blue);
  else
    XSetForeground(display, ::gc, green);
    
  XFillRectangle(display, w, ::gc, rect.x, rect.y, rect.width, rect.height);

  XmbTextExtents(fsIcon, str, strlen(str), &ink, &log);
  XSetForeground(display, ::gc, white);
  XmbDrawString(display, w, fsIcon, ::gc, rect.x, rect.y - log.y,
		str, strlen(str));

  delete [] str;
}

/*
 * Button1Press --
 *   Process press of button1 (mouse left button)
 */
void Icon::Button1Press(Time clickTime, const Point& ptRoot)
{
  XEvent ev;
  Point ptOld, ptNew;

  /*
   * First, unmap all menus and move focus to root window.
   */
  Qvwm::UnmapAllMenus();

  rootQvwm->SetFocus();

  /*
   * If double click, execute the function.
   */
  if (IsDoubleClick(iconClickTime, clickTime, ptPrevRoot, ptRoot)) {
#ifdef __EMX__  
    if (spawnl(P_NOWAIT, "cmd.exe", "cmd.exe", "/C", exec, NULL) == -1)
      QvwmError("Can't execute '%s'", exec);
#else
    if (!fork()) {
      char cmd[256];
      
      ASSERT(strlen(exec) + 5 < 256);
      sprintf(cmd, "exec %s", exec);
      if (execl("/bin/sh", "bin/sh", "-c", cmd, NULL) == -1) {
	QvwmError("Can't execute '%s'", exec);
	exit(1);
      }
    }
#endif    
    focusIcon = NULL;
    DrawIcon(False);
    return;
  }
  else {
    focusIcon = this;
    DrawIcon(True);
  }

  iconClickTime = clickTime;

  XLowerWindow(display, w);

  /*
   * Process icon movement.
   */
  ptOld = ptRoot;

  while (1) {
    XMaskEvent(display, ExposureMask | Button1MotionMask | ButtonReleaseMask,
	       &ev);
    switch (ev.type) {
    case Expose:
      DrawIcon(True);
      break;

    case MotionNotify:
      ptNew = Point(ev.xbutton.x_root, ev.xbutton.y_root);
      rc.x += ptNew.x - ptOld.x;
      rcVirt.x += ptNew.x - ptOld.x;
      rc.y += ptNew.y - ptOld.y;
      rcVirt.y += ptNew.y - ptOld.y;

      ptOld = ptNew;
      XMoveWindow(display, w, rc.x, rc.y);
      XMoveWindow(display, wrap, rc.x, rc.y);
      break;

    case ButtonRelease:
      return;
    }
  }
}

/*
 * Button3Press --
 *   Process press of button3.
 */
void Icon::Button3Release(const Point& ptRoot)
{
  Point pt;

  Qvwm::UnmapAllMenus();
  rootQvwm->SetFocus();

  focusIcon = this;
  DrawIcon(True);

  pt = ctrlMenu->GetFixedMenuPos(ptRoot);
  ctrlMenu->MapMenu(pt.x, pt.y);
}

/*
 * RedrawAllIcons --
 *   Redraw all icons in icon list.
 */
void Icon::RedrawAllIcons()
{
  Icon* tmpIcon = firstIcon;
  int count = 0;
  int iconColumnNum;

  iconColumnNum = rcScreen.height / ICON_AREA;

  while (tmpIcon != NULL) {
    if (tmpIcon->rcVirt.x == -1)
      tmpIcon->rcVirt.x = ICON_AREA * (count / iconColumnNum);
    if (tmpIcon->rcVirt.y == -1)
      tmpIcon->rcVirt.y = ICON_AREA * (count % iconColumnNum);

    tmpIcon->rc.x = rcScreen.x + tmpIcon->rcVirt.x;
    tmpIcon->rc.y = rcScreen.y + tmpIcon->rcVirt.y;
    count++;

    XMoveWindow(display, tmpIcon->w, tmpIcon->rc.x, tmpIcon->rc.y);
    XMoveWindow(display, tmpIcon->wrap, tmpIcon->rc.x, tmpIcon->rc.y);

    tmpIcon = tmpIcon->next;
  }
}

/*
 * LineUpAllIcons --
 *   Line up all icons in icon list.
 */
void Icon::LineUpAllIcons()
{
  Icon* tmpIcon = firstIcon;
  int modulo = 0;

  while (tmpIcon != NULL) {
    modulo = tmpIcon->rcVirt.x % ICON_AREA;
    tmpIcon->rcVirt.x += (modulo > ICON_AREA / 2) ? ICON_AREA-modulo : -modulo;
    modulo = tmpIcon->rcVirt.y % ICON_AREA;
    tmpIcon->rcVirt.y += (modulo > ICON_AREA / 2) ? ICON_AREA-modulo : -modulo;
  
    tmpIcon->rc.x = rcScreen.x + tmpIcon->rcVirt.x;
    tmpIcon->rc.y = rcScreen.y + tmpIcon->rcVirt.y;

    XMoveWindow(display, tmpIcon->w, tmpIcon->rc.x, tmpIcon->rc.y);
    XMoveWindow(display, tmpIcon->wrap, tmpIcon->rc.x, tmpIcon->rc.y);

    tmpIcon = tmpIcon->next;
  }
}

/*
 * CreateIconPixmap --
 *   Create default icon pixmap.
 */
void Icon::CreateIconPixmap()
{
  XpmAttributes attr;

  attr.valuemask = XpmColormap | XpmDepth;
  attr.colormap = colormap;
  attr.depth = depth;

  XpmCreatePixmapFromData(display, root, icon, &pixIcon, &maskIcon, &attr);
}

void Icon::CreateIconGC()
{
  Pixmap tile;

  /* 
   * Make clip mask for tile pattern.
   */
  tile = XCreateBitmapFromData(display, root, tile1_bits,
			       tile1_width, tile1_height);
  gcTileMask = XCreateGC(display, root, 0, 0);
  XSetClipMask(display, gcTileMask, tile);
  XSetClipOrigin(display, gcTileMask, 21, 2);
  XSetForeground(display, gcTileMask, blue);
}
