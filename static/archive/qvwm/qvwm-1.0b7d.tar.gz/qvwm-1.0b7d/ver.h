#ifndef _VER_H_
#define _VER_H_

const char* Version = "1.0b7d";

#endif // _VER_H_
