#ifndef _SWITCH_H_
#define _SWITCH_H_

#include "misc.h"

/*
 * TaskSwitcher class
 */
class TaskSwitcher {
private:
  Window frame;
  Window titleFrame;               // title name window included frame
  Window title;                    // title name window excluded frame
  Rect rc;

  static const int BASE_WIDTH = 350;
  static const int BASE_HEIGHT = 62;
  static const int TITLE_WIDTH = 322;
  static const int TITLE_HEIGHT = 24;

public:
  TaskSwitcher();
  ~TaskSwitcher();

  void SwitchTask();
  void DrawTaskSwitcher();
  void DrawTitle(const char* name);
  void DrawRect(int winNumber, int winNum);
  void DrawPixmaps(int winNum);
};

#endif // SWITCH_H
