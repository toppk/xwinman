typedef union {
  char* str;
  MenuItem* mItem;
  AttrStream* aStream;
} YYSTYPE;
#define	VARIABLE	258
#define	MENU	259
#define	SHORTCUT	260
#define	APP	261
#define	EXITDLG	262
#define	VAR	263
#define	STRING	264
#define	FUNC	265
#define	PLUS	266
#define	MINUS	267


extern YYSTYPE yylval;
