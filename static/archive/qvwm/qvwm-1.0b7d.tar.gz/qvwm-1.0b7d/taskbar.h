#ifndef _TASKBAR_H_
#define _TASKBAR_H_

#include "tbutton.h"

class TaskbarButton;
class Qvwm;

/*
 * Taskbar class
 */
class Taskbar {
friend TaskbarButton;
public:
  // Taskbar position
  enum TaskbarPos { BOTTOM, TOP, LEFT, RIGHT };

private:
  Window w;
  Window frame;
  Window clock;
  Rect rc[4];                      // 4 positions where taskbar can exist
  int buttonArea;                  // area size for taskbar button
  TaskbarPos pos;                  // taskbar position
  int clockWidth;

  static const int CLOCK_HEIGHT = 22;

public:
  static const int BASE_HEIGHT = 28;    // base height when TOP or BOTTOM
  static const int INC_HEIGHT =
    TaskbarButton::BUTTON_HEIGHT + TaskbarButton::BETWEEN_SPACE;  // gain

public:
  Taskbar(int width, unsigned int rows);
  ~Taskbar();
  Window GetFrameWin() const { return frame; }
  Rect GetRect() const { return rc[pos]; }
  TaskbarPos GetPos() const { return pos; }
  Bool IsTaskbarWindows(Window win);

  void MapTaskbar();
  void UnmapTaskbar();
  void MoveTaskbar(TaskbarPos tp);
  void MoveTaskbar(const Point& ptRoot);
  void ResizeTaskbar(const Point& ptRoot);
  void RaiseTaskbar();
  void DrawTaskbar();
  void DrawClock();

  void Exposure(Window win);
  void Button1Motion(Window win, const Point& ptRoot);
};

#endif // _TASKBAR_H_
