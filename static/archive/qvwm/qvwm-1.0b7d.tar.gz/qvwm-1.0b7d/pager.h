#ifndef _PAGER_H_
#define _PAGER_H_

#include "misc.h"
#include "util.h"

/*
 * Pager class
 */
class Pager {
friend Miniature;
private:
  Window frame;
  Window title;
  Window pages;             // window standing for whole page
  Window visual;            // window standing for current page
  Rect rc;                  // size and position of frame
  Rect rcOrig;              // size and position of pages
  Point gravity;            // gravity offset (see util.cc)
  Dim pageSize;             // size of one page in pager

  static const int BORDER_WIDTH = 3;
  static const int TITLE_HEIGHT = 7;

public:
  Pager(InternGeom geom);
  ~Pager();

  Window GetVisualWin() const { return visual; }

  Bool IsPagerWindows(Window win);
  void CalcPagerPos();
  void RecalcPager();
  Point ConvertToPagerPos(const Point& pt);
  Rect ConvertToPagerSize(const Rect& rect);
  Point ConvertToRealPos(const Point& pt);

  void DrawPages();
  void DrawVisualPage();
  void DrawFrame();
  void Button1Press(Window win, const Point& ptRoot, const Point& ptWin);
  void Button3Press(const Point& ptRoot);
  void Exposure(Window win);
};

/*
 * Miniature class
 *   Miniture window in pager according to real window.
 */
class Miniature {
friend Pager;
private:
  Window wMini;
  Rect rc;
  Qvwm* qvWm;
  Bool focus;
  
public:
  static XContext context;

public:
  Miniature(Qvwm* qvWm, const Rect& rect);
  ~Miniature();

  void SetFocus() { focus = True; DrawMiniature(); }
  void ResetFocus() { focus = False; DrawMiniature(); }

  void MapMiniature() { XMapWindow(display, wMini); }
  void UnmapMiniature() { XUnmapWindow(display, wMini); }
  void RaiseMiniature() { XRaiseWindow(display, wMini); }
  void MoveMiniature(const Point& pt);
  void MoveResizeMiniature(const Rect& rect);
  void DrawMiniature();
  void Button1Press(const Point& ptWin);
  void Button2Press(const Point& ptRoot);

  static void RestackMiniatures(Miniature* minis[], int nminis);
};

#endif // _PAGER_H_
