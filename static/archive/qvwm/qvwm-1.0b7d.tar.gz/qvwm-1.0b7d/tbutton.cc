#include <stdio.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "main.h"
#include "misc.h"
#include "util.h"
#include "qvwm.h"
#include "tbutton.h"
#include "sbutton.h"
#include "taskbar.h"
#include "startmenu.h"
#include "qvwmrc.h"
#include "paging.h"

Rect TaskbarButton::rcTButton(0, 0, 160, TaskbarButton::BUTTON_HEIGHT);
XFontSet* TaskbarButton::fsb;

TaskbarButton::TaskbarButton(Qvwm* qvwm, const Rect& rc, Pixmap p, GC pgc,
			     char *btnname)
: Button(taskBar->w, rc), focus(False), qvWm(qvwm), pix(p), gc(pgc),
  name(btnname), shortname(btnname)
{
}

TaskbarButton::~TaskbarButton()
{
  if (shortname != name)
    delete [] shortname;
  delete [] name;

  ASSERT(qvWm);

  if (pix != pixLogo && !qvWm->CheckFlags(SMALLPIX)) {
    XFreePixmap(display, pix);
    XFreeGC(display, gc);
  }
}

void TaskbarButton::SetName(char *str)
{
  if (shortname != name)
    delete [] shortname;
  if (name)
    delete [] name;

  name = str;
  shortname = GetFixName(fsTaskbar, name, (int)rc.width-24);
}

/*
 * MapButton --
 *   Map taskbar button.
 */
void TaskbarButton::MapButton()
{
  ASSERT(qvWm);

  if (!qvWm->CheckFlags(TRANSIENT)) {
    RedrawAllTaskbarButtons();
    Button::MapButton();
  }
}

/*
 * UnmapButton --
 *   Unmap taskbar button.
 */
void TaskbarButton::UnmapButton()
{
  ASSERT(qvWm);

  if (!qvWm->CheckFlags(TRANSIENT)) {
    Button::UnmapButton();
    RedrawAllTaskbarButtons();
  }
}

/*
 * DrawButton --
 *   Draw taskbar button.
 */
void TaskbarButton::DrawButton()
{
  ASSERT(qvWm);
  /*
   * No button for the transient window.
   */
  if (qvWm->CheckFlags(TRANSIENT))
    return;

  FillBackground();
  Button::DrawButton();

  if (CheckState(PUSH) && focus) {
    XSetForeground(display, ::gc, white);
    XDrawLine(display, frame, ::gc, 2, 2, rc.width, 2);
  }

  /*
   * Draw the pixmap of the taskbar button.
   */
  if (state == PUSH) {
    XSetClipOrigin(display, gc, 4, 4);
    XCopyArea(display, pix, frame, gc, 0, 0, SYMBOL_WIDTH, SYMBOL_HEIGHT,
	      4, 4);
  }
  else {
    XSetClipOrigin(display, gc, 4, 3);
    XCopyArea(display, pix, frame, gc, 0, 0, SYMBOL_WIDTH, SYMBOL_HEIGHT,
	      4, 3);
  }

  // Draw the title of the taskbar button.
  DrawName();
}

/*
 * FillBackground --
 *   Paint the background of taskbar button gray or tile pattern.
 */
void TaskbarButton::FillBackground()
{
  if (CheckState(PUSH) && focus)
    XFillRectangle(display, frame, gcTile, 2, 3, rc.width-4, rc.height-5);
  else {
    XSetForeground(display, ::gc, gray);
    XFillRectangle(display, frame, ::gc, 2, 2, rc.width-4, rcTButton.height-4);
  }
}

/*
 * DrawName --
 *   Draw the text taskbar button.
 */
void TaskbarButton::DrawName()
{
  ASSERT(qvWm);

  if (qvWm->CheckFlags(TRANSIENT))
    return;

  XRectangle ink, log;
  int y;

  XmbTextExtents(fsTaskbar, shortname, strlen(shortname), &ink, &log);
  y = (BUTTON_HEIGHT - log.height) / 2 - log.y;

  if (CheckState(PUSH)) {
    if (UseBoldFont && focus) {
      XSetForeground(display, ::gc, black);
      XmbDrawString(display, frame, *fsb, ::gc, 22, y+1,
		    shortname, strlen(shortname));
    }
    else {
      XSetForeground(display, ::gc, black);
      XmbDrawString(display, frame, fsTaskbar, ::gc, 22, y+1,
		    shortname, strlen(shortname));
      if (focus)
	XmbDrawString(display, frame, fsTaskbar, ::gc, 23, y+1,
		      shortname, strlen(shortname));
    }
  }
  else {
    if (UseBoldFont && focus) {
      XSetForeground(display, ::gc, black);
      XmbDrawString(display, frame, *fsb, ::gc, 22, y,
		    shortname, strlen(shortname));
    }
    else {
      XSetForeground(display, ::gc, black);
      XmbDrawString(display, frame, fsTaskbar, ::gc, 22, y,
		    shortname, strlen(shortname));
      if (focus)
	XmbDrawString(display, frame, fsTaskbar, ::gc, 23, y,
		      shortname, strlen(shortname));
    }
  }
}

/*
 * Button1Press --
 *   Process the press of button1(mouse left button).
 */
void TaskbarButton::Button1Press()
{
  Qvwm::UnmapAllMenus();
  
  ASSERT(qvWm);

  if (!qvWm->CheckFocus())
    Button::Button1Press();
}

/*
 * ExecButtonFunc --
 *   Give the focus to the taskbar button and the corresponding window.
 */
void TaskbarButton::ExecButtonFunc(ButtonState bs)
{
  if (bs == PUSH) {
    ASSERT(qvWm);

    if (qvWm->CheckStatus(MINIMIZE_WINDOW))
      qvWm->RestoreWindow();
    else {
      if (!qvWm->CheckFocus())
	qvWm->SetFocus();
      qvWm->RaiseWindow(True);
      qvWm->AdjustPage();
    }

    /*
     * When button is released, state is set to NORMAL in default.
     * So state sets to PUSH here.
     */
    if (qvWm->CheckFlags(NOFOCUS))
      state = NORMAL;
    else
      state = PUSH;
  }
}
  
/*
 * Button3Release --
 *   Process the release of button3(mouse right button).
 */
void TaskbarButton::Button3Release(const Point& ptRoot)
{
  Point ptNew;
  Bool noFocus = False;

  /*
   * When button3 is released, map menu if start menu isn't mapped.
   */
  if (startMenu == NULL || !startMenu->CheckMapped()) {
    ASSERT(Qvwm::focusQvwm);

    if (Qvwm::focusQvwm->CheckMenuMapped())
      Qvwm::focusQvwm->UnmapMenu();

    ASSERT(qvWm);
    /*
     * Temporarily, give the focus.
     */
    if (qvWm->CheckFlags(NOFOCUS)) {
      qvWm->ResetFlags(NOFOCUS);
      noFocus = True;
    }
    
    if (!qvWm->CheckFocus())
      qvWm->SetFocus();
    qvWm->RaiseWindow(True);
    qvWm->AdjustPage();
    
    ASSERT(qvWm->ctrlMenu);

    qvWm->ctrlMenu->SetQvwm(qvWm);
    ptNew = qvWm->ctrlMenu->GetFixedMenuPos(ptRoot);
    qvWm->ctrlMenu->MapMenu(ptNew.x, ptNew.y);

    if (noFocus)
      qvWm->SetFlags(NOFOCUS);
  }
}

/*
 * RedrawAllTaskbarButtons --
 *   Redraw all taskbar buttons.
 */
void TaskbarButton::RedrawAllTaskbarButtons()
{
  Qvwm* tmpQvwm = rootQvwm;
  unsigned int buttonWidth;
  int row, col;
  int buttonNum = 0, count = 0;
  Taskbar::TaskbarPos pos;
  StartButton *sButton = (StartButton *)rootQvwm->tButton;
  int x, y;

  ASSERT(sButton);
  ASSERT(rootQvwm->tButton);

  XMoveWindow(display, rootQvwm->tButton->frame, rcTButton.x, rcTButton.y);

  ASSERT(taskBar);

  pos = taskBar->GetPos();

  /*
   * Taskbar buttons are unvisible when the taskbar is shown minimumly.
   */
  if (taskBar->rc[pos].height == 6)
    rcTButton.y = -10000;
  if (taskBar->rc[pos].width == 6)
    rcTButton.x = -10000;

  /*
   * Adjust the position and the size of the start button.
   */
  rootQvwm->tButton->rc.x = rcTButton.x;
  rootQvwm->tButton->rc.y = rcTButton.y;
  if (taskBar->rc[pos].width > sButton->buttonWidth + 6)
    rootQvwm->tButton->rc.width = sButton->buttonWidth;
  else {
    rootQvwm->tButton->rc.width = taskBar->rc[pos].width - 6;
    if (rootQvwm->tButton->rc.width == 0)
      rootQvwm->tButton->rc.width = 1;
  }

  XMoveResizeWindow(display, rootQvwm->tButton->frame,
		    rootQvwm->tButton->rc.x, rootQvwm->tButton->rc.y,
		    rootQvwm->tButton->rc.width, rootQvwm->tButton->rc.height);

  /*
   * Count the number of taskbar buttons.
   */
  while ((tmpQvwm = tmpQvwm->GetNext()) != NULL)
    if (!tmpQvwm->CheckFlags(TRANSIENT) && !tmpQvwm->CheckFlags(NOTBUTTON) &&
	(tmpQvwm->CheckMapped() || tmpQvwm->CheckStatus(MINIMIZE_WINDOW)))
      buttonNum++;
     
  if (buttonNum == 0)
    return;

  /*
   * According to taskbar position, determine the way arranging buttons.
   */
  switch (pos) {
  case Taskbar::BOTTOM:
  case Taskbar::TOP:
    col = taskBar->rc[pos].height / (rcTButton.height + BETWEEN_SPACE);
    buttonWidth = taskBar->buttonArea*col / buttonNum - BETWEEN_SPACE;
    if (buttonWidth > rcTButton.width)
      buttonWidth = rcTButton.width;
    if (buttonWidth == 0)
      buttonWidth = 1;
    row = taskBar->buttonArea / buttonWidth;
    break;

  case Taskbar::LEFT:
  case Taskbar::RIGHT:
    row = (buttonNum * (rcTButton.height + BETWEEN_SPACE) - 1)
              / taskBar->buttonArea + 1;
    buttonWidth = (taskBar->rc[pos].width - 5) / row - BETWEEN_SPACE;
    if (buttonWidth == 0)
      buttonWidth = 1;
    break;
  }

  /*
   * Reposition all taskbar buttons.
   */
  tmpQvwm = rootQvwm;

  while ((tmpQvwm = tmpQvwm->GetNext()) != NULL) {
    if (tmpQvwm->CheckFlags(TRANSIENT) || tmpQvwm->CheckFlags(NOTBUTTON) ||
	(!tmpQvwm->CheckMapped() && !tmpQvwm->CheckStatus(MINIMIZE_WINDOW)))
      continue;

    TaskbarButton* tb = tmpQvwm->tButton;

    switch (taskBar->pos) {
    case Taskbar::BOTTOM:
    case Taskbar::TOP:
      x = rcTButton.x + sButton->buttonWidth + 4
	+ (buttonWidth + BETWEEN_SPACE) * (count % row);
      y = rcTButton.y + (count / row) * (rcTButton.height + BETWEEN_SPACE);
      tb->rc = Rect(x, y, buttonWidth, rcTButton.height);
      break;

    case Taskbar::LEFT:
    case Taskbar::RIGHT:
      x = rcTButton.x + (count % row) * (buttonWidth + BETWEEN_SPACE);
      y = rcTButton.y + BUTTON_HEIGHT + BETWEEN_SPACE
	   + (rcTButton.height + BETWEEN_SPACE) * (count / row);
      tb->rc = Rect(x, y, buttonWidth, rcTButton.height);
      break;
    }
    count++;

    XMoveResizeWindow(display, tb->frame,
		      tb->rc.x, tb->rc.y, tb->rc.width, tb->rc.height);

    // Free old short name
    if (tb->name != tb->shortname)
      delete [] tb->shortname;
    tb->shortname = GetFixName(fsTaskbar, tb->name, (int)tb->rc.width-24);
  }
}                         
