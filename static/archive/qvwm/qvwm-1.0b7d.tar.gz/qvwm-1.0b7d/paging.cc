#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <sys/time.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/cursorfont.h>
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "qvwmrc.h"
#include "paging.h"
#include "pager.h"
#include "events.h"
#ifdef __EMX__
#include <emx/syscalls.h>
#define usleep __sleep2
#endif

Paging::Paging(const Point& topLeft, const Dim& size)
: origin(Point(0, 0)), rcVirt(topLeft.x, topLeft.y, size.width, size.height)
{
  XSetWindowAttributes attributes;
  unsigned long valueMask;
  Cursor cs;
  Rect rcRoot = rootQvwm->GetRect();
  unsigned int fontCursor[4] = {XC_bottom_side, XC_top_side, 
				XC_left_side, XC_right_side};
  Rect rcPaging[4] = {Rect(0, rcRoot.height - PagingBeltSize,
			   rcRoot.width, PagingBeltSize),
                      Rect(0, 0, rcRoot.width, PagingBeltSize),
		      Rect(0, 0, PagingBeltSize, rcRoot.height),
		      Rect(rcRoot.width - PagingBeltSize, 0,
			   PagingBeltSize, rcRoot.height)};

  /*
   * Create transparent, long and slender windows in the 4 edges of screen
   * for paging.
   */
  attributes.override_redirect = True;
  attributes.event_mask = EnterWindowMask | LeaveWindowMask |
    Button1MotionMask;

  valueMask = CWEventMask | CWOverrideRedirect;

  if (PagingBeltSize > 0) {
    for (int i = 0; i < 4; i++) {
      side[i] = XCreateWindow(display, root,
			      rcPaging[i].x, rcPaging[i].y,
			      rcPaging[i].width, rcPaging[i].height,
			      0, CopyFromParent, InputOnly, CopyFromParent,
			      valueMask, &attributes);
      
      cs = XCreateFontCursor(display, fontCursor[i]);
      XDefineCursor(display, side[i], cs);
    }

    MapSides();
  }
  else {
    for (int i = 0; i < 4; i++)
      side[i] = None;
  }
}

Paging::~Paging()
{
  if (PagingBeltSize > 0)
    for (int i = 0; i < 4; i++)
      XDestroyWindow(display, side[i]);
}

/*
 * IsPagingBelt --
 *   Return True if the window is one of transparent windows for paging.
 */
Bool Paging::IsPagingBelt(Window win)
{
  if (win == side[0] || win == side[1] || win == side[2] || win == side[3])
    return True;
  else
    return False;
}

/*
 * HandlePaging --
 *   Do paging if the cursor is in screen edge and if paging resistance
 *   time was expired.
 *   Return True if did paging.
 */
Point Paging::HandlePaging(const Point& pt)
{      
  Taskbar::TaskbarPos pos = GetDisplayArea(pt);
  Rect rcRoot = rootQvwm->GetRect();
  Rect rect(PagingBeltSize,
	    PagingBeltSize,
	    rcRoot.width - PagingBeltSize * 2,
	    rcRoot.height - PagingBeltSize * 2);

  if (PagingBeltSize == 0)
    return Point(0, 0);

  ASSERT(pos >= 0 && pos < 4); /* XXX */

  /*
   * Return unless in the area where paging can be done.
   */
  if (InRect(pt, rect) || !mapped[pos])
    return Point(0, 0);

  /*
   * Agter wait for PagingResistance ticks without any events, do paging.
   */
  int ticks = 0;
  XEvent ev;
  Point ptNew;

  while (ticks < PagingResistance) {
    ticks += 10;
    usleep(10000);
    
    if (XCheckTypedEvent(display, MotionNotify, &ev)) {
      ptNew = Point(ev.xbutton.x_root, ev.xbutton.y_root);
      if (InRect(ptNew, rect))
	return Point(0, 0);
    }
    else if (XCheckTypedWindowEvent(display, side[pos], LeaveNotify, &ev))
      return Point(0, 0);
  }

  ptNew = PagingProc(side[pos]);

  XSync(display, 0);
  while (XCheckTypedEvent(display, Expose, &ev))
    ExposeProc(ev.xexpose.window);

  return ptNew;
}

/*
 * PagingProc --
 *   Do paging to the direction of win.
 */
Point Paging::PagingProc(Window win)
{
  Point ptDelta(0, 0);
  Rect rcRoot = rootQvwm->GetRect();
  Window junkRoot, junkChild;
  Point ptRoot, ptJunk;
  unsigned int mask;

  if (win == side[2])
    ptDelta.x = -(PagingMovement * rcRoot.width / 100);
  else if (win == side[3])
    ptDelta.x = PagingMovement * rcRoot.width / 100;
  else if (win == side[1])
    ptDelta.y = -(PagingMovement * rcRoot.height / 100);
  else if (win == side[0])
    ptDelta.y = PagingMovement * rcRoot.height / 100;
  else
    return Point(0, 0);

  Point oldOrigin = origin;

  origin.x += ptDelta.x;
  origin.y += ptDelta.y;

  PagingAllWindows(oldOrigin);

  XQueryPointer(display, root, &junkRoot, &junkChild, &ptRoot.x, &ptRoot.y,
		&ptJunk.x, &ptJunk.y, &mask);
  Point pt(ptRoot.x - ptDelta.x, ptRoot.y - ptDelta.y);

  if (pt.x < PagingBeltSize)
    pt.x = PagingBeltSize;
  else if (pt.x > (int)rcRoot.width-PagingBeltSize-1)
    pt.x = (int)rcRoot.width - PagingBeltSize - 1;
  if (pt.y < PagingBeltSize)
    pt.y = PagingBeltSize;
  else if (pt.y > (int)rcRoot.height-PagingBeltSize-1)
    pt.y = (int)rcRoot.height - PagingBeltSize - 1;

  XWarpPointer(display, None, root, 0, 0, 0, 0, pt.x, pt.y);

  return ptDelta;
}

/*
 * PagingProc --
 *   Do paging to the position of pt.
 */
void Paging::PagingProc(const Point& pt)
{
  Point oldOrigin = origin;

  origin = pt;
  PagingAllWindows(oldOrigin);
}

/*
 * PagingAllWindows --
 *   Move all windows according to paging movement.
 */
void Paging::PagingAllWindows(const Point& oldOrigin)
{
  Qvwm* qvWm = rootQvwm; 
  Rect rect;

  MapSides();

  while ((qvWm = qvWm->GetNext()) != NULL) {
    rect = qvWm->GetRect();

    if (qvWm->CheckFlags(STICKY)) {
      if (UsePager) {
	Point pt(rect.x - oldOrigin.x + origin.x,
		 rect.y - oldOrigin.y + origin.y);

	/*
	 * rc of STICKY window changes on paging.
	 */
	rect.x = pt.x;
	rect.y = pt.y;
	qvWm->SetRect(rect);

	ASSERT(qvWm->mini);
	qvWm->mini->MoveMiniature(pager->ConvertToPagerPos(pt));
      }
      continue;
    }
				  
    XMoveWindow(display, qvWm->GetFrameWin(),
		rect.x-origin.x, rect.y-origin.y);
    qvWm->SendConfigureEvent();
  }

  if (UsePager) {
    ASSERT(pager);
    pager->DrawVisualPage();
  }
}

void Paging::MapSides()
{
  Rect rcRoot = rootQvwm->GetRect();

  if (PagingBeltSize == 0)
    return;

  // Left side
  if (origin.x > rcVirt.x*(int)rcRoot.width) {
    XMapWindow(display, side[2]);
    mapped[2] = True;
  }
  else {
    origin.x = rcVirt.x * (int)rcRoot.width;
    XUnmapWindow(display, side[2]);
    mapped[2] = False;
  }

  // Right side
  if (origin.x < (rcVirt.x+(int)rcVirt.width-1)*(int)rcRoot.width) {
    XMapWindow(display, side[3]);
    mapped[3] = True;
  }
  else {
    origin.x = (rcVirt.x + rcVirt.width - 1) * (int)rcRoot.width;
    XUnmapWindow(display, side[3]);
    mapped[3] = False;
  }

  // Bottom side
  if (origin.y > rcVirt.y*(int)rcRoot.height) {
    XMapWindow(display, side[1]);
    mapped[1] = True;
  }
  else {
    origin.y = rcVirt.y * (int)rcRoot.height;
    XUnmapWindow(display, side[1]);
    mapped[1] = False;
  }

  // Top side
  if (origin.y < (rcVirt.y+(int)rcVirt.height-1)*(int)rcRoot.height) {
    XMapWindow(display, side[0]);
    mapped[0] = True;
  }
  else {
    origin.y = (rcVirt.y + rcVirt.height - 1) * (int)rcRoot.height;
    XUnmapWindow(display, side[0]);
    mapped[0] = False;
  }
}

/*
 * RaisePagingBelt --
 *   Raise transparent windows for paging.
 */
void Paging::RaisePagingBelt()
{
  if (PagingBeltSize == 0)
    return;

  for (int i = 0; i < 4; i++)
    XRaiseWindow(display, side[i]);
}
