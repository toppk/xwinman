#ifndef _UTIL_H_
#define _UTIL_H_

#include "taskbar.h"

/*
 * Qvwm function number.
 */
enum FuncNumber {
  Q_NONE,
  Q_SEPARATOR,
  Q_DIR,
  Q_EXEC,
  Q_RESTORE,
  Q_MOVE,
  Q_RESIZE,
  Q_MINIMIZE,
  Q_MAXIMIZE,
  Q_CLOSE,
  Q_KILL,
  Q_EXIT,
  Q_BOTTOM,
  Q_TOP,
  Q_LEFT,
  Q_RIGHT,
  Q_RESTART,
  Q_CHANGEWINDOW,
  Q_SWITCHTASK,
  Q_POPUPSTARTMENU,
  Q_POPUPMENU,
  Q_POPDOWNMENU,
  Q_POPDOWNALLMENU,
  Q_UPFOCUS,
  Q_DOWNFOCUS,
  Q_RIGHTFOCUS,
  Q_LEFTFOCUS,
  Q_ACTION,
  Q_LEFTPAGING,
  Q_RIGHTPAGING,
  Q_UPPAGING,
  Q_DOWNPAGING,
  Q_LINEUP,
  Q_OTHERWM,
};

/*
 * The origin of menu.
 */
struct MenuItem {
  char* name;
  char* file;
  FuncNumber func;
  char* exec;
  int x, y;
  MenuItem* next;
  MenuItem* child;
};

/*
 * ShortCutKey.
 */
struct ShortCutKey {
  KeySym sym;                     // symbol
  unsigned int mod;               // modifier
  FuncNumber func;                // function
};

/*
 * Fontset and fontname.
 */
struct FsNameSet {
  XFontSet* fs;
  char** fontname;
};

/*
 * Attribute bit and the name.
 */
struct AttrNameSet {
  char* name;
  unsigned long flag;
  Bool act;
};

class AppAttr {
public:
  unsigned long flags;
  char* small_file;
  Pixmap small_pix;
  GC small_gc;
  char* large_file;
  Pixmap large_pix;
  GC large_gc;

  AppAttr() : flags(0), small_file(NULL), small_pix(None), small_gc(NULL), 
              large_file(NULL), large_pix(None), large_gc(NULL) {}
  ~AppAttr() {
    if (small_pix != None) {
      XFreePixmap(display, small_pix);
      XFreeGC(display, small_gc);
    }
    if (large_pix != None) {
      XFreePixmap(display, large_pix);
      XFreeGC(display, large_gc);
    }
  }
};

/*
 * Size and bitmask from GetGeometry().
 */
class InternGeom {
public:
  Rect rc;
  Point gravity;

public:
  InternGeom() {}
  InternGeom(int x, int y, unsigned int width, unsigned int height,
	     const Point& grav)
    : rc(Rect(x, y, width, height)), gravity(grav) {}
};

/*
 * Offset
 */
const int CENTER = -1;
const int EAST = -2;
const int WEST = 0;
const int NORTH = 0;
const int SOUTH = -2;

extern Point GravityOffset[];

/*
 * inline function
 */
inline int Max(int x, int y)
{
  return ((x > y) ? x : y);
}

inline int RoundDown(int x, int y)
{
  return x / y * y;
}

class Menu;

extern Bool InRect(const Point& pt, const Rect& rc);
extern Bool IsDoubleClick(Time prevTime, Time clickTime, const Point& ptPrev,
			  const Point& ptClick);
extern int GetMenuItemNum(const MenuItem* mItem);
extern Bool CreatePixmapFromFile(const char* const file, Pixmap& pix,
				 Pixmap& mask, GC& gc);
extern Taskbar::TaskbarPos GetDisplayArea(const Point& pt);
extern char* GetFixName(XFontSet& fs, const char* name, int width);
extern void ExecShortCutKey(int num, const ShortCutKey sck[],
			    const XKeyEvent* ev, Menu* menu);
extern Bool MappedNotOverride(Window w, long* state);

#ifndef HAVE_USLEEP
extern void usleep(unsigned long);
#endif

#endif // _UTIL_H_
