#ifndef _EXITDLG_H_
#define _EXITDLG_H_

// Resource ID
#define STARTID         100
#define IDS_1           200

const int ExitDlgWidth = 385;

class Qvwm;
class MenuItem;

extern void ExitDlg(Qvwm* qvWm, MenuItem* mItem);

#endif // _EXITDLG_H_
