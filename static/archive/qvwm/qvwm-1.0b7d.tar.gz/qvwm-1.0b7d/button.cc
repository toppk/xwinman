#include <stdio.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "main.h"
#include "misc.h"
#include "button.h"
#include "events.h"

XContext Button::context;

Button::Button(Window pWin, const Rect& rect) : rc(rect), parent(pWin)
{
  XSetWindowAttributes attributes;
  unsigned long valueMask;

  // initialize state
  state = NORMAL;

  attributes.background_pixel = gray;
  attributes.event_mask = ExposureMask | ButtonPressMask | ButtonReleaseMask |
                          EnterWindowMask | LeaveWindowMask;
  valueMask = CWBackPixel | CWEventMask;

  frame = XCreateWindow(display, parent,
			rc.x, rc.y, rc.width, rc.height, 0,
			CopyFromParent, InputOutput, CopyFromParent,
			valueMask, &attributes);

  // save frame window id to context
  XSaveContext(display, frame, Button::context, (caddr_t)this);
}

Button::~Button()
{
  XDestroyWindow(display, frame);

  // delete frame window id to context
  XDeleteContext(display, frame, Button::context);
}  

/*
 * MapButton --
 *   Map button frame.
 */
void Button::MapButton()
{
  XMapWindow(display, frame);
}

/*
 * UnmapButton --
 *   Unmap button frame.
 */
void Button::UnmapButton()
{
  XUnmapWindow(display, frame);
}

/*
 * DrawButton --
 *   Draw button according to state.
 */
void Button::DrawButton()
{
  XPoint xp[3];

  xp[0].x = rc.width - 2;
  xp[0].y = 0;
  xp[1].x = 0;
  xp[1].y = 0;
  xp[2].x = 0;
  xp[2].y = rc.height - 2;

  if (state == PUSH)
    XSetForeground(display, gc, black);
  else
    XSetForeground(display, gc, white);
  XDrawLines(display, frame, gc, xp, 3, CoordModeOrigin);

  xp[0].x = rc.width - 1;
  xp[0].y = 0;
  xp[1].x = rc.width - 1;
  xp[1].y = rc.height - 1;
  xp[2].x = 0;
  xp[2].y = rc.height - 1;

  if (state == PUSH)
    XSetForeground(display, gc, white);
  else
    XSetForeground(display, gc, black);
  XDrawLines(display, frame, gc, xp, 3, CoordModeOrigin);

  xp[0].x = rc.width - 3;
  xp[0].y = 1;
  xp[1].x = 1;
  xp[1].y = 1;
  xp[2].x = 1;
  xp[2].y = rc.height - 3;

  if (state == PUSH)
    XSetForeground(display, gc, darkGray);
  else
    XSetForeground(display, gc, lightGray);
  XDrawLines(display, frame, gc, xp, 3, CoordModeOrigin);

  xp[0].x = rc.width - 2;
  xp[0].y = 1;
  xp[1].x = rc.width - 2;
  xp[1].y = rc.height - 2;
  xp[2].x = 1;
  xp[2].y = rc.height - 2;
  
  if (state == PUSH)
    XSetForeground(display, gc, lightGray);
  else
    XSetForeground(display, gc, darkGray);
  XDrawLines(display, frame, gc, xp, 3, CoordModeOrigin);
}

/*
 * MoveResizeButton --
 *   Move and resize button.
 */
void Button::MoveResizeButton(const Rect& rect)
{
  rc = rect;

  XMoveResizeWindow(display, frame, rc.x, rc.y, rc.width, rc.height);
}  

/*
 * Button1Press --
 *   Process press of button1 (mouse left button)
 */
void Button::Button1Press()
{
  XEvent ev;
  ButtonState bs;

  state = PUSH;
  DrawButton();

  while (1) {
    XMaskEvent(display, EnterWindowMask | LeaveWindowMask | ButtonReleaseMask,
	       &ev);
    switch (ev.type) {
    case EnterNotify:
      if (ev.xcrossing.window == frame) {
	state = PUSH;
	DrawButton();
      }
      break;

    case LeaveNotify:
      if (ev.xcrossing.window == frame) {
	state = NORMAL;
	DrawButton();
      }
      break;

    case ButtonRelease:
      if (ev.xbutton.state & Button1Mask) {
	bs = state;
	state = NORMAL;

	ExecButtonFunc(bs);
	DrawButton();
	return;
      }
    }
  }
}
