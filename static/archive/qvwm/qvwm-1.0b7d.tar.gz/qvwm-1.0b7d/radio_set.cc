#include <stdio.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "misc.h"
#include "qvwm.h"
#include "radio_set.h"
#include "radio_button.h"

RadioSet::RadioSet(RadioButton* rbutton[], int rbNum, ResourceId res_id,
		   ResourceId initId)
: rb(rbutton), num(rbNum), rid(res_id)
{
  int i;

  for (i = 0; i < rbNum; i++) {
    ASSERT(rb[i]);
    rb[i]->SetRS(this);
  }

  for (i = 0; i < rbNum; i++) 
    if (rb[i]->GetResId() == initId)
      rbFocus = rb[i];

  ASSERT(rbFocus);

  rbFocus->SetStatus(RADIO_CHECK);
}

RadioSet::~RadioSet()
{
  for (int i = 0; i < num; i++)
    delete rb[i];
  if (num > 0)
    delete [] rb;
}

/*
 * MapRadioButtons --
 *   Map all radio buttons in this radio set.
 */
void RadioSet::MapRadioButtons()
{
  for (int i = 0; i < num; i++) {
    ASSERT(rb[i]);
    rb[i]->MapButton();
  }
}

/*
 * GetFocusRB --
 *   Get focus radio button in this radio set.
 */
ResourceId RadioSet::GetFocusRB()
{
  for (int i = 0; i < num; i++)
    if (rbFocus == rb[i]) {
      ASSERT(rb[i]);
      return rb[i]->GetResId();
    }

  return NO_ID;
}
