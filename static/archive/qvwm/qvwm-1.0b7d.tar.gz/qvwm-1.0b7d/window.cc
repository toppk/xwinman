#include <stdio.h>
#include <signal.h>
#include <sys/time.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#ifdef SHAPE
#include <X11/extensions/shape.h>
#endif
#include "main.h"
#include "qvwm.h"
#include "misc.h"
#include "util.h"
#include "fbutton.h"
#include "tbutton.h"
#include "menu.h"
#include "qvwmrc.h"
#include "pager.h"
#include "timer.h"
#if defined(sun) && !defined(SVR4)
#include <sys/resource.h>
#endif

Qvwm* Qvwm::activeQvwm = NULL;

static void RaiseSoon();

/*
 * MapWindows --
 *   Map this window and the transient windows that should be mapped.
 */
void Qvwm::MapWindows()
{
  /*
   * Map itself and set mapped to parent transient window list.
   */
  MapWindow();

  if (CheckFlags(TRANSIENT) && transientFor) {
    QvwmList* qvList = transientFor->transient;
    while (qvList) {
      if (qvList->GetQvwm() == this) {
	qvList->SetMapped();
	break;
      }
      qvList = qvList->GetNext();
    }
  }

  /*
   * Map transient windows of this window.
   */
  QvwmList* qvList = transient;
  while (qvList) {
    if (qvList->CheckMapped()) {
      Qvwm* qvWm = qvList->GetQvwm();

      ASSERT(qvWm);
      qvWm->MapWindow();
      if (UsePager) {
	ASSERT(qvWm->mini);
	qvWm->mini->MapMiniature();
      }
    }
    qvList = qvList->GetNext();
  }

  RaiseWindow(True);

  if (UsePager) {
    ASSERT(mini);
    mini->MapMiniature();
  }
}

/*
 * MapWindow --
 *   Map window.
 */
void Qvwm::MapWindow()
{
  mapped = True;

  XMapWindow(display, frame);

  if (CheckFlags(BORDER)) {
    for (int i = 0; i < 4; i++) {
      XMapWindow(display, side[i]);
      XMapWindow(display, corner[i]);
    }
  }
  else {
    for (int i = 0; i < 4; i++) {
      XUnmapWindow(display, side[i]);
      XUnmapWindow(display, corner[i]);
    }
  }

  if (CheckFlags(TITLE)) {
    XMapRaised(display, title);
    if (CheckFlags(CTRL_MENU))
      XMapWindow(display, ctrl);
    else
      XUnmapWindow(display, ctrl);
    if (CheckFlags(BUTTON1))
      fButton[0]->MapButton();
    else
      fButton[0]->UnmapButton();
    if (CheckFlags(BUTTON2))
      fButton[1]->MapButton();
    else
      fButton[1]->UnmapButton();
    if (CheckFlags(BUTTON3) || CheckFlags(WM_DELETE_WINDOW)) {
      SetFlags(BUTTON3);
      fButton[2]->MapButton();
    }
    else
      fButton[2]->UnmapButton();
  }
  else
    XUnmapWindow(display, title);

  XMapRaised(display, parent);
  XMapWindow(display, wOrig);
}

/*
 * UnmapWindows --
 *   Unmap this window and the transient windows that are mapped.
 */
void Qvwm::UnmapWindows()
{
  /*
   * Unmap all menus.
   */
  if (CheckMenuMapped())
    UnmapMenu();

  mapped = False;

  if (CheckFlags(TRANSIENT) && transientFor) {
    QvwmList* qvList = transientFor->transient;
    while (qvList) {
      if (qvList->GetQvwm() == this) {
	qvList->ResetMapped();
	break;
      }
      qvList = qvList->GetNext();
    }
  }
  XUnmapWindow(display, wOrig);
  XUnmapWindow(display, frame);

  QvwmList* qvList = transient;
  while (qvList) {
    if (qvList->CheckMapped()) {
      Qvwm* qvWm = qvList->GetQvwm();

      ASSERT(qvWm);
      qvWm->mapped = False;
      XUnmapWindow(display, qvWm->frame);
      if (UsePager) {
	ASSERT(qvWm->mini);
	qvWm->mini->UnmapMiniature();
      }
    }
    qvList = qvList->GetNext();
  }

  if (UsePager) {
    ASSERT(mini);
    mini->UnmapMiniature();
  }
}

/*
 * RaiseWindow --
 *   Raise this window on top, but keep transient windows to be on the top.
 *   If soon is False, called this routine later again.
 */
void Qvwm::RaiseWindow(Bool soon)
{
#ifndef __EMX__
  /* no itimers under EMX... yet */
  struct itimerval itv;
#endif

  if (this == rootQvwm || this == activeQvwm)
    return;

  if (!soon && AutoRaise && AutoRaiseDelay > 0) {
#ifndef __EMX__
    timer->SetTimeout(AutoRaiseDelay, RaiseSoon);
#endif
  }
  else if (CheckMapped()) {
    Window* wins = new Window[transientNum + 1];
    Miniature** minis = new Miniature*[transientNum + 1];
    int nwindows = 0;

    QvwmList* qvList = transient;
    while (qvList) {
      Qvwm* qvWm = qvList->GetQvwm();

      ASSERT(qvWm);
      if (qvWm->CheckMapped()) {
	ASSERT(nwindows < transientNum)
	wins[nwindows] = qvWm->frame;
	if (UsePager)
	  minis[nwindows] = qvWm->mini;
	nwindows++;
      }
      qvList = qvList->GetNext();
    }
    wins[nwindows] = frame;
    if (UsePager)
      minis[nwindows] = mini;
    nwindows++;

    XRaiseWindow(display, wins[0]);
    XRestackWindows(display, wins, nwindows);
    if (UsePager) {
      ASSERT(minis[0]);
      minis[0]->RaiseMiniature();
      Miniature::RestackMiniatures(minis, nwindows);
    }

    delete [] wins;
    delete [] minis;

    taskBar->RaiseTaskbar();

    activeQvwm = this;
  }
}

/*
 * RaiseSoon --
 *   Raise soon if the window is raisable.
 */
static void RaiseSoon()
{
  ASSERT(Qvwm::focusQvwm);

  if (Qvwm::focusQvwm->CheckMapped() && !Qvwm::focusQvwm->CheckMenuMapped())
    Qvwm::focusQvwm->RaiseWindow(True);
}

/*
 * SetShape --
 *   Transparentize the shaped window.
 */
void Qvwm::SetShape()
{
#ifdef SHAPE
  int borderWidth, topBorder, titleHeight, titleEdge;

  GetBorderAndTitle(borderWidth, topBorder, titleHeight, titleEdge);

  /*
   * Transparentize the original window.
   */
  XShapeCombineShape(display, frame, ShapeBounding,
		     borderWidth, topBorder + titleHeight + titleEdge,
		     wOrig, ShapeBounding, ShapeSet);

  if (CheckFlags(TITLE)) {
    XRectangle rect;

    rect.x = topBorder;
    rect.y = topBorder;
    rect.width = rc.width - topBorder * 2;
    rect.height = titleHeight;
    
    XShapeCombineRectangles(display, frame, ShapeBounding, 0, 0, &rect, 1,
			    ShapeUnion, Unsorted);
  }

  if (CheckFlags(BORDER)) {
    XRectangle rect[4];

    rect[0].x = 0;
    rect[0].y = 0;
    rect[0].width = rc.width;
    rect[0].height = topBorder + titleHeight + titleEdge;

    rect[1].x = 0;
    rect[1].y = topBorder + titleHeight + titleEdge;
    rect[1].width = borderWidth;
    rect[1].height = rc.height - (borderWidth + topBorder + titleHeight
				  + titleEdge);

    rect[2].x = 0;
    rect[2].y = rc.height - borderWidth;
    rect[2].width = rc.width;
    rect[2].height = borderWidth;
    
    rect[3].x = rc.width - borderWidth;
    rect[3].y = topBorder + titleHeight + titleEdge;
    rect[3].width = borderWidth;
    rect[3].height = rc.height - (borderWidth + topBorder + titleHeight +
				  titleEdge);

    XShapeCombineRectangles(display, frame, ShapeBounding, 0, 0, rect, 4,
			    ShapeUnion, Unsorted);
  }
#endif
}
