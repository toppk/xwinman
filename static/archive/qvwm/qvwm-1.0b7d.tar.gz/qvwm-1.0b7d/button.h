#ifndef _BUTTON_H_
#define _BUTTON_H_

#include "misc.h"

/*
 * Button class
 */
class Button {
public:
  // Button state
  enum ButtonState { NORMAL, PUSH };

protected:
  Window parent;
  Window frame;
  Rect rc;
  ButtonState state;

public:
  static XContext context;

public:
  Button(Window parent, const Rect& rc);
  virtual ~Button();
  void SetState(ButtonState bs) { state = bs; }
  Bool CheckState(ButtonState bs) const { return state & bs; }
  Rect GetRect() const { return rc; }
  Window GetFrameWin() const { return frame; }
  Window GetParent() const { return parent; }

  virtual void MapButton();
  virtual void UnmapButton();
  virtual void DrawButton();
  virtual void MoveResizeButton(const Rect& rect);
  virtual void ExecButtonFunc(ButtonState state) = 0;
  virtual void Button1Press();
  virtual void Button3Release(const Point& ptRoot) {}
};

#endif // _BUTTON_H_
