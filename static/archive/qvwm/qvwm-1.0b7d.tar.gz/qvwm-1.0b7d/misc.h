#ifndef _MISC_H_
#define _MISC_H_

#ifdef __EMX__
extern "C" char *__XOS2RedirRoot(char *filename);
#endif

const int MAX_NAME = 200;
const int MAX_WINDOW_WIDTH = 32767;
const int MAX_WINDOW_HEIGHT = 32767;

/*
 * Cursor name
 */
enum CursorName {
  SYS,
  X_RESIZE,
  Y_RESIZE,
  RD_RESIZE,
  LD_RESIZE,
  WAIT,
  MOVE
};

/*
 * Point class
 */
class Point {
public:
  int x, y;

public:
  Point() {}
  Point(int px, int py) : x(px), y(py) {}
  Point(const Point& pt) : x(pt.x), y(pt.y) {}
  Point& operator=(const Point& pt);
  Point& operator+=(const Point& pt);
  Point& operator-=(const Point& pt);
  Point operator+(const Point& pt);
  Point operator-(const Point& pt);
};

inline Point& Point::operator=(const Point& pt)
{
  x = pt.x;
  y = pt.y;

  return *this;
}

inline Point& Point::operator+=(const Point& pt)
{
  x += pt.x;
  y += pt.y;

  return *this;
}

inline Point& Point::operator-=(const Point& pt)
{
  x -= pt.x;
  y -= pt.y;

  return *this;
}

inline Point Point::operator+(const Point& pt)
{
  return Point(x + pt.x, y + pt.y);
}

inline Point Point::operator-(const Point& pt)
{
  return Point(x - pt.x, y - pt.y);
}

/*
 * Rect class
 */
class Rect {
public:
  int x, y;
  unsigned int width, height;

public:
  Rect() {}
  Rect(int rx, int ry, int rwidth, int rheight)
    : x(rx), y(ry), width(rwidth), height(rheight) {}
  Rect(const Rect& rc)
    : x(rc.x), y(rc.y), width(rc.width), height(rc.height) {}
  Rect& operator=(const Rect& rc);
};

inline Rect& Rect::operator=(const Rect& rc)
{
  x = rc.x;
  y = rc.y;
  width = rc.width;
  height = rc.height;

  return *this;
}

/*
 * RectPt class
 */
class RectPt {
public:
  int left, top, right, bottom;

public:
  RectPt() {}
  RectPt(int left, int top, int right, int bottom)
    : left(left), top(top), right(right), bottom(bottom) {}
  RectPt(const RectPt& rp)
    : left(rp.left), top(rp.top), right(rp.right), bottom(rp.bottom) {}
  RectPt& operator=(const RectPt& rp) {
    left = rp.left;  top = rp.top;  right = rp.right;  bottom = rp.bottom;
    return *this;
  }
};

/*
 * Dim class
 */
class Dim {
public:
  unsigned int width, height;

public:
  Dim() {}
  Dim(unsigned int dwidth, unsigned int dheight)
    : width(dwidth), height(dheight) {}
  Dim(const Dim& dim)
    : width(dim.width), height(dim.height) {}
  Dim& operator=(const Dim& dim) {
    width = dim.width;  height = dim.height;
    return *this;
  }
};

#endif // _MISC_H_
