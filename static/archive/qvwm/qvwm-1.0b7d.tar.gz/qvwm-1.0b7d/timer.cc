#include <signal.h>
#include <sys/time.h>
#include <X11/Xlib.h>
#include "main.h"
#include "timer.h"

static void TrapAlarm(int sig);

Timer::Timer()
{
  signal(SIGALRM, TrapAlarm);
}

Timer::~Timer()
{
  signal(SIGALRM, SIG_DFL);
}

/*
 * SetTimeout --
 *   Set exclusive timeout.
 */
void Timer::SetTimeout(unsigned long msec, void (*action)())
{
  /*
   * Execute soon if msec is 0.
   */
  if (msec == 0) {
    (*action)();
    return;
  }

  act = action;

  itv.it_value.tv_sec = msec / 1000;
  itv.it_value.tv_usec = (msec * 1000) % 1000000;
  itv.it_interval.tv_sec = 0;
  itv.it_interval.tv_usec = 0;

  setitimer(ITIMER_REAL, &itv, NULL);
}

/*
 * ResetTimeout --
 *   Reset timeout.
 */
void Timer::ResetTimeout()
{
  act = NULL;

  itv.it_value.tv_sec = 0;
  itv.it_value.tv_usec = 0;
  itv.it_interval.tv_sec = 0;
  itv.it_interval.tv_usec = 0;

  setitimer(ITIMER_REAL, &itv, NULL);
}

/*
 * ForceTimeout --
 *   Timeout forcely and execute action.
 */
void Timer::ForceTimeout()
{
  void (*action)();

  if (act) {
    action = act;
    ResetTimeout();
    act = action;
    Execute();
  }
}

/*
 * TrapAlarm --
 *   Signal handler for timer.
 */
static void TrapAlarm(int sig)
{
  timer->Execute();

  signal(SIGALRM, TrapAlarm);
}
