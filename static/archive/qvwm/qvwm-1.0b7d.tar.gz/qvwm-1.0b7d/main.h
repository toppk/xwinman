#ifndef _MAIN_H_
#define _MAIN_H_

#ifdef DEBUG
# define ASSERT(ex) {						\
  if(!(ex)) {							\
    fprintf(stderr,"Assertion failed: file \"%s\", line %d\n",	\
	    __FILE__, __LINE__);				\
    Qvwm::FinishQvwm(False);					\
  }								\
}
#else
# define ASSERT(ex)
#endif

class Qvwm;
class Rect;

extern Display*		display;
extern int		screen;
extern unsigned int	depth;
extern Colormap		colormap;
extern Window		root;
extern Qvwm*		rootQvwm;
extern Rect		rcScreen;
extern GC		gc, gcXor, gcLogo, gcLargeLogo;
extern GC		gcTile, gcDash;
extern Pixmap		pixLogo, pixLargeLogo;
extern Cursor		cursor[7];
extern XFontSet		fsTitle, fsTaskbar, fsBoldTaskbar, fsIcon;
extern XFontSet		fsCtrlMenu, fsCascadeMenu, fsStartMenu, fsDialog;
extern unsigned	long	gray, darkGray, lightGray, blue, green, black, white;
extern Bool		shapeSupport;
extern char**           qvArgv;
extern Bool		start;

extern Atom _XA_WM_CHANGE_STATE;
extern Atom _XA_WM_STATE;
extern Atom _XA_WM_COLORMAP_WINDOWS;
extern Atom _XA_WM_PROTOCOLS;
extern Atom _XA_WM_TAKE_FOCUS;
extern Atom _XA_WM_DELETE_WINDOW;
extern Atom _XA_WM_DESKTOP;
extern Atom _XA_WM_ICON_SIZE;

class Taskbar;
class StartMenu;
class TaskSwitcher;
class Paging;
class Pager;
class Menu;
class SystemDialog;
class Timer;

extern Taskbar*		taskBar;
extern StartMenu*	startMenu;
extern TaskSwitcher*	taskSwitcher;
extern Paging*		paging;
extern Pager*		pager;
extern Menu*		ctrlMenu;
extern SystemDialog*	exitDlg;
extern Timer*           timer;

extern unsigned long CreatePixel(unsigned short red, unsigned short green,
				 unsigned short blue);
extern void QvwmError(const char* fmt, ...);

#endif // _MAIN_H_
