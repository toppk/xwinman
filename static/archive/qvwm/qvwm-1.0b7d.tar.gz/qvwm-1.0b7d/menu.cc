#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <X11/Xlib.h>
#include <X11/xpm.h>
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "menu.h"
#include "util.h"
#include "startmenu.h"
#include "qvwmrc.h"
#include "timer.h"
#include "bitmaps/menu0.xpm"
#include "bitmaps/menu1.xpm"
#include "bitmaps/next0.xpm"
#include "bitmaps/next1.xpm"

XContext	Menu::context;
Menu::MenuDir	Menu::fDir = Menu::RIGHT;
Pixmap		Menu::pixMenu[2];
GC		Menu::gcMenu[2];
Pixmap		Menu::pixWhiteNext, Menu::pixBlackNext;
GC		Menu::gcNext;
Menu*		Menu::delayMenu;
int		Menu::delayMenuNum;

static void PopupMenu();
static void PopdownMenu();

Menu::Menu(Qvwm* qvwm, MenuItem* mItem, int frame_between, int item_height,
	   int item_between, int pix_width, const Rect& rect, XFontSet& menufs,
	   Menu* parent)
: fBetween(frame_between), iHeight(item_height), iBetween(item_between),
  paWidth(pix_width), rcPix(rect), parent(parent), fs(menufs), qvWm(qvwm)
{
  int width, maxWidth = 0;
  int i, sep = 0;
  XSetWindowAttributes attributes;
  unsigned long valueMask;
  Rect rect;
  Pixmap mask;
  XRectangle ink, log;

  nitems = GetMenuItemNum(mItem);

  item = new Window[nitems];
  pix = new Pixmap[nitems];
  gc = new GC[nitems];
  name = new char*[nitems];
  func = new FuncNumber[nitems];
  exec = new char*[nitems];
  next = new Menu*[nitems];

  for (i = 0; i < nitems; i++) {
    ASSERT(mItem);

    func[i] = mItem->func;
    exec[i] = mItem->exec;
    name[i] = mItem->name;

    if (func[i] != Q_SEPARATOR) {
      width = XmbTextExtents(fs, name[i], strlen(name[i]), &ink, &log);
      if (width > maxWidth)
	maxWidth = width;
    }

    if (mItem->func == Q_DIR) {
      next[i] = new Menu(qvWm, mItem->child, fBetween, iHeight, iBetween,
			 paWidth, rcPix, fs, this);
      if (strcmp(mItem->file, "") == 0) {
	/*
	 * Default pixmap and GC of QDir
	 */
	pix[i] = pixMenu[0];
	gc[i] = gcMenu[0];
      }
      else
	CreatePixmapFromFile(mItem->file, pix[i], mask, gc[i]);
    }
    else {
      next[i] = NULL;
      if (strcmp(mItem->file, "") == 0) {
	/*
         * Default pixmap and GC of other than QDir
	 */
	pix[i] = pixMenu[1];
	gc[i] = gcMenu[1];
      }
      else
	CreatePixmapFromFile(mItem->file, pix[i], mask, gc[i]);
    }
    
    mItem = mItem->next;
  }

  rc.width = paWidth + maxWidth + MenuFrameWidth * 2 + 24;

  iFocus = -1;            // no focus
  mapped = False;
  child = NULL;

  /*
   * Create frame window.
   */
  attributes.save_under = DoesSaveUnders(ScreenOfDisplay(display, screen));
  attributes.background_pixel = gray;
  attributes.event_mask = ExposureMask | KeyPressMask; // | EnterWindowMask;
  valueMask = CWSaveUnder | CWBackPixel | CWEventMask;
  
  frame = XCreateWindow(display, root,
			0, 0, 10, 10,
			0, CopyFromParent, InputOutput, CopyFromParent,
			valueMask, &attributes);

  valueMask = CWBackPixel | CWEventMask;

  /*
   * Create item windows for menu.
   */
  for (i = 0; i < nitems; i++) {
    if (func[i] != Q_SEPARATOR) {
      attributes.event_mask = ButtonPressMask | ButtonReleaseMask |
	                      EnterWindowMask | LeaveWindowMask |
			      OwnerGrabButtonMask | ExposureMask;
      rect.y = MenuFrameWidth + fBetween + (i - sep) * (iHeight + iBetween)
	+ sep * SeparatorHeight;
      rect.height = iHeight;
    }
    else {
      attributes.event_mask = OwnerGrabButtonMask | ExposureMask;
      rect.y = MenuFrameWidth + fBetween + (i - sep) * (iHeight + iBetween)
	+ sep * SeparatorHeight;
      rect.height = SeparatorHeight;
      sep++;
    }

    rect.x = MenuFrameWidth;
    rect.width = rc.width - MenuFrameWidth*2;

    item[i] = XCreateWindow(display, frame,
			    rect.x, rect.y, rect.width, rect.height,
			    0, CopyFromParent, InputOutput, CopyFromParent,
			    valueMask, &attributes);
  }

  rc.height = (nitems - sep) * (iHeight + iBetween) + sep * SeparatorHeight
    + MenuFrameWidth * 2;

  XResizeWindow(display, frame, rc.width, rc.height);

  XSaveContext(display, frame, context, (caddr_t)this);
  for (i = 0; i < nitems; i++)
    XSaveContext(display, item[i], context, (caddr_t)this);    
}

Menu::~Menu()
{
  int i;

  if (nitems == 0)
    return;

  delete [] item;
  delete [] func;

  for (i = 0; i < nitems; i++) {
    if (pix[i] != pixMenu[0] && pix[i] != pixMenu[1])
      XFreePixmap(display, pix[i]);
    if (pix[i] != None && gc[i] != gcMenu[0] && gc[i] != gcMenu[1])
      XFreeGC(display, gc[i]);
  }
  delete [] pix;
  delete [] gc;

/*
  for (i = 0; i < nitems; i++) {
    free(name[i]);
    free(exec[i]);
  }
*/
  delete [] name;
  delete [] exec;
  delete [] next;
}

/*
 * MapMenu --
 *   Map menu.
 */
void Menu::MapMenu(int x, int y)
{
  mapped = True;
  rc.x = x;
  rc.y = y;

  XMoveWindow(display, frame, x, y);
  XMapRaised(display, frame);
  XMapSubwindows(display, frame);

  ASSERT(qvWm);

  /*
   * Take off the focus from the window when any menus are shown.
   */
  if (qvWm->CheckMapped()) {
    if (qvWm != rootQvwm)
      for (int i = 1; i < 4; i++)
	XGrabButton(display, i, 0, qvWm->GetWin(), True, ButtonPressMask,
		    GrabModeAsync, GrabModeAsync, None, cursor[0]);

    XSetInputFocus(display, frame, RevertToParent, CurrentTime);
  }
}

/*
 * UnmapMenu --
 *   Unmap menu.
 */
void Menu::UnmapMenu()
{
  int i;

  mapped = False;
  iFocus = -1;

  if (child != NULL)
    child->UnmapMenu();

  ASSERT(qvWm);

  /*
   * Yield the focus.
   */
  if (qvWm->CheckMapped()) {
    if (qvWm != rootQvwm)
      for (i = 1; i < 4; i++)
	XUngrabButton(display, i, 0, qvWm->GetWin());

    /*
     * Yield the focus to the parent, if any.
     */
    if (parent != NULL)
      XSetInputFocus(display, parent->frame, RevertToParent, CurrentTime);
    else {
      if (qvWm == rootQvwm) {
	ASSERT(taskBar);
	XSetInputFocus(display, taskBar->GetFrameWin(), RevertToParent,
		       CurrentTime);
      }
      else
	XSetInputFocus(display, qvWm->GetWin(), RevertToParent, CurrentTime);
    }
  }

  XUnmapWindow(display, frame);

  if (parent != NULL)
    parent->child = NULL;
}

/*
 * DrawMenu --
 *   Draw menu.
 */
void Menu::DrawMenu(Window win)
{
  int num;

  if (win == frame)
    DrawFrame();
  else {
    if ((num = FindItem(win)) != -1) {
      if (func[num] == Q_SEPARATOR)
	  DrawSeparator(num);
	else
	  SetMenuFocus(num);
    }
  }
}

/*
 * DrawFrame --
 *   Draw frame.
 */
void Menu::DrawFrame()
{
  XPoint xp[3];

  xp[0].x = rc.width - 1;
  xp[0].y = 0;
  xp[1].x = rc.width - 1;
  xp[1].y = rc.height - 1;
  xp[2].x = 0;
  xp[2].y = rc.height - 1;

  XSetForeground(display, ::gc, black);
  XDrawLines(display, frame, ::gc, xp, 3, CoordModeOrigin);

  xp[0].x = rc.width - 3;
  xp[0].y = 1;
  xp[1].x = 1;
  xp[1].y = 1;
  xp[2].x = 1;
  xp[2].y = rc.height - 3;

  XSetForeground(display, ::gc, white);
  XDrawLines(display, frame, ::gc, xp, 3, CoordModeOrigin);
  
  xp[0].x = rc.width - 2;
  xp[0].y = 1;
  xp[1].x = rc.width - 2;
  xp[1].y = rc.height - 2;
  xp[2].x = 1;
  xp[2].y = rc.height - 2;

  XSetForeground(display, ::gc, darkGray);
  XDrawLines(display, frame, ::gc, xp, 3, CoordModeOrigin);
}

/*
 * DrawSeparator --
 *   Draw the separator.
 */
void Menu::DrawSeparator(int num)
{
  ASSERT(num >= 0 && num < nitems);

  XSetForeground(display, ::gc, darkGray);
  XDrawLine(display, item[num], ::gc, 0, 2, rc.width-1, 2);

  XSetForeground(display, ::gc, white);
  XDrawLine(display, item[num], ::gc, 0, 3, rc.width-1, 3);
}

/*
 * DrawMenuContents --
 *   Draw the contents of the menu.
 */
void Menu::DrawMenuContents(int num)
{
  XRectangle ink, log;
  int y;

  ASSERT(num >= 0 && num < nitems);

  /*
   * Draw the menu text.
   */
  XmbTextExtents(fs, name[num], strlen(name[num]), &ink, &log);
  y = (iHeight-log.height)/2 - log.y;

  if (num == iFocus) {
    if (IsSelectable(func[num])) {
      XSetForeground(display, ::gc, white);
      XmbDrawString(display, item[num], fs, ::gc, paWidth, y,
		    name[num], strlen(name[num]));
    }
    else {
      XSetForeground(display, ::gc, darkGray);
      XmbDrawString(display, item[num], fs, ::gc, paWidth, y,
		    name[num], strlen(name[num]));
    }

    if (func[num] == Q_DIR) {
      XSetClipOrigin(display, gcNext, rc.width-14, iHeight/2-4);
      XCopyArea(display, pixWhiteNext, item[num], gcNext,
		0, 0, 4, 7, rc.width-14, iHeight/2-4);
    }
  }
  else {
    if (IsSelectable(func[num])) {
      XSetForeground(display, ::gc, black);
      XmbDrawString(display, item[num], fs, ::gc, paWidth, y,
		    name[num], strlen(name[num]));
    }
    else {
      XSetForeground(display, ::gc, white);
      XmbDrawString(display, item[num], fs, ::gc, paWidth+1, y+1,
		    name[num], strlen(name[num]));
      XSetForeground(display, ::gc, darkGray);
      XmbDrawString(display, item[num], fs, ::gc, paWidth, y,
		    name[num], strlen(name[num]));
    }

    if (func[num] == Q_DIR) {
      XSetClipOrigin(display, gcNext, rc.width-14, iHeight/2-4);
      XCopyArea(display, pixBlackNext, item[num],
		gcNext, 0, 0, 4, 7, rc.width-14, iHeight/2-4);
    }
  }

  /*
   * Draw the menu pixmap, if neccesary.
   */
  if (pix[num] && func[num] != Q_NONE) {
    XSetClipOrigin(display, gc[num], rcPix.x, 0);
    XCopyArea(display, pix[num], item[num], gc[num], 0, 0, rcPix.width,
	      rcPix.height, rcPix.x, rcPix.y);
  }
}

/*
 * SetMenuFocus --
 *   Give the focus to the menu item, and redraw.
 */
void Menu::SetMenuFocus(int num)
{
  ASSERT(num >= 0 && num < nitems);

  if (num == iFocus)
    XSetWindowBackground(display, item[num], blue);
  else
    XSetWindowBackground(display, item[num], gray);

  XClearWindow(display, item[num]);

  DrawMenuContents(num);
}

/*
 * FindItem --
 *   Find the menu item corresponding to given window.
 */
int Menu::FindItem(Window win)
{
  for (int i = 0; i < nitems; i++)
    if (win == item[i])
      return i;
  
  return -1;
}

/*
 * CalcItemYPos --
 *   Calculate y position of the menu item.
 */
int Menu::CalcItemYPos(int num)
{
  int y = MenuFrameWidth + fBetween;
  
  ASSERT(num < nitems);

  for (int i = 0; i < num; i++)
    if (func[i] != Q_SEPARATOR)
      y += iHeight + iBetween;
    else
      y += SeparatorHeight + iBetween;

  return y;
}

/*
 * GetFixedMenuPos --
 *   Adjust the menu position.
 */
Point Menu::GetFixedMenuPos(const Point& pt)
{
  Point ptNew;
  Rect rcRoot = rootQvwm->GetRect();

  if (pt.x + rc.width > rcRoot.width - 1)
    ptNew.x = pt.x - rc.width;
  else
    ptNew.x = pt.x;
  if (pt.y + rc.height > rcRoot.height - 1)
    ptNew.y = rcRoot.height - rc.height;
  else
    ptNew.y = pt.y;

  return ptNew;
}

/*
 * PopupMenu --
 *   Pop down previous child menu, if any, and pop up new child menu.
 */
static void PopupMenu()
{
  Menu* child = Menu::delayMenu->GetChildMenu();

  if (child)
    child->UnmapMenu();

  Menu::delayMenu->ExecFunction(Q_DIR, Menu::delayMenuNum);
}

/*
 * PopdownMenu --
 *   Pop down previous child menu.
 */
static void PopdownMenu()
{
  Menu::delayMenu->UnmapMenu();
}  

/*
 * Enter --
 *   Process enter event.
 */
void Menu::Enter(Window win)
{
  int num, pFocus;

  num = FindItem(win);

  if (iFocus != num) {
    if (iFocus != -1) {
      pFocus = iFocus;
      iFocus = -1;
      SetMenuFocus(pFocus);
    }
    iFocus = num;
    SetMenuFocus(num);

    /*
     * Delay that child menu popups.
     */
    if (func[num] == Q_DIR) {
      delayMenu = this;
      delayMenuNum = num;
      if (child)
	timer->SetTimeout(MenuDelayTime2, PopupMenu);
      else
	timer->SetTimeout(MenuDelayTime, PopupMenu);
    }
    else {
      if (child) {
	delayMenu = child;
	timer->SetTimeout(MenuDelayTime, PopdownMenu);
      }
    }
  }
}

/*
 * Leave --
 *   Process leave event.
 */
void Menu::Leave(Window win, const Point& ptRoot)
{
  int num;

  num = FindItem(win);

  if (child == NULL) {
    if (iFocus != num && iFocus != -1)
      num = iFocus;
    iFocus = -1;
    SetMenuFocus(num);
    timer->ResetTimeout();
  }
}

/*
 * Button1Press --
 *   Process the press of button1(mouse left button).
 */
void Menu::Button1Press(Window win) 
{
  int num;

  num = FindItem(win);
  ASSERT(num >= 0 && num < nitems);

  if (func[num] == Q_DIR)
    timer->ForceTimeout();
}

/*
 * Button1Release --
 *   Process the release of button1(mouse left button).
 */
void Menu::Button1Release(Window win)
{
  int num;

  num = FindItem(win);
  ASSERT(num >= 0 && num < nitems);

  if (IsSelectable(func[num])) {
    ASSERT(qvWm);
    /*
     * Erase all menus.
     */
    if (func[num] != Q_DIR)
      Qvwm::UnmapAllMenus();

    ExecFunction(func[num], num);
  }
}

/*
 * CreateMenuPixmap --
 *   Create the pixmaps for menu.
 */
void Menu::CreateMenuPixmap()
{
  XpmAttributes attr;
  Pixmap mask;
  XGCValues gcv;

  attr.valuemask = XpmColormap | XpmDepth;
  attr.colormap = colormap;
  attr.depth = depth;

  XpmCreatePixmapFromData(display, root, menu0, &pixMenu[0], &mask, &attr);
  gcv.clip_mask = mask;
  gcMenu[0] = XCreateGC(display, root, GCClipMask, &gcv);

  XpmCreatePixmapFromData(display, root, menu1, &pixMenu[1], &mask, &attr);
  gcv.clip_mask = mask;
  gcMenu[1] = XCreateGC(display, root, GCClipMask, &gcv);

  XpmCreatePixmapFromData(display, root, next0, &pixBlackNext, &mask, &attr);
  gcv.clip_mask = mask;
  gcNext = XCreateGC(display, root, GCClipMask, &gcv);

  XpmCreatePixmapFromData(display, root, next1, &pixWhiteNext, &mask, &attr);
}
