#include <stdio.h>
#include <time.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/types.h>
#ifdef __EMX__
#include <sys/select.h>
#endif
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#ifdef SHAPE
#include <X11/extensions/shape.h>
#endif
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "events.h"
#include "taskbar.h"
#include "fbutton.h"
#include "tbutton.h"
#include "sbutton.h"
#include "startmenu.h"
#include "menu.h"
#include "util.h"
#include "icon.h"
#include "qvwmrc.h"
#include "paging.h"
#include "pager.h"

#if defined(sun) && !defined(SVR4)
extern "C" int select(int, fd_set *, fd_set *, fd_set *, struct timeval *);
extern "C" int bzero(char *, int);
#endif

Qvwm*	Qvwm::focusQvwm;
Point	ptPrevRoot;
int	shapeEventBase;

void EnterNotifyProc(Window w, const Point& ptRoot);
void LeaveNotifyProc(Window w, const Point& ptRoot);
void ClientMessageProc(Window w, Atom mesType, long state);
void PropertyNotifyProc(Window w, Atom atom);
void ConfigureRequestProc(Window w, const XConfigureRequestEvent* cre);
void DestroyNotifyProc(Window w);
void UnmapNotifyProc(Window w);
void MapNotifyProc(Window w);
void MapRequestProc(Window w);
void ButtonPressProc(Window w, unsigned int buttonNum, Time clickTime,
		     const Point& ptRoot, const Point& ptWin);
void ButtonReleaseProc(Window w, unsigned int state, const Point& ptRoot);
void MotionNotifyProc(Window w);
void KeyPressProc(Window w, XKeyEvent* ev);

/*
 * MainLoop --
 *   Wait event and timeout.
 */
void MainLoop()
{  
  XEvent ev;
  int fd = ConnectionNumber(display);
  fd_set fds;
  timeval tm;
  time_t ctm, btm;

  time(&btm);
  btm = btm / 60 * 60;         // adjust by min unit

  while (1) {
    FD_ZERO(&fds);
    FD_SET(fd, &fds);

    while (XPending(display) != 0) {
      XNextEvent(display, &ev);
      DispatchEvent(&ev);
    }

    tm.tv_sec = 1;
    tm.tv_usec = 0;
    if (select(fd+1, &fds, 0, 0, &tm) == 0) {    // timeout
      time(&ctm);
      if (ctm - btm >= 60) {
	btm = ctm / 60 * 60;           // adjust by min unit
	taskBar->DrawClock();
      }
    }
  }
}

/*
 * DispatchEvent --
 *   Call the event procedure according to a event type.
 */
void DispatchEvent(const XEvent* ev)
{
  Point ptRoot, ptWin;
  
  switch (ev->type) {
  case EnterNotify:
    ptRoot = Point(ev->xcrossing.x_root, ev->xcrossing.y_root);
    EnterNotifyProc(ev->xcrossing.window, ptRoot);
    break;

  case LeaveNotify:
    ptRoot = Point(ev->xcrossing.x_root, ev->xcrossing.y_root);
    LeaveNotifyProc(ev->xcrossing.window, ptRoot);
    break;

  case PropertyNotify:
    PropertyNotifyProc(ev->xproperty.window, ev->xproperty.atom);
    break;

  case ClientMessage:
    ClientMessageProc(ev->xclient.window, ev->xclient.message_type,
		       ev->xclient.data.l[0]);
    break;

  case ConfigureRequest:
    ConfigureRequestProc(ev->xconfigure.window, (XConfigureRequestEvent *)ev);
    break;

  case ColormapNotify:
    ColormapNotifyProc(ev->xcolormap.window, ev->xcolormap.c_new,
		       (XColormapEvent *)ev);
    break;

  case Expose:
    ExposeProc(ev->xexpose.window);
    break;

  case DestroyNotify:
    DestroyNotifyProc(ev->xdestroywindow.window);
    break;

  case UnmapNotify:
    UnmapNotifyProc(ev->xunmap.window);
    break;

  case MapNotify:
    MapNotifyProc(ev->xmap.window);
    break;

  case MapRequest:
    MapRequestProc(ev->xmaprequest.window);
    break;

  case ButtonPress:
    ptRoot = Point(ev->xbutton.x_root, ev->xbutton.y_root);
    ptWin = Point(ev->xbutton.x, ev->xbutton.y);
    ButtonPressProc(ev->xbutton.window, ev->xbutton.button, ev->xbutton.time,
		    ptRoot, ptWin);
    ptPrevRoot = ptRoot;
    break;

  case ButtonRelease:
    ptRoot = Point(ev->xbutton.x_root, ev->xbutton.y_root);
    ButtonReleaseProc(ev->xbutton.window, ev->xbutton.state, ptRoot);
    break;

  case MotionNotify:
    MotionNotifyProc(ev->xbutton.window);
    break;

  case KeyPress:
    KeyPressProc(ev->xkey.window, (XKeyEvent*)ev);
    break;

#ifdef SHAPE
  default:
    if (shapeSupport) {
      if (ev->type == shapeEventBase + ShapeNotify) {
	XShapeEvent *sev = (XShapeEvent *)ev;
	ShapeNotifyProc(sev->window, sev->kind);
      }
    }
    break;
#endif
  }
}

/*
 * EnterNotifyProc --
 *   Process EnterNotify event.
 */
void EnterNotifyProc(Window w, const Point& ptRoot)
{
  XEvent ev;
  Menu* menu;
  Qvwm* qvWm;

  /*
   * Check if there is LeaveNotify event for the window and if so, return.
   */
  if(XCheckTypedWindowEvent(display, w, LeaveNotify, &ev)) {
    if(ev.xcrossing.mode == NotifyNormal &&
       ev.xcrossing.detail != NotifyInferior)
      return;
  }

  ASSERT(paging);

  if (XFindContext(display, w, Menu::context, (caddr_t*)&menu) == XCSUCCESS)
    menu->Enter(w);
  else if (XFindContext(display, w, Qvwm::context, (caddr_t*)&qvWm)
	                                                       == XCSUCCESS) {
    if (!ClickToFocus) {
      ASSERT(Qvwm::focusQvwm);
      if (!Qvwm::focusQvwm->CheckMenuMapped() &&
	  !(startMenu != NULL && startMenu->CheckMapped())) {
	qvWm->SetFocus();
	if (AutoRaise)
	  qvWm->RaiseWindow(False);
      }
    }
  }
  else if (paging->IsPagingBelt(w)) {
    paging->HandlePaging(ptRoot);
  }
}

/*
 * LeaceNotifyProc --
 *   Process LeaveNotify event.
 */
void LeaveNotifyProc(Window w, const Point& ptWin)
{
  Menu* menu;

  if (XFindContext(display, w, Menu::context, (caddr_t*)&menu) == XCSUCCESS)
    menu->Leave(w, ptWin);
}

/*
 * ClientMessageProc --
 *   Process ClientMessageNotify event.
 */
void ClientMessageProc(Window w, Atom mesType, long state)
{
  Qvwm* qvWm;

  if (XFindContext(display, w, Qvwm::context, (caddr_t*)&qvWm) == XCSUCCESS)
    if (mesType == _XA_WM_CHANGE_STATE && state == IconicState)
      qvWm->MinimizeWindow();
}

/*
 * PropertyNotifyProc --
 *   Process PropertyNotify event.
 */
void PropertyNotifyProc(Window w, Atom atom)
{
  Qvwm* qvWm;

  if (XFindContext(display, w, Qvwm::context, (caddr_t*)&qvWm) == XCSUCCESS)
    qvWm->SetProperty(atom);
}    

/*
 * ConfigureRequestProc --
 *   Process ConfigureRequest event.
 */
void ConfigureRequestProc(Window w, const XConfigureRequestEvent* cre)
{
  Qvwm* qvWm;
  XWindowChanges xwc;
  unsigned long xwcm;

  if (XFindContext(display, w, Qvwm::context, (caddr_t*)&qvWm) == XCNOENT) {
    xwcm = cre->value_mask & (CWX | CWY | CWWidth | CWHeight | CWBorderWidth);
    xwc.x = cre->x;
    xwc.y = cre->y;
    xwc.width = cre->width;
    xwc.height = cre->height;
    xwc.border_width = cre->border_width;

    XConfigureWindow(display, w, xwcm, &xwc);
  }
  else
    qvWm->Configure(cre);
}

/*
 * ExposeProc --
 *   Process Expose event.
 */
void ExposeProc(Window w)
{
  Qvwm* qvWm;
  Button* button;
  Menu* menu;
  Icon* icon;
  Miniature* mini;
  XEvent ev;

  ASSERT(taskBar);

  if (XFindContext(display, w, Qvwm::context, (caddr_t*)&qvWm) == XCSUCCESS) {
    qvWm->Exposure(w);
    while (XCheckWindowEvent(display, w, ExposureMask, &ev))
      ;
  }
  else if (XFindContext(display, w, Button::context, (caddr_t*)&button)
	                                                        == XCSUCCESS) {
    button->DrawButton();
    while (XCheckWindowEvent(display, w, ExposureMask, &ev))
      ;
  }
  else if (XFindContext(display, w, Menu::context, (caddr_t*)&menu)
	                                                        == XCSUCCESS) {
    menu->DrawMenu(w);
    while (XCheckWindowEvent(display, w, ExposureMask, &ev))
      ;
  }
  else if (XFindContext(display, w, Icon::context, (caddr_t*)&icon)
	                                                        == XCSUCCESS) {
    icon->DrawIcon(icon == Icon::focusIcon);
    while (XCheckWindowEvent(display, w, ExposureMask, &ev))
      ;
  }
  else if (XFindContext(display, w, Miniature::context, (caddr_t*)&mini)
	                                                        == XCSUCCESS) {
    mini->DrawMiniature();
    while (XCheckWindowEvent(display, w, ExposureMask, &ev))
      ;
  }
  else if (taskBar->IsTaskbarWindows(w)) {
    taskBar->Exposure(w);
  }
  else if (UsePager) {
    ASSERT(pager);
    pager->Exposure(w);
  }
}

/*
 * DestroyNotifyProc --
 *   Process DestroyNotify event.
 */
void DestroyNotifyProc(Window w)
{
  Qvwm* qvWm;

  if (XFindContext(display, w, Qvwm::context, (caddr_t*)&qvWm) == XCSUCCESS) {
    if (qvWm->CheckMapped()) {
      qvWm->ResetMapped();
      qvWm->ChangeFocus();
      qvWm->UnmapWindows();
    }
    qvWm->tButton->UnmapButton();
    delete qvWm;

    TaskbarButton::RedrawAllTaskbarButtons();

    if (!ClickToFocus)
      Qvwm::ChangeFocusToCursor();
  }
}

/*
 * UnmapNotifyProc --
 *   Process UnmapNotify event.
 */
void UnmapNotifyProc(Window w)
{
  Qvwm* qvWm;

  if (XFindContext(display, w, Qvwm::context, (caddr_t*)&qvWm) == XCSUCCESS) {
    if (qvWm->CheckMapped()) {
      XGrabServer(display);

      qvWm->ResetMapped();
      qvWm->ChangeFocus();
      qvWm->UnmapWindows();
      qvWm->tButton->UnmapButton();
      XRemoveFromSaveSet(display, qvWm->GetWin());

      if (!ClickToFocus)
	Qvwm::ChangeFocusToCursor();

      XSync(display, 0);
      XUngrabServer(display);
    }
  }
}

/*
 * MapNotifyProc --
 *   Process MapNotify event.
 */
void MapNotifyProc(Window w)
{
  Qvwm* qvWm;

  if (XFindContext(display, w, Qvwm::context, (caddr_t*)&qvWm) == XCSUCCESS) {
    if (!qvWm->CheckMapped()) {
      Qvwm::UnmapAllMenus();

      XGrabServer(display);

      if (qvWm->CheckFlags(MINIMIZE_WINDOW))
	qvWm->RestoreWindow();
      else {
	qvWm->MapWindows();
	qvWm->tButton->MapButton();
	XAddToSaveSet(display, qvWm->GetWin());
	qvWm->SetFocus();

	if (!ClickToFocus)
	  Qvwm::ChangeFocusToCursor();
      }

      XSync(display, 0);
      XUngrabServer(display);
    }
  }
}

/*
 * MapRequestProc --
 *   Process MapRequest event.
 */
void MapRequestProc(Window w)
{
  Qvwm* qvWm;
  XWMHints *wmHints;

  if ((qvWm = Qvwm::LookInList(w)) == NULL)
    qvWm = new Qvwm(w, False);

  wmHints = qvWm->GetWMHints();

  if (wmHints && (wmHints->flags & StateHint) && 
      wmHints->initial_state == IconicState) {
    int origSpeed = TitlebarMotionSpeed;

    TitlebarMotionSpeed = 0;
    qvWm->MinimizeWindow();
    TitlebarMotionSpeed = origSpeed;
  }
  else
    qvWm->MapWindows();

  ASSERT(qvWm->tButton);
  qvWm->tButton->MapButton();

  if (!qvWm->CheckStatus(MINIMIZE_WINDOW)) {
    if (ClickToFocus)
      qvWm->SetFocus();
    else
      Qvwm::ChangeFocusToCursor();
  }

  XSync(display, 0);
  XUngrabServer(display);
}

/*
 * ButtonPressProc --
 *   Process ButtonPress event.
 */
void ButtonPressProc(Window w, unsigned int buttonNum, Time clickTime,
		     const Point& ptRoot, const Point& ptWin)
{
  Qvwm* qvWm;
  Button* button;
  Menu* menu;
  Icon* icon;
  Miniature* mini;

  if (buttonNum == Button1) {
    /*
     * Right button.
     */
    if (XFindContext(display, w, Qvwm::context, (caddr_t*)&qvWm) == XCSUCCESS)
      qvWm->Button1Press(w, clickTime, ptRoot);
    else if (XFindContext(display, w, Button::context, (caddr_t*)&button)
	                                                         == XCSUCCESS)
      button->Button1Press();
    else if (XFindContext(display, w, Menu::context, (caddr_t*)&menu)
                                                                 == XCSUCCESS)
      menu->Button1Press(w);
    else if (XFindContext(display, w, Icon::context, (caddr_t*)&icon)
	                                                         == XCSUCCESS)
      icon->Button1Press(clickTime, ptRoot);
    else if (XFindContext(display, w, Miniature::context, (caddr_t*)&mini)
	                                                         == XCSUCCESS)
      mini->Button1Press(ptRoot);
    else {
      ASSERT(taskBar);
      if (taskBar->IsTaskbarWindows(w))
	Qvwm::UnmapAllMenus();
      else if (UsePager) {
	ASSERT(pager);
	if (pager->IsPagerWindows(w))
	  pager->Button1Press(w, ptRoot, ptWin);
      }
    }
  }
  else if (buttonNum == Button2) {
    if (XFindContext(display, w, Miniature::context, (caddr_t*)&mini)
                       	                                         == XCSUCCESS)
      mini->Button2Press(ptRoot);
  }
  else if (buttonNum == Button3) {
    if (UsePager) {
      ASSERT(pager);
      if (w == pager->GetVisualWin())
	pager->Button3Press(ptRoot);
    }
  }

  XAllowEvents(display, ReplayPointer, CurrentTime);
}

/*
 * ButtonReleaseProc --
 *   Process ButtonRelease event.
 */
void ButtonReleaseProc(Window w, unsigned int state, const Point& ptRoot)
{
  Qvwm* qvWm;
  Button* button;
  Menu* menu;
  Icon* icon;

  if (state & Button1Mask) {
    /*
     * Left button.
     */
    if (XFindContext(display, w, Qvwm::context, (caddr_t*)&qvWm) == XCSUCCESS)
      qvWm->Button1Release();
    else if (XFindContext(display, w, Menu::context, (caddr_t*)&menu)
	                                                         == XCSUCCESS)
      menu->Button1Release(w);
  }
  else if (state & Button3Mask) {
    /*
     * Right button.
     */
    if (XFindContext(display, w, Qvwm::context, (caddr_t*)&qvWm) == XCSUCCESS)
      qvWm->Button3Release(w, ptRoot);
    else if (XFindContext(display, w, Button::context, (caddr_t*)&button)
	                                                         == XCSUCCESS)
      button->Button3Release(ptRoot);
    else if (XFindContext(display, w, Icon::context, (caddr_t*)&icon)
	     == XCSUCCESS)
      icon->Button3Release(ptRoot);
  }
}

/*
 * MotionNotifyProc --
 *   Process MotionNotify event.
 */
void MotionNotifyProc(Window w)
{
  Qvwm* qvWm;

  ASSERT(Qvwm::focusQvwm);

  /*
   * Ignore MotionNotify when any menus are shown.
   */
  if (Qvwm::focusQvwm->CheckMenuMapped())
    return;
  if (startMenu != NULL && startMenu->CheckMapped())
    return;

  ASSERT(taskBar);

  if (XFindContext(display, w, Qvwm::context, (caddr_t*)&qvWm) == XCSUCCESS)
    qvWm->Button1Motion(w, ptPrevRoot);
  else if (taskBar->IsTaskbarWindows(w))
    taskBar->Button1Motion(w, ptPrevRoot);
}

/*
 * KeyPressProc --
 *   Process KeyPress event.
 */
void KeyPressProc(Window w, XKeyEvent* ev)
{
  Menu* menu;
  Qvwm* qvWm;

  if (XFindContext(display, w, Menu::context, (caddr_t*)&menu) == XCSUCCESS) {
    ExecShortCutKey(SCMenuKeyNum, scMenuKey, ev, menu);
    return;
  }
  else if (w == root) {
    ExecShortCutKey(SCRootKeyNum, scRootKey, ev, rootQvwm->ctrlMenu);
    return;
  }
  else if (XFindContext(display, w, Qvwm::context, (caddr_t*)&qvWm)
	   == XCSUCCESS) {
    ASSERT(qvWm->ctrlMenu);
    qvWm->ctrlMenu->SetQvwm(qvWm);
    ExecShortCutKey(SCKeyNum, scKey, ev, qvWm->ctrlMenu);
  }
}

#ifdef SHAPE
/*
 * ShapeNotifyProc --
 *   Process ShapeNotify event.
 */
void ShapeNotifyProc(Window w, int kind)
{
  Qvwm* qvWm;

  if (kind != ShapeBounding)
    return;

  if (XFindContext(display, w, Qvwm::context, (caddr_t*)&qvWm) == XCSUCCESS) {
    qvWm->SetShape();
  }
}
#endif // SHAPE
