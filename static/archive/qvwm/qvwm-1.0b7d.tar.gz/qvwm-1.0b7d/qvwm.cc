#include <stdio.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#ifdef SHAPE
#include <X11/extensions/shape.h>
#endif
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "util.h"
#include "fbutton.h"
#include "tbutton.h"
#include "sbutton.h"
#include "menu.h"
#include "startmenu.h"
#include "events.h"
#include "taskbar.h"
#include "icon.h"
#include "qvwmrc.h"
#include "switch.h"
#include "paging.h"
#include "pager.h"
#include "system_dialog.h"

Bool		Qvwm::umReserved = False;
XContext	Qvwm::context;
Qvwm*		Qvwm::lastQvwm;
int		Qvwm::initPos = (TITLE_HEIGHT + TOP_BORDER) * 2;

int FinishErrorHandler(Display* display, XErrorEvent* ev);

/*
 * Qvwm class constructor --
 *   Position the window at that point if usrPos is True;
 *   otherwise, the position of the window obeys a given rule.
 */
Qvwm::Qvwm(Window w, Bool usrPos) : wOrig(w)
{
  status = 0;
  mapped = False;
  pixLarge = None;
  nCmapWins = 0;
  transient = NULL;
  transientNum = 0;

  XGrabServer(display);

  XTextProperty xtp;
  char** cl;
  char* iconName;
  int n;

  /*
   * Get the window name.
   */
  if (XGetWMName(display, w, &xtp) != 0) {
    XmbTextPropertyToTextList(display, &xtp, &cl, &n);
    name = new char[strlen(cl[0]) + 1];
    strcpy(name, cl[0]);
    XFreeStringList(cl);
  }
  else {
    name = new char[9];
    strcpy(name, "Untitled");
  }

  /*
   * Get the icon name.
   */
  if (XGetWMIconName(display, w, &xtp) != 0) {
    XmbTextPropertyToTextList(display, &xtp, &cl, &n);
    iconName = new char[strlen(cl[0]) + 1];
    strcpy(iconName, cl[0]);
    XFreeStringList(cl);
  }
  else {
    iconName = new char[9];
    strcpy(iconName, "Untitled");
  }

  /*
   * Get some hints.
   */
  Pixmap pixSmall;
  GC gcSmall;

  wmHints = XGetWMHints(display, w);
  GetWindowSizeHints();
  GetWindowClassHints(pixSmall, gcSmall);
  FetchWMProtocols();
  
  /*
   * Set frame attribute.
   */
  Window tWin;

  if (XGetTransientForHint(display, w, &tWin)) {
    if (XFindContext(display, tWin, context, (caddr_t*)&transientFor)
	== XCSUCCESS) {
      QvwmList* qvList = new QvwmList(this);
      if (transientFor->transient != NULL)
	qvList->SetNext(transientFor->transient);
      transientFor->transient = qvList;
      transientFor->transientNum++;
    }
    else {
      transientFor = NULL;
    }
    SetFlags(TRANSIENT);
    ResetFlags(CTRL_MENU | BUTTON1 | BUTTON2 | BUTTON3);
  }
  else
    ResetFlags(TRANSIENT);

  /*
   * Preserve original border width and set border width to 0.
   */
  XWindowAttributes attr;

  XGetWindowAttributes(display, w, &attr);
  bwOrig = attr.border_width;
  XSetWindowBorderWidth(display, w, 0);

  ASSERT(paging);
  /*
   * Calculate the window position.
   */
  if (usrPos || flags & TRANSIENT || hints.flags & USPosition) {
    if (CheckFlags(STICKY))
      rcOrig = Rect(attr.x, attr.y, attr.width, attr.height);
    else
      rcOrig = Rect(attr.x + paging->origin.x, attr.y + paging->origin.y,
		    attr.width, attr.height);
    CalcWindowPos(rcOrig);
  }
  else {
    /*
     * If the window is forced out the screen, locate (0, 0).
     */
    if (initPos + attr.width + BORDER_WIDTH * 2 > (int)rcScreen.width ||
	initPos + attr.height + TITLE_HEIGHT + TOP_BORDER + BORDER_WIDTH
	> (int)rcScreen.height)
      initPos = 0;

    rc.x = initPos + rcScreen.x + paging->origin.x;
    rc.y = initPos + rcScreen.y + paging->origin.y;
    if (CheckFlags(STICKY))
      rcOrig = Rect(rc.x - rcScreen.x - paging->origin.x,
		    rc.y - rcScreen.y - paging->origin.y,
		    attr.width,
		    attr.height);
    else
      rcOrig = Rect(rc.x - rcScreen.x, rc.y - rcScreen.y,
		    attr.width, attr.height);

    initPos += TITLE_HEIGHT + TOP_BORDER;

    int borderWidth, topBorder, titleHeight, titleEdge;
    GetBorderAndTitle(borderWidth, topBorder, titleHeight, titleEdge);

    rc.width = attr.width + borderWidth * 2;
    rc.height = attr.height + borderWidth + topBorder + titleHeight
      + titleEdge;
  }

  Rect rcParent, rcTitle, rcCorner[4], rcSide[4], rcCtrl, rcButton[3];

  CalcFramePos(rc, &rcParent, &rcTitle, rcCorner, rcSide, &rcCtrl,
	       rcButton);

  CreateFrame(rc);
  CreateParent(rcParent);
  CreateSides(rcSide);
  CreateCorners(rcCorner);  
  CreateTitle(rcTitle);
  CreateCtrlButton(rcCtrl);

  if (CheckFlags(THIN_BORDER))
    XSetWindowBorderWidth(display, frame, 1);

  /*
   * Create three kinds of frame button.
   */
  fButton[0] = new FrameButton1(this, title, rcButton[0],
				FrameButton::pixButton[0]);
  fButton[1] = new FrameButton2(this, title, rcButton[1],
				FrameButton::pixButton[1]);
  fButton[2] = new FrameButton3(this, title, rcButton[2],
				FrameButton::pixButton[2]);
  
  if (!CheckFlags(LARGEPIX))
    GetFixedIcon(pixLarge, gcLarge, 32);
  if (!CheckFlags(SMALLPIX))
    GetFixedIcon(pixSmall, gcSmall, 16);

  Rect rect(-50, -50, 50, 50);
  tButton = new TaskbarButton(this, rect, pixSmall, gcSmall, iconName);

  ctrlMenu = ::ctrlMenu;

  ChangeOrigWindow();

#ifdef SHAPE
  int bShaped, cShaped;
  int xbs, ybs, xcs, ycs;
  unsigned int wbs, hbs, wcs, hcs;

  if (shapeSupport) {
    XShapeSelectInput(display, w, ShapeNotifyMask);
    XShapeQueryExtents(display, w, &bShaped, &xbs, &ybs, &wbs, &hbs,
		       &cShaped, &xcs, &ycs, &wcs, &hcs);
    if (bShaped) {
      SetFlags(SHAPED);
      SetShape();
    }
  }
#endif

  if (UsePager)
    mini = new Miniature(this, rc);

  ASSERT(lastQvwm);

  /*
   * Add qvwm in qvwm list.
   */
  lastQvwm->next = this;
  prev = lastQvwm;
  next = NULL;
  lastQvwm = this;

  GrabKeys();

  XUngrabServer(display);
}

/*
 * Qvwm class constructor --
 *   For only root window.
 */
Qvwm::Qvwm(Window root) : wOrig(root), frame(root)
{
  Rect rect(0, 0, BUTTON_WIDTH, BUTTON_HEIGHT);

  rc = Rect(0, 0,
	    DisplayWidth(display, screen), DisplayHeight(display, screen));

  next = prev = NULL;
  preFocus = NULL;
  parent = title = ctrl = None;
  for (int i = 0; i < 4; i++) {
    corner[i] = None;
    side[i]= None;
  }
  mapped = True;
  flags = 0L;
  name = "qvwm root";

  transient = NULL;
  transientNum = 0;

  XRectangle ink, log;

  XmbTextExtents(fsTaskbar, StartButtonTitle, strlen(StartButtonTitle),
                 &ink, &log);
  log.width += 2 + StartButton::SYMBOL_WIDTH + 4 + 2 + 4;

  taskBar = new Taskbar(log.width + 4, TaskbarRows);
  tButton = new StartButton(this, log.width);

  rect = Rect(0, 0, 0, 0);
  ctrlMenu = new Menu(this, DesktopMenuItem, 0, 16, 0, 14, rect, fsCtrlMenu,
		      NULL);

  XSaveContext(display, root, context, (caddr_t)this);
}

Qvwm::~Qvwm()
{
  int i;

  if (this != rootQvwm) {
    XDeleteContext(display, frame, context);
    XDeleteContext(display, parent, context);
    XDeleteContext(display, wOrig, context);
    XDeleteContext(display, title, context);
    for (i = 0; i < 4; i++) {
      XDeleteContext(display, corner[i], context);
      XDeleteContext(display, side[i], context);
    }
    XDeleteContext(display, ctrl, context);

    delete [] name;

    if (pixLarge != pixLargeLogo && !CheckFlags(LARGEPIX)) {
      XFreePixmap(display, pixLarge);
      XFreeGC(display, gcLarge);
    }

    if (wmHints)
      XFree(wmHints);

    /*
     * Delete frame buttons before the parent window(frame) is destroyed.
     */
    for (i = 0; i < 3; i++)
      delete fButton[i];
    delete tButton;

    /*
     * Clean transient window list and inform destory of parent window
     * to them. And free the transient window list.
     */
    QvwmList *qvList = transient;
    while (qvList != NULL) {
      QvwmList* tmpList = qvList;

      ASSERT(qvList->GetQvwm());
      qvList->GetQvwm()->transientFor = NULL;
      qvList = qvList->GetNext();
      delete tmpList;
    }

    /*
     * If this is transient window, remove from transient list of parent
     * window.
     */
    if (CheckFlags(TRANSIENT) && transientFor != NULL) {
      QvwmList *qvList = transientFor->transient, *prevList = NULL;
      while (qvList) {
	if (qvList->GetQvwm() == this) {
	  if (prevList == NULL)
	    transientFor->transient = qvList->GetNext();
	  else
	    prevList->SetNext(qvList->GetNext());
	  transientFor->transientNum--;

	  delete qvList;
	  break;
	}
	prevList = qvList;
	qvList = qvList->GetNext();
      }
    }

    if (UsePager)
      delete mini;

    XDestroyWindow(display, frame);
  }
  else
    delete ctrlMenu;

  /*
   * Remove this qvwm from qvwm list.
   */
  if (prev != NULL)
    prev->next = next;
  if (next == NULL)
    lastQvwm = prev;
  else
    next->prev = prev;
}

/*
 * ChangeOrigWindow --
 *   Change parent and attributes of original window.
 */
void Qvwm::ChangeOrigWindow()
{
  XSetWindowAttributes attributes;
  unsigned long valueMask;

  XReparentWindow(display, wOrig, parent, 0, 0);

  attributes.event_mask = StructureNotifyMask | PropertyChangeMask |
    EnterWindowMask | LeaveWindowMask | ColormapChangeMask;
  attributes.do_not_propagate_mask = ButtonPressMask | ButtonReleaseMask;
  valueMask = CWEventMask | CWDontPropagate;

  XChangeWindowAttributes(display, wOrig, valueMask, &attributes);

  XSaveContext(display, wOrig, context, (caddr_t)this);
  XAddToSaveSet(display, wOrig);
}

/*
 * GrabKeys --
 *   Grab keys of window.
 */
void Qvwm::GrabKeys()
{
  KeyCode keycode;
  
  for (int i = 0; i < SCKeyNum; i++) {
    keycode = XKeysymToKeycode(display, scKey[i].sym);
    if (keycode != 0)
      XGrabKey(display, keycode, scKey[i].mod, frame, True, GrabModeAsync,
	       GrabModeAsync);
  }
}

/*
 * GrabRootKeys --
 *   Grab keys of root window.
 */
void Qvwm::GrabRootKeys()
{
  for (int i = 0; i < SCRootKeyNum; i++)
    XGrabKey(display, XKeysymToKeycode(display, scRootKey[i].sym),
	     scRootKey[i].mod, root, True, GrabModeAsync, GrabModeAsync);
}

/*
 * UngrabRootKeys --
 *   Ungrab keys of root window.
 */
void Qvwm::UngrabRootKeys()
{
  for (int i = 0; i < SCRootKeyNum; i++)
    XUngrabKey(display, XKeysymToKeycode(display, scRootKey[i].sym),
	       scRootKey[i].mod, root);
}

/*
 * SendMessage --
 *   Send the messeage to this window.
 */
void Qvwm::SendMessage(Atom atom)
{
  XClientMessageEvent cev;

  cev.type = ClientMessage;
  cev.window = wOrig;
  cev.message_type = _XA_WM_PROTOCOLS;
  cev.format = 32;
  cev.data.l[0] = atom;
  cev.data.l[1] = CurrentTime;

  XSendEvent(display, wOrig, False, 0L, (XEvent *)&cev);
}

/*
 * AdjustPage --
 *   Switch to the page where the window center point exists.
 */
void Qvwm::AdjustPage()
{
  if (this == rootQvwm)
    return;

  Rect rect = GetRect();
  Point ptCenter(rect.x+rect.width/2, rect.y+rect.height/2);
  Rect rcRoot = rootQvwm->GetRect();
  
  if (ptCenter.x >= 0)
    ptCenter.x =  ptCenter.x / rcRoot.width * rcRoot.width;
  else
    ptCenter.x = (ptCenter.x / rcRoot.width - 1) * rcRoot.width;

  if (ptCenter.y >= 0)
    ptCenter.y = ptCenter.y / rcRoot.height * rcRoot.height;
  else 
    ptCenter.y = (ptCenter.y / rcRoot.height - 1) * rcRoot.height;
  
  ASSERT(paging);

  paging->PagingProc(ptCenter);
}

/*
 * Exposure --
 *   Process exposure event.
 */
void Qvwm::Exposure(Window win)
{
  if (win == frame)
    DrawFrame();
  else if (win == ctrl)
    DrawCtrlMenuMark();
  else if (win == title)
    DrawTitle();
}

/*
 * Button1Press --
 *   Process the press of button1(mouse left button).
 */
void Qvwm::Button1Press(Window win, Time clickTime, const Point& ptRoot)
{
  int borderWidth, topBorder, titleHeight, titleEdge;

  if (win == ctrl) {
    /*
     * Double click.
     */
    if (IsDoubleClick(menuClickTime, clickTime, ptPrevRoot, ptRoot)) {
      ExecFunction(Q_KILL);
    }
    else {
      if (CheckMenuMapped())
	umReserved = True;
      else {
	UnmapAllMenus();

	if (!CheckFocus())
	  SetFocus();
	RaiseWindow(True);

	GetBorderAndTitle(borderWidth, topBorder, titleHeight, titleEdge);

	ASSERT(paging);
	MapMenu(rc.x - paging->origin.x + topBorder,
		rc.y - paging->origin.y + topBorder + titleHeight);
      }
    }
    menuClickTime = clickTime;
  }
  else {
    UnmapAllMenus();
    
    if (!CheckFocus())
      SetFocus();
    RaiseWindow(True);

    /*
     * Title bar.
     */
    if (win == title) {
      /*
       * When double click.
       */
      if (!CheckFlags(TRANSIENT) &&
	  IsDoubleClick(titleClickTime, clickTime, ptPrevRoot, ptRoot)) {
	ASSERT(fButton[1]);
	fButton[1]->SetState(Button::NORMAL);
	if (CheckStatus(MAXIMIZE_WINDOW)) {
	  /*
	   * Restore if maximun window.
	   */
	  fButton[1]->SetPixmap(FrameButton::pixButton[FrameButton::MAXIMIZE]);
	  RestoreWindow();
	}
	else {
	  /*
	   * Maximize if normal window.
	   */
	  fButton[1]->SetPixmap(FrameButton::pixButton[FrameButton::RESTORE]);
	  MaximizeWindow();
	}
      }
      titleClickTime = clickTime;
    }
  }
}

/*
 * Button1Release --
 *   Process the release of button1(mouse left button).
 */
void Qvwm::Button1Release()
{
  /*
   * Unmap control menu if the menu is shown and menu button is pressed.
   */
  if (umReserved) {
    ASSERT(ctrlMenu);
    ctrlMenu->UnmapMenu();
    umReserved = False;
  }
}    

/*
 * Button3Release --
 *   Process the release of button3(mouse right button).
 */
void Qvwm::Button3Release(Window win, const Point& ptRoot)
{
  Point pt;

  if (this == rootQvwm) {
    UnmapAllMenus();
    
    if (!CheckFocus())
      SetFocus();
    
    ASSERT(ctrlMenu);
    pt = ctrlMenu->GetFixedMenuPos(ptRoot);
    ctrlMenu->MapMenu(pt.x, pt.y);
  }
  else if (win == title || win == ctrl) {
    UnmapAllMenus();
    
    if (!CheckFocus())
      SetFocus();

    if (CheckMapped())
      RaiseWindow(True);
    else
      RestoreWindow();

    ASSERT(ctrlMenu);
    ctrlMenu->SetQvwm(this);
    pt = ctrlMenu->GetFixedMenuPos(ptRoot);
    ctrlMenu->MapMenu(pt.x, pt.y);
  }
}

/*
 * Button1Motion --
 *   Move or resize according to mouse movement.
 */
void Qvwm::Button1Motion(Window win, const Point& ptRoot)
{
  if (win == title && !CheckStatus(MAXIMIZE_WINDOW))
    MoveWindow(ptRoot);
  else if (win == side[0])
    ResizeWindow(LEFT, ptRoot);
  else if (win == side[1])
    ResizeWindow(RIGHT, ptRoot);
  else if (win == side[2])
    ResizeWindow(TOP, ptRoot);
  else if (win == side[3])
    ResizeWindow(BOTTOM, ptRoot);
  else if (win == corner[0])
    ResizeWindow(LEFTTOP, ptRoot);
  else if (win == corner[1])
    ResizeWindow(RIGHTTOP, ptRoot);
  else if (win == corner[2])
    ResizeWindow(LEFTBOTTOM, ptRoot);
  else if (win == corner[3])
    ResizeWindow(RIGHTBOTTOM, ptRoot);
}

/*
 * LookInList -- 
 *   Return the pointer if the window exists in qvwm list;
 *   otherwise, return NULL.
 */
Qvwm* Qvwm::LookInList(Window w)
{
  Qvwm *tmpQvwm = rootQvwm;

  while ((tmpQvwm = tmpQvwm->next) != NULL)
    if (w == tmpQvwm->wOrig)
      break;

  if (tmpQvwm) {
    tmpQvwm->CalcWindowPos(tmpQvwm->rcOrig);
    XMoveWindow(display, tmpQvwm->frame,
		tmpQvwm->rc.x - paging->origin.x,
		tmpQvwm->rc.y - paging->origin.y);
  }

  return tmpQvwm;
}

/*
 * CaptureAllWindows --
 *   Decorate all windows.
 */
void Qvwm::CaptureAllWindows()
{
  Qvwm* qvWm;
  Window junkRoot, junkParent, *children;
  unsigned int nChildren;
  XEvent ev;
  long state;

  if (!XQueryTree(display, root, &junkRoot, &junkParent, &children,
		  &nChildren))
    return;

  for (int i = 0; i < (int)nChildren; i++) {
    if (children[i] && MappedNotOverride(children[i], &state)) {
      qvWm = new Qvwm(children[i], True);

      if (state == IconicState) {
	int origSpeed = TitlebarMotionSpeed;

	TitlebarMotionSpeed = 0;
	qvWm->MinimizeWindow();
	TitlebarMotionSpeed = origSpeed;
      }
      else
	qvWm->MapWindows();

      ASSERT(qvWm->tButton);
      qvWm->tButton->MapButton();

      if (state != IconicState)
	qvWm->SetFocus();
    }
  }

  ChangeFocusToCursor();

  if (nChildren)
    XFree(children);
}      

/*
 * FinishQvwm --
 *   Free all resources and finish qvwm.
 */
void Qvwm::FinishQvwm(Bool reStart)
{
  if (!start) {
    XCloseDisplay(display);
    exit(1);
  }

  XGrabServer(display);

  ASSERT(paging);

  /*
   * Restore default page.
   */
  paging->PagingProc(Point(0, 0));

  XSetErrorHandler(FinishErrorHandler);

  Qvwm *qvWm, *nextQvwm = rootQvwm->next;

  while ((qvWm = nextQvwm) != NULL) {
    XReparentWindow(display, qvWm->wOrig, root,
		    qvWm->rcOrig.x, qvWm->rcOrig.y);
    XSetWindowBorderWidth(display, qvWm->wOrig, qvWm->bwOrig);

    nextQvwm = qvWm->next;         // preserve ptr to next before destroy
    delete qvWm;
  }

  XUngrabServer(display);

  Icon *icon = Icon::firstIcon, *pIcon;

  while (icon != NULL) {
    pIcon = icon->GetNext();
    delete icon;
    icon = pIcon;
  }

  delete rootQvwm;
  delete taskBar;
  delete startMenu;
  delete taskSwitcher;
  delete paging;
  delete pager;
  delete ::ctrlMenu;
  delete exitDlg;
  delete appHashTable;

  XSetInputFocus(display, root, RevertToNone, CurrentTime);

  if (!reStart) {
    XCloseDisplay(display);
    exit(0);
  }
}

/*
 * FinishErrorHandler --
 *   Jump to here when error happens in FinishQvwm. This error is ignored.
 */
int FinishErrorHandler(Display* display, XErrorEvent* ev)
{
  return 0;
}
