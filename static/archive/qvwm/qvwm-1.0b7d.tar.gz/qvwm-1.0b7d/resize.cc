#include <stdio.h>
#include <time.h>
#include <sys/time.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#ifdef SHAPE
#include <X11/extensions/shape.h>
#endif
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "events.h"
#include "taskbar.h"
#include "fbutton.h"
#include "tbutton.h"
#include "qvwmrc.h"
#include "paging.h"
#include "pager.h"

#ifdef SHAPE
static Bool ResizeWithShape(Display* display, XEvent* ev, char* arg);
#endif

/*
 * MoveWindow --
 *   Move the window with mouse or keyboard.
 */
void Qvwm::MoveWindow(const Point& ptRoot)
{
  XEvent ev;
  Rect rcNew;
  Point ptNew, ptOld, ptMove;
  Window junkRoot;
  unsigned int junkBW, junkDepth;
  Bool first = True;
  Bool pointer = False;

  ptOld = ptRoot;

  XGrabKeyboard(display, root, True, GrabModeAsync, GrabModeAsync,
		CurrentTime);
  if (ClickToFocus)
    XSetInputFocus(display, root, RevertToParent, CurrentTime);
  if (!OpaqueMove)
    XGrabServer(display);

  XGetGeometry(display, frame, &junkRoot, &rcNew.x, &rcNew.y, &rcNew.width,
	       &rcNew.height, &junkBW, &junkDepth);

  if (!OpaqueMove)
    XDrawRectangle(display, root, gcXor, rcNew.x, rcNew.y, rcNew.width,
		   rcNew.height);

  while (1) {
    XMaskEvent(display, KeyPressMask | PointerMotionMask | ButtonReleaseMask |
	       ButtonPressMask | ExposureMask, &ev);
    switch (ev.type) {
    case KeyPress:
      if (first) {
	ptNew = ptRoot;
	XDefineCursor(display, root, cursor[SYS]);
	first = False;
	pointer = True;
	XGrabPointer(display, root, True, ButtonPressMask | PointerMotionMask,
		     GrabModeAsync, GrabModeAsync, root, None, CurrentTime);
      }

      switch (XKeycodeToKeysym(display, ev.xkey.keycode, 0)) {
      case XK_Up:
	ptNew.y -= MOVEMENT;
	break;

      case XK_Down:
	ptNew.y += MOVEMENT;
	break;

      case XK_Right:
	ptNew.x += MOVEMENT;
	break;

      case XK_Left:
	ptNew.x -= MOVEMENT;
	break;

      case XK_Return:
	goto decide;
      }
      XWarpPointer(display, None, root, 0, 0, 0, 0, ptNew.x, ptNew.y);
      // to be continued to next case statement

    case MotionNotify:
      if (!(pointer || ev.xbutton.state & Button1Mask))
	return;

      if (first) {
	XDefineCursor(display, root, cursor[SYS]);
	first = False;
      }

      if (!OpaqueMove)
	XDrawRectangle(display, root, gcXor, rcNew.x, rcNew.y,
		       rcNew.width, rcNew.height);

      if (ev.type == MotionNotify)
	ptNew = Point(ev.xbutton.x_root, ev.xbutton.y_root);

      ASSERT(paging);

      ptMove = paging->HandlePaging(ptNew);
      ptNew.x -= ptMove.x;
      ptNew.y -= ptMove.y;

      rcNew.x += ptNew.x - ptOld.x;
      rcNew.y += ptNew.y - ptOld.y;
      ptOld = ptNew;

      if (OpaqueMove) {
	XMoveWindow(display, frame, rcNew.x, rcNew.y);
	if (UsePager) {
	  Point pt(rcNew.x + paging->origin.x, rcNew.y + paging->origin.y);

	  ASSERT(mini);
	  ASSERT(pager);

	  mini->MoveMiniature(pager->ConvertToPagerPos(pt));
	}
      }
      else 
	XDrawRectangle(display, root, gcXor, rcNew.x, rcNew.y,
		       rcNew.width, rcNew.height);

      break;

    case ButtonRelease:
      goto decide;

    case ButtonPress:
      if (pointer)
	goto decide;
      if (ev.xbutton.window == title) {
	ptOld = Point(ev.xbutton.x_root, ev.xbutton.y_root);
	XDefineCursor(display, root, cursor[SYS]);
	first = False;
      }
      else
	XAllowEvents(display, ReplayPointer, CurrentTime);
      break;

    case Expose:
      ExposeProc(ev.xexpose.window);
      break;
    }
  }

 decide:
  if (!OpaqueMove) {
    XDrawRectangle(display, root, gcXor, rcNew.x, rcNew.y,
		   rcNew.width, rcNew.height);
    XUngrabServer(display);
  }

  if (ClickToFocus)
    XSetInputFocus(display, wOrig, RevertToParent, CurrentTime);
  if (pointer)
    XUngrabPointer(display, CurrentTime);
  XUngrabKeyboard(display, CurrentTime);

  XMoveWindow(display, frame, rcNew.x, rcNew.y);
  rcNew.x += paging->origin.x;
  rcNew.y += paging->origin.y;
  ConfigureNewRect(rcNew);
  if (UsePager) {
    ASSERT(pager);
    Point ptMini(pager->ConvertToPagerPos(Point(rcNew.x, rcNew.y)));

    ASSERT(mini);
    mini->MoveMiniature(ptMini);
  }

  ASSERT(taskBar);

  taskBar->RaiseTaskbar();
}

/*
 * ResizeWindow --
 *   Resize the window with mouse or keyboard.
 */
void Qvwm::ResizeWindow(PositionName pos, const Point& ptRoot)
{
  RectPt resize;                  // amount of change
  XEvent ev;
  Rect rcNew, rcReal;
  Point ptNew, ptOld, ptMove;
  Window junkRoot;
  unsigned int junkBW, junkDepth;
  int width_inc = hints.width_inc;
  int height_inc = hints.height_inc;
  Bool first = True;
  Bool pointer = False;
  int borderWidth, topBorder, titleHeight, titleEdge;

  ptOld = ptRoot;

  XGrabKeyboard(display, root, True, GrabModeAsync, GrabModeAsync,
		CurrentTime);
  if (ClickToFocus)
    XSetInputFocus(display, root, RevertToParent, CurrentTime);
  if (!OpaqueMove)
    XGrabServer(display);
  
  XGetGeometry(display, frame, &junkRoot, &rcNew.x, &rcNew.y,
	       &rcNew.width, &rcNew.height, &junkBW, &junkDepth);

  if (!OpaqueMove)
    XDrawRectangle(display, root, gcXor, rcNew.x, rcNew.y,
		   rcNew.width, rcNew.height);

  while (1) {
#ifdef SHAPE
    if (OpaqueMove)
      XIfEvent(display, &ev, ResizeWithShape, NULL);
    else
#endif
    XMaskEvent(display, KeyPressMask | PointerMotionMask | ButtonReleaseMask |
	       ButtonPressMask | ExposureMask, &ev);
    switch (ev.type) {
    case KeyPress:
      if (first) {
	pointer = True;
	XGrabPointer(display, root, True, ButtonPressMask | PointerMotionMask,
		     GrabModeAsync, GrabModeAsync, root, None, CurrentTime);
      }
      ptNew = Point(ev.xkey.x_root, ev.xkey.y_root);

      switch (XKeycodeToKeysym(display, ev.xkey.keycode, 0)) {
      case XK_Up:
	if (first) {
	  pos = TOP;
	  ptNew.y = rcNew.y;
	  ptOld = Point(ptNew.x, RoundDown(ptNew.y, height_inc));
	  XWarpPointer(display, None, root, 0, 0, 0, 0, ptNew.x, ptNew.y);
	  XDefineCursor(display, root, cursor[Y_RESIZE]);
	  first = False;
	}
	if (pos == LEFT) {
	  pos = LEFTTOP;
	  ptNew.y = rcNew.y;
	  ptOld.y = RoundDown(ptNew.y, height_inc);
	  XWarpPointer(display, None, root, 0, 0, 0, 0, ptNew.x, ptNew.y);
	  XDefineCursor(display, root, cursor[RD_RESIZE]);
	}
	else if (pos == RIGHT) {
	  pos = RIGHTTOP;
	  ptNew.y = rcNew.y;
	  ptOld.y = RoundDown(ptNew.y, height_inc);
	  XWarpPointer(display, None, root, 0, 0, 0, 0, ptNew.x, ptNew.y);
	  XDefineCursor(display, root, cursor[LD_RESIZE]);
	}
	ptNew.y -= MOVEMENT;
	break;

      case XK_Down:
	if (first) {
	  pos = BOTTOM;
	  ptNew.y = rcNew.y + rcNew.height;
	  ptOld = Point(ptNew.x, RoundDown(ptNew.y, height_inc));
	  XWarpPointer(display, None, root, 0, 0, 0, 0, ptNew.x, ptNew.y);
	  XDefineCursor(display, root, cursor[Y_RESIZE]);
	  first = False;
	}
	if (pos == LEFT) {
	  pos = LEFTBOTTOM;
	  ptNew.y = rcNew.y + rcNew.height;
	  ptOld.y = RoundDown(ptNew.y, height_inc);
	  XWarpPointer(display, None, root, 0, 0, 0, 0, ptNew.x, ptNew.y);
	  XDefineCursor(display, root, cursor[LD_RESIZE]);
	}
	else if (pos == RIGHT) {
	  pos = RIGHTBOTTOM;
	  ptNew.y = rcNew.y + rcNew.height;
	  ptOld.y = RoundDown(ptNew.y, height_inc);
	  XWarpPointer(display, None, root, 0, 0, 0, 0, ptNew.x, ptNew.y);
	  XDefineCursor(display, root, cursor[RD_RESIZE]);
	}
	ptNew.y += MOVEMENT;
	break;

      case XK_Right:
	if (first) {
	  pos = RIGHT;
	  ptNew.x = rcNew.x + rcNew.width;
	  ptOld = Point(RoundDown(ptNew.x, width_inc), ptNew.y);
	  XWarpPointer(display, None, root, 0, 0, 0, 0, ptNew.x, ptNew.y);
	  XDefineCursor(display, root, cursor[X_RESIZE]);
	  first = False;
	}
	if (pos == TOP) {
	  pos = RIGHTTOP;
	  ptNew.x = rcNew.x + rcNew.width;
	  ptOld.x = RoundDown(ptNew.x, width_inc);
	  XWarpPointer(display, None, root, 0, 0, 0, 0, ptNew.x, ptNew.y);
	  XDefineCursor(display, root, cursor[LD_RESIZE]);
	}
	else if (pos == BOTTOM) {
	  pos = RIGHTBOTTOM;
	  ptNew.x = rcNew.x + rcNew.width;
	  ptOld.x = RoundDown(ptNew.x, width_inc);
	  XWarpPointer(display, None, root, 0, 0, 0, 0, ptNew.x, ptNew.y);
	  XDefineCursor(display, root, cursor[RD_RESIZE]);
	}
	ptNew.x += MOVEMENT;
	break;

      case XK_Left:
	if (first) {
	  pos = LEFT;
	  ptNew.x = rcNew.x;
	  ptOld = Point(RoundDown(ptNew.x, width_inc), ptNew.y);
	  XWarpPointer(display, None, root, 0, 0, 0, 0, ptNew.x, ptNew.y);
	  XDefineCursor(display, root, cursor[X_RESIZE]);
	  first = False;
	}
	if (pos == TOP) {
	  pos = LEFTTOP;
	  ptNew.x = rcNew.x;
	  ptOld.x = RoundDown(ptNew.x, width_inc);
	  XWarpPointer(display, None, root, 0, 0, 0, 0, ptNew.x, ptNew.y);
	  XDefineCursor(display, root, cursor[RD_RESIZE]);
	}
	else if (pos == BOTTOM) {
	  pos = LEFTBOTTOM;
	  ptNew.x = rcNew.x;
	  ptOld.x = RoundDown(ptNew.x, width_inc);
	  XWarpPointer(display, None, root, 0, 0, 0, 0, ptNew.x, ptNew.y);
	  XDefineCursor(display, root, cursor[LD_RESIZE]);
	}
	ptNew.x -= MOVEMENT;
	break;

      case XK_Return:
	goto decide;
      }
      XWarpPointer(display, None, root, 0, 0, 0, 0, ptNew.x, ptNew.y);
      // continue

    case MotionNotify:
      if (!OpaqueMove)
	XDrawRectangle(display, root, gcXor, rcNew.x, rcNew.y,
		       rcNew.width, rcNew.height);

      if (ev.type == MotionNotify)
	ptNew = Point(ev.xbutton.x_root, ev.xbutton.y_root);

      ASSERT(paging);

      ptMove = paging->HandlePaging(ptNew);
      ptOld -= ptMove;
      ptNew -= ptMove;
      rcNew.x -= ptMove.x;
      rcNew.y -= ptMove.y;
	
      resize = RectPt(0, 0, 0, 0);

      switch (pos) {
      case LEFT:
	resize.left = RoundDown(ptNew.x - ptOld.x, width_inc);
	break;

      case RIGHT:
	resize.right = RoundDown(ptNew.x - ptOld.x, width_inc);
	break;

      case TOP:
	resize.top = RoundDown(ptNew.y - ptOld.y, height_inc);
	break;

      case BOTTOM:
	resize.bottom = RoundDown(ptNew.y - ptOld.y, height_inc);
	break;

      case LEFTTOP:
	resize.left = RoundDown(ptNew.x - ptOld.x, width_inc);
	resize.top = RoundDown(ptNew.y - ptOld.y, height_inc);
	break;

      case RIGHTTOP:
	resize.right = RoundDown(ptNew.x - ptOld.x, width_inc);
	resize.top = RoundDown(ptNew.y - ptOld.y, height_inc);
	break;

      case LEFTBOTTOM:
	resize.left = RoundDown(ptNew.x - ptOld.x, width_inc);
	resize.bottom = RoundDown(ptNew.y - ptOld.y, height_inc);
	break;

      case RIGHTBOTTOM:
	resize.right = RoundDown(ptNew.x - ptOld.x, width_inc);
	resize.bottom = RoundDown(ptNew.y - ptOld.y, height_inc);
	break;
      }
      
      ptOld += Point(resize.left + resize.right, resize.top + resize.bottom);

      rcNew.x += resize.left;
      rcNew.y += resize.top;
      rcNew.width += resize.right - resize.left;
      rcNew.height += resize.bottom - resize.top;

      GetBorderAndTitle(borderWidth, topBorder, titleHeight, titleEdge);

      /*
       * Check minimum limit of size.
       */
      if ((signed)rcNew.width - borderWidth * 2 <= 0)
	rcNew.width = 1 + borderWidth * 2;
      else if ((signed)rcNew.width - borderWidth * 2 < hints.min_width)
	rcNew.width = hints.min_width + borderWidth * 2;
      if ((signed)rcNew.height - (borderWidth + topBorder + titleHeight
				  + titleEdge) <= 0)
	rcNew.height = 1 + borderWidth + topBorder + titleHeight + titleEdge;
      else if ((signed)rcNew.height - (borderWidth + topBorder + titleHeight
				       + titleEdge) < hints.min_height)
	rcNew.height = hints.min_height + borderWidth + topBorder + titleHeight
	  + titleEdge;
      
      /*
       * Check maximum limit of size.
       */
      if ((int)rcNew.width - borderWidth * 2 > hints.max_width)
	rcNew.width = hints.max_width + borderWidth * 2;
      if ((int)rcNew.height-(borderWidth + topBorder + titleHeight
			     + titleEdge) > hints.max_height)
	rcNew.height = hints.max_height + borderWidth + topBorder + titleHeight
	  + titleEdge;
      
      if (OpaqueMove) {
	rcReal = Rect(rcNew.x + paging->origin.x, rcNew.y + paging->origin.y,
		      rcNew.width, rcNew.height);
	ConfigureNewRect(rcReal);
	RedrawWindow();
	if (UsePager) {
	  ASSERT(pager);
	  Rect rcMini(pager->ConvertToPagerSize(rcReal));

	  ASSERT(mini);
	  mini->MoveResizeMiniature(rcMini);
	}
      }
      else
	XDrawRectangle(display, root, gcXor, rcNew.x, rcNew.y,
		       rcNew.width, rcNew.height);

      break;
      
    case ButtonRelease:
      goto decide;

    case ButtonPress:
      if (pointer)
	goto decide;

      ptOld = Point(ev.xbutton.x_root, ev.xbutton.y_root);
      first = False;

      if (ev.xbutton.window == side[0])
	pos = LEFT;
      else if (ev.xbutton.window == side[1])
	pos = RIGHT;
      else if (ev.xbutton.window == side[2])
	pos = TOP;
      else if (ev.xbutton.window == side[3])
	pos = BOTTOM;
      else if (ev.xbutton.window == corner[0])
	pos = LEFTTOP;
      else if (ev.xbutton.window == corner[1])
	pos = RIGHTTOP;
      else if (ev.xbutton.window == corner[2])
	pos = LEFTBOTTOM;
      else if (ev.xbutton.window == corner[3])
	pos = RIGHTBOTTOM;
      else
	XAllowEvents(display, ReplayPointer, CurrentTime);
      break;

    case Expose:
      ExposeProc(ev.xexpose.window);
      break;

#ifdef SHAPE
    default:
      if (shapeSupport) {
	if (ev.type == shapeEventBase + ShapeNotify) {
	  XShapeEvent *sev = (XShapeEvent *)&ev;
	  ShapeNotifyProc(sev->window, sev->kind);
	}
      }
      break;
#endif
    }
  }

 decide:
  XDefineCursor(display, root, cursor[SYS]);

  if (!OpaqueMove) {
    XDrawRectangle(display, root, gcXor, rcNew.x, rcNew.y,
		   rcNew.width, rcNew.height);
    XUngrabServer(display);
  }

  if (ClickToFocus)
    XSetInputFocus(display, wOrig, RevertToParent, CurrentTime);
  if (pointer)
    XUngrabPointer(display, CurrentTime);
  XUngrabKeyboard(display, CurrentTime);
  
  if (!OpaqueMove) {
    ASSERT(paging);
    rcNew.x += paging->origin.x;
    rcNew.y += paging->origin.y;
    ConfigureNewRect(rcNew);
    RedrawWindow();
    if (UsePager) {
      ASSERT(pager);
      Rect rcMini(pager->ConvertToPagerSize(rcNew));

      ASSERT(mini);
      mini->MoveResizeMiniature(rcMini);
    }
  }
  
  ASSERT(taskBar);

  taskBar->RaiseTaskbar();
}

#ifdef SHAPE
static Bool ResizeWithShape(Display* display, XEvent* ev, char* arg)
{
  switch (ev->type) {
  case KeyPress:
  case ButtonPress:
  case ButtonRelease:
  case MotionNotify:
  case Expose:
    return True;
    
  default:
    if (shapeSupport)
      if (ev->type == shapeEventBase + ShapeNotify)
	return True;
    break;
  }
  
  return False;
}
#endif

/*
 * MaximizeWindow --
 *   Maximize the window.
 */
void Qvwm::MaximizeWindow()
{
  Window junkRoot;
  unsigned int junkBW, junkDepth;
  Rect rcSrc, rcDest, rect;

  XGrabServer(display);

  XGetGeometry(display, frame, &junkRoot, &rcSrc.x, &rcSrc.y,
	       &rcSrc.width, &rcSrc.height, &junkBW, &junkDepth);

  ASSERT(paging);

  if (CheckStatus(MINIMIZE_WINDOW)) {
    /*
     * min -> max
     */
    SetStateProperty(NormalState);

    ASSERT(tButton);
    ASSERT(taskBar);

    rcSrc = tButton->GetRect();
    rect = taskBar->GetRect();
    rcSrc.x += rect.x;
    rcSrc.y += rect.y;
  }
  else {
    /*
     * normal -> max
     */
    rcSrc = rc;
    rcSrc.x -= paging->origin.x;
    rcSrc.y -= paging->origin.y;
    flagsBak = flags;
  }

  rcDest = GetFixSize(rcScreen, hints.max_width, hints.max_height,
		      hints.width_inc, hints.height_inc,
		      hints.base_width, hints.base_height);
  rc = rcDest;
  rc.x += paging->origin.x;
  rc.y += paging->origin.y;

  rcOrigBak = rcOrig;

  ResetFlags(BORDER);

  SetStatus(MAXIMIZE_WINDOW);
  ResetStatus(MINIMIZE_WINDOW);

  MotionTitlebar(rcSrc, rcDest);
  ConfigureNewRect(rc);

  if (CheckFlags(THIN_BORDER))
    XSetWindowBorderWidth(display, frame, 0);

  RedrawWindow();
  MapWindows();
  SetFocus();
  if (UsePager) {
    ASSERT(mini);
    ASSERT(pager);
    mini->MoveResizeMiniature(pager->ConvertToPagerSize(rc));
  }

  XUngrabServer(display);
}

/*
 * MinimizeWindow --
 *   Minimize the window.
 */
void Qvwm::MinimizeWindow()
{
  Rect rcSrc, rcDest, rect;

  // cannot minimize without taskbar button
  if (CheckFlags(NOTBUTTON))
    return;

  XGrabServer(display);

  if (CheckStatus(MAXIMIZE_WINDOW)) {
    /*
     * max->min
     */
    rcSrc = GetFixSize(rcScreen, hints.max_width, hints.max_height,
		       hints.width_inc, hints.height_inc,
		       hints.base_width, hints.base_height);
  }
  else {
    ASSERT(paging);
    /*
     * normal->min
     */
    rcSrc = rc;
    rcSrc.x -= paging->origin.x;
    rcSrc.y -= paging->origin.y;
    flagsBak = flags;
  }

  ASSERT(tButton);
  ASSERT(taskBar);

  rcDest = tButton->GetRect();
  rect = taskBar->GetRect();
  rcDest.x += rect.x;
  rcDest.y += rect.y;

  SetStatus(MINIMIZE_WINDOW);
  SetStateProperty(IconicState);

  MotionTitlebar(rcSrc, rcDest);

  if (ClickToFocus)
    ChangeFocus();
  UnmapWindows();

  XUngrabServer(display);
}

/*
 * RestoreWindow --
 *   Restore the window to previous state.
 */
void Qvwm::RestoreWindow()
{
  Rect rcSrc, rcDest, rect;

  XGrabServer(display);

  ASSERT(paging);

  if (CheckStatus(MINIMIZE_WINDOW) && CheckStatus(MAXIMIZE_WINDOW)) {
    /*
     * min -> max
     */
    ResetStatus(MINIMIZE_WINDOW);
    SetStateProperty(NormalState);

    ASSERT(tButton);
    ASSERT(taskBar);

    rcSrc = tButton->GetRect();
    rect = taskBar->GetRect();
    rcSrc.x += rect.x;
    rcSrc.y += rect.y;
    rcDest = GetFixSize(rcScreen, hints.max_width, hints.max_height,
			hints.width_inc, hints.height_inc,
			hints.base_width, hints.base_height);
    rc = rcDest;

    rc.x += paging->origin.x;
    rc.y += paging->origin.y;

    ResetFlags(BORDER);
  }
  else if (CheckStatus(MINIMIZE_WINDOW)) {
    /*
     * min -> normal
     */
    ResetStatus(MAXIMIZE_WINDOW | MINIMIZE_WINDOW);
    SetStateProperty(NormalState);

    ASSERT(tButton);
    ASSERT(taskBar);

    rcSrc = tButton->GetRect();
    rect = taskBar->GetRect();
    rcSrc.x += rect.x;
    rcSrc.y += rect.y;
    flags = flagsBak;
    CalcWindowPos(rcOrig);

    rcDest = rc;
    rcDest.x -= paging->origin.x;
    rcDest.y -= paging->origin.y;
  }
  else if (CheckStatus(MAXIMIZE_WINDOW)) {
    /*
     * max -> normal
     */
    ResetStatus(MAXIMIZE_WINDOW | MINIMIZE_WINDOW);

    rcSrc = GetFixSize(rcScreen, hints.max_width, hints.max_height,
		       hints.width_inc, hints.height_inc,
		       hints.base_width, hints.base_height);
    flags = flagsBak;
    rcOrig = rcOrigBak;
    CalcWindowPos(rcOrig);

    rcDest = rc;
    rcDest.x -= paging->origin.x;
    rcDest.y -= paging->origin.y;
  }

  MotionTitlebar(rcSrc, rcDest);
  ConfigureNewRect(rc);

  if (CheckFlags(THIN_BORDER))
    XSetWindowBorderWidth(display, frame, 1);

  RedrawWindow();
  MapWindows();
  SetFocus();
  AdjustPage();
  if (UsePager) {
    ASSERT(mini);
    ASSERT(pager);
    mini->MoveResizeMiniature(pager->ConvertToPagerSize(rc));
  }

  XUngrabServer(display);
}

/*
 * RedrawWindow --
 *   Redraw the window decoration.
 */
void Qvwm::RedrawWindow()
{
  Rect rcParent, rcTitle, rcCorner[4], rcSide[4], rcCtrl, rcButton[3];

  CalcFramePos(rc, &rcParent, &rcTitle, rcCorner, rcSide, &rcCtrl, rcButton);

  ASSERT(paging);

  XMoveResizeWindow(display, frame,
		    rc.x - paging->origin.x, rc.y - paging->origin.y,
		    rc.width, rc.height);
  XMoveResizeWindow(display, parent, rcParent.x, rcParent.y,
		    rcParent.width, rcParent.height);
  XMoveResizeWindow(display, wOrig, 0, 0, rcParent.width, rcParent.height);
  if (CheckFlags(BORDER)) {
    for (int i = 0; i < 4; i++) {
      XMoveResizeWindow(display, side[i], rcSide[i].x, rcSide[i].y,
			rcSide[i].width, rcSide[i].height);
      XMoveWindow(display, corner[i], rcCorner[i].x, rcCorner[i].y);
    }
  }
  if (CheckFlags(TITLE)) {
    XMoveWindow(display, ctrl, rcCtrl.x, rcCtrl.y);
    for (int i = 0; i < 3; i++) {
      ASSERT(fButton[i]);
      fButton[i]->MoveResizeButton(rcButton[i]);
    }
    XMoveResizeWindow(display, title, rcTitle.x, rcTitle.y,
		      rcTitle.width, rcTitle.height);
  }
}

/*
 * MotionTitlebar --
 *   Move the titlebar to dest slowly.
 */
void Qvwm::MotionTitlebar(const Rect& rcSrc, const Rect& rcDest)
{
  Window motionBarWin;
  double incX, incY, incWidth;
  XSetWindowAttributes attributes;
  unsigned long valueMask;

  if (TitlebarMotionSpeed == 0)
    return;

  XSync(display, 0);

  attributes.save_under = True;
  attributes.background_pixel = blue;
  valueMask = CWSaveUnder | CWBackPixel;

  /*
   * Create a motion title bar.
   */
  motionBarWin = XCreateWindow(display, root, rcSrc.x, rcSrc.y,
			       rcSrc.width, TITLE_HEIGHT,
			       0, CopyFromParent, InputOutput, CopyFromParent, 
			       valueMask, &attributes);

  XMapRaised(display, motionBarWin);

  incX = (double)(rcDest.x - rcSrc.x) / TitlebarMotionSpeed;
  incY = (double)(rcDest.y - rcSrc.y) / TitlebarMotionSpeed;
  incWidth = (double)((int)rcDest.width-(int)rcSrc.width)/TitlebarMotionSpeed;

  /*
   * Move the titlebar slowly.
   */
  XSetForeground(display, gc, white);
  XSetClipOrigin(display, gcLogo, 2, 1);

  for (int i = 1; i < TitlebarMotionSpeed; i++) {
    XMoveResizeWindow(display, motionBarWin,
		      rcSrc.x + (int)(incX * i), rcSrc.y + (int)(incY * i),
		      rcSrc.width + (unsigned int)(incWidth * i),
		      TITLE_HEIGHT);
    XCopyArea(display, GetIconPixmap(), motionBarWin, GetIconGC(), 0, 0,
	      TaskbarButton::SYMBOL_WIDTH, TaskbarButton::SYMBOL_HEIGHT, 2, 1);

    /*
     * If you don't have this function, motion title bar may be underneath
     * main window.
     */
    XRaiseWindow(display, motionBarWin);
  }

  XDestroyWindow(display, motionBarWin);
}

/*
 * GetFixSize --
 *   Adjust the position and the size of the window according to the window
 *   property.
 */
Rect Qvwm::GetFixSize(const Rect& rc, int max_width, int max_height,
		      int width_inc, int height_inc,
		      int base_width, int base_height)
{
  Rect rect;
  int borderWidth, topBorder, titleHeight, titleEdge;

  rect.x = rc.x;
  rect.y = rc.y;

  GetBorderAndTitle(borderWidth, topBorder, titleHeight, titleEdge);

  /*
   * When the maximum size is smaller than the screen size.
   */
  if (max_width + borderWidth * 2 < (int)rcScreen.width)
    rect.width = max_width + borderWidth * 2;
  if (max_height + borderWidth + topBorder + titleHeight + titleEdge
      < (int)rcScreen.height)
    rect.height = max_height + borderWidth + topBorder + titleHeight
      + titleEdge;

  /*
   * Adjust the window size to base_size+incr*i.
   */
  rect.width = RoundDown(rc.width-base_width, width_inc) + base_width;
  rect.height = RoundDown(rc.height-base_height, height_inc) + base_height;

  return rect;
}
