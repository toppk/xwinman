#ifndef _STARTMENU_H_
#define _STARTMENU_H_

#include "menu.h"

class StartMenu : public Menu {
private:
  Window logo;                      // window for logo mark in the left side
  Window* itemFocus;                // transparent window for each item
                                    // this includes the parts of logo.
  static Pixmap pixAd;              // logo mark
  
  static const int LOGO_WIDTH = 21;

public:
  static Pixmap pixStart[2];
  static GC gcStart[2];

public:
  StartMenu(MenuItem* mItem);
  ~StartMenu();
  void MapMenu();
  void UnmapMenu();
  void DrawMenu(Window win);
  int FindItem(Window win);

  static void CreateStartMenuPixmap();
};

#endif // _STARTMENU_H_
