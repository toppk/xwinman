#ifndef _RESOURCE_H_
#define _RESOURCE_H_

#include "misc.h"
#include "main.h"

// Predefine
#define NO_ID     -1
#define ID_OK      0
#define ID_CANCEL  1
#define ID_HELP    2

typedef int ResourceId;

enum ItemKind {
  STRINGBUTTON,
  RADIOBUTTON,
  RADIOSET,
  STATICTEXT,
  ICONPIXMAP,
};

class DialogRes {
public:
  ItemKind kind;
  ResourceId rid;
  Rect rc;
  char* str;
  XFontSet& fs;
  ResourceId initId;
  Pixmap pix;
  GC gc;

public:
  // for STATICTEXT, RADIOBUTTON, STRINGBUTTON
  DialogRes(ItemKind ik, ResourceId res_id, const Rect& rect, char* label,
	    XFontSet& labelfs) : kind(ik), rid(res_id), rc(rect), str(label),
            fs(labelfs) {}
  // for ICONPIXMAP
  DialogRes(ItemKind ik, ResourceId res_id, const Rect& rect,
	    XFontSet& labelfs, ResourceId init, Pixmap p, GC pgc)
    : kind(ik), rid(res_id), rc(rect), fs(labelfs), initId(init), pix(p),
      gc(pgc) {}
  // for RADIOSET
  DialogRes(ItemKind ik, ResourceId res_id, ResourceId init)
    : kind(ik), rid(res_id), fs(fsDialog), initId(init) {}
};

class StaticText {
public:
  Point pt;
  char* text;
  XFontSet& fs;
  
public:
  StaticText(const Point& point, char* label, XFontSet& labelfs)
    : pt(point), text(label), fs(labelfs) {}
};

class IconPixmap {
public:
  Rect rc;
  Pixmap pix;
  GC gc;

public:
  IconPixmap(const Rect& rect, Pixmap p, GC pgc) : rc(rect), pix(p), gc(pgc) {}
};

#endif // _RESOURCE_H_
