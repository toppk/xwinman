#include <stdio.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/xpm.h>
#include "main.h"
#include "misc.h"
#include "util.h"
#include "qvwm.h"
#include "radio_button.h"
#include "radio_set.h"
#include "bitmaps/radio0.xpm"
#include "bitmaps/radio1.xpm"
#include "bitmaps/radio2.xpm"

XContext RadioButton::context;
Pixmap RadioButton::pixRadio[3];
GC RadioButton::gcRadio[3];

RadioButton::RadioButton(Window parent, const Point& point, char* btnname,
			 XFontSet& btnfs, ResourceId res_id)
: pt(point), name(btnname), fs(btnfs), rid(res_id)
{
  XSetWindowAttributes attributes;
  unsigned long valueMask;
  XRectangle ink, log;
  int width, height;

  status = 0;

  XmbTextExtents(fs, name, strlen(name), &ink, &log);
  width = BUTTON_SIZE + 5 + log.width + 1;
  height = Max(BUTTON_SIZE, log.height+2);

  rbY = (height - BUTTON_SIZE) / 2;
  rnY = (height - log.height) / 2 - log.y;

  XSetClipOrigin(display, gcRadio[0], 0, rbY);
  XSetClipOrigin(display, gcRadio[1], 0, rbY);
  XSetClipOrigin(display, gcRadio[2], 4, rbY+4);

  rc = Rect(BUTTON_SIZE + 4 - log.x, (height - log.height) / 2,
	    log.width + 1, log.height);

  attributes.background_pixel = gray;
  attributes.event_mask = ExposureMask | ButtonPressMask | ButtonReleaseMask |
                          EnterWindowMask | LeaveWindowMask;
  valueMask = CWBackPixel | CWEventMask;
  
  frame = XCreateWindow(display, parent, pt.x, pt.y, width, height,
			0, CopyFromParent, InputOutput, CopyFromParent,
			valueMask, &attributes);

  XSaveContext(display, frame, RadioButton::context, (caddr_t)this);
}

/*
 * MapButton --
 *   Map radio button frame.
 */
RadioButton::~RadioButton()
{
  XDestroyWindow(display, frame);
}

/*
 * DrawButton --
 *   Draw radio button. If all is True, draw text too.
 */
void RadioButton::MapButton()
{
  XMapWindow(display, frame);
}

void RadioButton::DrawButton(Bool all)
{
  if (status & RADIO_PUSH)
    XCopyArea(display, pixRadio[1], frame, gcRadio[1],
	      0, 0, BUTTON_SIZE, BUTTON_SIZE, 0, rbY);
  else
    XCopyArea(display, pixRadio[0], frame, gcRadio[0],
	      0, 0, BUTTON_SIZE, BUTTON_SIZE, 0, rbY);

  if (status & RADIO_CHECK) {
    XCopyArea(display, pixRadio[2], frame, gcRadio[2],
	      0, 0, CHECK_SIZE, CHECK_SIZE, 4, rbY+4);
    XSetForeground(display, gcDash, black);
    XDrawRectangle(display, frame, gcDash, rc.x, rc.y, rc.width, rc.height); 
  }
  else {
    XSetForeground(display, gcDash, gray);
    XDrawRectangle(display, frame, gcDash, rc.x, rc.y, rc.width, rc.height); 
  }

  /*
   * Draw text.
   */
  if (all) {
    XSetForeground(display, ::gc, black);
    XmbDrawString(display, frame, fs, ::gc, BUTTON_SIZE + 5, rnY,
		  name, strlen(name));
  }
}

/*
 * Button1Press --
 *   Process press of button1 (mouse left button).
 */
void RadioButton::Button1Press()
{
  XEvent ev;

  status |= RADIO_PUSH;
  DrawButton(False);
  
  while (1) {
    XMaskEvent(display, EnterWindowMask | LeaveWindowMask | ButtonReleaseMask,
	       &ev);
    switch (ev.type) {
    case EnterNotify:
      status |= RADIO_PUSH;
      DrawButton(False);
      break;

    case LeaveNotify:
      status &= ~RADIO_PUSH;
      DrawButton(False);
      break;

    case ButtonRelease:
      if (ev.xbutton.state & Button1Mask) {
	if (status & RADIO_PUSH) {
	  ASSERT(rs);
	  
	  if (rs->rbFocus != this) {
	    ASSERT(rs->rbFocus)
	    rs->rbFocus->status = 0;
	    rs->rbFocus->DrawButton(False);
	    rs->rbFocus = this;
	  }
	  status = RADIO_CHECK;
	  DrawButton(False);
	}
	return;
      }
      break;
    }
  }
}

/*
 * CreateRadioButtonPixmap --
 *   Create 3 kinds of radio button pixmaps.
 */
void RadioButton::CreateRadioButtonPixmap()
{
  XpmAttributes attr;
  Pixmap mask;
  XGCValues gcv;

  attr.valuemask = XpmColormap | XpmDepth;
  attr.colormap = colormap;
  attr.depth = depth;

  XpmCreatePixmapFromData(display, root, radio0, &pixRadio[0], &mask, &attr);
  gcv.clip_mask = mask;
  gcRadio[0] = XCreateGC(display, root, GCClipMask, &gcv);

  XpmCreatePixmapFromData(display, root, radio1, &pixRadio[1], &mask, &attr);
  gcv.clip_mask = mask;
  gcRadio[1] = XCreateGC(display, root, GCClipMask, &gcv);

  XpmCreatePixmapFromData(display, root, radio2, &pixRadio[2], &mask, &attr);
  gcv.clip_mask = mask;
  gcRadio[2] = XCreateGC(display, root, GCClipMask, &gcv);
}
  
