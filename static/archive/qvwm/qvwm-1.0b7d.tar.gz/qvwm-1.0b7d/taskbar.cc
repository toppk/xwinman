#include <stdio.h>
#include <string.h>
#include <time.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "taskbar.h"
#include "tbutton.h"
#include "sbutton.h"
#include "startmenu.h"
#include "events.h"
#include "icon.h"
#include "paging.h"
#include "pager.h"
#include "qvwmrc.h"

Taskbar::Taskbar(int width, unsigned int rows)
{
  XSetWindowAttributes attributes;
  unsigned long valueMask;
  Dim dRoot(DisplayWidth(display, screen), DisplayHeight(display, screen));
  Dim base;
  char *str;
  int len;
  XRectangle ink, log;

  /*
   * Calculate clock width.
   */
  if (Clock12Hours) {
    str = "88:88 AM";
    len = 8;
  }
  else {
    str = "88:88";
    len = 5;
  }
  XmbTextExtents(fsTaskbar, str, len, &ink, &log);
  clockWidth = log.width + 20;

  base.width = (width > clockWidth + 6) ? width : clockWidth + 6;
  base.height = (rows - 1) * INC_HEIGHT + BASE_HEIGHT;
  if (base.height > dRoot.height / 2)
    base.height = (dRoot.height / 2 - BASE_HEIGHT) / INC_HEIGHT * INC_HEIGHT
      + BASE_HEIGHT;
 
  rc[BOTTOM] = Rect(0, dRoot.height - base.height, dRoot.width, base.height);
  rc[TOP] = Rect(0, 0, dRoot.width, base.height);
  rc[LEFT] = Rect(0, 0, base.width, dRoot.height);
  rc[RIGHT] = Rect(dRoot.width - base.width, 0, base.width, dRoot.height);

  /*
   * Create taskbar.
   */
  attributes.background_pixel = gray;
  attributes.override_redirect = True;
  attributes.event_mask = ExposureMask | ButtonPressMask | ButtonReleaseMask |
                          Button1MotionMask;
  valueMask = CWBackPixel | CWOverrideRedirect | CWEventMask;

  frame = XCreateWindow(display, root,
			-10, -10, 10, 10,
			0, CopyFromParent, InputOutput, CopyFromParent,
			valueMask, &attributes);

  attributes.event_mask = ButtonPressMask | ButtonReleaseMask |
                          Button1MotionMask;
  attributes.background_pixel = gray;
  attributes.cursor = cursor[SYS];
  valueMask = CWBackPixel | CWCursor | CWEventMask;

  w = XCreateWindow(display, frame,
		    0, 0, 10, 10,
		    0, CopyFromParent, InputOutput, CopyFromParent,
		    valueMask, &attributes);

  /*
   * Create clock.
   */
  attributes.event_mask = ExposureMask;
  valueMask = CWBackPixel | CWEventMask;

  clock = XCreateWindow(display, w,
			0, 0, clockWidth, CLOCK_HEIGHT,
			0, CopyFromParent, InputOutput, CopyFromParent,
			valueMask, &attributes);
}

Taskbar::~Taskbar()
{
  XDestroyWindow(display, frame);
}

/*
 * MapTaskbar --
 *   Map the taskbar.
 */
void Taskbar::MapTaskbar()
{
  XMapRaised(display, frame);
  XMapWindow(display, w);

  ASSERT(rootQvwm);
  ASSERT(rootQvwm->tButton);

  rootQvwm->tButton->MapButton();         // Start menu
  XMapWindow(display, clock);

  paging->RaisePagingBelt();
}

/*
 * UnmapTaskbar --
 *   Unmap the taskbar.
 */
void Taskbar::UnmapTaskbar()
{
  XUnmapWindow(display, frame);
}

/*
 * MoveTaskbar --
 *   Move the taskbar to the tp position.
 */
void Taskbar::MoveTaskbar(TaskbarPos tp)
{
  Rect rcRoot = rootQvwm->GetRect();
  StartButton *sButton = (StartButton *)rootQvwm->tButton;

  ASSERT(sButton);

  pos = tp;

  XMoveResizeWindow(display, frame, rc[pos].x, rc[pos].y, rc[pos].width,
		    rc[pos].height);

  switch (pos) {
  case BOTTOM:
    XDefineCursor(display, frame, cursor[Y_RESIZE]);
    XMoveResizeWindow(display, w, 0, 4, rc[BOTTOM].width, rc[BOTTOM].height-4);

    TaskbarButton::rcTButton.x = 2;
    TaskbarButton::rcTButton.y = 0;

    rcScreen = Rect(0, 0, rcRoot.width, rcRoot.height-rc[BOTTOM].height);
    buttonArea = rcRoot.width - (sButton->buttonWidth + clockWidth + 8);

    XMoveWindow(display, clock, rcScreen.width-clockWidth-3, 0);
    break;

  case TOP:
    XDefineCursor(display, frame, cursor[Y_RESIZE]);
    XMoveResizeWindow(display, w, 0, 0, rc[TOP].width, rc[TOP].height-4);

    TaskbarButton::rcTButton.x = 2;
    TaskbarButton::rcTButton.y = 2;

    rcScreen = Rect(0, rc[TOP].height,
		    rcRoot.width, rcRoot.height-rc[TOP].height);
    buttonArea = rcRoot.width - (sButton->buttonWidth + clockWidth + 8);

    XMoveWindow(display, clock, rc[TOP].width-clockWidth-3, 2);
    break;

  case LEFT:
    XDefineCursor(display, frame, cursor[X_RESIZE]);
    XMoveResizeWindow(display, w, 0, 0, rc[LEFT].width-4, rc[LEFT].height);

    TaskbarButton::rcTButton.x = 2;
    TaskbarButton::rcTButton.y = 2;

    rcScreen = Rect(rc[LEFT].width, 0,
		    rcRoot.width-rc[LEFT].width, rcRoot.height);
    
    if (rc[LEFT].width < sButton->buttonWidth + clockWidth + 19) {
      XMoveWindow(display, clock,
		  (rc[LEFT].width - 2 -clockWidth) / 2,
		  rc[LEFT].height - CLOCK_HEIGHT - 6);
      buttonArea = rcRoot.height - (TaskbarButton::rcTButton.y
				    + TaskbarButton::BUTTON_HEIGHT
				    + TaskbarButton::BETWEEN_SPACE
				    + CLOCK_HEIGHT + 6);
    }
    else {
      XMoveWindow(display, clock,
		  sButton->buttonWidth + 11, TaskbarButton::rcTButton.y);
      buttonArea = rcRoot.height - (TaskbarButton::rcTButton.y
				    + TaskbarButton::BUTTON_HEIGHT
				    + TaskbarButton::BETWEEN_SPACE);
    }
    break;

  case RIGHT:
    XDefineCursor(display, frame, cursor[X_RESIZE]);
    XMoveResizeWindow(display, w, 4, 0, rc[RIGHT].width-4, rc[RIGHT].height);

    TaskbarButton::rcTButton.x = 0;
    TaskbarButton::rcTButton.y = 2;

    rcScreen = Rect(0, 0, rcRoot.width-rc[RIGHT].width, rcRoot.height);

    if (rc[RIGHT].width < sButton->buttonWidth + clockWidth + 19) {
      XMoveWindow(display, clock,
		  (rc[RIGHT].width - 2 - clockWidth) / 2,
		  rc[RIGHT].height - CLOCK_HEIGHT - 6);
      buttonArea = rcRoot.height - (TaskbarButton::rcTButton.y
				    + TaskbarButton::BUTTON_HEIGHT
				    + TaskbarButton::BETWEEN_SPACE
				    + CLOCK_HEIGHT + 6);
    }
    else {
      XMoveWindow(display, clock,
		  sButton->buttonWidth + 11, TaskbarButton::rcTButton.y);
      buttonArea = rcRoot.height - (TaskbarButton::rcTButton.y
				    + TaskbarButton::BUTTON_HEIGHT
				    + TaskbarButton::BETWEEN_SPACE);
    }
    break;
  }

  TaskbarButton::RedrawAllTaskbarButtons();
  Qvwm::RecalcAllWindows();
  Icon::RedrawAllIcons();
  if (UsePager) {
    ASSERT(pager);
    pager->RecalcPager();
  }

  ASSERT(paging);

  paging->RaisePagingBelt();
}

/*
 * MoveTaskbar --
 *   Drag the taskbar to move.
 */
void Taskbar::MoveTaskbar(const Point& ptRoot)
{
  XEvent ev;
  Point ptNew;
  Rect rcRoot = rootQvwm->GetRect();

  /*
   * There is parts that cannot let taskbar to move.
   */
  switch (pos) {
  case BOTTOM:
    if (ptRoot.y == (int)rcRoot.height-1 || ptRoot.y == (int)rcRoot.height-2)
      return;
    break;

  case TOP:
    if (ptRoot.y == 0 || ptRoot.y == 1)
      return;
    break;

  case LEFT:
    if (ptRoot.x == 0 || ptRoot.x == 1)
      return;
    break;

  case RIGHT:
    if (ptRoot.x == (int)rcRoot.width-1 || ptRoot.x == (int)rcRoot.width-2)
      return;
    break;
  }
  
  if (!OpaqueMove) {
    XGrabServer(display);
    XDrawRectangle(display, root, gcXor, rc[pos].x, rc[pos].y,
		   rc[pos].width, rc[pos].height);
  }

  while (1) {
    XMaskEvent(display, Button1MotionMask | ButtonReleaseMask | ExposureMask,
	       &ev);
    switch (ev.type) {
    case MotionNotify:
      if (!OpaqueMove)
	XDrawRectangle(display, root, gcXor, rc[pos].x, rc[pos].y,
		       rc[pos].width, rc[pos].height);

      ptNew = Point(ev.xbutton.x_root, ev.xbutton.y_root);
      pos = GetDisplayArea(ptNew);

      if (OpaqueMove)
	MoveTaskbar(pos);
      else
	XDrawRectangle(display, root, gcXor, rc[pos].x, rc[pos].y,
		       rc[pos].width, rc[pos].height);
      break;

    case ButtonRelease:
      if (!OpaqueMove) {
	XDrawRectangle(display, root, gcXor, rc[pos].x, rc[pos].y,
		       rc[pos].width, rc[pos].height);
	XUngrabServer(display);
      }

      ptNew = Point(ev.xbutton.x_root, ev.xbutton.y_root);
      MoveTaskbar(GetDisplayArea(ptNew));
      return;
      
    case Expose:
      ExposeProc(ev.xexpose.window);
      break;
    }
  }
}  

/*
 * ResizeTaskbar --
 *   Resize the taskbar.
 */
void Taskbar::ResizeTaskbar(const Point& ptRoot)
{
  RectPt resize;
  XEvent ev;
  Rect rcNew = rc[pos], rcOld = rc[pos];
  Point ptNew;
  Rect rcRoot = rootQvwm->GetRect();

  if (!OpaqueMove) {
    XGrabServer(display);
    XDrawRectangle(display, root, gcXor,
		   rcNew.x, rcNew.y, rcNew.width, rcNew.height);
  }

  while (1) {
    XMaskEvent(display, Button1MotionMask | ButtonReleaseMask | ExposureMask,
	       &ev);
    switch (ev.type) {
    case MotionNotify:
      if (!OpaqueMove)
	XDrawRectangle(display, root, gcXor,
		       rcNew.x, rcNew.y, rcNew.width, rcNew.height);

      ptNew = Point(ev.xbutton.x_root, ev.xbutton.y_root);
      resize = RectPt(0, 0, 0, 0);

      switch (pos) {
      case BOTTOM:
	resize.top = ptNew.y - ptRoot.y;
	break;

      case TOP:
	resize.bottom = ptNew.y - ptRoot.y;
	break;

      case LEFT:
	resize.right = ptNew.x - ptRoot.x;
	break;

      case RIGHT:
	resize.left = ptNew.x - ptRoot.x;
	break;
      }
      
      rcNew.x = rcOld.x + resize.left;
      rcNew.y = rcOld.y + resize.top;
      rcNew.width = rcOld.width - resize.left + resize.right;
      rcNew.height = rcOld.height - resize.top + resize.bottom;
      
      /*
       * Adjust.
       */
      switch (pos) {
      case BOTTOM:
      case TOP:
	if (rcNew.height > rcRoot.height/2)
	  rcNew.height = rcRoot.height / 2;
	rcNew.height = rcNew.height / INC_HEIGHT * INC_HEIGHT + 3;
	if (rcNew.height < 6)
	  rcNew.height = 6;
	break;

      case LEFT:
      case RIGHT:
	if (rcNew.width > rcRoot.width/2)
	  rcNew.width = rcRoot.width / 2;
	if (rcNew.width < 6)
	  rcNew.width = 6;
	break;
      }
      
      if (pos == BOTTOM)
	rcNew.y = rcRoot.height - rcNew.height;
      if (pos == RIGHT)
	rcNew.x = rcRoot.width - rcNew.width;
      
      if (OpaqueMove) {
	rc[pos] = rcNew;
	MoveTaskbar(pos);
      }
      else 
	XDrawRectangle(display, root, gcXor,
		       rcNew.x, rcNew.y, rcNew.width, rcNew.height);
      break;
      
    case ButtonRelease:
      if (!OpaqueMove) {
	XDrawRectangle(display, root, gcXor,
		       rcNew.x, rcNew.y, rcNew.width, rcNew.height);
	XUngrabServer(display);
      }

      rc[pos] = rcNew;
      MoveTaskbar(pos);
      return;

    case Expose:
      ExposeProc(ev.xexpose.window);
      break;
    }
  }
}  

/*
 * RaiseTaskbar --
 *   Raise the taskbar.
 */
void Taskbar::RaiseTaskbar()
{
  XRaiseWindow(display, frame);

  ASSERT(paging);

  paging->RaisePagingBelt();
}

/*
 * DrawTaskbar --
 *   Draw the taskbar.
 */
void Taskbar::DrawTaskbar()
{
  Window win[2];
  int nwindows = 0;

  switch (pos) {
  case BOTTOM:
    XSetForeground(display, gc, white);
    XDrawLine(display, frame, gc, rc[BOTTOM].x, 1, rc[BOTTOM].width-1, 1);
    break;

  case TOP:
    XSetForeground(display, gc, darkGray);
    XDrawLine(display, frame, gc, rc[TOP].x, rc[TOP].height-2,
	      rc[TOP].width-1, rc[TOP].height-2);
    XSetForeground(display, gc, black);
    XDrawLine(display, frame, gc, rc[TOP].x, rc[TOP].height-1,
	      rc[TOP].width-1, rc[TOP].height-1);
    break;

  case LEFT:
    XSetForeground(display, gc, darkGray);
    XDrawLine(display, frame, gc, rc[LEFT].width-2, rc[LEFT].y,
	      rc[LEFT].width-2, rc[LEFT].height-1);
    XSetForeground(display, gc, black);
    XDrawLine(display, frame, gc, rc[LEFT].width-1, rc[LEFT].y,
	      rc[LEFT].width-1, rc[LEFT].height-1);
    break;

  case RIGHT:
    XSetForeground(display, gc, white);
    XDrawLine(display, frame, gc, 1, rc[RIGHT].y, 1, rc[RIGHT].height-1);
    break;
  }

  if (startMenu != NULL && startMenu->CheckMapped())
    win[nwindows++] = startMenu->GetFrameWin();
  else {
    ASSERT(Qvwm::focusQvwm);
    if (Qvwm::focusQvwm->CheckMenuMapped()) {
      ASSERT(Qvwm::focusQvwm->ctrlMenu);
      win[nwindows++] = Qvwm::focusQvwm->ctrlMenu->GetFrameWin();
    }
  }
  win[nwindows++] = frame;

  XRestackWindows(display, win, nwindows);
}

/*
 * DrawClock --
 *   Draw the clock in the right or bottom side.
 */
void Taskbar::DrawClock()
{
  XPoint xp[3];
  time_t t;
  struct tm *tm;
  char str[9];
  int len;
  Point pt;
  XRectangle ink, log;

  XClearWindow(display, clock);

  xp[0].x = clockWidth - 2;
  xp[0].y = 0;
  xp[1].x = 0;
  xp[1].y = 0;
  xp[2].x = 0;
  xp[2].y = CLOCK_HEIGHT - 2;

  XSetForeground(display, gc, darkGray);
  XDrawLines(display, clock, gc, xp, 3, CoordModeOrigin);

  xp[0].x = clockWidth - 1;
  xp[0].y = 0;
  xp[1].x = clockWidth - 1;
  xp[1].y = CLOCK_HEIGHT - 1;
  xp[2].x = 0;
  xp[2].y = CLOCK_HEIGHT - 1;

  XSetForeground(display, gc, white);
  XDrawLines(display, clock, gc, xp, 3, CoordModeOrigin);

  time(&t);
  tm = localtime(&t);
  int hour = tm->tm_hour;
  int min = tm->tm_min;

  if (Clock12Hours) {
    sprintf(str, "%s%d:%02d%s", (((hour + 11) % 12 + 1) < 10) ? " " : "",
	    (hour + 11) % 12 + 1, min, (hour < 12) ? " AM" : " PM");
    len = 8;
  }
  else {
    sprintf(str, "%s%d:%02d", (hour < 10) ? " " : "",
	    hour, min);
    len = 5;
  }

  XmbTextExtents(fsTaskbar, str, len, &ink, &log);
  pt.x = (clockWidth - log.width) / 2 - log.x;
  pt.y = (CLOCK_HEIGHT - log.height) / 2 - log.y;

  XSetForeground(display, gc, black);
  XSetBackground(display, gc, gray);
  XmbDrawImageString(display, clock, fsTaskbar, gc, pt.x, pt.y, str, len);
}

/*
 * Exposure --
 *   Process expose event.
 */
void Taskbar::Exposure(Window win)
{
  if (win == frame)
    DrawTaskbar();
  else if (win == clock)
    DrawClock();
}

/*
 * Button1Motion --
 *   Process drag.
 */
void Taskbar::Button1Motion(Window win, const Point& ptRoot)
{
  if (win == w)
    MoveTaskbar(ptRoot);
  else if (win == frame)
    ResizeTaskbar(ptRoot);
}

/*
 * IsTaskbarWindows --
 *   Return True if the window is taskbar window.
 */
Bool Taskbar::IsTaskbarWindows(Window win)
{
  if (win == w || win == frame || win == clock)
    return True;

  return False;
}
