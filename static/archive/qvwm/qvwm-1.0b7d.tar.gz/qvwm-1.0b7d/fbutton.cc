#include <stdio.h>
#include <X11/Xlib.h>
#include <X11/xpm.h>
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "fbutton.h"
#include "bitmaps/button0.xpm"
#include "bitmaps/button1.xpm"
#include "bitmaps/button2.xpm"
#include "bitmaps/button3.xpm"

Pixmap FrameButton::pixButton[4];

/*
 * DrawButton --
 *   Draw frame button.
 */
void FrameButton::DrawButton()
{
  Button::DrawButton();

  if (state == NORMAL)
    XCopyArea(display, pix, frame, gc, 0, 0,
	      BUTTON_WIDTH, BUTTON_HEIGHT, 2, 2);
  else
    XCopyArea(display, pix, frame, gc, 0, 0,
	      BUTTON_WIDTH, BUTTON_HEIGHT, 3, 3);
}

/*
 * Button1Press --
 *   Process press of button1 (mouse left button)
 */
void FrameButton::Button1Press()
{
  ASSERT(qvWm);

  if (!qvWm->CheckFocus())
    qvWm->SetFocus();

  qvWm->RaiseWindow(True);

  Button::Button1Press();
}

/*
 * ExecButtonFunc --
 *   Execute the function of frame button 1 (minimize).
 */
void FrameButton1::ExecButtonFunc(ButtonState bs)
{
  ASSERT(qvWm);
  
  if (bs == PUSH)
    qvWm->MinimizeWindow();
}

/*
 * ExecButtonFunc --
 *   Execute the function of frame button 2 (maximize or restore).
 */
void FrameButton2::ExecButtonFunc(ButtonState bs)
{
  ASSERT(qvWm);

  if (bs == PUSH) {
    if (qvWm->CheckStatus(MAXIMIZE_WINDOW)) {
      SetPixmap(pixButton[MAXIMIZE]);
      qvWm->RestoreWindow();
    }
    else {
      SetPixmap(pixButton[RESTORE]);
      qvWm->MaximizeWindow();
    }
  }
}

/*
 * ExecButtonFunc --
 *   Execute the function of frame button 3 (close window).
 */
void FrameButton3::ExecButtonFunc(ButtonState bs)
{
  ASSERT(qvWm);

  if (bs == PUSH)
    qvWm->ExecFunction(Q_CLOSE);
}

/*
 * CreateFrameButtonPixmap --
 *   Create pixmaps for frame button.
 */
void FrameButton::CreateFrameButtonPixmap()
{
  XpmAttributes attr;

  attr.valuemask = XpmColormap | XpmDepth;
  attr.colormap = colormap;
  attr.depth = depth;

  XpmCreatePixmapFromData(display, root, button0,
			  &pixButton[MINIMIZE], NULL, &attr);
  XpmCreatePixmapFromData(display, root, button1,
			  &pixButton[MAXIMIZE], NULL, &attr);
  XpmCreatePixmapFromData(display, root, button2,
			  &pixButton[CLOSE], NULL, &attr);
  XpmCreatePixmapFromData(display, root, button3,
			  &pixButton[RESTORE], NULL, &attr);
}
