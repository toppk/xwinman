#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "fbutton.h"
#include "paging.h"

/*
 * Configure --
 *   Change window position and size according to cre.
 *   rcOrig = cre - rcScreen + paging
 *   rc = cre + gravity + paging
 */
void Qvwm::Configure(const XConfigureRequestEvent* cre)
{
  Qvwm* tmpQvwm;
  XWindowChanges xwc;
  int borderWidth, topBorder, titleHeight, titleEdge;
  Point gravity;

  ASSERT(cre);

  if (cre->value_mask & CWStackMode) {
    if ((cre->value_mask & CWSibling) &&
	XFindContext(display, cre->above, Qvwm::context, (caddr_t *)&tmpQvwm)
	== XCSUCCESS)
      xwc.sibling = tmpQvwm->frame;
    else
      xwc.sibling = cre->above;
    
    xwc.stack_mode = cre->detail;
    XConfigureWindow(display, frame,
		     cre->value_mask & (CWSibling | CWStackMode), &xwc);
  }

  if (cre->value_mask & CWBorderWidth)
    bwOrig = cre->border_width;

  GetBorderAndTitle(borderWidth, topBorder, titleHeight, titleEdge);
  gravity = GetGravityOffset();

  ASSERT(paging);

  if (cre->value_mask & CWX) {
    rcOrig.x = cre->x - rcScreen.x;
    if (!CheckFlags(STICKY))
      rcOrig.x += paging->origin.x;
    rc.x = cre->x + paging->origin.x + (borderWidth - bwOrig) * gravity.x;
  }
  if (cre->value_mask & CWY) {
    rcOrig.y = rc.y - rcScreen.y;
    if (!CheckFlags(STICKY))
      rcOrig.y += paging->origin.y;
    rc.y = cre->y + paging->origin.y;
    if (gravity.y == CENTER)
      rc.y -= topBorder + titleHeight + titleEdge - bwOrig;
    else if (gravity.y == SOUTH)
      rc.y -= borderWidth + topBorder + titleHeight + titleEdge - bwOrig*2;
  }
  if (cre->value_mask & CWWidth) {
    rcOrig.width = cre->width;
    rc.width = cre->width + borderWidth * 2;
  }
  if (cre->value_mask & CWHeight) {
    rcOrig.height = cre->height;
    rc.height = cre->height + borderWidth + topBorder + titleHeight
      + titleEdge;
  }

  ASSERT(fButton[1]);

  fButton[1]->SetState(Button::NORMAL);
  fButton[1]->SetPixmap(FrameButton::pixButton[FrameButton::MAXIMIZE]);
  ResetStatus(MAXIMIZE_WINDOW | MINIMIZE_WINDOW);

  SendConfigureEvent();
  RedrawWindow();
}

/*
 * ConfigureNewRc --
 *   Change original window according to rcNew (frame rc).
 *   rcOrig = rc - rcScreen - gravity
 */
void Qvwm::ConfigureNewRect(const Rect& rcNew)
{
  int borderWidth, topBorder, titleHeight, titleEdge;
  Point gravity;
  Rect rect;

  rc = rcNew;

  GetBorderAndTitle(borderWidth, topBorder, titleHeight, titleEdge);

  gravity = GetGravityOffset();

  rcOrig.x = rcNew.x - rcScreen.x - (borderWidth - bwOrig) * gravity.x;
  rcOrig.y = rcNew.y - rcScreen.y;
  if (CheckFlags(STICKY)) {
    rcOrig.x -= paging->origin.x;
    rcOrig.y -= paging->origin.y;
  }
  if (gravity.y == CENTER)
    rcOrig.y += topBorder + titleHeight + titleEdge - bwOrig;
  else if (gravity.y == SOUTH)
    rcOrig.y += borderWidth + topBorder + titleHeight + titleEdge - bwOrig * 2;
  
  rcOrig.width = rcNew.width - borderWidth * 2;
  rcOrig.height = rcNew.height - (titleHeight + borderWidth + topBorder
				  + titleEdge);

  /*
   * Adjust taskbar position.
   */
  switch (taskBar->GetPos()) {
  case Taskbar::BOTTOM:
  case Taskbar::TOP:
    // South??Gravity
    if (gravity.y == SOUTH) {
      rect = taskBar->GetRect();
      rcOrig.y += rect.height;
    }
    break;

  case Taskbar::LEFT:
  case Taskbar::RIGHT:
    // ??EastGravity
    if (gravity.x == EAST) {
      rect = taskBar->GetRect();
      rcOrig.x += rect.width;
    }
    break;
  }

  SendConfigureEvent();
}

/*
 * SendConfigureEvent --
 *   Send event to the window whose position and size changed.
 */
void Qvwm::SendConfigureEvent()
{
  XEvent clientEvent;
  int borderWidth, topBorder, titleHeight, titleEdge;
  Point gravity;
  
  clientEvent.type = ConfigureNotify;
  clientEvent.xconfigure.display = display;
  clientEvent.xconfigure.event = wOrig;
  clientEvent.xconfigure.window = wOrig;
      
  GetBorderAndTitle(borderWidth, topBorder, titleHeight, titleEdge);
  gravity = GetGravityOffset();

  ASSERT(paging);

  clientEvent.xconfigure.x = rc.x - paging->origin.x + borderWidth;
  clientEvent.xconfigure.y = rc.y - paging->origin.y + topBorder
    + titleHeight + titleEdge;
  clientEvent.xconfigure.width = rc.width - borderWidth * 2;
  clientEvent.xconfigure.height = rc.height - (borderWidth + topBorder
					       + titleHeight + titleEdge);

  clientEvent.xconfigure.border_width = 0;
  clientEvent.xconfigure.above = frame;
  clientEvent.xconfigure.override_redirect = False;
  
  XSendEvent(display, wOrig, False, StructureNotifyMask, &clientEvent);
}

/*
 * GetBorderAndTitle --
 *   Get border width, top border width, title height, title edge height
 *   according to the flags.
 *
 *  top border width
 *   /\
 *   +------------------------------+  \ top border width
 *   | +--------------------------+ |  /
 *   | | TITLE                    | |  - title height 
 *   + +--------------------------+ |  \
 *   |  +------------------------+  |  / title edge
 *   |  |                        |  |
 *   |  |                        |  |
 *   \ /
 *  border width
 */
void Qvwm::GetBorderAndTitle(int& borderWidth, int& topBorder,
			     int& titleHeight, int& titleEdge)
{
  if (CheckFlags(BORDER)) {
    borderWidth = BORDER_WIDTH;
    topBorder = CheckFlags(TITLE) ? TOP_BORDER : TOP_BORDER - 1;
  }
  else {
    borderWidth = 2;
    topBorder = 0;
  }

  if (!CheckFlags(BORDER_EDGE)) {
    borderWidth -= 2;
    titleEdge = 0;
  }
  else
    titleEdge = TITLE_EDGE;

  titleHeight = CheckFlags(TITLE) ? TITLE_HEIGHT : 0;
}
