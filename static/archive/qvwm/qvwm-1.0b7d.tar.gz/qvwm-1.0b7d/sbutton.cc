#include <stdio.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "main.h"
#include "qvwm.h"
#include "sbutton.h"
#include "startmenu.h"
#include "qvwmrc.h"

StartButton::StartButton(Qvwm* qvWm, unsigned int some_width)
: TaskbarButton(qvWm, Rect(rcTButton.x, rcTButton.y,
			   some_width, TaskbarButton::BUTTON_HEIGHT),
		pixLogo, gcLogo, StartButtonTitle)

{
  buttonWidth = some_width;

  XSelectInput(display, frame, ExposureMask | ButtonPressMask |
	       ButtonReleaseMask | Button1MotionMask | OwnerGrabButtonMask);
}

void StartButton::FillBackground()
{
  XSetForeground(display, ::gc, gray);
  XFillRectangle(display, frame, ::gc, 2, 2, rc.width-4, rcTButton.height-4);
}

/*
 * DrawName --
 *   Don't adjust the text in start button even if it is too long.
 */
void StartButton::DrawName()
{
  int y;
  XRectangle ink, log;

  XmbTextExtents(fsTaskbar, name, strlen(name), &ink, &log);
  y = (TaskbarButton::BUTTON_HEIGHT - log.height) / 2 - log.y;

  if (CheckState(PUSH)) {
    if (UseBoldFont) {
      XSetForeground(display, ::gc, black);
      XmbDrawString(display, frame, *fsb, ::gc, 22, y+1, name, strlen(name));
    }
    else {
      XSetForeground(display, ::gc, black);
      XmbDrawString(display, frame, fsTaskbar, ::gc, 22, y+1,
		    name, strlen(name));
      XmbDrawString(display, frame, fsTaskbar, ::gc, 23, y+1,
		    name, strlen(name));
    }
  }
  else {
    if (UseBoldFont) {
      XSetForeground(display, ::gc, black);
      XmbDrawString(display, frame, *fsb, ::gc, 22, y, name, strlen(name));
    }
    else {
      XSetForeground(display, ::gc, black);
      XmbDrawString(display, frame, fsTaskbar, ::gc, 22, y,
		    name, strlen(name));
      XmbDrawString(display, frame, fsTaskbar, ::gc, 23, y,
		    name, strlen(name));
    }
  }
}

/*
 * Button1Press --
 *   Process the press of button1(mouse left button).
 */
void StartButton::Button1Press()
{
  /*
   * Create start button if it isn't still created. The creation of start
   * button is delayed until it is needed.
   */
  if (startMenu == NULL) {
    StartMenu::CreateStartMenuPixmap();
    startMenu = new StartMenu(StartMenuItem);
  }

  if (startMenu->CheckMapped())
    startMenu->UnmapMenu();
  else {
    ASSERT(Qvwm::focusQvwm);
    if (Qvwm::focusQvwm->CheckMenuMapped())
      Qvwm::focusQvwm->UnmapMenu();
    startMenu->MapMenu();
  }
}
