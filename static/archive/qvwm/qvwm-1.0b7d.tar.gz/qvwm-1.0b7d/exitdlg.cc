#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>
#include <X11/xpm.h>
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "events.h"
#include "system_dialog.h"
#include "exitdlg.h"
#include "radio_button.h"
#include "qvwmrc.h"

/*
 * ExitDlg --
 *   Process exit dialog.
 */
void ExitDlg(Qvwm* qvWm, MenuItem* mItem)
{
  static FuncNumber* rFunc = NULL;

  if (exitDlg == NULL) {
    /*
     * Resource for exit dialog.
     */
    int nitems = GetMenuItemNum(ExitDlgItem);
    int i = 0, base = 12;
    ResourceId dlgid = STARTID, initRB = 0;
    ItemKind prevItem = ICONPIXMAP;
    Pixmap pixExit, maskExit;
    GC gcExit;
    char* exitTitle = "Exit qvwm";
    DialogRes** dr = new DialogRes*[nitems + 1];

    delete [] rFunc;
    rFunc = new FuncNumber[nitems];

    while (mItem) {
      if (strcmp(mItem->name, "StaticText") == 0) {
	if (prevItem != STATICTEXT)
	  base += 9;
	if (prevItem == STRINGBUTTON)
	  base += 36;

	ASSERT(i <= nitems);

	Rect rect(70, base, -1, -1);
	dr[i++] = new DialogRes(STATICTEXT, NO_ID, rect, mItem->file,
				fsDialog);
	base += 21;
	prevItem = STATICTEXT;
      }
      else if (strcmp(mItem->name, "RadioButton") == 0) {
	if (prevItem != RADIOBUTTON)
	  base += 9;
	if (prevItem == STRINGBUTTON)
	  base += 36;

	ASSERT(dlgid - STARTID >= 0 && dlgid - STARTID < nitems);

	rFunc[dlgid - STARTID] = mItem->func;
	if (initRB == 0)
	  initRB = dlgid;

	ASSERT(i <= nitems);

	Rect rect(75, base, -1, -1);
	dr[i++] = new DialogRes(RADIOBUTTON, dlgid++, rect, mItem->file,
				fsDialog);
	base += 21;
	prevItem = RADIOBUTTON;
      }
      else if (strcmp(mItem->name, "IconPixmap") == 0) {
	Rect rect(21, 17, 32, 32);
	if (CreatePixmapFromFile(mItem->file, pixExit, maskExit, gcExit)) {
	  ASSERT(i <= nitems);
	  dr[i++] = new DialogRes(ICONPIXMAP, dlgid++, rect, fsDialog, NO_ID,
				  pixExit, gcExit);
	}
      }
      else if (strcmp(mItem->name, "OKButton") == 0) {
	if (prevItem != STRINGBUTTON)
	  base += 22;

	ASSERT(i <= nitems);

	Rect rect(84, base, 88, 23);
	dr[i++] = new DialogRes(STRINGBUTTON, ID_OK, rect, mItem->file,
				fsDialog);
	prevItem = STRINGBUTTON;
      }
      else if (strcmp(mItem->name, "CancelButton") == 0) {
	if (prevItem != STRINGBUTTON)
	  base += 22;

	ASSERT(i <= nitems);

	Rect rect(179, base, 88, 23);
	dr[i++] = new DialogRes(STRINGBUTTON, ID_CANCEL, rect, mItem->file,
				fsDialog);
	prevItem = STRINGBUTTON;
      }
      else if (strcmp(mItem->name, "HelpButton") == 0) {
	if (prevItem != STRINGBUTTON)
	  base += 22;

	ASSERT(i <= nitems);

	Rect rect(274, base, 88, 23);
	dr[i++] = new DialogRes(STRINGBUTTON, ID_HELP, rect, mItem->file,
				fsDialog);
	prevItem = STRINGBUTTON;
      }
      else if (strcmp(mItem->name, "Title") == 0)
	exitTitle = mItem->file;
      else
	QvwmError("Type '%s' is invalid", mItem->name);
      
      mItem = mItem->next;
    }
    if (initRB != 0) {
      ASSERT(i <= nitems);
      dr[i++] = new DialogRes(RADIOSET, IDS_1, initRB);
    }

    Rect rcRoot = rootQvwm->GetRect();
    Rect rect((rcRoot.width - ExitDlgWidth) / 2,
	      (rcRoot.height - (base + 37)) / 2,
	      ExitDlgWidth, base + 37);

    /*
     * Create pixmaps and context for radio button.
     */
    RadioButton::CreateRadioButtonPixmap();
    RadioButton::context = XUniqueContext();

    exitDlg = new SystemDialog(rect, exitTitle, dr, i);
  }

  ASSERT(exitDlg);
  exitDlg->MapDialog();

  XGrabServer(display);

  ResourceId id;
  do {
    id = exitDlg->EventLoop();
  } while (!(id == ID_OK || id == ID_CANCEL));

  XUngrabServer(display);

  FuncNumber func;

  switch (id) {
  case ID_OK:
    exitDlg->UnmapDialog();

    ASSERT(exitDlg->GetSelectedRB(IDS_1) >= 0 &&
	exitDlg->GetSelectedRB(IDS_1) - STARTID < GetMenuItemNum(ExitDlgItem));

    func = rFunc[exitDlg->GetSelectedRB(IDS_1) - STARTID];
    if (func == Q_EXIT)
      Qvwm::FinishQvwm(False);
    else {
      ASSERT(qvWm);
      qvWm->ExecFunction(func);
    }
    break;

  case ID_CANCEL:
    exitDlg->UnmapDialog();
    break;
  }
}
