#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xlocale.h>
#include "main.h"
#include "util.h"
#include "taskbar.h"
#include "icon.h"
#include "parse.h"
#include "hash.h"
#include "qvwmrc.h"
#include "qvwm.h"

static Hash<FuncNumber>*	funcHashTable;
static Hash<VariableTable>*	varHashTable;

extern FILE*	yyin;
extern int 	yyparse();
extern int 	line;

void SetFont();
#ifdef __EMX__
static char* TranslateForOS2(char* name);
#endif

/*
 * ParseQvwmrc --
 *   Parse '.qvwmrc', 'system.qvwmrc', etc.
 */
void ParseQvwmrc(const char* rcFileName)
{
  char *home, *rcPath;
  int i;

  /*
   * Initializa hash table.
   */
  funcHashTable = new Hash<FuncNumber>(HashTableSize);
  for (i = 0; i < FuncTableSize; i++)
    funcHashTable->SetHashItem(funcTable[i].name, &funcTable[i].num);

  varHashTable = new Hash<VariableTable>(HashTableSize);
  for (i = 0; i < VarTableSize; i++)
    varHashTable->SetHashItem(varTable[i].name, &varTable[i]);

  Qvwm::appHashTable = new Hash<AppAttr>(HashTableSize);

  if (rcFileName != NULL) {
#ifdef __EMX__
    if ((strchr(rcFileName, '/') == NULL) &&
	(strchr(rcFileName, '\\') == NULL))
      yyin = fopen(rcFileName, "r");
    else
      yyin = fopen(__XOS2RedirRoot((char*)rcFileName), "r");
    if (yyin != NULL) {
#else    
    if ((yyin = fopen(rcFileName, "r")) != NULL) {
#endif    
      line = 1;
      yyparse();
      fclose(yyin);
    }
    else {
      QvwmError("Can't open rcfile '%s'", rcFileName);
      SetFont();
    }

    delete funcHashTable;
    delete varHashTable;

    return;
  }

  home = getenv("HOME");
  rcPath = new char[strlen(home)+9];
  sprintf(rcPath, "%s/.qvwmrc", home);

  if ((yyin = fopen(rcPath, "r")) != NULL) {
    line = 1;
    yyparse();
    fclose(yyin);
  }
  else {
    delete [] rcPath;
    rcPath = new char[strlen(QVWMDIR) + 15];
    sprintf(rcPath, "%s/system.qvwmrc", QVWMDIR);

#ifdef __EMX__
    if ((yyin = fopen(__XOS2RedirRoot(rcPath), "r")) != NULL) {
#else        
    if ((yyin = fopen(rcPath, "r")) != NULL) {
#endif    
      line = 1;
      yyparse();
      fclose(yyin);
    }
    else {
      QvwmError("Can't open file '%s'", rcPath);
      SetFont();
    }
  }

  delete [] rcPath;
  delete funcHashTable;
  delete varHashTable;
}

/*
 * AssignVariable --
 *   Assign a value to string variable.
 */
void AssignVariable(const char* var, char* str)
{
  VariableTable* vItem;

  if ((vItem = varHashTable->GetHashItem(var))) {
    ASSERT(vItem);
    switch (vItem->attr) {
    case F_STRING:
      {
	char** sVal = (char **)vItem->var;
	*sVal = str;
      }
      break;

    case F_NATURAL:
      {
	int val;

	if ((val = atoi(str)) >= 0) {
	  int* nVal = (int *)vItem->var;
	  *nVal = val;
	}
	else
	  QvwmError("%d: '%s' is not natual number", line, str);
      }
      break;
	
    case F_POSITIVE:
      {
	int val;

	if ((val = atoi(str)) > 0) {
	  int* nVal = (int *)vItem->var;
	  *nVal = val;
	}
	else
	  QvwmError("%d: '%s' is not positive number", line, str);
      }
      break;
	
    case F_COLOR:
      {
	XColor color;

	if (XParseColor(display, colormap, str, &color) != 0) {
	  XAllocColor(display, colormap, &color);
	  unsigned long* pVal = (unsigned long *)vItem->var;
	  *pVal = color.pixel;
	}
	else
	  QvwmError("%d: '%s' is invalid color", line, str);
      }
      break;

    case F_BOOL:
      {
	int* nVal = (int *)vItem->var;

	if (strcmp(str, "True") == 0)
	  *nVal = 1;
	else if (strcmp(str, "False") == 0)
	  *nVal = 0;
	else
	  QvwmError("%d: '%s' is not boolean", line, str);
      }
      break;

    case F_TASKBAR:
      {
	Taskbar::TaskbarPos* tVal = (Taskbar::TaskbarPos *)vItem->var;

	if (strcmp(str, "Bottom") == 0)
	  *tVal = Taskbar::BOTTOM;
	else if (strcmp(str, "Top") == 0)
	  *tVal = Taskbar::TOP;
	else if (strcmp(str, "Left") == 0)
	  *tVal = Taskbar::LEFT;
	else if (strcmp(str, "Right") == 0)
	  *tVal = Taskbar::RIGHT;
      }
      break;

    case F_GEOMETRY:
      {
	InternGeom ig, *iVal = (InternGeom *)vItem->var;
	int bitmask;

	bitmask = XParseGeometry(str, &ig.rc.x, &ig.rc.y,
				 &ig.rc.width, &ig.rc.height);
	if (bitmask & (WidthValue|HeightValue) != (WidthValue|HeightValue)) {
	  QvwmError("%d: geometry requires width and height", line);
	  break;
	}

	ASSERT(iVal);

	iVal->rc.width = ig.rc.width;
	iVal->rc.height = ig.rc.height;

	if (bitmask & XNegative) {     // EastGravity
	  iVal->gravity.x = EAST;
	  iVal->rc.x = DisplayWidth(display, screen) - ig.rc.x - ig.rc.width;
	}
	else if (bitmask & XValue) {   // WestGravity
	  iVal->gravity.x = WEST;
	  iVal->rc.x = ig.rc.x;
	}
	else {                         // CenterGravity
	  iVal->gravity.x = CENTER;
	  iVal->rc.x = ig.rc.x;
	}
	if (bitmask & YNegative) {     // SouthGravity
	  iVal->gravity.y = SOUTH;
	  iVal->rc.y = DisplayHeight(display, screen) - ig.rc.y - ig.rc.height;
	}
	else if (bitmask & YValue) {   // NorthGravity
	  iVal->gravity.y = NORTH;
	  iVal->rc.y = ig.rc.y;
	}
	else {                         // CenterGravity
	  iVal->gravity.y = CENTER;
	  iVal->rc.y = ig.rc.y;
	}
      }
      break;

    case F_OFFSET:
      {
	Point* pVal = (Point *)vItem->var;
	unsigned int dummy;
	
	ASSERT(pVal);

	XParseGeometry(str, &pVal->x, &pVal->y, &dummy, &dummy);
      }
      break;
      
    case F_SIZE:
      {
	Dim* dVal = (Dim *)vItem->var;
	int dummy;

	ASSERT(dVal);

	XParseGeometry(str, &dummy, &dummy, &dVal->width, &dVal->height);
      }
      break;
    }
  }
  else
    QvwmError("%d: '%s' is unknown variable", line, var);
}

/*
 * MakeExecItem --
 *
 */
MenuItem* MakeExecItem(char* name, char* file, char* exec)
{
  MenuItem* mItem = new MenuItem;

  mItem->name = name;

#ifdef __EMX__
  mItem->file = TranslateForOS2(file);
#else
  mItem->file = file;
#endif

  mItem->func = Q_EXEC;

#ifdef __EMX__
  mItem->exec = TranslateForOS2(exec);
#else
  mItem->exec = exec;
#endif  

  mItem->child = NULL;

  return mItem;
}

/*
 * MakeDesktopItem --
 *
 */
MenuItem* MakeDesktopItem(char* name, char* file, char* exec, char* x, char* y)
{
  MenuItem* mItem;
  
  mItem = MakeExecItem(name, file, exec);

  mItem->x = mItem->y = -1;
  if (x != NULL) {
    if (*x == '!')
      mItem->x = atoi(x+1) * Icon::ICON_AREA;
    else
      mItem->x = atoi(x);
  }
  if (y != NULL) {
    if (*y == '!')
      mItem->y = atoi(y+1) * Icon::ICON_AREA;
    else
      mItem->y = atoi(y);
  }

  return mItem;
}  

/*
 * MakeFuncItem --
 */
MenuItem* MakeFuncItem(char* name, char* file, char* func)
{
  MenuItem* mItem = new MenuItem;
  FuncNumber* fNum;

  mItem->name = name;

#ifdef __EMX__
  mItem->file = TranslateForOS2(file);
#else
  mItem->file = file;
#endif  

  if ((fNum = funcHashTable->GetHashItem(func)) != NULL)
    mItem->func = *fNum;
  else
    mItem->func = Q_NONE;
  mItem->exec = "";
  mItem->child = NULL;

  return mItem;
}

/*
 * MakeDirItem --
 *
 */
MenuItem* MakeDirItem(char* name, char* file, MenuItem* child)
{
  MenuItem* mItem = new MenuItem;

  mItem->name = name;

#ifdef __EMX__
  mItem->file = TranslateForOS2(file);
#else
  mItem->file = file;
#endif  

  mItem->func = Q_DIR;
  mItem->exec = "";
  mItem->child = child;

  return mItem;
}

/*
 * MakeDlgItem --
 */
MenuItem* MakeDlgItem(char* name, char* str, char* func)
{
  MenuItem* mItem = new MenuItem;
  FuncNumber* fNum;

  mItem->name = name;
  mItem->file = str;
  if (func == NULL || (fNum = funcHashTable->GetHashItem(func)) == NULL)
    mItem->func = Q_NONE;
  else
    mItem->func = *fNum;
  mItem->exec = "";
  mItem->child = NULL;

  return mItem;
}

/*
 * ChainMenuItem --
 *   Chain two MenuItems.
 */
MenuItem* ChainMenuItem(MenuItem* mItem, MenuItem* nextItem)
{
  ASSERT(mItem);

  mItem->next = nextItem;

  return mItem;
}

/*
 * CompleteMenu --
 *   Complete menu.
 */
void CompleteMenu(char* menuName, MenuItem* mItem)
{
  if (strcmp(menuName, "Shortcuts") == 0) {
    ShortCutItem = mItem;
    return;
  }
  else if (strcmp(menuName, "ExitDialog") == 0) {
    ExitDlgItem = mItem;
    return;
  }

  if (mItem == NULL) {
    mItem = new MenuItem;

    mItem->name = "(None) ";
    mItem->func = Q_NONE;
    mItem->file = "";
    mItem->exec = "";
    mItem->next = NULL;
    mItem->child = NULL;
  }
  
  if (strcmp(menuName, "StartMenu") == 0)
    StartMenuItem = mItem;
  else if (strcmp(menuName, "CtrlMenu") == 0)
    CtrlMenuItem = mItem;
  else if (strcmp(menuName, "DesktopMenu") == 0)
    DesktopMenuItem = mItem;
}

/*
 * DoAllSetting --
 *   Complete Setting.
 */
void DoAllSetting()
{
  // !!Set fonts BEFORE make icons.
  SetFont();

  /*
   * Create shortcut. (can create only in the last stage)
   */
  if (ShortCutItem != NULL)
    CreateShortCut(ShortCutItem);
}

/*
 * CreateShortCut --
 *   Create shortcut icons.
 */
void CreateShortCut(MenuItem* mItem)
{
  Icon* icon;
  Pixmap pix, mask;
  GC gc;
  MenuItem* tmpItem;

  Icon::CreateIconPixmap();

  while (mItem) {
    if (strcmp(mItem->file, "") == 0) {
      pix = Icon::pixIcon;
      mask = Icon::maskIcon;
    }
    else if (!CreatePixmapFromFile(mItem->file, pix, mask, gc)) {
      pix = Icon::pixIcon;
      mask = Icon::maskIcon;
    }
    
    icon = new Icon(pix, mask, mItem->name, mItem->exec, mItem->x, mItem->y);
    icon->MapIcon();

    tmpItem = mItem;
    mItem = mItem->next;
    
    delete tmpItem;
  }
}  

/*
 * MakeStream --
 *   Make stream item for attribute.
 */
AttrStream* MakeStream(char* attr, char* value, AttrStream* stream)
{
  AttrStream* newStream = new AttrStream;
  int i;

  newStream->next = stream;

  for (i = 0; i < AttrNum; i++)
    if (strcmp(attr, attrSet[i].name) == 0) {
      newStream->attr = attrSet[i].flag;
      newStream->act = attrSet[i].act;
      newStream->value = value;
      break;
    }

  if (i == AttrNum) {
    QvwmError("Attribute '%s' is invalid.", attr);
    delete newStream;
    return stream;
  }

  return newStream;
}

/*
 * CreateAppHash --
 *   Create a hash for application attributes.
 */
void CreateAppHash(char* appName, AttrStream* stream)
{
  AttrStream* tmpStream;
  AppAttr* attrs;

  while (stream) {
    if (!(attrs = Qvwm::appHashTable->GetHashItem(appName))) {
      attrs = new AppAttr;
      attrs->flags = TITLE | BORDER | BORDER_EDGE | CTRL_MENU | BUTTON1
	| BUTTON2 | BUTTON3;
      Qvwm::appHashTable->SetHashItem(appName, attrs);
    }
    if (stream->act)
      attrs->flags |= stream->attr;
    else
      attrs->flags &= ~stream->attr;

    if (stream->attr == SMALLPIX)
      attrs->small_file = stream->value;
    else if (stream->attr == LARGEPIX)
      attrs->large_file = stream->value;

    tmpStream = stream;
    stream = stream->next;

    delete tmpStream;
  }
}

/*
 * SetFont --
 *   Set fonts.
 */
void SetFont()
{
  if (setlocale(LC_ALL, LocaleName) == NULL)
    QvwmError("Can't set the locale");

  char **miss, *def;
  int nMiss;
  int fsNum = (UseBoldFont) ? FsNum : FsNum - 1;

  /*
   * Create specified FontSets, but keep times of XCreateFontSet() to a 
   * mininum because the function takes much time.
   */
  for (int i = 0; i < fsNum; i++) {
    Bool match = False;
    for (int j = 0; j < i; j++)
      if (strcmp(*fsSet[i].fontname, *fsSet[j].fontname) == 0) {
	*fsSet[i].fs = *fsSet[j].fs;
	match = True;
	break;
      }
    if (!match) {
      *fsSet[i].fs = XCreateFontSet(display, *fsSet[i].fontname, &miss, &nMiss,
				    &def);
      // FontSet is pointer.
      if (*fsSet[i].fs == NULL) {
	QvwmError("Can't find font '%s'", *fsSet[i].fontname);
	*fsSet[i].fs = XCreateFontSet(display, "-*-*-medium-r-normal--14-*",
				      &miss, &nMiss, &def);
        /*
	 * If standard font does not exist, qvwm exits.
	 */
	if (*fsSet[i].fs == NULL)
	  exit(1);
      }
    }
  }
}

/*
 * IsFunction
 *   Return True if text is a function. The identifier beginning with 'QVWM_'
 *   is an internal function.
 */
Bool IsFunction(const char* text)
{
  char prefix[6];

  strncpy(prefix, text, 5);
  prefix[5] = '\0';

  if (strcmp(prefix, "QVWM_") == 0)
    return True;
  else
    return False;
}

/*
 * IsAttribute --
 *   Return True if text is an attribute.
 */
Bool IsAttribute(const char* text)
{
  for (int i = 0; i < AttrNum; i++)
    if (strcmp(text, attrSet[i].name) == 0)
      return True;

  return False;
}

#ifdef __EMX__
static char* TranslateForOS2(char* name)
{
  char* tName;

  if (name != NULL)
    if (strchr(name, '/') != NULL || strchr(name, '\\') != NULL) {
      char nom[300];

      strcpy(nom, __XOS2RedirRoot(name));
      tName = new char[strlen(nom) + 1];
      strcpy(tName, nom);

      return (tName);
    }
  
  return (name);
}
#endif  
