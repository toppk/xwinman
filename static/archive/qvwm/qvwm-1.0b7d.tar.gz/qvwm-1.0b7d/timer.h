#ifndef _TIMER_H_
#define _TIMER_H_

class Timer {
private:
  struct itimerval itv;
  void (*act)();
  
public:
  Timer();
  ~Timer();

  void SetTimeout(unsigned long msec, void (*action)());
  void ResetTimeout();
  void ForceTimeout();
  void Execute() {
    if (act) {
      (*act)();
      act = NULL;
    }
  }
};

#endif // _TIMER_H_
