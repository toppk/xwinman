%{
#include <stdio.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "main.h"
#include "parse.h"

extern int line;
extern int yylex();
extern int yyerror(char* error);
%}

%union {
  char* str;
  MenuItem* mItem;
  AttrStream* aStream;
}

%token <str> VARIABLE MENU SHORTCUT APP EXITDLG VAR STRING FUNC PLUS MINUS

%type <str> session, sessions
%type <mItem> item, items, sc, scs, dlgitem, dlgitems
%type <aStream> stream

%%

qvwmrc:	  sessions			{ DoAllSetting(); }
	|				{ DoAllSetting(); }
	;

sessions: session sessions
	| session
	;

session:  VARIABLE vars
	| VARIABLE
	| APP apps
	| APP
	| MENU items			{ CompleteMenu($1, $2); }
	| MENU
	| SHORTCUT scs			{ CompleteMenu($1, $2); }
	| SHORTCUT
	| EXITDLG dlgitems		{ CompleteMenu($1, $2); }
	| EXITDLG
	;

vars:	  var vars
	| var
	;

var:	  VAR '=' STRING		{ AssignVariable($1, $3); }
	| VAR '=' VAR			{ AssignVariable($1, $3); }
	;

items:	  item items			{ $$ = ChainMenuItem($1, $2); }
	| item				{ $$ = ChainMenuItem($1, NULL); }
	;

item:	  STRING STRING STRING		{ $$ = MakeExecItem($1, $2, $3); }
	| STRING STRING FUNC		{ $$ = MakeFuncItem($1, $2, $3); }
	| STRING STRING PLUS items MINUS { $$ = MakeDirItem($1, $2, $4); }
	;

scs:	  sc scs			{ $$ = ChainMenuItem($1, $2); }
	| sc				{ $$ = ChainMenuItem($1, NULL); }
	;

sc:	  STRING STRING STRING VAR ',' VAR
				{ $$ = MakeDesktopItem($1, $2, $3, $4, $6); }
	| STRING STRING STRING VAR
				{ $$ = MakeDesktopItem($1, $2, $3, $4, NULL); }
	| STRING STRING STRING ',' VAR
				{ $$ = MakeDesktopItem($1, $2, $3, NULL, $5); }
	| STRING STRING STRING
			    { $$ = MakeDesktopItem($1, $2, $3, NULL, NULL); }
	;
	
apps:	  app
	| app apps

app:	  STRING stream			{ CreateAppHash($1, $2); }
	;

stream:   VAR ',' stream		{ $$ = MakeStream($1, NULL, $3); }
	| VAR				{ $$ = MakeStream($1, NULL, NULL); }
	| VAR '=' STRING ',' stream	{ $$ = MakeStream($1, $3, $5); }
	| VAR '=' STRING		{ $$ = MakeStream($1, $3, NULL); }
	;

dlgitems: dlgitem dlgitems		{ $$ = ChainMenuItem($1, $2); }
	| dlgitem			{ $$ = ChainMenuItem($1, NULL); }
	;

dlgitem:  VAR STRING FUNC		{ $$ = MakeDlgItem($1, $2, $3); }
	| VAR STRING			{ $$ = MakeDlgItem($1, $2, NULL); }
	;

%%
int yyerror(char* error)
{
  QvwmError("%d: %s", line, error);
}
