#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "util.h"

Colormap	curCmap = None;
Qvwm*		curCmapQvwm = NULL;

/*
 * ColormapNotifyProc --
 *   Process ColormapNotify event.
 */
void ColormapNotifyProc(Window w, Bool newCmap, const XColormapEvent* cev)
{
  Qvwm* qvWm;
  XWindowAttributes attr;
  Bool reInstall = False;
  XEvent ev;

  ASSERT(cev);

  if (XFindContext(display, w, Qvwm::context, (caddr_t *)&qvWm) != XCSUCCESS)
    return;

  if (newCmap) {
    XGetWindowAttributes(display, w, &attr);
    if (qvWm == curCmapQvwm && qvWm->GetNumCmapWins() == 0)
      curCmap = attr.colormap;
    reInstall = True;
  }
  else if (cev->state == ColormapUninstalled && curCmap == cev->colormap)
    reInstall = True;
  
  while (XCheckTypedEvent(display, ColormapNotify, &ev)) {
    if (XFindContext(display, w, Qvwm::context, (caddr_t *)&qvWm) == XCNOENT)
      qvWm == NULL;
    if (qvWm && newCmap) {
      XGetWindowAttributes(display, qvWm->GetWin(), &attr);
      if (qvWm == curCmapQvwm && qvWm->GetNumCmapWins() == 0)
	curCmap = attr.colormap;
      reInstall = True;
    }
    else if (qvWm && cev->state == ColormapUninstalled &&
	     curCmap == cev->colormap)
      reInstall = False;
  }
  
  if (reInstall)
    XInstallColormap(display, curCmap);
}

/*
 * InstallWindowColormaps --
 *   Install window colormap.
 */
void Qvwm::InstallWindowColormaps()
{
  XWindowAttributes attr;

  if (CheckMapped())
    XGetWindowAttributes(display, wOrig, &attr);
  else
    XGetWindowAttributes(display, root, &attr);

  XInstallColormap(display, attr.colormap);    

/*
  XWindowAttributes attr;
  Bool isThisWin = False;

  curCmapQvwm = this;

  if (nCmapWins > 0)
    for (int i = nCmapWins-1; i >= 0; i--) {
      if (cmapWins[i] == wOrig)
	isThisWin = True;
      XGetWindowAttributes(display, cmapWins[i], &attr);

      if (curCmap != attr.colormap) {
	curCmap = attr.colormap;
	XInstallColormap(display, attr.colormap);
      }
    }
  
  if (!isThisWin) {
    XGetWindowAttributes(display, wOrig, &attr);
    if (curCmap != attr.colormap) {
      curCmap = attr.colormap;
      XInstallColormap(display, attr.colormap);
    }
  }
*/
}

/*
 * FetchWMColormapWindows --
 *
 */
void Qvwm::FetchWMColormapWindows()
{
  if(XGetWMColormapWindows(display, wOrig, &cmapWins, &nCmapWins) == 0) {
    cmapWins = NULL;
    nCmapWins = 0;
  }
}
