#include <stdio.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include "main.h"
#include "taskbar.h"
#include "util.h"
#include "parse.h"
#include "qvwmrc.h"
#include "qvwm.h"

/*
 * Default values
 */
int DoubleClickTime		    = 400;
int DoubleClickRange		    = 5;
int TitlebarMotionSpeed		    = 50;
int MenuDelayTime		    = 300;
int MenuDelayTime2		    = 300;
int PagingResistance		    = 250;
int PagingMovement		    = 100;
int PagingBeltSize		    = 2;
Point TopLeftPage		    = Point(0, 0);
Dim PagingSize			    = Dim(1, 1);
InternGeom PagerGeometry	    = InternGeom(0, 0, 48, 48, Point(0, 0));
Taskbar::TaskbarPos TaskbarPosition = Taskbar::BOTTOM;
unsigned int TaskbarRows	    = 1;
char* WallPaper			    = "Windows95";
unsigned long IconForeColor	    = 0x0000;
unsigned long IconBackColor	    = 0xffff;
char* StartButtonTitle		    = "Start";
char* LocaleName		    = "";
Bool UseBoldFont		    = False;
Bool UseExitDialog		    = False;
Bool UsePager			    = False;
Bool OpaqueMove			    = True;
Bool ClickToFocus		    = True;
Bool AutoRaise			    = False;
Bool Clock12Hours		    = False;
int AutoRaiseDelay		    = 300;
char* IconPath			    = PIXDIR;
unsigned long MiniNonActiveColor    = 0x0000;
unsigned long MiniActiveColor	    = 0xffff;
char* OtherWM			    = "twm";

/*
 * Default fonts
 */
char* TitleFont			    = "-*-*-medium-r-normal--14-*";
char* TaskbarFont		    = "-*-*-medium-r-normal--14-*";
char* TaskbarBoldFont		    = "-*-*-medium-r-normal--14-*";
char* CascadeMenuFont		    = "-*-*-medium-r-normal--14-*";
char* CtrlMenuFont		    = "-*-*-medium-r-normal--14-*";
char* StartMenuFont		    = "-*-*-medium-r-normal--14-*";
char* IconFont			    = "-*-*-medium-r-normal--14-*";
char* DialogFont		    = "-*-*-medium-r-normal--14-*";

/*
 * Default start menu
 */
MenuItem StartMenuTemplate[] =
  {{"Exit qvwm            ", "exit.xpm", Q_EXIT, "", -1, -1, NULL, NULL}};

/*
 * Default control menu
 */
MenuItem CtrlMenuTemplate[] =
  {{"Restore      ", "", Q_RESTORE,   "", -1, -1, &CtrlMenuTemplate[1], NULL},
   {"Move",          "", Q_MOVE,      "", -1, -1, &CtrlMenuTemplate[2], NULL},
   {"Resize",        "", Q_RESIZE,    "", -1, -1, &CtrlMenuTemplate[3], NULL},
   {"Minimize",      "", Q_MINIMIZE,  "", -1, -1, &CtrlMenuTemplate[4], NULL},
   {"Maximize",      "", Q_MAXIMIZE,  "", -1, -1, &CtrlMenuTemplate[5], NULL},
   {"",              "", Q_SEPARATOR, "", -1, -1, &CtrlMenuTemplate[6], NULL},
   {"Close",         "", Q_CLOSE,     "", -1, -1, &CtrlMenuTemplate[7], NULL},
   {"Kill",          "", Q_KILL,      "", -1, -1, NULL,                 NULL}};

MenuItem DesktopMenuTemplate[] =
  {{"(None) ", "", Q_NONE, "", -1, -1, NULL, NULL}};

MenuItem IconCtrlMenuTemplate[] =
  {{"Execute", "", Q_EXEC, "", -1, -1, NULL, NULL}};

MenuItem ExitDlgTemplate[] =
  {{"StaticText", "Can I exit with next way?", Q_NONE, "", -1, -1,
    &ExitDlgTemplate[1], NULL},
   {"RadioButton", "Exit qvwm.", Q_EXIT, "", -1, -1,
    &ExitDlgTemplate[2], NULL},
   {"RadioButton", "Restart qvwm.", Q_RESTART, "", -1, -1,
    &ExitDlgTemplate[3], NULL},
   {"IconPixmap", "exit2.xpm", Q_NONE, "", -1, -1,
    &ExitDlgTemplate[4], NULL},
   {"OKButton",	"Yes", Q_NONE, "", -1, -1,
    &ExitDlgTemplate[5], NULL},
   {"CancelButton", "No", Q_NONE, "", -1, -1,
    &ExitDlgTemplate[6], NULL},
   {"HelpButton", "Help", Q_NONE, "", -1, -1,
    NULL, NULL}};

MenuItem* StartMenuItem = StartMenuTemplate;
MenuItem* CtrlMenuItem = CtrlMenuTemplate;
MenuItem* DesktopMenuItem = DesktopMenuTemplate;
MenuItem* IconCtrlMenuItem = IconCtrlMenuTemplate;
MenuItem* ExitDlgItem = ExitDlgTemplate;
MenuItem* ShortCutItem = NULL;

/*
 * Table for used variables
 */
FuncTable funcTable[] =
  {{"QVWM_NONE",         Q_NONE},
   {"QVWM_SEPARATOR",    Q_SEPARATOR},
   {"QVWM_RESTORE",      Q_RESTORE},
   {"QVWM_MOVE",         Q_MOVE},
   {"QVWM_RESIZE",       Q_RESIZE},
   {"QVWM_MINIMIZE",     Q_MINIMIZE},
   {"QVWM_MAXIMIZE",     Q_MAXIMIZE},
   {"QVWM_CLOSE",        Q_CLOSE},
   {"QVWM_KILL",         Q_KILL},
   {"QVWM_EXIT",         Q_EXIT},
   {"QVWM_BOTTOM",       Q_BOTTOM},
   {"QVWM_TOP",          Q_TOP},
   {"QVWM_LEFT",         Q_LEFT},
   {"QVWM_RIGHT",        Q_RIGHT},
   {"QVWM_RESTART",      Q_RESTART},
   {"QVWM_CHANGEWINDOW", Q_CHANGEWINDOW},
   {"QVWM_LEFTPAGING",   Q_LEFTPAGING},
   {"QVWM_RIGHTPAGING",  Q_RIGHTPAGING},
   {"QVWM_UPPAGING",     Q_UPPAGING},
   {"QVWM_DOWNPAGING",   Q_DOWNPAGING},
   {"QVWM_LINEUP",       Q_LINEUP},
   {"QVWM_OTHERWM",      Q_OTHERWM}};

VariableTable varTable[] =
  {{"DoubleClickTime",      F_POSITIVE, &DoubleClickTime},
   {"DoubleClickRange",     F_POSITIVE, &DoubleClickRange},
   {"TitlebarMotionSpeed",  F_NATURAL,  &TitlebarMotionSpeed},
   {"MenuDelayTime",        F_NATURAL,  &MenuDelayTime},
   {"MenuDelayTime2",       F_NATURAL,  &MenuDelayTime2},
   {"PagingResistance",     F_NATURAL,  &PagingResistance},
   {"PagingMovement",       F_NATURAL,  &PagingMovement},
   {"PagingBeltSize",       F_NATURAL,  &PagingBeltSize},
   {"TopLeftPage",          F_OFFSET,   &TopLeftPage},
   {"PagingSize",           F_SIZE,     &PagingSize},
   {"PagerGeometry",        F_GEOMETRY, &PagerGeometry},
   {"TaskbarPosition",      F_TASKBAR,  &TaskbarPosition},
   {"TaskbarRows",          F_POSITIVE, &TaskbarRows},
   {"AutoRaiseDelay",       F_NATURAL,  &AutoRaiseDelay},
   {"IconForeColor",        F_COLOR,    &IconForeColor},
   {"IconBackColor",        F_COLOR,    &IconBackColor},
   {"WallPaper",            F_STRING,   &WallPaper},
   {"StartButtonTitle",     F_STRING,   &StartButtonTitle},
   {"LocaleName",           F_STRING,   &LocaleName},
   {"UseBoldFont",          F_BOOL,     &UseBoldFont},
   {"UseExitDialog",        F_BOOL,     &UseExitDialog},
   {"UsePager",             F_BOOL,     &UsePager},
   {"OpaqueMove",           F_BOOL,     &OpaqueMove},
   {"ClickToFocus",         F_BOOL,     &ClickToFocus},
   {"AutoRaise",            F_BOOL,     &AutoRaise},
   {"Clock12Hours",         F_BOOL,     &Clock12Hours},
   {"IconPath",             F_STRING,   &IconPath},
   {"MiniNonActiveColor",   F_COLOR,    &MiniNonActiveColor},
   {"MiniActiveColor",      F_COLOR,    &MiniActiveColor},
   {"OtherWM",              F_STRING,   &OtherWM},
   {"TitleFont",            F_STRING,   &TitleFont},
   {"TaskbarFont",          F_STRING,   &TaskbarFont},
   {"TaskbarBoldFont",      F_STRING,   &TaskbarBoldFont},
   {"CascadeMenuFont",      F_STRING,   &CascadeMenuFont},
   {"CtrlMenuFont",         F_STRING,   &CtrlMenuFont},
   {"StartMenuFont",        F_STRING,   &StartMenuFont},
   {"IconFont",             F_STRING,   &IconFont},
   {"DialogFont",           F_STRING,   &DialogFont}};

/*
 * Table for fontset variable and font name.
 */
FsNameSet fsSet[] =
  {{&fsTitle,       &TitleFont},
   {&fsTaskbar,     &TaskbarFont},
   {&fsCascadeMenu, &CascadeMenuFont},
   {&fsCtrlMenu,    &CtrlMenuFont},
   {&fsStartMenu,   &StartMenuFont},
   {&fsIcon,        &IconFont},
   {&fsDialog,      &DialogFont},
   {&fsBoldTaskbar, &TaskbarBoldFont}};

/*
 * Table for short cut keys.
 */
ShortCutKey scKey[] =
  {{XK_F4,       Mod1Mask,    Q_CLOSE},
   {XK_Escape,   ControlMask, Q_POPUPSTARTMENU},
   {XK_Escape,   Mod1Mask,    Q_CHANGEWINDOW},
   {XK_Tab,      Mod1Mask,    Q_SWITCHTASK},
   {XK_space,    Mod1Mask,    Q_POPUPMENU},
   {XK_Left,     ControlMask, Q_LEFTPAGING},
   {XK_Right,    ControlMask, Q_RIGHTPAGING},
   {XK_Up,       ControlMask, Q_UPPAGING},
   {XK_Down,     ControlMask, Q_DOWNPAGING},
   {XK_KP_Right, ControlMask, Q_RIGHTPAGING},
   {XK_KP_Left,  ControlMask, Q_LEFTPAGING},
   {XK_KP_Up,    ControlMask, Q_UPPAGING},
   {XK_KP_Down,  ControlMask, Q_DOWNPAGING}};

ShortCutKey scRootKey[] =
  {
   {XK_Escape,   ControlMask, Q_POPUPSTARTMENU},
   {XK_Escape,   Mod1Mask,    Q_CHANGEWINDOW},
   {XK_Tab,      Mod1Mask,    Q_SWITCHTASK},
   {XK_F4,       Mod1Mask,    Q_EXIT},
   {XK_Left,     ControlMask, Q_LEFTPAGING},
   {XK_Right,    ControlMask, Q_RIGHTPAGING},
   {XK_Up,       ControlMask, Q_UPPAGING},
   {XK_Down,     ControlMask, Q_DOWNPAGING},
#ifdef XK_KP_Right
   {XK_KP_Right, ControlMask, Q_RIGHTPAGING},
#endif
#ifdef XK_KP_Left
   {XK_KP_Left,  ControlMask, Q_LEFTPAGING},
#endif
#ifdef XK_KP_Up
   {XK_KP_Up,    ControlMask, Q_UPPAGING},
#endif
#ifdef XK_KP_Down
   {XK_KP_Down,  ControlMask, Q_DOWNPAGING},
#endif
  };

ShortCutKey scMenuKey[] =
  {{XK_Escape,   0,           Q_POPDOWNMENU},
   {XK_Alt_L,    0,           Q_POPDOWNALLMENU},
   {XK_Alt_R,    0,           Q_POPDOWNALLMENU},
   {XK_Meta_L,   0,           Q_POPDOWNALLMENU},
   {XK_Meta_R,   0,           Q_POPDOWNALLMENU},
   {XK_Up,       0,           Q_UPFOCUS},
   {XK_Down,     0,           Q_DOWNFOCUS},
   {XK_Right,    0,           Q_RIGHTFOCUS},
   {XK_Left,     0,           Q_LEFTFOCUS},
   {XK_Return,   0,           Q_ACTION}};

AttrNameSet attrSet[] =
  {{"STICKY",    STICKY,               True},
   {"NOFOCUS",   NOFOCUS,              True},
   {"NOTITLE",   TITLE,                False},
   {"NOBORDER",  BORDER | BORDER_EDGE, False},
   {"NOTBUTTON", NOTBUTTON,            True},
   {"SMALLPIX",  SMALLPIX,             True},
   {"LARGEPIX",  LARGEPIX,             True}};

const int FuncTableSize = sizeof(funcTable)/sizeof(FuncTable);
const int VarTableSize = sizeof(varTable)/sizeof(VariableTable);
const int FsNum = sizeof(fsSet)/sizeof(FsNameSet);
const int SCKeyNum = sizeof(scKey)/sizeof(ShortCutKey);
const int SCRootKeyNum = sizeof(scRootKey)/sizeof(ShortCutKey);
const int SCMenuKeyNum = sizeof(scMenuKey)/sizeof(ShortCutKey);
const int AttrNum = sizeof(attrSet)/sizeof(AttrNameSet);
