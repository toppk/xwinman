#ifndef _SBUTTON_H_
#define _SBUTTON_H_

#include "tbutton.h"

/*
 * StartButton class
 */
class StartButton : public TaskbarButton {
public:
  unsigned int buttonWidth;

private:
  void FillBackground();
  void DrawName();

public:
  StartButton(Qvwm* qvWm, unsigned int some_width);
  ~StartButton() {}
  
  void ExecButtonFunc(ButtonState state) {}
  void Button1Press();
  void Button3Release(const Point& ptRoot) {}
};

#endif // _SBUTTON_H_
