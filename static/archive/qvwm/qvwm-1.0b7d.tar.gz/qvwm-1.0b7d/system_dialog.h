#ifndef _SYSDLG_H_
#define _SYSDLG_H_

#include "dialog.h"

class StringButton;
class RadioSet;

class SystemDialog : public Dialog {
private:
  Window parent;
  Window title;

  int sbNum;                      // # of string button
  int rsNum;                      // # of radio button set
  int stNum;                      // # of explanation texts
  int ipNum;                      // # of icon pixmaps

  StringButton** sb;              // string buttons
  RadioSet** rs;                  // radio button sets
  StaticText** st;                // explanation texts
  IconPixmap** ip;                // icon pixmaps on system dialog

  static const int TITLE_HEIGHT = 18;
  
public:
  SystemDialog(const Rect& rc, char* name, DialogRes** dr, int drNum);
  ~SystemDialog();

  ResourceId GetSelectedRB(ResourceId idRadioSet);
  void CreateDialogResource(DialogRes** dr, int drNum);
  void DrawDialog();
  void DrawTitle();

  void MapDialog();
  void UnmapDialog() { XUnmapWindow(display, parent); }
  void DrawClientWin();
  void Exposure(Window win);
  ResourceId Button1Press(Window win);
};

#endif // _SYSDLG_H_
