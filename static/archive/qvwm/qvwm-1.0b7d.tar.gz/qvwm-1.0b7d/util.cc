#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifndef HAVE_USLEEP
#include <sys/time.h>
#endif
#include <X11/Xlib.h>
#include <X11/Xlocale.h>
#include <X11/xpm.h>
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "menu.h"
#include "util.h"
#include "taskbar.h"
#include "qvwmrc.h"

/*
 * Gravity offset for frame decoration.
 */
Point GravityOffset[] = {
  Point(CENTER, CENTER),            // ForgetGravity
  Point(WEST,   NORTH),             // NorthWestGravity
  Point(CENTER, NORTH),             // NorthGravity
  Point(EAST,   NORTH),             // NorthEastGravity
  Point(WEST,   CENTER),            // WestGravity
  Point(CENTER, CENTER),            // CenterGravity
  Point(EAST,   CENTER),            // EastGravity
  Point(WEST,   SOUTH),             // SouthWestGravity
  Point(CENTER, SOUTH),             // SouthGravity
  Point(EAST,   SOUTH),             // SouthEastGravity
  Point(CENTER, CENTER),            // StaticGravity
};

/*
 * InRect --
 *   Return True if the point is in a given rectangle.
 */
Bool InRect(const Point& pt, const Rect& rc)
{
  if (pt.x < rc.x)
    return False;
  if (pt.x >= rc.x+(int)rc.width)
    return False;
  if (pt.y < rc.y)
    return False;
  if (pt.y >= rc.y+(int)rc.height)
    return False;

  return True;
}

/*
 * IsDoubleClick --
 *   Return True if the click is decided as double click from time and space.
 */
Bool IsDoubleClick(Time prevTime, Time clickTime, const Point& ptPrev,
		   const Point& ptClick)
{
  Rect rcPrev;

  if (clickTime - prevTime > (unsigned int)DoubleClickTime)
    return False;

  rcPrev = Rect(ptPrev.x-DoubleClickRange, ptPrev.y-DoubleClickRange,
		ptPrev.x+DoubleClickRange, ptPrev.y+DoubleClickRange);
  if (!InRect(ptClick, rcPrev))
    return False;

  return True;
}

/*
 * GetMenuItemNum --
 *   Return the number of elements in mItem.
 */
int GetMenuItemNum(const MenuItem* mItem)
{
  int num = 0;

  while (mItem) {
    num++;
    mItem = mItem->next;
  }

  return num;
}

/*
 * CreatePixmapFromFile --
 *   Create a pixmap from the file in IconPath or PIXDIR.
 */
Bool CreatePixmapFromFile(const char* file, Pixmap& pix, Pixmap& mask, GC& gc)
{
  XpmAttributes attr;
  XGCValues gcv;
  char* pathname[2];
  char* filename;
  int error;

  pathname[0] = IconPath;
  pathname[1] = PIXDIR;

  attr.valuemask = XpmColormap | XpmDepth;
  attr.colormap = colormap;
  attr.depth = depth;
  
  for (int i = 0; i < 2; i++) {
    filename = new char[strlen(pathname[i])+strlen(file)+2];
    sprintf(filename, "%s/%s", pathname[i], file);
  
#ifdef __EMX__
    if ((error = XpmReadFileToPixmap(display, root, __XOS2RedirRoot(filename), 
                                     &pix, &mask, &attr)) == XpmSuccess) {
#else
    if ((error = XpmReadFileToPixmap(display, root, filename, &pix, &mask,
				     &attr)) == XpmSuccess) {
#endif
      gcv.clip_mask = mask;
      gc = XCreateGC(display, root, GCClipMask, &gcv);
      
      delete [] filename;
      return True;
    }

    delete [] filename;
  }

  switch (error) {
  case XpmOpenFailed:
    QvwmError("Can't find pixmap '%s'", file);
    break;

  case XpmFileInvalid:
    QvwmError("'%s' isn't valid pixmap file", file);
    break;

  case XpmColorFailed:
    QvwmError("Too many colors in '%s'", file);
    break;

  default:
    QvwmError("Pixmap error in '%s'", file);
  }

  pix = None;
  mask = None;
  gc = NULL;

  return False;
}

/*
 * GetDisplayArea --
 *   Devide screen to 4 areas of up, down, left and right, and return the
 *   position where a given point belongs to.
 */
Taskbar::TaskbarPos GetDisplayArea(const Point& pt)
{
  
  Rect rcRoot = rootQvwm->GetRect();
  int x1, x2;
  int y1, y2;

  x1 = int(double(rcRoot.width - 1) / (rcRoot.height - 1) * pt.y);
  x2 = (rcRoot.width - 1) - x1;

  if (x2 < pt.x && pt.x < x1)
    return Taskbar::BOTTOM;
  else if (x1 < pt.x && pt.x < x2)
    return Taskbar::TOP;

  y1 = int(double(rcRoot.height - 1) / (rcRoot.width - 1) * pt.x);
  y2 = (rcRoot.height - 1) - y1;

  if (y1 < pt.y && pt.y < y2)
    return Taskbar::LEFT;
  else if (y2 < pt.y && pt.y < y1)
    return Taskbar::RIGHT;

  return Taskbar::BOTTOM;
}

/*
 * GetFixName --
 *   Abbreviate the name by attatching '...' at the end if it is too long.
 *   For example, 'kterm@orestes.is.s.u-tokyo.ac.jp' is 'kterm@orest...'.
 */
char* GetFixName(XFontSet& fs, const char* name, int width)
{
  int len, wlen, dotWidth, curWidth;
#ifdef WCHAR
  wchar_t *wname;
#endif
  char *str;
  XRectangle ink, log;

  len = strlen(name);

  if ((curWidth = XmbTextExtents(fs, name, len, &ink, &log)) > width){
    dotWidth = XmbTextExtents(fs, "...", 3, &ink, &log);
    // can't write even "..."
    if (width < dotWidth) {
      str = new char[1];
      str[0] = '\0';
      return str;
    }

#ifdef WCHAR
    wname = new wchar_t[len + 1];
    mbstowcs(wname, name, len + 1);
    for (wlen = 0; wname[wlen] != 0; wlen++)
      ;
#else
    wlen = len;
#endif

    if (curWidth < ((int)width-dotWidth) * 2) {
#ifdef WCHAR
      while (XwcTextExtents(fs, wname, wlen, &ink, &log) > width - dotWidth)
#else
      while (XmbTextExtents(fs, name, wlen, &ink, &log) > width - dotWidth)
#endif
	if (--wlen == 0) {
#ifdef WCHAR
	  delete [] wname;
#endif

	  str = new char[4];
	  strcpy(str, "...");
	  return str;
	}
    }
    else {
      wlen = 0;
#ifdef WCHAR
      while (XwcTextExtents(fs, wname, wlen, &ink, &log) < width - dotWidth)
#else
      while (XmbTextExtents(fs, name, wlen, &ink, &log) < width - dotWidth)
#endif
	wlen++;
      wlen--;
    }

#ifdef WCHAR
    wname[wlen] = 0;
    str = new char[len + 4];
    wcstombs(str, wname, len + 4);
    delete [] wname;
#else
    str = new char[wlen + 4];
    strncpy(str, name, wlen);
    str[wlen] = '\0';
#endif

    strcat(str, "...");
  }
  else {
    str = new char[len + 1];
    strcpy(str, name);
  }

  return str;
}

/*
 * ExecShortCutKey --
 *   Execute the function of shortcut key.
 */
void ExecShortCutKey(int num, const ShortCutKey sck[], const XKeyEvent* ev,
		     Menu* menu)
{
  for (int i = 0; i < num; i++)
    if (ev->keycode == XKeysymToKeycode(display, sck[i].sym) &&
	ev->state == sck[i].mod) {
      menu->ExecFunction(sck[i].func, 0);
      return;
    }
}

/*
 * MappedNotOverride --
 *   Return True if the window attribute doesn't include override_redirect.
 */
Bool MappedNotOverride(Window w, long* state)
{
  XWindowAttributes attr;
  Atom atype;
  int aformat;
  unsigned long nitems, bytes_remain;
  unsigned char* prop;

  if(!XGetWindowAttributes(display, w, &attr))
    return False;

  *state = NormalState;

  if (XGetWindowProperty(display, w, _XA_WM_STATE, 0, 3, False, _XA_WM_STATE,
			 &atype, &aformat, &nitems, &bytes_remain, &prop)
      ==Success) {
    if (prop != NULL) {
      *state = *(long *)prop;
      XFree(prop);
    }
  }

  return (((*state == IconicState) || (attr.map_state != IsUnmapped))
	  && !attr.override_redirect);
}

#ifndef HAVE_USLEEP

#if defined(sun) && !defined(SVR4)
extern "C" int select(int, fd_set *, fd_set *, fd_set *, struct timeval *);
#endif

void usleep(unsigned long usec)
{
  struct timeval tm;
  
  if (usec <= 0)
    return;
  
  tm.tv_usec = usec % 1000000;
  tm.tv_sec = usec / 1000000;
  
  select(1, NULL, NULL, NULL, &tm);
}
#endif // HAVE_USLEEP
