#ifndef _ICON_H_
#define _ICON_H_

#include "misc.h"
#include "menu.h"

/*
 * Icon class
 */
class Icon {
private:
  Icon* prev;                  // prev icon in icon list
  Icon* next;                  // next icon in icon list

  Window w;                    // icon window
  Window wrap;                 // window accepting events around icon
  Rect rc;                     // position and size
  Rect rcVirt;                 // the same in virtual coordinates
  Pixmap pix;                  // icon pixmap
  Pixmap mask;                 // icon mask
#ifndef SHAPE
  GC gc;
#endif
  char* name;            // icon name
  char* exec;            // icon function

  Time iconClickTime;          // click interval when icon executes function

public:
  static const unsigned int ICON_SIZE = 32;
  static const unsigned int ICON_AREA = 75;

  static Icon* firstIcon;               // first icon in icon list
  static Icon* lastIcon;                // last icon in icon list
  static Icon* focusIcon;               // icon with focus
  static XContext context;
  static Pixmap pixIcon, maskIcon;
  static GC gcTileMask;
  static Menu* ctrlMenu;                // popup menu on right-click

public:
  Icon(Pixmap pix, Pixmap mask, char* name, char* exec, int x, int y);
  ~Icon();
  Icon* GetNext() const { return next; }
  Bool CheckMenuMapped() const { return ctrlMenu->CheckMapped(); }
  void UnmapMenu() { ctrlMenu->UnmapMenu(); }

  void MapIcon();
  void UnmapIcon();
  void DrawIcon(Bool focus);
  void Button1Press(Time clickTime, const Point& ptRoot);
  void Button3Release(const Point& ptRoot);

  static void RedrawAllIcons();
  static void LineUpAllIcons();
  static void CreateIconPixmap();
  static void CreateIconGC();
};

#endif // _ICON_H_

