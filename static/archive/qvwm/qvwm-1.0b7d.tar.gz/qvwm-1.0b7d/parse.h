#ifndef _PARSE_H_
#define _PARSE_H_

#include "util.h"

enum VarAttribute {
  F_STRING,
  F_NATURAL,
  F_POSITIVE,
  F_COLOR,
  F_BOOL,
  F_TASKBAR,
  F_GEOMETRY,
  F_OFFSET,
  F_SIZE,
};

struct VariableTable {
  char* name;
  VarAttribute attr;
  void* var;
};

struct FuncTable {
  char* name;
  FuncNumber num;
};

struct AttrStream {
  unsigned long attr;		// frame attribute
  Bool act;			// act direction (True:+, False:-)
  char* value;			// pixmap name etc.
  AttrStream* next;
};

extern void ParseQvwmrc(const char* rcFileName);
extern FuncNumber GetFuncNumber(const char* func);
extern void AssignVariable(const char* var, char* str);
extern MenuItem* MakeExecItem(char* name, char* file, char* exec);
extern MenuItem* MakeDesktopItem(char* name, char* file, char* exec,
				 char* x, char* y);
extern MenuItem* MakeFuncItem(char* name, char* file, char* func);
extern MenuItem* MakeDirItem(char* name, char* file, MenuItem* next);
extern MenuItem* MakeDlgItem(char* name, char* str, char* func);
extern MenuItem* ChainMenuItem(MenuItem* mItem, MenuItem* nextItem);
extern void CompleteMenu(char* menuName, MenuItem* mList);
extern void DoAllSetting();
extern void CreateShortCut(MenuItem* mItem);
extern AttrStream* MakeStream(char* attr, char* value, AttrStream* stream);
extern void CreateAppHash(char* name, AttrStream* stream);
extern Bool IsFunction(const char* text);
extern Bool IsAttribute(const char* text);

#endif // _PARSE_H_
