#ifndef _RADIO_SET_H_
#define _RADIO_SET_H_

#include "resource.h"

class RadioButton;

/*
 * RadioSet class
 */
class RadioSet {
friend RadioButton;
private:
  RadioButton** rb;               // RadioButton belonging to this set
  int num;                        // # of RadioButton
  RadioButton* rbFocus;           // RadioButton with focus
  ResourceId rid;

public:
  RadioSet(RadioButton* rb[], int rbNum, ResourceId rid,
	   ResourceId initId);
  ~RadioSet();

  ResourceId GetResId() const { return rid; }
  ResourceId GetFocusRB();

  void MapRadioButtons();
};

#endif // _RADIO_SET_H_
