#include <stdio.h>
#include <X11/Xlib.h>
#include <X11/xpm.h>
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "util.h"
#include "menu.h"
#include "startmenu.h"
#include "taskbar.h"
#include "tbutton.h"
#include "bitmaps/smenu0.xpm"
#include "bitmaps/smenu1.xpm"
#ifdef __EMX__
#include "bitmaps/ados2.xpm"
#else
#include "bitmaps/ad.xpm"
#endif

Pixmap	StartMenu::pixStart[2];
GC	StartMenu::gcStart[2];
Pixmap	StartMenu::pixAd;

StartMenu::StartMenu(MenuItem* mItem)
: Menu(rootQvwm, mItem, 1, 20, 2, 28, Rect(4, 0, 20, 20), fsCascadeMenu,
       NULL)
{
  XSetWindowAttributes attributes;
  unsigned long valueMask;
  int i, sep = 0;
  Rect rect;

  /*
   * First, start menu was created as normal menu because the constructor
   * of menu creates menus recursively. Here, start menu is recreated.
   */
  fBetween = 0;
  iHeight = 32;
  iBetween = 0;
  paWidth = LOGO_WIDTH + 44;
  rcPix = Rect(LOGO_WIDTH + 6, 0, 32, 32);
  fs = fsStartMenu;

  attributes.background_pixel = darkGray;
  valueMask = CWBackPixel;
  
  logo = XCreateWindow(display, frame,
		       MenuFrameWidth, MenuFrameWidth,
		       LOGO_WIDTH, rc.height - MenuFrameWidth * 2,
		       0, CopyFromParent, InputOutput,
		       CopyFromParent, valueMask, &attributes);
  XSaveContext(display, logo, context, (caddr_t)this);

  /*
   * Report events even on the logo.
   */
  itemFocus = new Window[nitems];

  valueMask = CWEventMask;

  for (i = 0; i < nitems; i++) {
    if (func[i] != Q_SEPARATOR) {
      attributes.event_mask = ButtonPressMask | ButtonReleaseMask |
	                      EnterWindowMask | LeaveWindowMask |
			      OwnerGrabButtonMask | ExposureMask;
      rect.y = MenuFrameWidth + fBetween + (i - sep) * (iHeight + iBetween)
	+ sep * SeparatorHeight;
      rect.height = iHeight;
    }
    else {
      attributes.event_mask = ButtonPressMask | ButtonReleaseMask |
		     	      OwnerGrabButtonMask | ExposureMask;
      rect.y = MenuFrameWidth + fBetween + (i - sep) * (iHeight + iBetween)
	+ sep * SeparatorHeight;
      rect.height = SeparatorHeight;
      sep++;
    }

    rect.x = MenuFrameWidth;
    rect.width = rc.width + LOGO_WIDTH + 16 - MenuFrameWidth * 2;

    /*
     * Create transparent wrapper window on logo and menu item.
     */
    itemFocus[i] = XCreateWindow(display, frame, rect.x, rect.y,
				 rect.width, rect.height,
				 0, CopyFromParent, InputOnly, CopyFromParent,
				 valueMask, &attributes);
    XSaveContext(display, itemFocus[i], context, (caddr_t)this);

    /*
     * Change the size of item window, which is created in the size of
     * ctrl menu.
     */
    XMoveResizeWindow(display, item[i],
		      MenuFrameWidth, rect.y,
		      rc.width + LOGO_WIDTH + 16 - MenuFrameWidth * 2,
		      rect.height);

    /*
     * Change to the pixmap for start menu when use default pixmap.
     */
    if (pix[i] == pixMenu[0]) {
      pix[i] = pixStart[0];
      gc[i] = gcStart[0];
    }
    else if (pix[i] == pixMenu[1]) {
      pix[i] = pixStart[1];
      gc[i] = gcStart[1];
    }
  }

  rc.width += LOGO_WIDTH + 16;
  rc.height = (nitems - sep) * (iHeight + iBetween) + sep * SeparatorHeight
    + MenuFrameWidth * 2;

  XResizeWindow(display, logo, LOGO_WIDTH, rc.height - MenuFrameWidth * 2);
  XResizeWindow(display, frame, rc.width, rc.height);
}

StartMenu::~StartMenu()
{
  XDeleteContext(display, frame, context);
  XDeleteContext(display, logo, context);

  XDestroyWindow(display, logo);
}

/*
 * MapMenu --
 *   Map start menu according to taskbar position.
 */
void StartMenu::MapMenu()
{
  Rect rect;

  ASSERT(rootQvwm);
  ASSERT(rootQvwm->tButton);
  
  rootQvwm->tButton->SetState(Button::PUSH);
  rootQvwm->SetFocus();
  rootQvwm->tButton->DrawButton();

  ASSERT(taskBar);

  switch (taskBar->GetPos()) {
  case Taskbar::BOTTOM:
    rect = taskBar->GetRect();
    rc.x = 2;
    rc.y = rect.y - rc.height + 4;
    break;

  case Taskbar::TOP:
    rect = taskBar->GetRect();
    rc.x = 2;
    rc.y = rect.height-4 - Taskbar::INC_HEIGHT *
      ((rect.height - Taskbar::BASE_HEIGHT) / Taskbar::INC_HEIGHT);
    break;

  case Taskbar::LEFT:
    rc.x = 2;
    rc.y = TaskbarButton::BUTTON_HEIGHT + 2;
    break;

  case Taskbar::RIGHT:
    {
      Rect rcRoot = rootQvwm->GetRect();

      rc.x = rcRoot.width - rc.width - 2;
      rc.y = TaskbarButton::BUTTON_HEIGHT + 2;
    }
    break;
  }

  fDir = RIGHT;
  Menu::MapMenu(rc.x, rc.y);

  XRaiseWindow(display, logo);
  for (int i = 0; i < nitems; i++)
    XRaiseWindow(display, itemFocus[i]);

  XSelectInput(display, rootQvwm->tButton->GetFrameWin(), 
	       ExposureMask | ButtonPressMask | ButtonReleaseMask |
	       Button1MotionMask);
}

/*
 * UnmapMenu --
 *   Unmap start menu.
 */
void StartMenu::UnmapMenu()
{
  Menu::UnmapMenu();

  ASSERT(rootQvwm);
  ASSERT(rootQvwm->tButton);

  rootQvwm->tButton->SetState(Button::NORMAL);
  rootQvwm->tButton->DrawButton();

  XSelectInput(display, rootQvwm->tButton->GetFrameWin(),
	       ExposureMask | ButtonPressMask | ButtonReleaseMask |
	       Button1MotionMask | OwnerGrabButtonMask);
}

/*
 * DrawMenu --
 *   Draw start menu.
 */
void StartMenu::DrawMenu(Window win)
{
  Menu::DrawMenu(win);

#ifdef __EMX__
  XCopyArea(display, pixAd, logo, ::gc, 0, 0, 21, 119, 0, rc.height - 129);
#else  
  XCopyArea(display, pixAd, logo, ::gc, 0, 0, 21, 65, 0, rc.height - 75);
#endif
}

/*
 * FindItem --
 *   Find the menu item corresponding to win.
 */
int StartMenu::FindItem(Window win)
{
  for (int i = 0; i < nitems; i++)
    if (win == item[i] || win == itemFocus[i])
      return i;

  return -1;
}

/*
 * CreateStartMenuPixmap --
 *   Create pixmaps for start menu.
 */
void StartMenu::CreateStartMenuPixmap()
{
  XpmAttributes attr;
  Pixmap mask;
  XGCValues gcv;

  attr.valuemask = XpmColormap | XpmDepth;
  attr.colormap = colormap;
  attr.depth = depth;

  XpmCreatePixmapFromData(display, root, smenu0, &pixStart[0], &mask, &attr);
  gcv.clip_mask = mask;
  gcStart[0] = XCreateGC(display, root, GCClipMask, &gcv);

  XpmCreatePixmapFromData(display, root, smenu1, &pixStart[1], &mask, &attr);
  gcv.clip_mask = mask;
  gcStart[1] = XCreateGC(display, root, GCClipMask, &gcv);

  XpmCreatePixmapFromData(display, root, ad, &pixAd, NULL, &attr);
}
  
