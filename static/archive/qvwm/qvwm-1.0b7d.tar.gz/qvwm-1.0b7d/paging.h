#ifndef _PAGING_H_
#define _PAGING_H_

#include "misc.h"

/*
 * Paging class
 */
class Paging {
private:
  Window side[4];
  Bool mapped[4];

public:
  Point origin;             // left-top point in logical coordinates
  Rect rcVirt;              // size and top-left page of virtual page

public:
  Paging(const Point& topLeft, const Dim& size);
  ~Paging();

  Bool IsPagingBelt(Window win);

  Point HandlePaging(const Point& pt);
  Point PagingProc(Window win);
  void PagingProc(const Point& pt);
  void PagingAllWindows(const Point& oldOrigin);
  void MapSides();
  void RaisePagingBelt();
};

#endif // _PAGING_H_
