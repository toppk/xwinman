#ifndef _DIALOG_H_
#define _DIALOG_H_

#include "util.h"
#include "resource.h"

/*
 * Dialog class
 */
class Dialog {
protected:
  Window frame;                    // frame
  Rect rc;                         // position and size
  char* name;                      // title name

public:
  Dialog(const Rect& rc, char* name);
  virtual ~Dialog();

  Window GetFrameWin() { return frame; }

  virtual void MapDialog();
  virtual void DrawClientWin() {}
  virtual ResourceId EventLoop();
  virtual void Exposure(Window win) {}
  virtual ResourceId Button1Press(Window win);
};

#endif // _DIALOG_H_
