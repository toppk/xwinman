#ifndef _QVWM_H_
#define _QVWM_H_

#include "main.h"
#include "misc.h"
#include "util.h"
#include "menu.h"
#include "hash.h"
#include "startmenu.h"
#include "icon.h"

/*
 * Frame attributes
 */
#define TITLE             (1L << 0)
#define BORDER            (1L << 1)
#define CTRL_MENU         (1L << 2)
#define BUTTON1           (1L << 3)	// minimize button
#define BUTTON2           (1L << 4)	// maximize (restore) button
#define BUTTON3           (1L << 5)	// exit button
#define TRANSIENT         (1L << 6)	// transient window
#define WM_DELETE_WINDOW  (1L << 7)	// intercept close
#define WM_TAKE_FOCUS     (1L << 8)
#define STICKY            (1L << 9)	// always display the window
#define NOFOCUS           (1L << 10)	// has no focus
#define SMALLPIX          (1L << 11)	// has particular small pixmap (16x16)
#define LARGEPIX          (1L << 12)	// has particular large pixmap (32x32)
#define SHAPED            (1L << 13)	// shaped window
#define BORDER_EDGE       (1L << 14)	// 2 dot line inside border
#define THIN_BORDER       (1L << 15)	// 1 dot border surrounding frame
#define NOTBUTTON         (1L << 16)    // has no taskbar button

/*
 * Window status
 */
#define MINIMIZE_WINDOW   (1 << 0)
#define MAXIMIZE_WINDOW   (1 << 1)

class FrameButton;
class TaskbarButton;
class QvwmList;
class Miniature;

/*
 * Qvwm class
 */
class Qvwm {
friend class TaskSwitcher;
private:
  Qvwm* next;
  Qvwm* prev;
  Qvwm* preFocus;                // FocusQvwm before get focus

  Window wOrig;                  // Original window 
  Rect rcOrig;                   // Original window position
  unsigned int bwOrig;           // Original border width 

  Window frame;                  // Frame window (child of root window) 
  Window parent;                 // Parent window of original window 
  Window corner[4];              // Corner window 
  Window side[4];                // Side border window 
  Window title;                  // Title window 
  Window ctrl;                   // Control menu window 
  Rect rc;                       // Frame position
  unsigned long flags;           // Frame attributes (with title etc.) 
  unsigned int status;           // Window status (maximize etc.) 
  Bool mapped;                   // Flag if this window is mapped
  char* name;                    // Window name 
  Pixmap pixLarge;               // Large icon pixmap for task switcher
  GC gcLarge;
  XSizeHints hints;
  XWMHints* wmHints;
  XClassHint classHints;

  Qvwm* transientFor;            // which window is this transient window for?
  QvwmList* transient;           // transient window list of this window
  int transientNum;              // # of transient list

  Window* cmapWins;              // Colormap window list
  int nCmapWins;                 // # of elements of the list

  // Temporary
  Time menuClickTime;            // Previous left click time of menu button 
  Time titleClickTime;           // Previous left click time of titlebar 
  unsigned long flagsBak;        // Frame attributes (backup when maximize)
  Rect rcOrigBak;                // Original window position backup

  static Bool umReserved;        // Ctrl menu unmap reserved flag

  static const int BUTTON_WIDTH = 16;      // frame button width
  static const int BUTTON_HEIGHT = 14;     // frame button height
  static const int MOVEMENT = 13;

public:
  FrameButton* fButton[3];       // Frame button (minimize etc.) 
  TaskbarButton* tButton;        // Taskbar button 
  Menu* ctrlMenu;                // Control popup menu 
  Miniature* mini;               // Miniture window used by pager

  static Qvwm* lastQvwm;
  static Qvwm* focusQvwm;        // focus Qvwm (not always activeQvwm)
  static Qvwm* activeQvwm;       // active Qvwm (raised window)
  static XContext context;
  static Hash<AppAttr>* appHashTable;
  static int initPos;

  static const int TITLE_HEIGHT = BUTTON_HEIGHT + 4;
  static const int BORDER_WIDTH = 6;	// left, right and bottom border
  static const int TOP_BORDER = BORDER_WIDTH - 2;   // top border is special
  static const int TITLE_EDGE = 3;      // the part of border below title

  // frame position name
  enum PositionName { LEFT, RIGHT, TOP, BOTTOM,
		      LEFTTOP, RIGHTTOP, LEFTBOTTOM, RIGHTBOTTOM };

private:
  void CreateFrame(const Rect& rect);
  void CreateParent(const Rect& rect);
  void CreateSides(const Rect rect[]);
  void CreateCorners(const Rect rect[]);  
  void CreateTitle(const Rect& rect);
  void CreateCtrlButton(const Rect& rect);
  void ChangeOrigWindow();

  void MotionTitlebar(const Rect& rcSrc, const Rect& rcDest);
  Rect GetFixSize(const Rect& rc, int max_width, int max_height, int width_inc,
		  int height_inc, int base_width, int base_height);

  void DrawTitle();
  void DrawCtrlMenuMark();
  void DrawFrame();
  void RedrawWindow();
  void CalcWindowPos(const Rect& base);
  void CalcFramePos(const Rect& rcFrame, Rect* rcParent, Rect* rcTitle,
		    Rect rcCorner[], Rect rcSide[], Rect* rcCtrl,
		    Rect rcButton[]);

  void MapWindow();

  void GrabKeys();
  void GrabRootKeys();
  void UngrabRootKeys();

  void FetchWMColormapWindows();
  void GetWindowClassHints(Pixmap& pixSmall, GC& gcSmall);
  void GetWindowSizeHints();
  Point& GetGravityOffset();
  void GetFixedIcon(Pixmap& pix, GC& gc, int size);

public:
  Qvwm(Window w, Bool usrPos);
  Qvwm(Window root);
  ~Qvwm();

  Qvwm* GetNext() const { return next; }
  Window GetFrameWin() const { return frame; }
  Window GetWin() const { return wOrig; }
  Bool CheckStatus(unsigned long kind) const { return status & kind; }
  void SetStatus(unsigned long kind) { status |= kind; }
  void ResetStatus(unsigned long kind) { status &= ~kind; }
  Bool CheckFlags(unsigned int kind) const { return flags & kind; }
  void SetFlags(unsigned int kind) { flags |= kind; }
  void ResetFlags(unsigned int kind) { flags &= ~kind; }
  unsigned int GetOrigBW() const { return bwOrig; }
  void SetName(char* str) { name = str; }
  char* GetName() const { return name; }
  Bool CheckMapped() const { return mapped; }
  void ResetMapped() { mapped = False; }
  Bool CheckMenuMapped() const { return ctrlMenu->CheckMapped(); }
  Bool CheckFocus() const { return (this == focusQvwm); }
  Pixmap GetIconPixmap() const { return tButton->GetPixmap(); }
  GC GetIconGC() const { return tButton->GetGC(); }
  Rect GetRect() const { return rc; }
  void SetRect(Rect& rect) { rc = rect; }
  int GetNumCmapWins() const { return nCmapWins; }
  XWMHints* GetWMHints() const { return wmHints; }

  void MapWindows();
  void UnmapWindows();
  void RaiseWindow(Bool soon);
  void CloseWindow() { SendMessage(_XA_WM_DELETE_WINDOW); }
  void SetShape();

  void MapMenu(int x, int y) {
    ASSERT(ctrlMenu);
    ctrlMenu->SetQvwm(this);
    ctrlMenu->MapMenu(x, y);
  }
  void UnmapMenu() {
    ASSERT(ctrlMenu);
    ctrlMenu->UnmapMenu();
  }

  void SetFocus();
  void ChangeFocus();
  void PushFocusStack();
  Qvwm* GetNextFocus();
  static void RollFocus();

  void MoveWindow(const Point& ptPress);
  void ResizeWindow(PositionName pos, const Point& ptPress);
  void MaximizeWindow();
  void MinimizeWindow();
  void RestoreWindow();

  void ExecFunction(FuncNumber fn) {
    ctrlMenu->SetQvwm(this);
    ctrlMenu->ExecFunction(fn, 0);
  }

  void SendMessage(Atom atom);
  void KillClient() {
    XKillClient(display, wOrig);
  }

  void SetProperty(Atom atom);
  void FetchWMProtocols();
  void SetStateProperty(int state);

  void Configure(const XConfigureRequestEvent* cre);
  void ConfigureNewRect(const Rect& rcNew);
  void SendConfigureEvent();
  void GetBorderAndTitle(int& borderWidth, int& topBorder, int& titleHeight,
			 int& titleEdge);

  void AdjustPage();

  void InstallWindowColormaps();

  void Exposure(Window win);
  void Button1Press(Window win, Time clickTime, const Point& ptRoot);
  void Button1Release();
  void Button3Release(Window win, const Point& ptRoot);
  void Button1Motion(Window win, const Point& ptRoot);

  static Qvwm* LookInList(Window w);
  static void CaptureAllWindows();
  static void UnmapAllMenus() {
    ASSERT(focusQvwm);
    if (focusQvwm->CheckMenuMapped())
      focusQvwm->UnmapMenu();
    if (startMenu != NULL && startMenu->CheckMapped())
      startMenu->UnmapMenu();
    if (Icon::focusIcon->CheckMenuMapped())
      Icon::focusIcon->UnmapMenu();
  }
  static void FinishQvwm(Bool reStart);
  static void RecalcAllWindows();
  static void ChangeFocusToCursor();
};

/*
 * class QvwmList
 */
class QvwmList {
friend Qvwm;
private:
  Qvwm* qvWm;
  QvwmList* next;
  Bool mapped;            // whether this was mapped when parent was unmapped

public:
  QvwmList(Qvwm* qvwm) : qvWm(qvwm), next(NULL), mapped(False) {}
  ~QvwmList() {}

  void SetNext(QvwmList* qvList) { next = qvList; }
  QvwmList* GetNext() const { return next; }
  Qvwm* GetQvwm() const { return qvWm; }
  void SetMapped() { mapped = True; }
  void ResetMapped() { mapped = False; }
  Bool CheckMapped() const { return mapped; }
};

#endif // _QVWM_H_ 
