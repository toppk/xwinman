#include <stdio.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "events.h"
#include "qvwmrc.h"
#include "paging.h"
#include "pager.h"
#include "util.h"

Pager::Pager(InternGeom geom)
: rcOrig(geom.rc), gravity(geom.gravity)
{
  XSetWindowAttributes attributes;
  unsigned long valueMask;

  /*
   * If width or height is 0, set default value.
   */
  if (rcOrig.width == 0)
    rcOrig.width = 48;
  if (rcOrig.height == 0)
    rcOrig.height = 48;

  /*
   * Adjust pager size and position.
   */
  rcOrig.width = RoundDown(rcOrig.width, paging->rcVirt.width);
  rcOrig.height = RoundDown(rcOrig.height, paging->rcVirt.height);
  if (gravity.x == EAST)
    rcOrig.x += geom.rc.width - rcOrig.width;
  if (gravity.y == SOUTH)
    rcOrig.y += geom.rc.height - rcOrig.height;

  CalcPagerPos();

  /*
   * Create the frame window for pager.
   */
  attributes.background_pixel = gray;
  attributes.override_redirect = True;
  attributes.event_mask = ExposureMask;
  valueMask = CWBackPixel | CWEventMask | CWOverrideRedirect;
  
  frame = XCreateWindow(display, root,
			rc.x, rc.y, rc.width, rc.height,
			0, CopyFromParent, InputOutput, CopyFromParent,
			valueMask, &attributes);
  
  /*
   * Create the title window.
   */
  attributes.background_pixel = blue;
  attributes.event_mask = ButtonPressMask | ButtonReleaseMask |
                          Button1MotionMask;
  valueMask = CWBackPixel | CWEventMask;
  
  title = XCreateWindow(display, frame,
			BORDER_WIDTH, BORDER_WIDTH, rcOrig.width, TITLE_HEIGHT,
			0, CopyFromParent, InputOutput, CopyFromParent,
			valueMask, &attributes);
  
  /*
   * Create the window for the miniature of whole virtual screen.
   */
  attributes.background_pixel = gray;
  attributes.event_mask = ButtonPressMask | ExposureMask;
  valueMask = CWBackPixel | CWEventMask;
  
  pages = XCreateWindow(display, frame,
			BORDER_WIDTH, TITLE_HEIGHT + BORDER_WIDTH + 1,
			rcOrig.width, rcOrig.height,
			0, CopyFromParent, InputOutput, CopyFromParent,
			valueMask, &attributes);
  
  ASSERT(paging);

  pageSize = Dim(rcOrig.width / paging->rcVirt.width,
		 rcOrig.height / paging->rcVirt.height);
  
  /*
   * Create the window standing for current page.
   */
  attributes.background_pixel = darkGray;
  attributes.event_mask = ButtonPressMask | ButtonReleaseMask |
                          Button3MotionMask;
  valueMask = CWBackPixel | CWEventMask;
  
  visual = XCreateWindow(display, pages,
			 0, 0, pageSize.width - 2, pageSize.height - 2,
			 0, CopyFromParent, InputOutput, CopyFromParent,
			 valueMask, &attributes);
  
  XMapWindow(display, frame);
  XMapWindow(display, title);
  XMapWindow(display, pages);
  XMapWindow(display, visual);
  
  DrawVisualPage();
}

Pager::~Pager()
{
  XDestroyWindow(display, frame);
}

/*
 * IsPagerWindows --
 *   Return True if the window is pager window.
 */
Bool Pager::IsPagerWindows(Window win)
{
  if (win == pages || win == visual || win == frame || win == title)
    return True;
  else
    return False;
}

void Pager::CalcPagerPos()
{
  Rect rect;

  rc.x = rcOrig.x + rcScreen.x + BORDER_WIDTH * gravity.x;
  rc.y = rcOrig.y + rcScreen.y;
  if (gravity.y == CENTER)
    rc.y -= BORDER_WIDTH + TITLE_HEIGHT + 1;
  else if (gravity.y == SOUTH)
    rc.y -= BORDER_WIDTH * 2 + TITLE_HEIGHT + 1;

  ASSERT(taskBar);

  switch (taskBar->GetPos()) {
  case Taskbar::BOTTOM:
  case Taskbar::TOP:
    // South??Gravity
    if (gravity.y == SOUTH) {
      rect = taskBar->GetRect();
      rc.y -= rect.height;
    }
    break;
  case Taskbar::LEFT:
  case Taskbar::RIGHT:
    // ??EastGravity
    if (gravity.x == EAST) {
      rect = taskBar->GetRect();
      rc.x -= rect.width;
    }
    break;
  }

  rc.width = rcOrig.width + BORDER_WIDTH * 2;
  rc.height = rcOrig.height + BORDER_WIDTH * 2 + TITLE_HEIGHT + 1;
}

/*
 * RecalcPager --
 *   Recalc the position of pager according to rcScreen and move the pager.
 */
void Pager::RecalcPager()
{
  CalcPagerPos();
  XMoveWindow(display, frame, rc.x, rc.y);
}

/*
 * ConvertToPagerPos
 *   Convert real position to position in pager.
 */
Point Pager::ConvertToPagerPos(const Point& pt)
{
  Rect rcRoot = rootQvwm->GetRect();
  Point ptMini;

  ASSERT(paging);

  ptMini.x = pt.x * (int)pageSize.width / (int)rcRoot.width -
    paging->rcVirt.x * (int)pageSize.width;
  ptMini.y = pt.y * (int)pageSize.height / (int)rcRoot.height -
    paging->rcVirt.y * (int)pageSize.height;

  return (ptMini);
}

/*
 * ConvertToPagerSize
 *   Convert real size to size in pager.
 */
Rect Pager::ConvertToPagerSize(const Rect& rect)
{
  Rect rcRoot = rootQvwm->GetRect();
  Rect rcMini;

  ASSERT(paging);

  rcMini.x = rect.x * (int)pageSize.width / (int)rcRoot.width -
    paging->rcVirt.x * (int)pageSize.width;
  rcMini.y = rect.y * (int)pageSize.height / (int)rcRoot.height -
    paging->rcVirt.y * (int)pageSize.height;
  rcMini.width = rect.width * pageSize.width / rcRoot.width;
  if (rcMini.width == 0)
    rcMini.width = 1;
  rcMini.height = rect.height * pageSize.height / rcRoot.height;
  if (rcMini.height == 0)
    rcMini.height = 1;

  return (rcMini);
}

/*
 * ConvertToRealPos
 *   Convert position in pager to real position.
 */
Point Pager::ConvertToRealPos(const Point& pt)
{
  Rect rcRoot = rootQvwm->GetRect();
  Point ptReal;

  ASSERT(paging);

  ptReal.x = pt.x * (int)rcRoot.width / (int)pageSize.width +
    paging->rcVirt.x * (int)rcRoot.width;
  ptReal.y = pt.y * (int)rcRoot.height / (int)pageSize.height +
    paging->rcVirt.y * (int)rcRoot.height;

  return (ptReal);
}

/*
 * DrawPages --
 *   Draw pages.
 */
void Pager::DrawPages()
{
  int i;

  ASSERT(paging);

  for (i = 1; i < (int)paging->rcVirt.width; i++) {
    XSetForeground(display, gc, darkGray);
    XDrawLine(display, pages, gc,
	      pageSize.width*i - 1, 1,
	      pageSize.width * i - 1, rcOrig.height - 2);
    XSetForeground(display, gc, white);
    XDrawLine(display, pages, gc,
	      pageSize.width * i, 1,
	      pageSize.width * i, rcOrig.height - 2);
  }
  for (i = 1; i < (int)paging->rcVirt.height; i++) {
    XSetForeground(display, gc, darkGray);
    XDrawLine(display, pages, gc,
	      1, pageSize.height * i - 1,
	      rcOrig.width - 2, pageSize.height * i - 1);
    XSetForeground(display, gc, white);
    XDrawLine(display, pages, gc,
	      1, pageSize.height * i,
	      rcOrig.width - 2, pageSize.height * i);
  }
}

/*
 * DrawVisualPage --
 *   Draw area standing for visual page.
 */
void Pager::DrawVisualPage()
{
  Rect rcRoot = rootQvwm->GetRect();
  Point ptVisual;

  ASSERT(paging);

  ptVisual.x = (paging->origin.x - paging->rcVirt.x * rcRoot.width)
    * rcOrig.width / (rcRoot.width * paging->rcVirt.width) + 1;
  ptVisual.y = (paging->origin.y - paging->rcVirt.y * rcRoot.height)
    * rcOrig.height / (rcRoot.height * paging->rcVirt.height) + 1;
  
  XMoveWindow(display, visual, ptVisual.x, ptVisual.y);
}

/*
 * DrawFrame --
 *   Draw pager frame.
 */
void Pager::DrawFrame()
{
  XPoint xp[3];

  xp[0].x = rc.width - 2;
  xp[0].y = 0;
  xp[1].x = 0;
  xp[1].y = 0;
  xp[2].x = 0;
  xp[2].y = rc.height - 2;
  
  XSetForeground(display, gc, lightGray);
  XDrawLines(display, frame, gc, xp, 3, CoordModeOrigin);

  xp[0].x = rc.width - 1;
  xp[0].y = 0;
  xp[1].x = rc.width - 1;
  xp[1].y = rc.height - 1;
  xp[2].x = 0;
  xp[2].y = rc.height - 1;

  XSetForeground(display, ::gc, black);
  XDrawLines(display, frame, ::gc, xp, 3, CoordModeOrigin);

  xp[0].x = rc.width - 3;
  xp[0].y = 1;
  xp[1].x = 1;
  xp[1].y = 1;
  xp[2].x = 1;
  xp[2].y = rc.height - 3;

  XSetForeground(display, ::gc, white);
  XDrawLines(display, frame, ::gc, xp, 3, CoordModeOrigin);
  
  xp[0].x = rc.width - 2;
  xp[0].y = 1;
  xp[1].x = rc.width - 2;
  xp[1].y = rc.height - 2;
  xp[2].x = 1;
  xp[2].y = rc.height - 2;

  XSetForeground(display, ::gc, darkGray);
  XDrawLines(display, frame, ::gc, xp, 3, CoordModeOrigin);
}

/*
 * Button1Press --
 *   Process the press of button1(mouse left button).
 */
void Pager::Button1Press(Window win, const Point& ptRoot, const Point& ptWin)
{
  XRaiseWindow(display, frame);

  ASSERT(paging);
  paging->RaisePagingBelt();

  if (win == pages) {
    /*
     * Move the current page to the clicked area.
     */
    Point ptPage;
    Rect rcRoot = rootQvwm->GetRect();

    ptPage.x = ptWin.x * paging->rcVirt.width / rcOrig.width;
    ptPage.y = ptWin.y * paging->rcVirt.height / rcOrig.height;
    
    Point oldOrigin = paging->origin;
    paging->origin.x = (ptPage.x + paging->rcVirt.x) * rcRoot.width;
    paging->origin.y = (ptPage.y + paging->rcVirt.y) * rcRoot.height;

    paging->PagingAllWindows(oldOrigin);
  }
  else if (win == title) {
    /*
     * Move the pager.
     */
    XEvent ev;
    Point ptOld(ptRoot), ptNew, ptMove;

    while (1) {
      XMaskEvent(display, Button1MotionMask | ButtonReleaseMask | ExposureMask,
		 &ev);
      switch (ev.type) {
      case MotionNotify:
	ptNew = Point(ev.xbutton.x_root, ev.xbutton.y_root);
	ptMove = ptNew - ptOld;
	rc.x += ptMove.x;
	rc.y += ptMove.y;
	rcOrig.x += ptMove.x;
	rcOrig.y += ptMove.y;
	ptOld = ptNew;
	XMoveWindow(display, frame, rc.x, rc.y);
	break;

      case ButtonRelease:
	return;

      case Expose:
	ExposeProc(ev.xexpose.window);
	break;
      }
    }
  }
}

/*
 * Button3Press --
 *   Process the press of button3(mouse right button).
 *   You can move the visual page, or the current screen freely.
 */
void Pager::Button3Press(const Point& ptRoot)
{
  XEvent ev;
  Point ptOld, ptNew;
  Rect rcRoot = rootQvwm->GetRect();
  
  XRaiseWindow(display, frame);

  ASSERT(paging);
  paging->RaisePagingBelt();

  ptOld = ptRoot;

  while (1) {
    XMaskEvent(display, Button3MotionMask | ButtonReleaseMask | ExposureMask,
	       &ev);
    switch (ev.type) {
    case MotionNotify:
      {
	Point oldOrigin = paging->origin;

	ptNew = Point(ev.xbutton.x_root, ev.xbutton.y_root);
	paging->origin.x += (ptNew.x - ptOld.x) *
	  (rcRoot.width * paging->rcVirt.width / rcOrig.width);
	paging->origin.y += (ptNew.y - ptOld.y) *
	  (rcRoot.height * paging->rcVirt.height / rcOrig.height);
	ptOld = ptNew;
	paging->PagingAllWindows(oldOrigin);
	break;
      }

    case ButtonRelease:
      return;

    case Expose:
      ExposeProc(ev.xexpose.window);
      break;
    }
  }
}

/*
 * Exposure --
 *   Process exposure event.
 */
void Pager::Exposure(Window win)
{
  if (win == frame)
    DrawFrame();
  else if (win == pages)
    DrawPages();
}

XContext Miniature::context;

/*
 * Miniature class constructor
 */
Miniature::Miniature(Qvwm* qvWm, const Rect& rect) : qvWm(qvWm), focus(False)
{
  XSetWindowAttributes attributes;
  unsigned long valueMask;

  ASSERT(pager);

  rc = pager->ConvertToPagerSize(rect);

  attributes.border_pixel = darkGray;
  attributes.event_mask = ExposureMask | ButtonPressMask | ButtonReleaseMask |
    Button2MotionMask;
  valueMask = CWBorderPixel | CWEventMask;

  wMini = XCreateWindow(display, pager->pages, rc.x, rc.y, rc.width, rc.height,
			1, CopyFromParent, InputOutput, CopyFromParent,
			valueMask, &attributes);

  XSaveContext(display, wMini, context, (caddr_t)this);
}

Miniature::~Miniature()
{
  XDeleteContext(display, wMini, context);

  XDestroyWindow(display, wMini);
}

/*
 * MoveMiniature --
 *   Move miniature window in miniature coordinate.
 */
void Miniature::MoveMiniature(const Point& pt)
{
  rc.x = pt.x;
  rc.y = pt.y;

  XMoveWindow(display, wMini, pt.x, pt.y);
}

/*
 * MoveResizeMiniature --
 *   Move and resize miniature window in miniature coordinate.
 */
void Miniature::MoveResizeMiniature(const Rect& rect)
{
  rc = rect;

  XMoveResizeWindow(display, wMini, rc.x, rc.y, rc.width, rc.height);
}

/*
 * DrawMiniature --
 *   Draw miniature window.
 */
void Miniature::DrawMiniature()
{
  if (focus)
    XSetWindowBackground(display, wMini, MiniActiveColor);
  else
    XSetWindowBackground(display, wMini, MiniNonActiveColor);
  
  XClearWindow(display, wMini);
}

/*
 * Button1Press --
 *   Process the press of button1(left button).
 *   Switch to the page and give focus to the corresponding window.
 */
void Miniature::Button1Press(const Point& ptRoot)
{
  Point ptWin;
  Window junkChild;

  ASSERT(pager);

  XRaiseWindow(display, pager->frame);

  ASSERT(paging);
  paging->RaisePagingBelt();

  XTranslateCoordinates(display, root, pager->pages, ptRoot.x, ptRoot.y,
			&ptWin.x, &ptWin.y, &junkChild);

  pager->Button1Press(pager->pages, ptRoot, ptWin);

  if (ClickToFocus) {
    ASSERT(qvWm);
    qvWm->SetFocus();
    qvWm->RaiseWindow(True);
  }
}

/*
 * Button2Press --
 *   Process the press of button2(middle button or left & right botton).
 *   Move miniature window.
 */
void Miniature::Button2Press(const Point& ptRoot)
{
  XEvent ev;
  Point ptOld, ptNew, ptMini, ptReal;
  Rect rcReal;
  
  ASSERT(pager);
  XRaiseWindow(display, pager->frame);

  ASSERT(paging);
  paging->RaisePagingBelt();

  ASSERT(qvWm);

  if (ClickToFocus) {
    if (!qvWm->CheckFocus())
      qvWm->SetFocus();
    qvWm->RaiseWindow(True);
    qvWm->AdjustPage();
  }

  ptOld = ptRoot;

  while (1) {
    XMaskEvent(display, Button2MotionMask | ButtonReleaseMask | ExposureMask,
	       &ev);
    switch (ev.type) {
    case MotionNotify:
      ptNew = Point(ev.xbutton.x_root, ev.xbutton.y_root);
      rc.x += ptNew.x - ptOld.x;
      rc.y += ptNew.y - ptOld.y;
      ptOld = ptNew;

      ptMini = Point(rc.x, rc.y);
      MoveMiniature(ptMini);

      if (OpaqueMove) {
	ptReal = pager->ConvertToRealPos(ptMini);
	XMoveWindow(display, qvWm->GetFrameWin(),
		    ptReal.x - paging->origin.x, ptReal.y - paging->origin.y);
	
	rcReal = qvWm->GetRect();
	rcReal.x = ptReal.x;
	rcReal.y = ptReal.y;
	qvWm->ConfigureNewRect(rcReal);
      }
      break;
      
    case ButtonRelease:
      if (!OpaqueMove) {
	ptReal = pager->ConvertToRealPos(ptMini);
	XMoveWindow(display, qvWm->GetFrameWin(),
		    ptReal.x - paging->origin.x, ptReal.y - paging->origin.y);
	
	rcReal = qvWm->GetRect();
	rcReal.x = ptReal.x;
	rcReal.y = ptReal.y;
	qvWm->ConfigureNewRect(rcReal);
      }
      return;

    case Expose:
      ExposeProc(ev.xexpose.window);
      break;
    }
  }
}

/*
 * RestackMiniatures --
 *   Restack miniatures according to minis's order.
 */
void Miniature::RestackMiniatures(Miniature* minis[], int nminis)
{
  Window* wins = new Window[nminis];

  for (int i = 0; i < nminis; i++)
    wins[i] = minis[i]->wMini;

  XRestackWindows(display, wins, nminis);

  delete [] wins;
}
