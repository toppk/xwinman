#ifndef _EVENTS_H_
#define _EVENTS_H_

class Point;

extern Point	ptPrevRoot;
extern int	shapeEventBase;

extern void MainLoop();
extern void DispatchEvent(const XEvent* ev);
extern void ColormapNotifyProc(Window w, Bool newCmap,
			       const XColormapEvent* ev);
extern void ExposeProc(Window w);
#ifdef SHAPE
extern void ShapeNotifyProc(Window w, int kind);
#endif

#endif // _EVENTS_H_
