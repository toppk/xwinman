#ifndef _STRING_BUTTON_H_
#define _STRING_BUTTON_H_

#include "button.h"
#include "resource.h"

class StringButton : public Button {
private:
  char* str;
  XFontSet& fs;
  ResourceId rid;
  
  Bool triggered;

public:
  StringButton(Window parent, const Rect& rc, char* str, XFontSet& fs,
	       ResourceId rid);
  ~StringButton() {}

  Bool IsTriggered() { return triggered; }
  ResourceId GetResId() { return rid; }
  
  void DrawButton();
  void ExecButtonFunc(ButtonState state);
};

#endif // _STRING_BUTTON_H_
