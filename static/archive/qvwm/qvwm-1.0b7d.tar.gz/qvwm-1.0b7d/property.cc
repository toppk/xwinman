#include <stdio.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include "main.h"
#include "misc.h"
#include "qvwm.h"
#include "hash.h"
#include "tbutton.h"
#include "qvwmrc.h"
#include "util.h"

Hash<AppAttr>* Qvwm::appHashTable;

static Pixmap FixIconPixmap(Pixmap origPix, unsigned int width,
			    unsigned int height, int size, unsigned int depth,
			    unsigned long fore, unsigned long back);
static void GetDefLogo(Pixmap& pix, GC& gc, int size);

/*
 * SetProperty --
 *   Set window property.
 */
void Qvwm::SetProperty(Atom atom)
{
  XTextProperty xtp;
  char** cl;
  char *iconName;
  int n;
  Pixmap pixSmall;
  GC gcSmall;

  switch (atom) {
  case XA_WM_NAME:
    if (name)
      delete [] name;

    if (XGetWMName(display, wOrig, &xtp) != 0) {
      XmbTextPropertyToTextList(display, &xtp, &cl, &n);
      name = new char[strlen(cl[0]) + 1];
      strcpy(name, cl[0]);
      XFreeStringList(cl);
    }
    else {
      name = new char[9];
      strcpy(name, "Untitled");
    }
    DrawTitle();
    break;

  case XA_WM_ICON_NAME:
    ASSERT(tButton);
    if (XGetWMIconName(display, wOrig, &xtp) != 0) {
      XmbTextPropertyToTextList(display, &xtp, &cl, &n);
      iconName = new char[strlen(cl[0]) + 1];
      strcpy(iconName, cl[0]);
      XFreeStringList(cl);
      tButton->SetName(iconName);
    }
    else {
      iconName = new char[9];
      strcpy(iconName, "Untitled");
      tButton->SetName(iconName);
    }
    tButton->DrawButton();
    break;

  case XA_WM_HINTS:
    if (!CheckFlags(LARGEPIX))
      GetFixedIcon(pixLarge, gcLarge, 32);
    if (!CheckFlags(SMALLPIX)) {
      GetFixedIcon(pixSmall, gcSmall, 16);
      ASSERT(tButton);
      tButton->SetPixmap(pixSmall);
      tButton->SetGC(gcSmall);
      tButton->DrawButton();
    }
    break;

  case XA_WM_NORMAL_HINTS:
    GetWindowSizeHints();
    break;

  default:
    if (atom == _XA_WM_PROTOCOLS)
      FetchWMProtocols();
    else if (atom == _XA_WM_COLORMAP_WINDOWS) {
      FetchWMColormapWindows();
      XSync(display, 0);
      InstallWindowColormaps();
    }
  }
}

/*
 * GetWindowClassHints --
 *
 */
void Qvwm::GetWindowClassHints(Pixmap& pixSmall, GC& gcSmall)
{
  AppAttr* attrs;
  Pixmap mask;

  classHints.res_name = NULL;
  classHints.res_class = NULL;

  XGetClassHint(display, wOrig, &classHints);

#ifdef DEBUG
  printf("class: %s(%s)\n", classHints.res_name, classHints.res_class);
#endif

  /*
   * Set flags and pixmaps according to resource name, resource class and 
   * application name.
   */
  if ((attrs = appHashTable->GetHashItem(classHints.res_name)) ||
      (attrs = appHashTable->GetHashItem(classHints.res_class)) ||
      (attrs = appHashTable->GetHashItem(name))) {
    flags = attrs->flags;

    if (!CheckFlags(BORDER))
      SetFlags(THIN_BORDER);

    /*
     * If LARGEPIX is specified and large pixmap hasn't been created,
     * create it.
     */
    if (CheckFlags(LARGEPIX) && attrs->large_pix == None)
      if (!CreatePixmapFromFile(attrs->large_file, attrs->large_pix, mask,
				attrs->large_gc))
	ResetFlags(LARGEPIX);
    pixLarge = attrs->large_pix;
    gcLarge = attrs->large_gc;

    /*
     * If SMALLPIX is specified and large pixmap hasn't been created,
     * create it.
     */
    if (CheckFlags(SMALLPIX) && attrs->small_pix == None)
      if (!CreatePixmapFromFile(attrs->small_file, attrs->small_pix, mask,
				attrs->small_gc))
	ResetFlags(SMALLPIX);
    pixSmall = attrs->small_pix;
    gcSmall = attrs->small_gc;

    return;
  }

  // Default flags
  flags = TITLE | BORDER | BORDER_EDGE | CTRL_MENU | BUTTON1 | BUTTON2
    | BUTTON3;
}

/*
 * GetWindowSizeHints --
 *   Get window size hints.
 */
void Qvwm::GetWindowSizeHints()
{
  long supplied;

  if (!XGetWMNormalHints(display, wOrig, &hints, &supplied))
    hints.flags = 0;
  
  if (hints.flags & PResizeInc) {
    if (hints.width_inc == 0)
      hints.width_inc = 1;
    if (hints.height_inc == 0)
      hints.height_inc = 1;
  }
  else {
    hints.width_inc = 1;
    hints.height_inc = 1;
  }
  
  if (!(hints.flags & PBaseSize)) {
    if (hints.flags & PMinSize) {
      hints.base_width = hints.min_width;
      hints.base_height = hints.min_height;
    }
    else {
      hints.base_width = 0;
      hints.base_height = 0;
    }
  }
  
  if (!(hints.flags & PMinSize)) {
    hints.min_width = hints.base_width;
    hints.min_height = hints.base_height;
  }
    
  if (!(hints.flags & PMaxSize)) {
    hints.max_width = MAX_WINDOW_WIDTH;
    hints.max_height = MAX_WINDOW_HEIGHT;
  }
    
  if (!(hints.flags & PWinGravity)) {
    hints.win_gravity = NorthWestGravity;
    hints.flags |= PWinGravity;
  }
}

/*
 * GetGravityOffset --
 *   Get the offset needed in the gravity.
 */
Point& Qvwm::GetGravityOffset()
{
  int gr = NorthWestGravity;

  if (hints.flags & PWinGravity)
    gr = hints.win_gravity;

  if (gr < ForgetGravity || gr > StaticGravity)
    return GravityOffset[NorthWestGravity];
  else
    return GravityOffset[gr];
}
  
/*
 * FetchWMProtocols --
 */
void Qvwm::FetchWMProtocols()
{
  Atom *protocols, *ap;
  int i, n;
  Atom atype;
  int aformat;
  unsigned long bytes_remain, nitems;
  
  if (XGetWMProtocols(display, wOrig, &protocols, &n)) {
    ap = protocols;
    for (i = 0; i < n; i++) {
      if (*ap == (Atom)_XA_WM_DELETE_WINDOW)
	SetFlags(WM_DELETE_WINDOW);
      if (*ap == (Atom)_XA_WM_TAKE_FOCUS)
	SetFlags(WM_TAKE_FOCUS);
      ap++;
    }
    if (protocols)
      XFree(protocols);
  }
  else {
    if ((XGetWindowProperty(display, wOrig, _XA_WM_PROTOCOLS, 0L, 10L, False,
			    _XA_WM_PROTOCOLS, &atype, &aformat, &nitems,
			    &bytes_remain, (unsigned char **)&protocols))
	== Success) {
      ap = protocols;
      for (i = 0; i < (int)nitems; i++) {
	if (*ap == (Atom)_XA_WM_DELETE_WINDOW)
	  SetFlags(WM_DELETE_WINDOW);
	if (*ap == (Atom)_XA_WM_TAKE_FOCUS)
	  SetFlags(WM_TAKE_FOCUS);
	ap++;
      }
      if (protocols)
	XFree(protocols);
    }
  }
}

/*
 * GetFixedIcon --
 *   Get icon whose size becomes 16 or 32.
 */
void Qvwm::GetFixedIcon(Pixmap& pix, GC& gc, int size)
{
  Window junkRoot;
  Rect rect;
  unsigned int junkBW, pixDepth;
  Pixmap mask;
  XGCValues gcv;

  if (wmHints == NULL || !(wmHints->flags & IconPixmapHint))
    GetDefLogo(pix, gc, size);
  else {
    if (XGetGeometry(display, wmHints->icon_pixmap, &junkRoot,
		     &rect.x, &rect.y, &rect.width, &rect.height,
		     &junkBW, &pixDepth) == 0) {
      GetDefLogo(pix, gc, size);
      XFree(wmHints);
      return;
    }
	
    if (rect.width == 0 || rect.height == 0) {
      GetDefLogo(pix, gc, size);
      XFree(wmHints);
      return;
    }

    pix = FixIconPixmap(wmHints->icon_pixmap, rect.width, rect.height, size,
			depth, IconForeColor, IconBackColor);
    if (pix == None) {
      GetDefLogo(pix, gc, size);
      XFree(wmHints);
      return;
    }

    if (wmHints->flags & IconMaskHint) {
      mask = FixIconPixmap(wmHints->icon_mask, rect.width, rect.height, size,
			   1, 1, 0);
      gcv.clip_mask = mask;
      gc = XCreateGC(display, root, GCClipMask, &gcv);
    }
    else
      gc = XCreateGC(display, root, 0, 0);
  }
}

/*
 * GetDefLogo --
 *   Get default logo pixmap.
 */
static void GetDefLogo(Pixmap& pix, GC& gc, int size)
{
  if (size == 16) {
    pix = pixLogo;
    gc = gcLogo;
  }
  else if (size == 32) {
    pix = pixLargeLogo;
    gc = gcLargeLogo;
  }
}

/*
 * FixIconPixmap --
 *   Adjust icon pixmap size.
 */
static Pixmap FixIconPixmap(Pixmap origPix, unsigned int width,
			    unsigned int height, int size, unsigned int depth,
			    unsigned long fore, unsigned long back)
{
  XImage *srcImage, *destImage;
  char* data = new char[(size*size*depth)>>3];
  Point pt;
  unsigned long pixel;
  Pixmap pix;
  GC gc;

  srcImage = XGetImage(display, origPix, 0, 0, width, height, AllPlanes,
		       XYPixmap);
  destImage = XCreateImage(display, DefaultVisual(display, screen), depth,
			   XYPixmap, 0, data, size, size, 8, 0);

  for (int x = 0; x < size; x++) {
    pt.x = (int)((double)width / size * x);
    for (int y = 0; y < size; y++) {
      pt.y = (int)((double)height / size * y);

      pixel = XGetPixel(srcImage, pt.x, pt.y);
      XPutPixel(destImage, x, y, pixel ? fore : back);
    }
  }

  pix = XCreatePixmap(display, root, size, size, depth);
  gc = XCreateGC(display, pix, 0, 0);
  XPutImage(display, pix, gc, destImage, 0, 0, 0, 0, size, size);

  XFreeGC(display, gc);
  XDestroyImage(srcImage);
  XFree(destImage);
  delete [] data;

  return pix;
}

void Qvwm::SetStateProperty(int state)
{
  unsigned long data[2];
  
  ASSERT(tButton);

  data[0] = (unsigned long)state;
  data[1] = (unsigned long)tButton->GetFrameWin();
  
  XChangeProperty(display, wOrig, _XA_WM_STATE, _XA_WM_STATE, 32, 
		  PropModeReplace, (unsigned char *)data, 2);
}
