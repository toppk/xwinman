/***********************************************************
		Copyright IBM Corporation 1987

                      All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the name of IBM not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.  

IBM DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
IBM BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
******************************************************************/
/* $Header: defaultcursor.h,v 1.1 88/09/16 11:53:16 ajp Exp $ */
/* $ACIS:defaultcursor.h 1.5$ */
/* $Source: /afs/andrew.cmu.edu/itc/src/andrew/overhead/cwm/defaultcursor.h,v $ */

#if !defined(lint) && !defined(LOCORE) && defined(RCS_HDRS)
static char *rcsiddefaultcursor = "$Header: defaultcursor.h,v 1.1 88/09/16 11:53:16 ajp Exp $";
#endif

/*********************************************
Cambridge Window Manager
*********************************************/

/** DEFAULT cursor definition **/

#define defaultcursor_width 	32
#define defaultcursor_height    16

#ifdef VAX

#define defaultcursor_hotx      31
#define defaultcursor_hoty      3
#else
#define defaultcursor_hotx      1
#define defaultcursor_hoty      3

#endif

/**    DEFINITION     **/
/**

00@@------------------------------
01@/@@----------------------------
02@///@@@@@-----------------------
03@///////@-----------------------
04@//////@------------------------
05@////@@-------------------------
06@/////@@------------------------
07@//@///@@@----------------------
08@/@-@////@@@--------------------
09@/@--@/////@@@@-----------------
10@@@--@@///////@-----------------
11------@@/////@@-----------------
12-------@@///@@------------------
13--------@@/@@-------------------
14---------@@@--------------------
15--------------------------------

**/

/**  CODING INFORMATION  
 **
 **    IMAGE         MASK        RESULT
 **   
 **        0                    0               invisible
 **        1                    0               XOR
 **        0                    1               solid black
 **        1                    1               solid white
 **/


/**               MASK                          **/
/**
 00   1100 0000 0000 0000 0000 0000 0000 0000   C0000000  
 01   1111 0000 0000 0000 0000 0000 0000 0000   F0000000     
 02   1111 1111 1000 0000 0000 0000 0000 0000   FF800000   
 03   1111 1111 1000 0000 0000 0000 0000 0000   FF800000
 04   1111 1111 0000 0000 0000 0000 0000 0000   FF000000
 05   1111 1110 0000 0000 0000 0000 0000 0000   FE000000
 06   1111 1111 0000 0000 0000 0000 0000 0000   FF000000
 07   1111 1111 1100 0000 0000 0000 0000 0000   FFC00000
 08   1110 1111 1111 0000 0000 0000 0000 0000   EFF00000
 09   1110 0111 1111 1110 0000 0000 0000 0000   E7FE0000
 10   1110 0111 1111 1110 0000 0000 0000 0000   E7FE0000
 11   0000 0011 1111 1110 0000 0000 0000 0000   03FE0000
 12   0000 0001 1111 1100 0000 0000 0000 0000   01FC0000
 13   0000 0000 1111 1000 0000 0000 0000 0000   00F80000
 14   0000 0000 0111 0000 0000 0000 0000 0000   00700000
 15   0000 0000 0000 0000 0000 0000 0000 0000   00000000

**/


/**       IMAGE                                  **/        
/**
 00   1100 0000 0000 0000 0000 0000 0000 0000    C0000000
 01   1001 0000 0000 0000 0000 0000 0000 0000    90000000
 02   1000 1111 1000 0000 0000 0000 0000 0000    8F800000
 03   1000 0000 1000 0000 0000 0000 0000 0000    80800000
 04   1000 0001 0000 0000 0000 0000 0000 0000    81000000
 05   1000 0110 0000 0000 0000 0000 0000 0000    86000000
 06   1000 0011 0000 0000 0000 0000 0000 0000    83000000
 07   1001 0001 1100 0000 0000 0000 0000 0000    91C00000
 08   1010 1000 0111 0000 0000 0000 0000 0000    A8700000
 09   1010 0100 0001 1110 0000 0000 0000 0000    A41E0000
 10   1110 0110 0000 0010 0000 0000 0000 0000    E6020000
 11   0000 0011 0000 0110 0000 0000 0000 0000    03060000
 12   0000 0001 1000 1100 0000 0000 0000 0000    018C0000
 13   0000 0000 1101 1000 0000 0000 0000 0000    00D80000
 14   0000 0000 0111 0000 0000 0000 0000 0000    00700000
 15   0000 0000 0000 0000 0000 0000 0000 0000    00000000

 **/

#ifdef vax
static int defaultcursor_image[] = {
	0x00000003,
	0x00000009,
	0x000001F1,
	0x00000101,
	0x00000081,
	0x00000061,
	0x000000C1,
	0x00000389,
	0x00000E15,
	0x00007825,
	0x00004067,
	0x000060C0,
	0x00003180,
	0x00001B00,
	0x00000E00,
	0x00000000,
};
static int defaultcursor_mask[] = {
	0x00000003,
	0x0000000F,
	0x000001FF,
	0x000001FF,
	0x000000FF,
	0x0000007F,
	0x000000FF,
	0x000003FF,
	0x00000FF7,
	0x00007FE7,
	0x00007FE7,
	0x00007FC0,
	0x00003F80,
	0x00001F00,
	0x00000E00,
	0x00000000,
};
#else 

static int defaultcursor_mask[] = {
    0xC0000000, 
    0xF0000000,        
    0xFF800000, 
    0xFF800000,
    0xFF000000,
    0xFE000000,
    0xFF000000,
    0xFFC00000,
    0xEFF00000,
    0xE7FE0000,
    0xE7FE0000,
    0x03FE0000,
    0x01FC0000,
    0x00F80000,
    0x00700000,
    0x00000000};

static int defaultcursor_image[] = {
    0xC0000000,
    0x90000000,
    0x8F800000,
    0x80800000,
    0x81000000,
    0x86000000,
    0x83000000,
    0x91C00000,
    0xA8700000,
    0xA41E0000,
    0xE6020000,
    0x03060000,
    0x018C0000,
    0x00D80000,
    0x00700000,
    0x00000000};
#endif
