/***********************************************************
		Copyright IBM Corporation 1987

                      All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the name of IBM not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.  

IBM DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
IBM BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
******************************************************************/
/* $Header: window.c,v 1.2 88/09/16 15:58:16 ghoti Exp $ */
/* $ACIS:window.c 1.16$ */
/* $Source: /afs/andrew.cmu.edu/itc/src/andrew/overhead/cwm/RCS/window.c,v $ */

#ifndef lint
static char *rcsid = "$Header: window.c,v 1.2 88/09/16 15:58:16 ghoti Exp $";
#endif

/*********************************************
Cambridge Window Manager
*********************************************/
#include <stdio.h>
#include <sys/time.h>
#include <sys/resource.h>

#include <X11/Xlib.h>
#include <X11/X10.h>
#include <X11/Xutil.h>
#include "cmenu.h"

#include "window.h"
#include "cwm.h"
#include "display.h"

#define MAXCOLS 6
static struct SplitWindow *ColumnRoot[MAXCOLS];
static BorderStyle;
int BorderWidth;
int BlackEdgeWidth;
int ZapAll;
int UnmapByShrinking;
int ShowErrors;
static UnacceptablySmallWindowExists;
static AlwaysZoom;
static int ShrinkToColumn;
static int ShrinkToPosition;
char SnapShotDir[100];

struct SplitWindow  *MovingBar = 0;

#define W ((struct wmWindow *) w)
#define MIN(a,b) ((a)<(b)? (a) : (b))
#define MAX(a,b) ((a)>(b)? (a) : (b))

MoveSplit (w, new_x, new_y)
register struct SplitWindow *w;
register new_x, new_y;
{
    int gray = 0;

debug ( ("MoveSplit 0x%x x %d y %d \n", w, new_x, new_y) );

/* Do not try to process a split dragged to another display. */
    if (w->t.display != CursorDisplay)
        return;

    UnacceptablySmallWindowExists = 0;

    {
	register struct SplitWindow *ww;
	for (ww = w;  ww->t.type==SplitWindowType;  ww = ww->bottom) ;
	gray = ww->t.ViewPort.height;
    }

    if (gray>2 && w->t.type==SplitWindowType && w->t.column >= 0) {

	/* Users didn't seem to like window-blind mode */

	if (w->SplitHorizontally && w->top) {
	    ((struct wmWindow *)w->top)->Shrunk = 0;
	    AllocateColumnSpace(ColumnRoot[w->t.column], w->top,
		as_specified, fairly_by_height,
		MAX(0, new_y - w->t.ViewPort.top));
	} else if (w->top) {
	    AllocateColumnSpace(ColumnRoot[w->t.column], w->top,
		as_specified, fairly_by_height,
		MAX(0, new_x - w->t.ViewPort.left));
	}

    } else if (w -> t.type == SplitWindowType) {

	register xdelt, ydelt;
        struct wmWindow *above = (struct wmWindow *) w->top;
	struct wmWindow *below = (struct wmWindow *) w->bottom->top;

	if (w -> SplitHorizontally) {

	    int height = above->t.ViewPort.height
		+ (below? below->t.ViewPort.height : 0);
            char WindowNeedsAdjustment = 1;

	    xdelt = 0;
	    ydelt = new_y - w -> SplitValue;
	    if (-3 <= ydelt && ydelt <= 3)
		return;
	    {
		if (above->Shrunk && ydelt<=0) return;
		if (below && below->Shrunk && ydelt>=0) return;
		above->Shrunk = 0;
		if (below) below->Shrunk = 0;
	    }
/* The following code prevents column splits from being dragged over each
 *  other. There used to be fancy code here that tried to make room for the
 *  movement by deleteing the obstructing column. This had the annoying 
 *  effect of core-dumping the program.
 *  Now we just stop when we get too close. -zs
 */
	    if (
	       above->t.ViewPort.height + ydelt < MinWindowHeight)
                if (w->t.column == -1) { /* A column split */
                    ydelt = MinWindowHeight - above->t.ViewPort.height;
                    new_y = w -> SplitValue + ydelt;
                    if (below && below->t.ViewPort.height - ydelt < MinWindowHeight)
                        return;
		}
		else {
                    if (ShrinkWindow(above))
		        height -= above->t.ViewPort.height;
		    else
		        DeleteWindow(above);
		    if (below) AllocateColumnSpace(ColumnRoot[w->t.column], below,
		        as_specified, fairly_by_height, height);
                    WindowNeedsAdjustment = 0;
		}
	    else if (below
	      && below->t.ViewPort.height - ydelt < MinWindowHeight)
                if (w->t.column == -1) { /* A column split */
                    ydelt = below->t.ViewPort.height - MinWindowHeight;
                    new_y = w -> SplitValue + ydelt;
	            if (above->t.ViewPort.height + ydelt < MinWindowHeight)
		        return;
		}
                else {
                    if (ShrinkWindow(below))
		        height -= below->t.ViewPort.height;
		    else
		        DeleteWindow(below);
		    AllocateColumnSpace(ColumnRoot[w->t.column], above,
		        as_specified, fairly_by_height, height);

                    WindowNeedsAdjustment = 0;
		}
            if (WindowNeedsAdjustment) {
                w -> SplitValue = new_y;
	        AdjustWindow (w -> top, 0, 0, xdelt, ydelt);
	        AdjustWindow (w -> bottom, xdelt, ydelt, -xdelt, -ydelt);
	    }
	}
	else {
	    xdelt = new_x - w -> SplitValue;
	    ydelt = 0;
	    if (-3 <= xdelt && xdelt <= 3)
		return;
            if (w->t.column == -1
	      && above->t.ViewPort.width + xdelt <= MinWindowWidth) {
                xdelt = MinWindowWidth - above->t.ViewPort.width;
                new_x = w -> SplitValue + xdelt;
                if (above->t.ViewPort.width + xdelt < MinWindowWidth)
		    return;
	    }
	    else if (w->t.column == -1 && below
	      && below->t.ViewPort.width - xdelt <= MinWindowWidth) {
                xdelt = below->t.ViewPort.width - MinWindowWidth;
                new_x = w -> SplitValue + xdelt;
		if (above->t.ViewPort.width + xdelt < MinWindowWidth)
		    return;
	    }
	    w -> SplitValue = new_x;
	    AdjustWindow (w -> top, 0, 0, xdelt, ydelt);
	    AdjustWindow (w -> bottom, xdelt, ydelt, -xdelt, -ydelt);
	}
    }

    while (UnacceptablySmallWindowExists) {
	register i;
	UnacceptablySmallWindowExists = 0;
	for (i = 0; i < NDisplays; i++)
	    DeleteNegativeWindow (wmRootWindow[i]);
    }

nodebug ( ("MoveSplit returning \n") );
}


static
DeleteNegativeWindow (w)
register struct SplitWindow *w; {

debug ( ("DeleteNegativeWindow 0x%x \n", w) );
    if (!w)
        return (0);
    if (!w -> t.deleted
	&& (w -> t.ViewPort.width < MinWindowWidth
	    || (w -> t.ViewPort.height < MinWindowHeight
		&& !(w->t.type==WindowType && ((struct wmWindow *)w)->Shrunk)))
	/* in column mode, split windows should not be deleted! */
	&& !(w->t.type==SplitWindowType)
    ) {
	DeleteWindow (w);
	UnacceptablySmallWindowExists = 1;
	return 1;
    }
    if (w -> t.type == SplitWindowType)
	return DeleteNegativeWindow (w -> top)
	    || DeleteNegativeWindow (w -> bottom);

    debug ( ("DeleteNeagtiveWindow returning \n") );

    return 0;
}


/*
 * Allocate and initialize from init a new struct EmptyWindow
 */

struct EmptyWindow *
NewEmptyWindow(init)
register struct TypedObject *init;
{
    register struct EmptyWindow *w =
	(struct EmptyWindow *) malloc(sizeof(struct EmptyWindow));
    w->t.type = EmptyWindowType;
    w->t.deleted = 0;
    w->t.ViewPort = init->ViewPort;
    w->t.parent = init->parent;
    w->t.display = init->display;
    w->t.column = init->column;

    {
    Window ew;
    struct wqe *wqe;
    Visual visual;
    XSetWindowAttributes xswa;
    int top = w -> t.ViewPort.top + BorderWidth;
    int left =  w -> t.ViewPort.left + BorderWidth;
    int width =  w -> t.ViewPort.width - 2*BorderWidth;
    int height =  w -> t.ViewPort.height - 2*BorderWidth;

    /* Create an InputOnly window for this empty window */
    xswa.event_mask = (EnterWindowMask | LeaveWindowMask | BUTTONS);
    visual.visualid = CopyFromParent;

#ifdef EMPTYVISIBLE
    /* DBB
    This option does not affect the functioning of the window manager.
    It makes the normally invisible empty windows visible (black).
    */
    xswa.background_pixel = BLACKPIXEL;
    xswa.border_pixel = WHITEPIXEL;
    ew = XCreateWindow (XDisplay, XRoot, left, top, width, height, 0, 0,
	InputOutput, &visual, CWEventMask | CWBackPixel | CWBorderPixel, &xswa);
#else
    ew = XCreateWindow (XDisplay, XRoot, left, top, width, height, 0, 0,
	InputOnly, &visual, CWEventMask, &xswa);
#endif EMPTYVISIBLE

    if (!ew)
	cwmError (1, "Can't create empty window \n");

    XStoreName ( XDisplay, ew, "cwm Empty window");

    debug ( ("Empty Window for 0x%x is 0x%x \n", w, ew) );
    debug ( ("0x%x l %d t %d w %d h %d \n", ew, left, top, width, height) );
 
    w->xWindow = ew;

    wqe = (struct wqe *) malloc (sizeof (struct wqe) );
    if (!wqe)
	cwmError (1, "Can't allocate a window queue element \n");
    memdebug ( ("MALLOC wqe 0x%x %d bytes \n", wqe, sizeof (struct wqe) ) );

    wqe->client = ew;
    wqe->client_wm = (struct wmWindow *) w;
    wqe->titlebar = NULL;

    /* Map it */
    XMapWindow (XDisplay, ew);
    debug ( ("Window 0x%x (empty window) mapped \n", ew ) );

    /* Add it to the window queue */
    XMakeAssoc (XDisplay, windowinfo, ew, (char *) wqe );

    insque (wqe, wqhead);
    }

    return w;
}



ShrinkWindow(w)
struct wmWindow *w;
{
    debug ( ("Shrink Window 0x%x \n", w) );

    if (!w || w->t.type!=WindowType
      || w->Shrunk || !w->t.parent || w->t.deleted || !w->Visible
      || !w->t.parent->SplitHorizontally)
	return 0;

    w->original_column = w->t.column;

    if (ShrinkToColumn < 0 && ShrinkToPosition < 0) {
	/* There is a copy of the folowing lines in PutWindowInColumn. */
	w->Shrunk = 1;
	AllocateColumnSpace(ColumnRoot[w->t.column], w, as_specified,
	    fairly_by_height, w->ModeViewPort.height+2*BorderWidth);
    } else {
	register struct SplitWindow *c =
	    ColumnRoot[ (ShrinkToColumn<0 ? w->t.column: ShrinkToColumn) ];
	register int i;
	DeleteWindowFromColumn(w);
	if (ShrinkToColumn >= 0)
	    w->t.column = ShrinkToColumn;
	w->Shrunk = 1;
	for (i=0; i<ShrinkToPosition && c->top; i++, c=c->bottom);
	while (c->top && ((struct wmWindow *)c->top)->Shrunk) c = c->bottom;
	PutWindowInColumn(w, c->top, at_least_min);
    }
    nodebug ( ("cwm not sending H to process \n") );
    nodebug ( ("ShrinkWindow returning \n") );
    return 1;
}



DeleteWindow (w)
register struct SplitWindow *w; {
    register struct SplitWindow *p, *other, *ww;

    debug ( ("DeleteWindow 0x%x \n", w) );

    if (w && !w -> t.deleted) {
	register    MyWidth = w -> t.ViewPort.width;
	register    MyHeight = w -> t.ViewPort.height;
	int     Visible = 1;
	w -> t.deleted = 1;
	switch (w -> t.type) {
	    case SplitWindowType:
		debug(("Tried to delete SplitWindow in ColumnMode!\n"));
		w->t.deleted = 0;
		return;
	    case EmptyWindowType:
		break;
	    case WindowType:
		if (W -> SubProcess > 0)

		/* DBB
		 * pass a pointer to the window itself
		 * to avoid a reference to WindowChannel
		 */
		    HideProcess (W);

		if (W == WindowInFocus) GiveUpInputFocus ();
		Visible = W -> Visible;
		W -> Visible = 0;
		break;
	}
	if (Visible) {
	    register i;

	    for (i = 0; i < NDisplays && wmRootWindow[i] != w; i++) ;
	    if (i < NDisplays) {
		wmRootWindow[i] = 0;
		if (! Shutdown)  {
 		    /* should we save CurrentDisplay and CurrentViewPort?  -bl */
 		    if (CurrentDisplay != &displays[i]) {
 			CurrentDisplay = &displays[i];
 			display = *CurrentDisplay;
 		    }
		    CurrentClipRectangle = CurrentViewPort = &display.screen;
		    /* is this select color ok? -bl */

		    debug ( ("cwm Not clearing the screen \n") );
		}
		return;
	    }
	    if ((p = w -> t.parent) == 0) {
		debug (("Orphan window!  (%s)\n", W -> name));
		return;
	    } else
		if (p -> t.deleted)   /* why? -bl */
		    return;
 
	    if (w->t.type == WindowType) {

		DeleteWindowFromColumn(w);

	    } else if (w->t.type != EmptyWindowType) {

		if (p -> top == w)
		    if (p -> SplitHorizontally)
			AdjustWindow (other = p -> bottom, 0, -MyHeight, 0, MyHeight);
		    else
			AdjustWindow (other = p -> bottom, -MyWidth, 0, MyWidth, 0);
		else
		    if (p -> SplitHorizontally)
			AdjustWindow (other = p -> top, 0, 0, 0, MyHeight);
		    else
			AdjustWindow (other = p -> top, 0, 0, MyWidth, 0);

		/* w is dead,  p is parent,  other is still alive */
		ww = p;
		if (p = p -> t.parent)
		    if (p -> top == ww)
			p -> top = other;
		    else
			p -> bottom = other;
		else {
		    for (i = 0; i < NDisplays && wmRootWindow[i] != ww; i++);
		    if (i < NDisplays)
			wmRootWindow[i] = other;
		    else
			debug (("Window not in root list!\n"));
		}
		other -> t.parent = p;
	    }

	    if (w -> t.type == SplitWindowType /* || w->t.type == EmptyWindowType - LATER */) {
		/*  This free() pairs with the mallocs() in SplitWindow() */
	        free (w);
	    }

	}
    }

nodebug ( ("DeleteWindow returning \n") );
}


#define pSW (struct SplitWindow *) 
#define pWW (struct wmWindow *)
#define SW ((struct SplitWindow *) w)

AdjustWindow (w, Dl, Dt, Dw, Dh)
register struct wmWindow *w; {

    debug ( ("AdjustWindow 0x%x l %d t %d w %d h %d \n", w, Dl, Dt, Dw, Dh) );

    if (!w)
	return;
    if (w -> t.type == WindowType || w -> t.type == EmptyWindowType)
	SetWindowSize (w,
		w -> t.ViewPort.left + Dl,
		w -> t.ViewPort.top + Dt,
		w -> t.ViewPort.width + Dw,
		w -> t.ViewPort.height + Dh);
    else {
	w -> t.ViewPort.top += Dt;
	w -> t.ViewPort.left += Dl;
	w -> t.ViewPort.width += Dw;
	w -> t.ViewPort.height += Dh;

	/* this can happen when column boundary is moved */
	if (SW->t.column>=0 && ColumnRoot[SW->t.column]==SW && SW->top &&
	  (SW->SplitHorizontally? Dh : Dw) )
	    AllocateColumnSpace(SW, 0, 0, fairly_by_height, 0);

	/* added !SW->bottom, etc.: somebody has to make an adjustment!  -bl */
	/* this eliminates possiblility of negative NIL windows (I hope) */
	else if (SW -> SplitHorizontally) {
	    if (Dt || Dw || !SW->bottom)
		AdjustWindow (pWW(SW -> top), Dl, Dt, Dw, Dh);
	    if (!Dt || Dw || !SW->top)
		AdjustWindow (pWW(SW -> bottom), Dl, Dt, Dw, Dh);
	    if (!SW->bottom)
		SW->SplitValue = w->t.ViewPort.top + w->t.ViewPort.height;
	    if (!SW->top)
		SW->SplitValue = w->t.ViewPort.top;
	}
	else {
	    if (Dl || Dh || !SW->bottom)
		AdjustWindow (pWW(SW -> top), Dl, Dt, Dw, Dh);
	    if (!Dl || Dh || !SW->top)
		AdjustWindow (pWW(SW -> bottom), Dl, Dt, Dw, Dh);
	    if (!SW->bottom)
		SW->SplitValue = w->t.ViewPort.left + w->t.ViewPort.width;
	    if (!SW->top)
		SW->SplitValue = w->t.ViewPort.left;
	}
    }

nodebug ( ("AdjustWindow returning \n") );
}


SetWindowSize (p, l, t, w, h)
register struct wmWindow *p; {
    debug ( ("SetWindowSize 0x%x l %d t %d w %d h %d \n", p, l, t, w, h) );

    switch (p -> t.type) {
	case WindowType: 
	    debug ( ("WindowType \n") );

	    /* Don't bother if being destroyed */
	    if ( Destroyee && (p == Destroyee->client_wm) )
		{
		debug ( ("Not configuring Destroyee \n") );
		return;
		}

	    if (p -> t.ViewPort.top != t ||
		    p -> t.ViewPort.left != l ||
		    p -> t.ViewPort.width != w ||
		    p -> t.ViewPort.height != h) {
		p -> t.ViewPort.top = t;
		p -> t.ViewPort.left = l;
		p -> t.ViewPort.width = w;
		p -> t.ViewPort.height = h;
		if ((w < MinWindowWidth || h < MinWindowHeight) && !p->Shrunk)
		    UnacceptablySmallWindowExists = 1;

		p -> ModeViewPort.top = t + BorderWidth;
		p -> ModeViewPort.left = l + BorderWidth;
		p -> ModeViewPort.width = w - 2*(BorderWidth + BlackEdgeWidth);
		p -> ModeViewPort.height = TitlebarHeight; 

		p -> SubViewPort.top = t + TitlebarHeight + BorderWidth + BlackEdgeWidth;
		p -> SubViewPort.left = l + BorderWidth;
		p -> SubViewPort.width = w - 2*(BorderWidth + BlackEdgeWidth);
		p -> SubViewPort.height = h - (TitlebarHeight + 2*BorderWidth + 3*BlackEdgeWidth);

		p -> ClipRectangle = p -> SubViewPort;

		/* Reconfigure the client and title bar here */
		{
		Window client = p -> SubProcess;
		Window titlebar = p -> TitleBar;
		XWindowChanges wc;

		/* If the window is being shrunk - 
		   make it very short and place it off screen. */

		if ((p ->SubViewPort.height < 0) ||
			(p->SubViewPort.width < 0)) {

		    wc.x = p ->ModeViewPort.left;
		    wc.y = p ->ModeViewPort.top + ScreenHeight;
		    wc.width = p ->ModeViewPort.width;
		    wc.height = /* p ->ModeViewPort.height >> */ 1;
		    wc.stack_mode = Below;
		    p->ShrunkUnder = 1;

		} else {
		    wc.x = p ->SubViewPort.left;
		    wc.y = p ->SubViewPort.top;
		    wc.width = p ->SubViewPort.width;
		    wc.height = p ->SubViewPort.height;
		    wc.stack_mode = Above;
		    p->ShrunkUnder = 0;
		}

		debug ( ("Configure client 0x%x l %d t %d w %d h %d \n", client,
			wc.x, wc.y,
			wc.width, wc.height ) );


		XConfigureWindow (XDisplay, client, 
				CWX | CWY | CWWidth | CWHeight | CWStackMode, 
				&wc);

		debug ( ("Configure titlebar 0x%x l %d t %d w %d h %d \n", titlebar,
			p -> ModeViewPort.left, p ->ModeViewPort.top,
			p -> ModeViewPort.width, p -> ModeViewPort.height) );

		wc.x = p ->ModeViewPort.left;
		wc.y = p ->ModeViewPort.top;
		wc.width = p ->ModeViewPort.width;
		wc.height = p ->ModeViewPort.height;
		wc.stack_mode = Above;

		XConfigureWindow (XDisplay, titlebar,
				CWX | CWY | CWWidth | CWHeight | CWStackMode, 
				&wc);

		}
		
	    }
	    break;
	case EmptyWindowType:
	    debug ( ("EmptyWindowType \n") );
	    if (p -> t.ViewPort.top != t ||
		    p -> t.ViewPort.left != l ||
		    p -> t.ViewPort.width != w ||
		    p -> t.ViewPort.height != h) {
		p -> t.ViewPort.top = t;
		p -> t.ViewPort.left = l;
		p -> t.ViewPort.width = w;
		p -> t.ViewPort.height = h;

		/* Reconfigure the X Window here */
		{
		Window ew = ( (struct EmptyWindow *) p)->xWindow;
		int top = t + BorderWidth;
		int left = l + BorderWidth;
		int width = w - 2*BorderWidth;
		int height = h - 2*BorderWidth;
		XWindowChanges ewc;

		debug ( ("Configure empty 0x%x l %d t %d w %d h %d \n", ew,
			left, top, width, height) );

		ewc.x = left;
		ewc.y = top;
		ewc.width = width;
		ewc.height = height;

		if (height < 0)
			{
			debug ( ("resetting negative height to 1 \n") );
			ewc.height = 1;
			}

		/* DBB isn't X fun? */
		ewc.stack_mode = (height < 0) ? Below : Above;

		XConfigureWindow (XDisplay, ew, 
				CWX | CWY | CWWidth | CWHeight | CWStackMode, 
				&ewc);
		}
	    }
	    break;
    }
nodebug ( ("SetWindowSize returning \n") );
}

AllocateWindow (p, l, t, w, h)
register struct wmWindow *p; {

    nodebug ( ("AllocateWindow 0x%x l %d t %d w %d h %d \n", p, l, t, w, h) );

    p -> t.type = WindowType;
    p -> t.parent = 0;
    p -> Visible = 1;
    p -> t.display = 0;
    SetWindowSize (p, l, t, w, h);
    p -> t.deleted = 0;

nodebug ( ("AllocateWindow returning \n") );
}

/*
 *  p is the new window,  w is the window to split.
 *  creates a new SplitWindow,  and links the two to it
 */

SplitWindow (w, pos, horizontal, p)
register struct wmWindow *w, *p; {
    register struct SplitWindow *up;
    int     cutabove = horizontal & 2;

    nodebug ( ("SplitWindow 0x%x for 0x%x position %d horizontal %s \n", w, p, pos, YorN(horizontal) ) );

    if (w->t.type == EmptyWindowType) {
	register struct SplitWindow *up = w->t.parent;
	AllocateWindow(p, w->t.ViewPort.left, w->t.ViewPort.top,
	    w->t.ViewPort.width, w->t.ViewPort.height);
        if (up) {
	    if (up->bottom == (struct SplitWindow *) w)
		up->bottom = (struct SplitWindow *) p;
	    else
		up->top = (struct SplitWindow *) p;
	} else {
	    register int i;
	    for (i = 0; i < NDisplays && wmRootWindow[i] != (struct SplitWindow *) w; i++);
	    if (i < NDisplays)
		wmRootWindow[i] = (struct SplitWindow *) p;
	    else
		debug (("Can't find root pointer in split (replace)\n"));
	}
	p->t.parent = up;
	p->t.display = w->t.display;
	free(w);
	return 1;
    }

    horizontal &= 1;
    up = (struct SplitWindow *) malloc(sizeof (struct SplitWindow));
    up -> t.ViewPort = w -> t.ViewPort;
    if (horizontal) {
	if (pos <= w -> t.ViewPort.top)
	    return 0;
	if (cutabove) {
	    AllocateWindow (p, w -> t.ViewPort.left, w -> t.ViewPort.top, w -> t.ViewPort.width,
		    pos - w -> t.ViewPort.top);
	    AdjustWindow (w, 0, p -> t.ViewPort.height, 0, -p -> t.ViewPort.height);
	}
	else {
	    AllocateWindow (p, w -> t.ViewPort.left, pos, w -> t.ViewPort.width,
		    w -> t.ViewPort.top + w -> t.ViewPort.height - pos);
	    AdjustWindow (w, 0, 0, 0, -p -> t.ViewPort.height);
	}
    }
    else {
	if (pos <= w -> t.ViewPort.left)
	    return 0;
	if (cutabove) {
	    AllocateWindow (p, w -> t.ViewPort.left, w -> t.ViewPort.top,
		    pos - w -> t.ViewPort.left, w -> t.ViewPort.height);
	    AdjustWindow (w, p -> t.ViewPort.width, 0, -p -> t.ViewPort.width, 0);
	}
	else {
	    AllocateWindow (p, pos, w -> t.ViewPort.top,
		    w -> t.ViewPort.left + w -> t.ViewPort.width - pos, w -> t.ViewPort.height);
	    AdjustWindow (w, 0, 0, -p -> t.ViewPort.width, 0);
	}
    }
    up -> t.type = SplitWindowType;
    up -> t.deleted = 0;
    up -> SplitValue = pos;
    up -> SplitHorizontally = horizontal;
    up -> t.parent = w -> t.parent;
    w -> t.parent = p -> t.parent = up;
    up -> t.display = p -> t.display = w -> t.display;
    if (cutabove) {
	up -> top = (struct SplitWindow *) p;
	up -> bottom = (struct SplitWindow *) w;
    }
    else {
	up -> top = (struct SplitWindow *) w;
	up -> bottom = (struct SplitWindow *) p;
    }
    if (up -> t.parent)
	if (up -> t.parent -> top == (struct SplitWindow   *) w)
	                                                        up -> t.parent -> top = up;
	else
	    up -> t.parent -> bottom = up;
    else {
	register    i;
	for (i = 0; i < NDisplays && wmRootWindow[i] != (struct SplitWindow *) w; i++);
	if (i < NDisplays)
	    wmRootWindow[i] = up;
	else
	    debug (("Can't find root pointer in split\n"));
    }
    while (UnacceptablySmallWindowExists) {
	register    i;
	for (i = 0; i < NDisplays; i++)
	    DeleteNegativeWindow (wmRootWindow[i]);
	UnacceptablySmallWindowExists = 0;
    }
    nodebug ( ("SplitWindow returning \n") );

    return 1;
}



PrintWindowStructure (w, depth)
register struct SplitWindow *w; {
#ifdef DEBUG
    if (!depth)
	debug ( ("\n===== PrintWindowStructure =====\n") );
    debug (("%*s", depth * 4, ""));
    if (w == 0)
	debug (("  NIL\n"));
    else {
	debug (("%c %8xa %8xp %3dx %3dy %3dw %3dh",
		w -> t.type != SplitWindowType ? ' '
		: w -> SplitHorizontally ? '-' : '|',
		w, w->t.parent,
		w -> t.ViewPort.left,
		w -> t.ViewPort.top,
		w -> t.ViewPort.width,
		w -> t.ViewPort.height));
	if (w -> t.type == SplitWindowType) {
	    debug ((" %3ds", w -> SplitValue));
	}
	else if (w->t.type == WindowType) {
/*
	    debug ((" %3dbx %3dby",
		    W -> SubViewPort.left, W -> SubViewPort.top));
*/
	    debug ((" %6xc %6xtb", W->SubProcess, W->TitleBar));
	}
	else if (w->t.type == EmptyWindowType) {
	    debug ((" empty"));
	}
	debug (("\n"));
	if (w -> t.type == SplitWindowType) {
	    PrintWindowStructure (w -> top, depth + 1);
	    PrintWindowStructure (w -> bottom, depth + 1);
	}
    }
    if (!depth)
	debug ( ("===== PrintWindowStructure =====\n\n") );
#endif DEBUG
}


static struct zoomBoxLine {
    short x1,y1,x2,y2;
} zoomBox[4];

#define zoomSteps 30
#define zoomWidth 3

static DrawZoomBoxLine(p1,p2,scale)
register struct zoomBoxLine *p1,*p2;
register    scale; {

XDrawLine (XDisplay, XRoot, invertGC,
	p1->x1 + (p1->x2 - p1->x1) * scale / zoomSteps,
	p1->y1 + (p1->y2 - p1->y1) * scale / zoomSteps,
	p2->x1 + (p2->x2 - p2->x1) * scale / zoomSteps,
	p2->y1 + (p2->y2 - p2->y1) * scale / zoomSteps);
}

static DrawZoomBox(scale) {
    DrawZoomBoxLine (&zoomBox[0], &zoomBox[1], scale);
    DrawZoomBoxLine (&zoomBox[1], &zoomBox[2], scale);
    DrawZoomBoxLine (&zoomBox[2], &zoomBox[3], scale);
    DrawZoomBoxLine (&zoomBox[3], &zoomBox[0], scale);
}


CreateWindow (w)
register struct wmWindow *w;
{

    nodebug ( ("CreateWindow 0x%x \n", w) );

    PutWindowInColumn(w, NULL, at_least_min);

    if (zoomY > 0 || AlwaysZoom) {
	register struct ViewPort   *ovp = CurrentViewPort,
				   *ocr = CurrentClipRectangle;
	register    i;
	if (CurrentDisplay != w -> t.display) {
	    if (w -> t.display == 0) {
		debug (("Null display pointer in window %s\n", w -> name));
		return;
	    }
	    CurrentDisplay = w -> t.display;
	    display = *CurrentDisplay;
	}
	CurrentClipRectangle = CurrentViewPort = &display.screen;

	if (zoomY <= 0) {
	    zoomX = w -> t.ViewPort.left + (w -> t.ViewPort.width>>1);
	    zoomY = w -> t.ViewPort.top + (w -> t.ViewPort.height>>1);
	    zoomW = zoomH = 0;
	}
	zoomBox[0].x1 = zoomX;
	zoomBox[0].y1 = zoomY;
	zoomBox[0].x2 = w -> t.ViewPort.left;
	zoomBox[0].y2 = w -> t.ViewPort.top;
	zoomBox[1].x1 = zoomX + zoomW;
	zoomBox[1].y1 = zoomY;
	zoomBox[1].x2 = w -> t.ViewPort.left + w -> t.ViewPort.width;
	zoomBox[1].y2 = w -> t.ViewPort.top;
	zoomBox[2].x1 = zoomX + zoomW;
	zoomBox[2].y1 = zoomY + zoomH;
	zoomBox[2].x2 = w -> t.ViewPort.left + w -> t.ViewPort.width;
	zoomBox[2].y2 = w -> t.ViewPort.top + w -> t.ViewPort.height;
	zoomBox[3].x1 = zoomX;
	zoomBox[3].y1 = zoomY + zoomH;
	zoomBox[3].x2 = w -> t.ViewPort.left;
	zoomBox[3].y2 = w -> t.ViewPort.top + w -> t.ViewPort.height;
	for (i = 0; i <= zoomSteps; i++) {
	    DrawZoomBox (i);
	    if (i >= zoomWidth)
		DrawZoomBox (i - zoomWidth);
	}
	i -= zoomWidth;
	while (i <= zoomSteps)
	    DrawZoomBox (i++);
	CurrentViewPort = ovp;  CurrentClipRectangle = ocr;
    }

nodebug ( ("CreateWindow returning \n") );
}


#define Indent 2
#define VerticalAdjust 1

DrawModeLine (w)
register struct wmWindow *w;
{

register struct ViewPort   *ovp = CurrentViewPort, *ocr = CurrentClipRectangle;
int xo = Indent;
int yo = ModeFont->max_bounds.ascent + VerticalAdjust;

int NameWidth = XTextWidth (ModeFont, w->name, strlen (w->name));
int LeftSpace = ((w->ModeViewPort.width - NameWidth) >> 1) - (Indent<<1);
int HostWidth = XTextWidth (ModeFont, w->hostname, strlen (w->hostname));
int ProgWidth = w->ProgramName[0] ?
	XTextWidth (ModeFont, w->ProgramName, strlen (w->ProgramName))
	: 999999;

/*
debug ( ("DrawModeLine w 0x%x \n", w) );
debug ( ("xo %d yo %d \n", xo, yo) );
debug ( ("Name <%s> ProgName <%s> Host <%s> \n",
	w->name, w->ProgramName, w->hostname) );
debug ( ("LeftSpace %d HostWidth %d ProgWidth %d \n",
	LeftSpace, HostWidth, ProgWidth) );
*/

CurrentClipRectangle = CurrentViewPort = &w->ModeViewPort;
if (EmphasizedWindow ==  w /*&& BorderStyle == 0*/)
	EmphasizedWindow = 0;

XClearWindow (XDisplay, w->TitleBar);

if (LeftSpace > ProgWidth)
	XDrawString (XDisplay, w->TitleBar, blackGC,
		xo, yo, w->ProgramName, strlen (w->ProgramName) );

XDrawString (XDisplay, w->TitleBar, blackGC,
	xo+LeftSpace+Indent, yo, w->name, strlen (w->name) );

if (LeftSpace - xo > HostWidth)
	XDrawString (XDisplay, w->TitleBar, blackGC, w->ModeViewPort.width - HostWidth - Indent,
		yo, w->hostname, strlen (w->hostname) );

CurrentViewPort = ovp;  CurrentClipRectangle = ocr;

if (WindowInFocus == w)
	SetInputFocus (w);
}

FlipEmphasis (w)
register struct wmWindow *w; {

nodebug ( ("FlipEmphasis w 0x%x \n", w) );

if (w && w -> Visible) {

	register struct ViewPort   *ovp = CurrentViewPort,
				   *ocr = CurrentClipRectangle;
	if (CurrentDisplay != w -> t.display) {
	if (w -> t.display == 0) {
		debug (("Null display pointer in window %s\n", w -> name));
		return;
	}
	CurrentDisplay = w -> t.display;
	display = *CurrentDisplay;
	}

	CurrentClipRectangle = CurrentViewPort = &w -> ModeViewPort;

	XFillRectangle (XDisplay, w->TitleBar, invertGC,
		0, 0, w ->ModeViewPort.width, w ->ModeViewPort.height);
	CurrentViewPort = ovp;  CurrentClipRectangle = ocr;
}
}

#define FocusStackSize 10
static struct wmWindow *FocusStack[FocusStackSize];
static int FocusStackFill;

SetInputFocus (w)
register struct wmWindow *w; {
    if (w && w -> Visible) {
	register struct display *OldDisplay = CurrentDisplay;
	if (w != EmphasizedWindow) {
	    debug ( ("SetInputFocus 0x%x \n", w->SubProcess) );
	    XSetInputFocus (XDisplay, w->SubProcess, RevertToNone, CurrentTime);

	    if (EmphasizedWindow)
		FlipEmphasis (EmphasizedWindow);
	    FlipEmphasis (w);
	    EmphasizedWindow = w;

	}
	if (WindowInFocus != w) {
	    FocusStack[FocusStackFill++] = WindowInFocus;
	    if (FocusStackFill >= FocusStackSize)
		FocusStackFill = 0;

/* DBB
	    if (WindowInFocus)
		setpriority(PRIO_PGRP, WindowInFocus->pgrp, 0);
*/
	    WindowInFocus = w;
/* DBB
	    if (WindowInFocus)
		setpriority(PRIO_PGRP, WindowInFocus->pgrp, -10);
*/
	}
	if (CurrentDisplay != OldDisplay) {
	    CurrentDisplay = OldDisplay;
	    display = *CurrentDisplay;
	}
    }
}

GiveUpInputFocus () {
    register struct wmWindow *w;
    register struct wqe *wqe;
    register    n = FocusStackSize;
    /* TAG 11/11/87 */
    CursorWindow = 0;
    while (--n >= 0) {
	if (--FocusStackFill < 0)
	    FocusStackFill = FocusStackSize - 1;
	if (w = FocusStack[FocusStackFill]) {
	    FocusStack[FocusStackFill] = 0;
	    if (w != WindowInFocus && w -> Visible) {
		SetInputFocus (w);
		return;
	    }
	}
    }

    for (wqe = wqhead->prev; wqe != wqhead; wqe = wqe->prev)
	{
	w = wqe->client_wm;
	if (w ->t.type == WindowType && w -> Visible)
		{
		SetInputFocus (w);
		return;
		}
	}
}


/*
 * malloc and initialize a new SplitWindow
 */

struct SplitWindow *
NewSplitWindow()
{
    register struct SplitWindow *new =
	(struct SplitWindow *) calloc (1, sizeof(struct SplitWindow));
    new->t.type = SplitWindowType;
    new->t.column = -1;
    return(new);
}


/*
 * wm.Columns:  (h  %40 (v  %10 (h 1) %90 (v 2))  %60 (v 3))
 * wm.Columns:  h  %50 (v 1) %50 (v 2)
 *
 * list		mode spec [ spec ... ]
 * mode		"h" | "v"
 * spec		%n (mode node)
 * node		spec-list | name
 *
 * Below left: a column with two windows, w1 and w2; S is a SplitWindow, E
 * is an EmptyWindow.  Below right: column with no windows.  Left link "/"
 * is ->top; right link "\" is ->bottom.
 *
 *		S		S
 *	       / \	       / \
 *	      w1  S	     NIL  E
 *		 / \
 *		w2  S
 *		   / \
 *		 NIL  E
 */

#define SKIP(s) {while (*s==' ') s++;}

static
struct SplitWindow *
CreateColumns(sp, display, vp)
char **sp;
struct ViewPort vp;
struct display *display;
{
    char *s = *sp, mode;
    struct SplitWindow *root = 0;

    SKIP(s);
    if (*s=='(') s++;
    SKIP(s);
    mode = *s++;
    SKIP(s);
    if (*s=='%') {
	struct SplitWindow *up = 0, *new;
	struct ViewPort subvp, newvp;
	newvp = vp;
	while (*s++ == '%') {
	    int pct = 0;
	    new = NewSplitWindow();
	    while ('0'<=*s && *s<='9')
		pct = 10*pct + *s++ - '0';
	    SKIP(s);
	    new->t.parent = up;
	    new->t.ViewPort = newvp;
	    new->t.display = display;
	    subvp = newvp;
	    if (mode=='h') {
		subvp.width = 1 + vp.width*pct/100;
		if (subvp.left + subvp.width > vp.left + vp.width)
		    subvp.width = vp.left + vp.width - subvp.left;
		new->top = CreateColumns(&s, display, subvp);
		new->SplitHorizontally = 0;
		new->SplitValue = newvp.left + subvp.width;
		newvp.width -= subvp.width;
		newvp.left += subvp.width;
	    } else {
		subvp.height = 1 + vp.height*pct/100;
		if (subvp.top + subvp.height > vp.top + vp.height)
		    subvp.height = vp.top + vp.height - subvp.top;
		new->top = CreateColumns(&s, display, subvp);
		new->SplitHorizontally = 1;
		new->SplitValue = newvp.top + subvp.height;
		newvp.height -= subvp.height;
		newvp.top += subvp.height;
	    }
	    if (up) up->bottom = new;
	    else root = new;
	    new->top->t.parent = new;
	    up = new;
	    SKIP(s);
	}
	/*
	 * new->bottom is NIL; so move new->top up and free new
	 */
	if (new->t.parent)
	    (new->t.parent->bottom = new->top) -> t.parent = new->t.parent;
	else
	    root = new->top;
	free(new);
    } else if ('0'<=*s && *s<='9') {
	struct SplitWindow *new = NewSplitWindow();
	int column = *s - '0';
	new->t.ViewPort = vp;
	new->t.display = display;
	new->t.column = column;
	new->bottom /*top*/ = (struct SplitWindow *)
	    NewEmptyWindow(&new->t);
	if (mode=='h') {
	    new->SplitValue = vp.left /* + vp.width*/;
	    new->SplitHorizontally = 0;
	} else {
	    new->SplitValue = vp.top /* + vp.height*/;
	    new->SplitHorizontally = 1;
	}
	ColumnRoot[column] = root = new;
	new-> bottom /*top*/ ->t.parent = new;
	SKIP(s);
    } else {
    }
    while (*s && *s != ' ' && *s != ')') s++;
    SKIP(s);
    if (*s==')') s++;
    SKIP(s);
    *sp = s;
    return root;
}
	    
	    
/*
 * Put "w" above window "before".
 * If before is NULL, figure out a column and put "w"
 * at the end.
 */
 
PutWindowInColumn(w, before, expandMode)
register struct wmWindow *w;
register struct wmWindow *before;
enum mode expandMode;
{
    register struct SplitWindow *column, *new, *old, *next;

    debug ( ("Put Window 0x%x In Column %d (mode %d) \n", w, before, expandMode) );
    debug ( ("    w->t.column %d \n", w->t.column));

    if (before)
	{
	debug ( ("    before was set: its column is %d \n", before->t.column));
	w->t.column = before->t.column;
	}
    if (w->t.column < 0) {
	char var[1000], *val;
	debug ( ("column was <0 ProgramName %s \n", w->ProgramName) );

	sprintf(var, "%scolumn", w->ProgramName);
	val = (char *) getprofile(var);

	if (val && '0'<=*val && *val<='9') {
	    w->t.column = *val - '0';
	} else {
	    static char *column1[] = {
		"console", "typescript", "xload", "xclock", "xterm",
		"author:", "david", "berkowitz", 0
	    };
	    int i;
	    for (i=0; column1[i] && !FoldedEQ(w->ProgramName,column1[i]); i++);
	    w->t.column = (column1[i]? 1 : 2);
	    debug ( ("w->t.column %d \n", w->t.column) );
	}
    }
    if (!ColumnRoot[w->t.column]) {
	int i;
	for (i=0; i<MAXCOLS; i++) {
	    if (ColumnRoot[i]) {
		w->t.column = i;
		break;
	    }
	}
	if (i==MAXCOLS)
	    debug(("No columns!\n"));
    }
    column = ColumnRoot[w->t.column];

    if (before && before->t.type==EmptyWindowType)
	before = NULL;
    for (old=column; old->top!=(struct SplitWindow *)before; old=old->bottom);
    next = old->bottom;

    /*		 \			  \
     *		old	   =>		 old
     *	       /   \		        /   \
     *	   before  next		       w   new
     *					  /   \
     *				      before  next
     */

    new = NewSplitWindow();
    *new = *old;
    new->t.parent = old;
    next->t.parent = new;
    if (before) before->t.parent = new;
    old->top = (struct SplitWindow *) w;
    old->bottom = new;
    w->t.parent = old;
    w->t.ViewPort = old->t.ViewPort;
    if (column->SplitHorizontally)
	w->t.ViewPort.height = 0;
    else
	w->t.ViewPort.width = 0;
    w->t.display = column->t.display;
    w->t.deleted = 0;
    w->Visible = 1;

    if (!w->Shrunk)
	{
	debug ( ("Not Shrunk \n") );
	AllocateColumnSpace(column, w, expandMode, fairly_by_height, 0);
	}
    else
	{
	/* Following is a copy of what shrink does.  May not always work. */
	debug ( ("Shrunk \n") );
	AllocateColumnSpace(ColumnRoot[w->t.column], w, as_specified,
	    fairly_by_height, w->ModeViewPort.height+2*BorderWidth);
	}

nodebug ( ("PutWindowInColumn returning \n") );
}


/*
 * Allocate each window a new place
 */

static int should_blt = 1;
#define PCT 10000

#define MINHEIGHT(w) (w->Shrunk? w->t.ViewPort.height: w->minheight)
#define HEIGHT(w) (w->t.ViewPort.height)
#define MAXHEIGHT(w) (w->Shrunk? w->t.ViewPort.height: \
    MIN(w->maxheight, column->t.ViewPort.height))
#define MOD_MIN(w) (w->Shrunk? w->t.ViewPort.height: \
    (w==new ? ((new_mode == as_specified) ? specified_height : w->minheight) : MIN(w->minheight, w->t.ViewPort.height)))
#define MOD_MAX(w) (w->Shrunk? w->t.ViewPort.height: \
    MAX(MAXHEIGHT(w), w->t.ViewPort.height))

#define EXCH(a,b) (temp=a,a=b,b=temp)

TransposeWindow(w)
struct wmWindow *w;
{
    register int temp;

    nodebug ( ("TransposeWindow 0x%x \n", w) );

    EXCH(w->t.ViewPort.left, w->t.ViewPort.top);
    EXCH(w->t.ViewPort.width, w->t.ViewPort.height);
    if (w->t.type==WindowType) {
	EXCH(w->minwidth, w->minheight);
	EXCH(w->maxwidth, w->maxheight);
    }

nodebug ( ("TransposeWindow returning \n") );
}

TransposeColumn(column)
register struct SplitWindow *column;
{
    register struct SplitWindow *sw;

    nodebug ( ("TransposeColumn 0x%x \n", column) );

    for (sw=column;  sw->t.type==SplitWindowType; sw=sw->bottom) {
	TransposeWindow(pWW(sw));
	TransposeWindow(pWW(sw->top? sw->top: sw->bottom));
    }

nodebug ( ("TransposeColumn returning \n") );
}


AllocateColumnSpace(column, new, new_mode, old_mode, specified_height)
struct SplitWindow *column;
struct wmWindow *new;
enum mode new_mode, old_mode;
int specified_height;
{
    struct SplitWindow *c, *last;
    struct wmWindow *w;
    int sum_min=0, sum_height=0,  sum_max=0, sum_mod_min=0, sum_mod_max=0;
    int new_height, remaining, top, pct, height, transposed=0;
    int will_blt = 0;

    debug ( ("AllocateColumnSpace column 0x%x new 0x%x nmode %d omode %d height %d \n",
	column, new, new_mode, old_mode, specified_height) );
    if (!column->SplitHorizontally) {
	TransposeColumn(column);
	transposed = 1;
    }

    {

	/* collect stats on windows */
	for (c=column; w=(struct wmWindow *)c->top; c=c->bottom) {
            sum_min += MINHEIGHT(w);
            sum_height += HEIGHT(w);
	    sum_max += MAXHEIGHT(w);
	    sum_mod_min += MOD_MIN(w);
	    sum_mod_max += MOD_MAX(w);
	}

        if (new_mode == hog)
            do {
	  debug ( ("new_mode was hog \n") );
                c = column;
                sum_mod_min = 0;
	        for (;w = (struct wmWindow *) c->top; c = c->bottom)
	            if (w != new)
		        if (!w->Shrunk && w->t.type == WindowType) {
			    ShrinkWindow(w);
			    c = column; /* (sigh) */
			    break;
			}
                        else
		            sum_mod_min += w->t.ViewPort.height;
	    } while (c->top != NULL && c->t.type != EmptyWindowType);
        else 
            /* kick out windows to make room for sum_mod_min; never kick out new */
            while (sum_mod_min > column->t.ViewPort.height) {
	        struct wmWindow *smallest = 0;
	        for (c=column; w=(struct wmWindow *)c->top; c=c->bottom)
		    if (w!=new && (!smallest
		      || w->t.ViewPort.height<smallest->t.ViewPort.height))
		        smallest = w;
	        if (!smallest)
		    break;
	        sum_min -= MINHEIGHT(smallest);
	        sum_height -= HEIGHT(smallest);
	        sum_max -= MAXHEIGHT(smallest);
	        sum_mod_min -= MOD_MIN(smallest);
	        sum_mod_max -= MOD_MAX(smallest);
	        if (transposed) TransposeColumn(column);
	        if (!ShrinkWindow(smallest))
		    DeleteWindow(pSW(smallest));
	        if (transposed) TransposeColumn(column);
            }

	for (last=column; last->top; last=last->bottom);
	remaining = column->t.ViewPort.height;

	/* determine height for new: new_height */
        if (new) {
	    switch(new_mode) {
	    case at_least_min: 
		if (MINHEIGHT(new) <= last->t.ViewPort.height) {
		    new_height = MIN(MAXHEIGHT(new),
			last->t.ViewPort.height + new->t.ViewPort.height);
		    break;
		}
		/* this break omitted intentionally */
	    case fairly_by_max:
		if (sum_max-sum_min == 0) pct = PCT;
		else pct = MIN(PCT, PCT * (remaining-sum_min)
		    / (sum_max-sum_min));
		new_height = MINHEIGHT(new)
		    + pct * (MAXHEIGHT(new)-MINHEIGHT(new)) / PCT;
		break;
	    case as_specified:
		/* assumes old will be fairly_by_height */
		new_height = MIN(remaining-sum_mod_min+MOD_MIN(new),
		    specified_height);
		break;
	    case hog:
		/* assumes old will be fairly_by_height */
		new_height = remaining-sum_mod_min;
		break;
	    }
	    sum_height -= HEIGHT(new);
	    sum_min -= MINHEIGHT(new);
	    sum_max -= MAXHEIGHT(new);
	    sum_mod_min -= MOD_MIN(new);
	    sum_mod_max -= MOD_MAX(new);
	    remaining -= new_height;
	}

	/* compute percentage between min and max for old windows */
	switch (old_mode) {
	case fairly_by_max:
	    if (sum_max-sum_min == 0) pct = PCT;
	    else pct = MIN(PCT, PCT * (remaining-sum_min) / (sum_max-sum_min));
	    break;
	case fairly_by_height:
	    if (sum_height-sum_mod_min == 0) pct = PCT;
	    else pct = MIN(PCT, PCT * (remaining-sum_mod_min) / (sum_height-sum_mod_min));
	    if (pct==PCT && should_blt && new) {
		will_blt=1;
	    }
	    break;
	}

	/* allocate space */
	top = column->t.ViewPort.top;
	remaining = column->t.ViewPort.height;
	for (c=column; w=(struct wmWindow *)c->top; c=c->bottom) {
	    if (w==new) {
		height = new_height;
	    } else switch (old_mode) {
	    case fairly_by_max:
		height = MINHEIGHT(w) + pct * (MAXHEIGHT(w)-MINHEIGHT(w)) / PCT;
		break;
	    case fairly_by_height:
		height = MOD_MIN(w) + pct * (HEIGHT(w)-MOD_MIN(w)) / PCT;
		break;
	    }
	    if (!transposed) {
		AdjustWindow(w, 0, top - w->t.ViewPort.top,
		    0, height - w->t.ViewPort.height);
	    } else {
		TransposeWindow(w);
		AdjustWindow(w, top - w->t.ViewPort.left, 0,
		    height - w->t.ViewPort.width, 0);
		TransposeWindow(w);
	    }
	    if (will_blt) {
		debug ( ("cwm not calling MoveWindowRegions \n") );
	    }
	    c->t.ViewPort.top = top;
	    c->t.ViewPort.height = remaining;
	    top += height, remaining -= height;
	    c->SplitValue = top;
	}
	if (will_blt) {
	    debug ( ("cwm not blitting the window \n") );
	}
	if (!transposed) {
	    AdjustWindow(pWW(last), 0, top - last->t.ViewPort.top,
		0, remaining - last->t.ViewPort.height);
	} else {
	    TransposeColumn(column);
	    AdjustWindow(pWW(last), top - last->t.ViewPort.left, 0,
		remaining - last->t.ViewPort.width, 0);
	}
    }

nodebug ( ("AllocateColumnSpace returning \n") );
}


/*
 * Make w take up lots of room
 */

ExpandColumnWindow(w, expandMode)
struct wmWindow *w;
enum mode expandMode;
{
debug ( ("ExpandColumnWindow 0x%x \n", w) );

    if (!w->Shrunk)
	AllocateColumnSpace(ColumnRoot[w->t.column], w,
	    hog, fairly_by_height, 0);
    else {
	w->Shrunk = 0;
	if (ShrinkToColumn == -1 && ShrinkToPosition == -1) {
	    /* shrinking/expanding in place */
	    AllocateColumnSpace(ColumnRoot[w->t.column], w,
		expandMode, fairly_by_height, 0);
	}
	else {
	    DeleteWindowFromColumn(w); 
	    w->t.column = w->original_column;
	    PutWindowInColumn(w, 0, expandMode);
	}
	debug ( ("cwm not sending E to process \n") );
    }

nodebug ( ("ExpandColumnWindow returning \n") );
}


/*
 * Reproportion all windows
 */

ReproportionColumns()
{
    int i;
    for (i=0; i<MAXCOLS; i++) {
	if (ColumnRoot[i])
	    AllocateColumnSpace(ColumnRoot[i], 0, fairly_by_max, fairly_by_max, 0);
    }
}


/*
 * Remove w from it's column
 */

DeleteWindowFromColumn(d)
register struct wmWindow *d;
{
    register struct SplitWindow *c;
    register struct wmWindow *w;


    d->t.deleted = 1;
    AllocateColumnSpace(ColumnRoot[d->t.column], d, as_specified, fairly_by_height, 0);

    for (c=d->t.parent;  c->top;  c=c->bottom) {
	w = (struct wmWindow *) (c->top = c->bottom->top);

	/*
	 *	 c
	 *	/ \
	 *     w   S
	 *	  /
	 *	 w
	 */

	if (w)
	    w->t.parent = c;
	c->t.ViewPort = c->bottom->t.ViewPort;
	c->SplitValue = c->bottom->SplitValue;
    }

    /*
     *	    S
     *	   / \
     *	 NIL  c
     *	     / \
     *	   NIL  E
     */

    (c->t.parent->bottom = c->bottom) -> t.parent = c->t.parent;
    free(c);
}
    


int
InitializeWindowSystem ()
{

    int i, j;
    char *temp;

    CursorDisplay = &displays[0];
    CursorDisplayNumber = 0;
    CurrentDisplay = CursorDisplay;
    display = displays[0];

    AlwaysZoom = getprofileswitch ("AlwaysZoom", 0);
    debug ( (" ** AlwaysZoom %s \n", YorN(AlwaysZoom) ) );

    ShrinkToColumn = getprofileint("ShrinkToColumn", -1);
    debug ( (" ** ShrinkToColumn %d \n", ShrinkToColumn ) );

    ShrinkToPosition = getprofileint("ShrinkToPosition", 0);
    debug ( (" ** ShrinkToPosition %d \n", ShrinkToPosition ) );

    ZapAll = getprofileswitch ("ZapAll", 1);
    debug ( (" ** ZapAll %s \n", YorN(ZapAll) ) );

    /* DBB
       this was a little too late in the game, maybe next time
    */
#ifdef notdef
    UnmapByShrinking = getprofileswitch ("UnmapByShrinking", 1);
    debug ( (" ** UnmapByShrinking %s \n", YorN(UnmapByShrinking) ) );
#endif
    UnmapByShrinking = 0;

    ShowErrors = getprofileswitch ("ShowErrors", 0);
    debug ( (" ** ShowErrors %s \n", YorN(ShowErrors) ) );

    temp = getprofile ("snapshotdir");
    debug ( (" ** SnapShotDir %s \n", temp) );
    if (temp == NULL)
	{
	strcpy (SnapShotDir, "/tmp");
	debug ( ("    setting it to /tmp \n") );
	}
    else
	strcpy (SnapShotDir, temp);

    BorderStyle = getprofileint ("borderstyle", 4);
    debug ( (" ** BorderStyle %d \n", BorderStyle ) );

    if (BorderStyle < 0 || BorderStyle > 6)
	BorderStyle = 4;
    BlackEdgeWidth = 1;
    BorderWidth = BorderStyle+1;
    if (BorderStyle>2)
	BlackEdgeWidth++;

    debug ( (" ** therefore: \n") );
    debug ( (" ** BorderWidth %d BlackEdgeWidth %d TitlebarHeight %d \n",
	BorderWidth, BlackEdgeWidth, TitlebarHeight) );

    {
	char *columns;
	columns = getprofile("columns");
	debug ( (" ** columns: %s \n", columns ) );

	if (!columns)
	    columns = "h  %35 v 1  %65 v 2";

	wmRootWindow[0] = CreateColumns(&columns, &displays[0], displays[0].screen);

	/* allocate columns for the other displays */
	for (i=1; i<NDisplays; i++) {
	    for (j=0; j<MAXCOLS && ColumnRoot[j]; j++);
	    if (j<MAXCOLS) {
		char buf[100], *s;
		sprintf(buf, "h %%100 v %d", j);
		s = buf;
		wmRootWindow[i] = CreateColumns(&s, &displays[i], displays[i].screen);
	    } else {
		fprintf(stderr, "too many displays+columns!\n");
		NDisplays = i;
	    }
	}

	if (ShrinkToColumn >= 0)
	    if (!ColumnRoot[ShrinkToColumn])
		ShrinkToColumn = -1;
    }
    return (1);
}
