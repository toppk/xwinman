/***********************************************************
		Copyright IBM Corporation 1987

                      All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the name of IBM not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.  

IBM DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
IBM BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
******************************************************************/
/* $Header: profile.c,v 1.2 88/09/16 15:58:12 ghoti Exp $ */
/* $ACIS:profile.c 1.7$ */
/* $Source: /afs/andrew.cmu.edu/itc/src/andrew/overhead/cwm/RCS/profile.c,v $ */

#ifndef lint
static char *rcsid = "$Header: profile.c,v 1.2 88/09/16 15:58:12 ghoti Exp $";
#endif

/*********************************************
Cambridge Window Manager
*********************************************/

#include <stdio.h>
#include <X11/Xlib.h>
#include <X11/X10.h>
#include "cwm.h"

extern char *XGetDefault();

char FoldTRT[256];
#define FOLDEDEQ(s1,s2) (FoldTRT[s1[0]]==FoldTRT[s2[0]] && FoldedEQ(s1,s2))

char FoldTRT[256] = {
0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, '!', '"', '#', '$', '%',
'&', '\'', '(', ')', '*', '+', ',', '-', '.', '/', '0', '1', '2', '3', '4',
'5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?', '@', 'a', 'b', 'c',
'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r',
's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '[', '\\', ']', '^', '_', '`', 'a',
'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p',
'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~', 127,
0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, '!', '"', '#', '$', '%',
'&', '\'', '(', ')', '*', '+', ',', '-', '.', '/', '0', '1', '2', '3', '4',
'5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?', '@', 'a', 'b', 'c',
'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r',
's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '[', '\\', ']', '^', '_', '`', 'a',
'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p',
'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~', 127, };

FoldedEQ(s1, s2)
register unsigned char	*s1,
			*s2; {
    while (*s1)
	if (FoldTRT[*s1++] != FoldTRT[*s2++])
	    return 0;
    return * s2 == 0;
}

FoldedEQn(s1, s2, n)
register unsigned char	*s1,
			*s2; {
    while (*s1 && n--)
	if (FoldTRT[*s1++] != FoldTRT[*s2++])
	    return 0;
    return (* s2 == 0 || n == 0);
}

static
char *getprofilestring (var)
char *var; {

return (XGetDefault (XDisplay, "cwm", var ));
}


static char profilestring[300];

char *getprofile (var)
char *var; {
    char *val;

    val = getprofilestring(var);
    if (val != 0)  {
	strcpy(profilestring,val);
	return profilestring;
    }
    else
        return 0;
}


getprofileswitch (var, DefaultValue)
char   *var; {
    char   *val;
    register    len;
    static struct keys {
	char   *name;
	int     value;
    }                   keys[] = {
	                    "true", 1,
	                    "false", 0,
	                    "on", 1,
	                    "off", 0,
	                    "yes", 1,
	                    "no", 0,
	                    "1", 1,
	                    "0", 0,
	                    0, 0
    };
    register struct keys   *p;
    if (var && (val = getprofilestring (var))) {
	len = strlen (val);
	for (p = keys; p -> name; p++)
	    if (p -> name[0] == val[0] && strncmp (p -> name, val, len) == 0)  {
		return p -> value;
	    }
    }
    return DefaultValue;
}

getprofileint (var, DefaultValue)
char   *var; {
    register char  *val;
    register    n = 0;
    register    neg = 0;
    if (var == 0 || (val = getprofilestring (var)) == 0)  {
	return DefaultValue;
    }
    while (*val) {
	if (*val == '-')
	    neg = ~neg;
	else
	    if (*val != ' ' && *val != '\t')
		if ('0' <= *val && *val <= '9')
		    n = n * 10 + *val - '0';
		else  {
		    return DefaultValue;
		}
	val++;
    }
    return neg ? -n : n;
}
