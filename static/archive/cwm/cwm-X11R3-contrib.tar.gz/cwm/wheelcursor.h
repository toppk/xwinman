/***********************************************************
		Copyright IBM Corporation 1987

                      All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the name of IBM not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.  

IBM DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
IBM BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
******************************************************************/
/* $Header: wheelcursor.h,v 1.1 88/09/16 11:53:32 ajp Exp $ */
/* $ACIS:wheelcursor.h 1.6$ */
/* $Source: /afs/andrew.cmu.edu/itc/src/andrew/overhead/cwm/wheelcursor.h,v $ */

#if !defined(lint) && !defined(LOCORE) && defined(RCS_HDRS)
static char *rcsidwheelcursor = "$Header: wheelcursor.h,v 1.1 88/09/16 11:53:32 ajp Exp $";
#endif

/*********************************************
Cambridge Window Manager
*********************************************/

/** WHEEL cursor definition **/
#ifdef vax
#define wheelcursor_width  32
#define wheelcursor_height  16
#define wheelcursor_hotx  8
#define wheelcursor_hoty  8
#else
#define wheelcursor_width  32
#define wheelcursor_height  24
#define wheelcursor_hotx  15
#define wheelcursor_hoty  14
#endif


/**    DEFINITION    ***/
/**

00  --------------------------------
01  --------------------------------
02  -----------@@@@@@@@@------------
03  ---------@@@///////@@@----------
04  --------@@///////////@@---------
05  -------@@///@@@/@@@///@@--------
06  ------@@//@@@-@/@/@@@//@@-------
07  ------@//@@---@/@---@@//@-------
08  -----@@//@----@/@----@//@@------
09  -----@//@@----@/@----@@//@------
10  -----@//@-----@/@-----@//@------
11  -----@//@@@@@@@@@@@@@@@//@------
12  -----@////////@-@////////@------
13  -----@//@@@@@@@@@@@@@@@//@------
14  -----@//@-----@/@-----@//@------
15  -----@//@@----@/@----@@//@------
16  -----@@//@----@/@----@//@@------
17  ------@//@@---@/@---@@//@-------
18  ------@@//@@@-@/@-@@@//@@-------
19  -------@@///@@@/@@@///@@--------
20  --------@@///////////@@---------
21  ---------@@@///////@@@----------
22  -----------@@@@@@@@@------------
23  --------------------------------

**/



/**              MASK                 **/
/**
00  0000 0000 0000 0000 0000 0000 0000 0000     00000000
01  0000 0000 0000 0000 0000 0000 0000 0000     00000000
02  0000 0000 0001 1111 1111 0000 0000 0000     001FF000
03  0000 0000 0111 1111 1111 1100 0000 0000     007FFC00
04  0000 0000 1111 1111 1111 1110 0000 0000     00FFFE00
05  0000 0001 1111 1111 1111 1111 0000 0000     01FFFF00
06  0000 0011 1111 1011 1111 1111 1000 0000     03FBFF80
07  0000 0011 1110 0011 1000 1111 1000 0000     03E38F80
08  0000 0111 1100 0011 1000 0111 1100 0000     07C387C0
09  0000 0111 1100 0011 1000 0111 1100 0000     07C387C0
10  0000 0111 1000 0011 1000 0011 1100 0000     078383C0
11  0000 0111 1111 1111 1111 1111 1100 0000     07FFFFC0
12  0000 0111 1111 1110 1111 1111 1100 0000     07FEFFC0
13  0000 0111 1111 1111 1111 1111 1100 0000     07FFFFC0
14  0000 0111 1000 0011 1000 0011 1100 0000     078383C0
15  0000 0111 1100 0011 1000 0111 1100 0000     07C387C0
16  0000 0111 1100 0011 1000 0111 1100 0000     07C387C0
17  0000 0011 1110 0011 1000 1111 1000 0000     03E38F80
18  0000 0011 1111 1011 1011 1111 1000 0000     03FBBF80
19  0000 0001 1111 1111 1111 1111 0000 0000     01FFFF00
20  0000 0000 1111 1111 1111 1110 0000 0000     00FFFE00
21  0000 0000 0111 1111 1111 1100 0000 0000     007FFC00
22  0000 0000 0001 1111 1111 0000 0000 0000     001FF000
23  0000 0000 0000 0000 0000 0000 0000 0000     00000000

**/


/**       IMAGE            **/
/**
00  0000 0000 0000 0000 0000 0000 0000 0000     00000000
01  0000 0000 0000 0000 0000 0000 0000 0000     00000000
02  0000 0000 0001 1111 1111 0000 0000 0000     001FF000
03  0000 0000 0111 0000 0001 1100 0000 0000     00701C00
04  0000 0000 1100 0000 0000 0110 0000 0000     00C00600
05  0000 0001 1000 1110 1110 0011 0000 0000     018EE300
06  0000 0011 0011 1010 1011 1001 1000 0000     033AB980
07  0000 0010 0110 0010 1000 1100 1000 0000     02628C80
08  0000 0110 0100 0010 1000 0100 1100 0000     064284C0
09  0000 0100 1100 0010 1000 0110 0100 0000     04C28640
10  0000 0100 1000 0010 1000 0010 0100 0000     04828240
11  0000 0100 1111 1111 1111 1110 0100 0000     04FFFE40
12  0000 0100 0000 0010 1000 0000 0100 0000     04028040
13  0000 0100 1111 1111 1111 1110 0100 0000     04FFFE40
14  0000 0100 1000 0010 1000 0010 0100 0000     04828240
15  0000 0100 1100 0010 1000 0110 0100 0000     04C28640
16  0000 0110 0100 0010 1000 0100 1100 0000     064284C0
17  0000 0010 0110 0010 1000 1100 1000 0000     02628C80
18  0000 0011 0011 1010 1011 1001 1000 0000     033AB980
19  0000 0001 1000 1110 1110 0011 0000 0000     018EE300
20  0000 0000 1100 0000 0000 0110 0000 0000     00C00600
21  0000 0000 0111 0000 0001 1100 0000 0000     00701C00
22  0000 0000 0001 1111 1111 0000 0000 0000     001FF000
23  0000 0000 0000 0000 0000 0000 0000 0000     00000000

**/

#ifdef vax /* Small version of cursor for qvss display */
static int wheelcursor_mask[] = {
	0x0FF0,
	0x3FFC,
	0x7FFE,
	0x7FFE,
	0xFBDF,
	0xF3CF,
	0xFFFF,
	0xFFFF,
	0xFFFF,
	0xFFFF,
	0xF3CF,
	0xFBDF,
	0x7FFE,
	0x7FFE,
	0x3FFC,
	0x0FF0
};
static int wheelcursor_image[] = {
	0x0FF0,
	0x381C,
	0x6006,
	0x4E72,
	0xDA5B,
	0x9249,
	0x9E79,
	0x8001,
	0x8001,
	0x9E79,
	0x9249,
	0xDA5B,
	0x4E72,
	0x6006,
	0x381C,
	0x0FF0
};
#else
static int wheelcursor_mask[] = {
    0x00000000,
    0x00000000,
    0x001FF000,
    0x007FFC00,
    0x00FFFE00,
    0x01FFFF00,
    0x03FBBF80,
    0x03E38F80,
    0x07C387C0,
    0x07C387C0,
    0x078383C0,
    0x07FFFFC0,
    0x07FEFFC0,
    0x07FFFFC0,
    0x078383C0,
    0x07C387C0,
    0x07C387C0,
    0x03E38F80,
    0x03FBBF80,
    0x01FFFF00,
    0x00FFFE00,
    0x007FFC00,
    0x001FF000,
    0x00000000};


static int wheelcursor_image[] = {
    0x00000000,
    0x00000000,
    0x001FF000,
    0x00701C00,
    0x00C00600,
    0x018EE300,
    0x033AB980,
    0x02628C80,
    0x064284C0,
    0x04C28640,
    0x04828240,
    0x04FFFE40,
    0x04028040,
    0x04FFFE40,
    0x04828240,
    0x04C28640,
    0x064284C0,
    0x02628C80,
    0x033AB980,
    0x018EE300,
    0x00C00600,
    0x00701C00,
    0x001FF000,
    0x00000000};

#endif
