/***********************************************************
		Copyright IBM Corporation 1987

                      All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the name of IBM not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.  

IBM DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
IBM BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
******************************************************************/
/* $Header: mode.c,v 1.2 88/09/16 15:58:08 ghoti Exp $ */
/* $ACIS:mode.c 1.3$ */
/* $Source: /afs/andrew.cmu.edu/itc/src/andrew/overhead/cwm/RCS/mode.c,v $ */

#ifndef lint
static char *rcsid = "$Header: mode.c,v 1.2 88/09/16 15:58:08 ghoti Exp $";
#endif

/*********************************************
Cambridge Window Manager
*********************************************/

#include <stdio.h>
#include <sys/time.h>
#include <sys/resource.h>

#include <X11/Xlib.h>
#include <X11/Xutil.h>


#include "window.h"
#include "menu.h"
#include "display.h"
#include "wmclient.h"
#include "cwm.h"
#include "assoc.h"

extern int FocusHighlightStyle;
extern struct wqe *wqhead;
extern Display *XDisplay;
extern GC whiteGC, blackGC, invertGC;
extern XFontStruct *ModeFont;
extern XAssocTable *windowinfo;

#define Indent 2


DrawModeLine (w)
register struct wmWindow *w;
{

register struct ViewPort   *ovp = CurrentViewPort, *ocr = CurrentClipRectangle;
struct wqe *wqe;
int xo = Indent;
int yo = ModeFont->max_bounds.ascent + 1;

/* DBB This renders the NameWidth field irrelevant */
int NameWidth = XTextWidth (ModeFont, w->name, strlen (w->name));
int LeftSpace = ((w->ModeViewPort.width - NameWidth) >> 1) - (Indent<<1);
int HostWidth = XTextWidth (ModeFont, w->hostname, strlen (w->hostname));
int ProgWidth = w->ProgramName[0] ?
	XTextWidth (ModeFont, w->ProgramName, strlen (w->ProgramName))
	: 999999;

/*
debug ( ("DrawModeLine w 0x%x \n", w) );
debug ( ("xo %d yo %d \n", xo, yo) );
debug ( ("Name <%s> ProgName <%s> Host <%s> \n",
	w->name, w->ProgramName, w->hostname) );
debug ( ("LeftSpace %d HostWidth %d ProgWidth %d \n",
	LeftSpace, HostWidth, ProgWidth) );
*/

CurrentClipRectangle = CurrentViewPort = &w->ModeViewPort;
if (EmphasizedWindow ==  w /*&& BorderStyle == 0*/)
	EmphasizedWindow = 0;

XClear (XDisplay, w->TitleBar);

if (LeftSpace > ProgWidth)
	XText (XDisplay, w->TitleBar, blackGC,
		xo, yo, w->ProgramName, strlen (w->ProgramName) );

XText (XDisplay, w->TitleBar, blackGC,
	xo+LeftSpace+Indent, yo, w->name, strlen (w->name) );

if (LeftSpace - xo > HostWidth && !w->titlemenu)
	XText (XDisplay, w->TitleBar, blackGC, w->ModeViewPort.width - HostWidth - Indent,
		yo, w->hostname, strlen (w->hostname) );

CurrentViewPort = ovp;  CurrentClipRectangle = ocr;

if (WindowInFocus == w)
	SetInputFocus (w);
}

FlipEmphasis (w)
register struct wmWindow *w; {

debug ( ("FlipEmphasis w 0x%x \n", w) );

if (w && w -> Visible) {

	register struct ViewPort   *ovp = CurrentViewPort,
				   *ocr = CurrentClipRectangle;
	register t;
	if (CurrentDisplay != w -> t.display) {
	if (w -> t.display == 0) {
		debug (("Null display pointer in window %s\n", w -> name));
		return;
	}
	CurrentDisplay = w -> t.display;
	display = *CurrentDisplay;
	}

	switch (FocusHighlightStyle) {
	case 1: 
		CurrentClipRectangle = CurrentViewPort = &w -> ModeViewPort;

		XFillRectangle (XDisplay, w->TitleBar, invertGC,
			0, 0, w ->ModeViewPort.width, w ->ModeViewPort.height);
		break;
/* DBB not yet
	case 2: 
		CurrentClipRectangle = CurrentViewPort = &w -> t.ViewPort;
		t = BorderWidth-BlackEdgeWidth;
		HW_RasterSmash (0, 0, w -> t.ViewPort.width, t);
		HW_RasterSmash (0, w -> t.ViewPort.height - t, w -> t.ViewPort.width, t);
		HW_RasterSmash (0, 0, t, w -> t.ViewPort.height);
		HW_RasterSmash (w -> t.ViewPort.width - t, 0, t, w -> t.ViewPort.height);
		break;
*/
	}
	CurrentViewPort = ovp;  CurrentClipRectangle = ocr;
}
}
