/***********************************************************
		Copyright IBM Corporation 1987

                      All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the name of IBM not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.  

IBM DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
IBM BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
******************************************************************/
/* $Header: arbitrator.c,v 1.3 88/09/16 16:05:33 ghoti Exp $ */
/* $ACIS:arbitrator.c 1.17$ */
/* $Source: /afs/.andrew.cmu.edu/itc/src/andrew/overhead/cwm/RCS/arbitrator.c,v $ */

#ifndef lint
static char *rcsid = "$Header: arbitrator.c,v 1.3 88/09/16 16:05:33 ghoti Exp $";
#endif

/*********************************************
Cambridge Window Manager
*********************************************/

#include <stdio.h>
#include <sys/file.h>
#include <signal.h>

#include <X11/Xlib.h>
#include <X11/X10.h>
#include <X11/Xatom.h>
#include <X11/Xutil.h>
#include "cmenu.h"
#include "cwmStubs.h"

#include "window.h"
#include "display.h"
#include "cwm.h"

extern int BlackEdgeWidth;
extern int BorderWidth;
extern int UnmapByShrinking;

struct SplitWindow *MovingBar;
struct wqe *Destroyee = NULL;
Bool Moving = False;
Bool flag = False;

#define CLIENT_EVENTS (EnterWindowMask | LeaveWindowMask | PropertyChangeMask)
#define TITLEBAR_EVENTS (BUTTONS | EnterWindowMask | LeaveWindowMask | ExposureMask)

#define NONAME ""
#define NOTITLE ""
/*
#define NOHOST "?host?"
*/
#define NOHOST ""
#define NOHELP ""


char *
GetWindowName (w)
struct wmWindow *w;
{
char *fetchstring;

if (XFetchName (XDisplay, w->SubProcess, &fetchstring))
	nodebug ( ("FetchName succeeded <%s> \n", fetchstring) );
else
	{
	nodebug ( ("FetchName failed \n") );
	fetchstring = NONAME;
	}

return fetchstring;
}


char *
GetWindowTitle (w)
struct wmWindow *w;
{
char *fetchstring;

if (!cwm_FetchTitle (XDisplay, w->SubProcess, &fetchstring))
	nodebug ( ("FetchTitle succeeded <%s> \n", fetchstring) );
else
	{
	nodebug ( ("FetchTitle failed <%s> \n", fetchstring) );
	fetchstring = NOTITLE;
	}

return fetchstring;
}


GetWindowHost (w)
struct wmWindow *w;
{
char *fetchstring;

if (!cwm_FetchHost (XDisplay, w->SubProcess, &fetchstring))
	{
	/* fixed 8/1/85 to remove preceding parts (split on dashes) like
	 * to user's machine name e.g. process from cmu-ws-foo in window
	 * of machine cmu-ws-mumble appears as foo.  cmu-itc-bar on the
	 * same machine would appear as itc-bar.  Note this means that a
	 * window originating from the user's machine, the usual case, has
	 * the last part of the machine name. -wdh
	 */

	char *herhost = fetchstring;
	int difloc = 0,
	i = 0;

	nodebug ( ("FetchHost succedded <%s> \n", fetchstring) );

	while ((herhost[i] != 0) && (herhost[i] == OurHost[i]))
	if (herhost[i++] == '-')
		difloc = i;
	herhost = &herhost[difloc];

	/* DBB the following is a model for what needs to be done */

	if (strlen(herhost) < sizeof(w->hostname))
		strcpy(w->hostname,herhost);
	else
		{
		strncpy(w->hostname,herhost,sizeof(w->hostname)-1);
		w->hostname[sizeof(w->hostname)-1] = 0;
		}
	}
else
	{
	nodebug ( ("FetchHost failed <%s> \n", fetchstring) );
	strcpy (w->hostname, NOHOST);
	}
}


char *
GetWindowHelp (w)
struct wmWindow *w;
{
char *fetchstring;

if (!cwm_FetchHelp (XDisplay, w->SubProcess, &fetchstring))
	nodebug ( ("FetchHelp succeeded <%s> \n", fetchstring) );
else
	{
	debug ( ("FetchHelp failed <%s> \n", fetchstring) );
	fetchstring = NOHELP;
	}

return fetchstring;
}


NewConnection (window)
Window window;
{

    register struct wmWindow  *w;
    register struct wqe *wqe;
    Window titlebar;
    char *namestring, *titlestring, *helpstring;

    debug ( ("\n\n===== NewConnection =====\n") );

    /* Allocate a brand new wmWindow structure for this X Window */
    w = (struct wmWindow *) calloc (1, sizeof (struct wmWindow) );
    if (!w)
	cwmError (1, "Can't allocate a wmWindow \n" );
    memdebug ( ("MALLOC wmWindow 0x%x %d bytes \n", w, sizeof (struct wmWindow) ) );  

    /* Create the title bar X window */
    titlebar = XCreateSimpleWindow (XDisplay, XRoot, 0, 0, 1, 1,
		BlackEdgeWidth, BLACKPIXEL, WHITEPIXEL);
    debug ( ("Titlebar for 0x%x is 0x%x \n", window, titlebar) );
    if (!titlebar)
	cwmError (1, "Can't create titlebar \n");

    {
    XSetWindowAttributes swa;
    XWindowChanges changes;

    swa.event_mask = TITLEBAR_EVENTS;
    swa.cursor = modecursor;
    XChangeWindowAttributes (XDisplay, titlebar, CWEventMask | CWCursor, &swa);

    swa.event_mask = CLIENT_EVENTS;
    /* DBB we really could care less about events within the window */
    swa.do_not_propagate_mask = BUTTONS;
    swa.border_pixel = BLACKPIXEL;
    XChangeWindowAttributes (XDisplay, window,
	CWDontPropagate | CWEventMask | CWBorderPixel, &swa);

    changes.border_width = BlackEdgeWidth;
    XConfigureWindow (XDisplay, window, CWBorderWidth, &changes);
    }

    /* wmWindows are associated with an X Window, not a "process" */
    w -> SubProcess = window;
    w -> TitleBar = titlebar;

    /* Get the program name (left side of title bar) */
    namestring = GetWindowName (w);

    {
    char temp[100];
    sprintf (temp, "cwm title bar %s", namestring);
    XStoreName (XDisplay, titlebar, temp);
    }

    /* Get the title (middle of title bar) */
    titlestring = GetWindowTitle (w);

    /* Get and set the host name (right side of title bar) */
    GetWindowHost (w);

    /* Set the help file (to pass on to help program) */
    helpstring = GetWindowHelp (w);
    SetHelpCall (w, helpstring);

    /* Set the process group */
    w -> pgrp = -1;

    /* Initialize the rest of the new wmWindow */
    w -> x = 0;
    w -> y = 0;
    w -> Hidden = 0;
    w -> Visible = 0;
    w -> Shrunk = 0;
    w -> minwidth = MinWindowWidth;
    w -> maxwidth = 2000;
    w -> minheight = MinWindowHeight;
    w -> maxheight = 2000;
    w -> t.column = -1;

    /* DBB look for size hints */
    {
    XSizeHints hints;
    if (XGetNormalHints (XDisplay, window, &hints) )
	{
	if (hints.flags & PMinSize)
	    {
	    debug (("min wants to be %d x %d \n", hints.min_width, hints.min_height));
	    w -> minwidth = hints.min_width < MinWindowWidth ? MinWindowWidth : hints.min_width;
	    w -> minheight = hints.min_height < MinWindowHeight ? MinWindowHeight : hints.min_height;

	    debug (("first round: minw %d minh %d \n", w->minwidth, w->minheight));
	    }

	if (hints.flags & PMaxSize)
	    {
	    debug (("max wants to be %d x %d \n", hints.max_width, hints.max_height));
	    w -> maxwidth = hints.max_width < w->minwidth ? w->minwidth : hints.max_width;
	    w -> maxheight = hints.max_height < w->minheight ? w->minheight : hints.max_height;

	    debug (("first round: maxw %d maxh %d \n", w->maxwidth, w->maxheight));
	    }

	if ( (hints.flags & USSize) || (hints.flags & PSize) )
	    {
    	    debug (("exact size wants to be %d x %d \n", hints.width, hints.height));
	    /*
	    w -> minwidth = hints.width < MinWindowWidth ? MinWindowWidth : hints.width;
	    w -> minheight = hints.height < MinWindowHeight ? MinWindowHeight : hints.height;
	    */
	    /* let's try only setting max */
	    w -> maxwidth = hints.width < w->minwidth ? w->minwidth : hints.width;
	    w -> maxheight = hints.height < w->minheight ? w->minheight : hints.height;
	    }

	    /* adjust client notion of window size by adding title bar height */
	    w ->minheight += TitlebarHeight;
	    w ->maxheight += TitlebarHeight;
	}
    }

debug (("final dimensions: minw %d minh %d maxw %d maxh %d \n", w->minwidth, w->minheight, w->maxwidth, w->maxheight));

    /* Set the name and title of this window */
    SetWindowTitle (w, titlestring, namestring);

    /*Actually register the new wmWindow with the Window System */
    CreateWindow (w);

    /* Associate the new wmWindow with the X Window */
    wqe = (struct wqe *) malloc (sizeof (struct wqe) );
    if (!wqe)
	cwmError (1, "Can't allocate a window queue element \n");
    memdebug ( ("MALLOC wqe 0x%x %d bytes \n", wqe, sizeof (struct wqe) ) );

    wqe->client = window;
    wqe->client_wm = w;
    wqe->titlebar = titlebar;

    XMapWindow (XDisplay, window);	
    debug ( ("New client window 0x%x mapped \n", window ) );

    XMapWindow (XDisplay, titlebar);
    debug ( ("New client titlebar 0x%x mapped \n", titlebar ) );

    XMakeAssoc (XDisplay, windowinfo, window, (char *) wqe );
    XMakeAssoc (XDisplay, windowinfo, wqe->titlebar, (char *) wqe );

    insque (wqe, wqhead);

    debug (("===== NewConnection complete =====\n\n"));
}


Eshell () {
    if (vfork () == 0) {

        int fd;
        char *typescriptCommand;

        if ((fd = open("/dev/null", O_RDWR)) >= 0) {
            dup2(fd, 0);
            dup2(fd, 1);
            dup2(fd, 2);
            close(fd);
        }
        else { /* If nothing else, it protects our files. */
            close(0);
            close(1);
            close(2);
        }
	signal (SIGPIPE, SIG_DFL);
	signal (SIGURG, SIG_IGN);
	signal (SIGTERM, SIG_DFL);
	setpriority(0, getpid(), 0);
	setuid(getuid());
        if ((typescriptCommand = getprofile("TypescriptCommand")) == NULL)
            typescriptCommand = "typescript";
	execlp (typescriptCommand, typescriptCommand, 0);
	write(2, "Exec failed!\n", 13);
	exit (-1);
    }
}


struct SplitWindow *
FindWindow (x, y)
int x,y;
{
struct SplitWindow *w = wmRootWindow[CursorDisplayNumber];

while (w && w->t.type == SplitWindowType)
	{
	int diff = w->SplitValue - (w->SplitHorizontally ? y : x);
	if (diff <= -BorderWidth)
		w = w->bottom;
	else if (diff > BorderWidth)
		w = w->top;
	else
		break;
	}

debug ( ("(%d, %d) is in window 0x%x \n", x, y, w) );

return w;
}


#ifdef DEBUG
static char Button[6][10] = { "Unknown0", "Left", "Middle", "Right", "Unknown4", "Unknown5" };
static char Detail[8][20] = { "Ancestor", "Virtual", "Inferior", "Nonlinear",
	"NonlinearVirtual", "Pointer", "PointerRoot", "DetailNone" };
static char Mode[4][15] = { "Normal", "Grab", "Ungrab", "WhileGrabbed" };
#endif DEBUG

#define W ((struct wmWindow *) wqe->client_wm)

#define LEFTBUTTON Button1
#define MIDDLEBUTTON Button2
#define RIGHTBUTTON Button3

extern int ExposeWindow();

EventLoop()
{
while (1)
    {
    XEvent ev;
    Window w;				/* for all events */
    struct wqe *wqe;			/* for all events */
    int startx, starty;			/* where a reshape operation begins */

    XNextEvent(XDisplay, &ev);

    debug ( ("CWM: ") );

    switch(ev.type)
	{

	case ButtonPress:
		debug ( ("%s ButtonPress ", Button[ev.xbutton.button] ) );
		debug ( ("time: %x \n", ev.xbutton.time ) );

		switch (ev.xbutton.button)
		    {
		    case LEFTBUTTON:
			{
			w = ev.xbutton.window;

			/* don't care if on gray */
			if (w == XRoot)
				break;

			wqe = (struct wqe *) XLookUpAssoc (XDisplay, windowinfo, w);
			if (!wqe)
				cwmError (1, "LeftPress: window not in queue! \n");

			if (W->t.type == EmptyWindowType)
				{
				debug ( ("Press in an EmptyWindow breaking \n") );
				break;
				}

			if (w != wqe->titlebar)
				cwmError ( 0, "button press is not in a titlebar! \n");

			if (W->Shrunk)
				{
				debug ( ("was shrunk, expanding \n") );
				ExpandColumnWindow (W, at_least_min);
				}
			else
				{
				debug ( ("hiding or shrinking \n") );
				HideOrShrink (W);
				}

			debug ( ("UNGRABBING THE POINTER \n") );
			XUngrabPointer (XDisplay, CurrentTime);
			}

			break;

                    case MIDDLEBUTTON:

		if (Reshapee)
			break;

		if (MovingBar)
			{
			debug ( ("MovingBar is set, grabbing server and setting Moving \n") );

#ifndef DONTGRABDURINGRESHAPE
			debug ( ("GRABBING THE SERVER \n") );
			XGrabServer (XDisplay);
#endif
			Moving = True;
			}
		else
			{
			int stat;
                        long menuReturn;

#ifdef DEBUG
			w = ev.xbutton.window;
			/* don't care if on gray */
			if (w == XRoot)
				{
				debug ( ("Middle press in the root \n") );
				}

			else
				{
				wqe = (struct wqe *) XLookUpAssoc (XDisplay, windowinfo, w);
				if (!wqe)
					{
					debug ( ("Middle press: unknown window ox%x \n", w) );
					break;
					}

				else if (W->t.type == EmptyWindowType)
					{
					debug ( ("Middle press in an EmptyWindow \n") );
					}

				else if (w == wqe->titlebar)
					debug ( ( "Middle press in a titlebar! \n") );

				}
#endif
			stat = cmenu_Activate(cwmMenu, &ev, &menuReturn, cmenu_NoSaveUnder, NULL);

			if (stat == cm_FAILURE) 
				cwmError (1, "Menu Error");
			else if (stat == cm_NO_SELECT)
				debug ( ("no selection made\n") );
			else {

                            struct cwmmenudata *data = (struct cwmmenudata *) menuReturn;

                            (*data->function)(data->rock);
                        }
			break;
                }
            case RIGHTBUTTON:
		{

		if (Reshapee)
			{
			/* finish the reshape on the NEXT right button release */
			debug (("Finish reshape on NEXT right release.\n"));
			flag = True;
			break;
			}
		else
			{
			w = ev.xbutton.window;

			/* don't care if on gray */
			if (w == XRoot)
				break;

			wqe = (struct wqe *) XLookUpAssoc (XDisplay, windowinfo, w);
			if (!wqe)
				cwmError (1, "RightPress: window not in queue! \n");

			if (W->t.type == EmptyWindowType)
				{
				debug ( ("Press in an EmptyWindow breaking \n") );
				break;
				}

			if (w != wqe->titlebar){
				cwmError ( 0, "button press is not in a titlebar! \n");

				break;
			}
			
#ifndef DONTGRABDURINGMOVE
			debug ( ("UNGRABBING THE SERVER \n") );
			XGrabServer (XDisplay);
#endif

			{
			Window grabwindow = XRoot;
			Bool ownerevents = False;
			int eventmask = ButtonPressMask | ButtonReleaseMask;
			int pointermode = GrabModeAsync;
			int keyboardmode = GrabModeAsync;
			Window confineto = XRoot;
			Cursor cursor = movecursor;

			startx = ev.xbutton.x_root;
			starty = ev.xbutton.y_root;

			debug ( ("UNGRABBING THE POINTER \n") );
			XGrabPointer (
				XDisplay,
				grabwindow,
				ownerevents,
				eventmask,
				pointermode,
				keyboardmode,
				confineto,
				cursor,
				CurrentTime
				);
			}

			Reshape (W);
			}
		}
			break;

		    default:
			break;
		    }

		break;

	case ButtonRelease:
		debug ( ("%s ButtonRelease ", Button[ev.xbutton.button] ) );
		debug ( ("time: %x \n", ev.xbutton.time ) );

		switch (ev.xbutton.button)
		    {
		    case RIGHTBUTTON:
			{
			int x = ev.xbutton.x_root;
			int y = ev.xbutton.y_root;
			int dx = x - startx;
			int dy = y -starty;

			if (!Reshapee)
				break;

			debug ( ("start (%d, %d) current (%d, %d) delta (%d, %d) \n",
				startx, starty, x, y, dx, dy) );

			if (flag || dx<=-10 || dx>10 || dy<=-10 || dy>10)
				{
				debug ( ("finishing reshape \n") );
				FinishReshape (x,y);
				Reshapee = 0;
				flag = False;

				debug ( ("UNGRABBING THE POINTER \n") );
				XUngrabPointer (XDisplay, CurrentTime);
#ifndef DONTGRABDURINGMOVE
				debug ( ("UNGRABBING THE SERVER \n") );
				XUngrabServer (XDisplay);
#endif
				}
			else
				debug ( ("NOT finishing reshape \n") );
			}
			break;

		    case MIDDLEBUTTON:
			{
			int x = ev.xbutton.x_root;
			int y = ev.xbutton.y_root;

			if (!MovingBar)
				break;
			debug ( ("Moving Split 0x%x to %d, %d \n", MovingBar, x, y) );
			MoveSplit (MovingBar, x, y);
			Moving = False;

#ifndef DONTGRABDURINGRESHAPE
			debug ( ("UNGRABBING THE SERVER \n") );
			XUngrabServer (XDisplay);
#endif
			}

		    case LEFTBUTTON:
			{
			/*
			if (Reshapee)
				break;

			debug ( ("UNGRABBING THE POINTER \n") );
			XUngrabPointer (XDisplay, CurrentTime);
			*/
			}

		    default:
			break;
		    }

		break;

#ifdef DEBUG
	case ConfigureNotify:
		debug ( ("ConfigureNotify: ") );
		w = ev.xconfigure.window;
		debug ( ("w 0x%x \n", w ) );
		break;

	case ConfigureRequest:
		debug ( ("ConfigureRequest: ") );
		w = ev.xconfigurerequest.window;
		debug ( ("w 0x%x *IGNORED* \n", w) );
		break;

	case CreateNotify:
		debug ( ("CreateNotify: ") );
		w = ev.xcreatewindow.window;
		debug ( ("w 0x%x \n", w) );
		break;
#endif DEBUG

	case DestroyNotify:
		debug ( ("DestroyNotify: ") );
		w = ev.xdestroywindow.window;
		debug ( ("w 0x%x ", w) );
		wqe = (struct wqe *) XLookUpAssoc (XDisplay, windowinfo, w);

                if (Destroyee != NULL) {
                    if (w == Destroyee->titlebar) {
                        debug ( ("It's the Destroyee's title bar - do nothing \n") );
                        break;
                    }
                    else if (w == Destroyee->client)
                    {
                        debug ( ("It's the Destroyee's client window - cleaning up \n") );
                        free (Destroyee);
                        memdebug ( ("FREE wqe 0x%x %d bytes \n", Destroyee,
                                     sizeof (struct wqe) ) );
                        Destroyee = 0;
                        break;
                    }

                }

		if (wqe != NULL) {
			debug ( ("Client destroyed its window - cleaning up \n") );
			KillWindow (W);
                        if (Destroyee != NULL) {
                            free (Destroyee);
                            Destroyee = 0;
                        }
			memdebug ( ("FREE wqe 0x%x %d bytes \n", Destroyee,
				sizeof (struct wqe) ) );
                }
                else
                    debug ( ("window not in queue! *IGNORING* \n") );

		break;

	case EnterNotify:
		debug ( ("EnterNotify: ") );

		{
		int detail = ev.xcrossing.detail;

		w = ev.xcrossing.window;
		debug ( ("w 0x%x %s %s \n", w, Detail[detail], Mode[mode]) );

		if (Moving || Reshapee)
			{
			debug ( ("Moving or Reshaping *IGNORING* \n") );
			break;
			}

		if (detail == NotifyInferior)
			{
			debug ( ("Inferior *IGNORING* \n") );
			break;
			}

#ifdef notdef
		/* this might fix PTM 4303 */
		if (mode == NotifyUngrab)
			{
			debug ( ("Ungrab *IGNORING* \n") );
			break;
			}
#endif

		wqe = (struct wqe *) XLookUpAssoc (XDisplay, windowinfo, w);
		if (!wqe)
			{
			if (Destroyee)
				debug ( ("EnterNotify on destroyed wqe *IGNORING* \n") );
			else
				debug ( ("EnterNotify on unknown window *IGNORING* \n") );
			break;
			}

		if (MovingBar && !Moving)
			{
			debug ( ("Enter resetting MovingBar, ungrabbing pointer \n") );
			debug ( ("UNGRABBING THE POINTER \n") );
			XUngrabPointer (XDisplay, CurrentTime);
			MovingBar = 0;
			}

		if (W->t.type == EmptyWindowType)
			{
			debug ( ("Empty window, breaking \n") );
			break;
			}

		if (W != WindowInFocus)
			SetInputFocus (W);

		debug ( ("setting CursorWindow \n") );
		CursorWindow = W;
		}

		break;

	case Expose:
		debug ( ("Expose: ") );

		{
		w = ev.xexpose.window;
		debug ( ("w 0x%x last %d \n", w, ev.xexpose.count) );

		wqe = (struct wqe *) XLookUpAssoc (XDisplay, windowinfo, w);
		if (!wqe)
			{
			if (Destroyee)
				debug ( ("Expose: a destroyed window *IGNORING* \n") );
			else
				debug ( ("Expose: window not in queue! \n") );
			break;
			}

		DrawModeLine (W);
		}

		break;

	case LeaveNotify:
		debug ( ("LeaveNotify: ") );

		{
		int detail = ev.xcrossing.detail;
		int mode = ev.xcrossing.mode;
		int x = ev.xcrossing.x_root;
		int y = ev.xcrossing.y_root;
		struct SplitWindow *sw;

		w = ev.xcrossing.window;
		debug ( ("w 0x%x %s %s \n", w, Detail[detail], Mode[mode]) );

		if (Moving || Reshapee)
			{
			debug ( ("Moving or Reshaping *IGNORING* \n") );
			break;
			}

		if (detail == NotifyInferior)
			{
			debug ( ("Inferior *IGNORING* \n") );
			break;
			}

		/* this might fix PTM 4303 */
		if (mode == NotifyGrab)
			{
			debug ( ("Grab *IGNORING* \n") );
			break;
			}

		wqe = (struct wqe *) XLookUpAssoc (XDisplay, windowinfo, w);
		if (!wqe)
			{
			if (Destroyee)
				debug ( ("LeaveNotify on destroyed wqe *IGNORING* \n") );
			else
				debug ( ("LeaveNotify on unknown window *IGNORING* \n") );
			break;
			}

		debug ( ("resetting CursorWindow \n") );
		CursorWindow = 0;

		sw = FindWindow (x,y);

		if (sw->t.type == SplitWindowType)
			{
			debug ( ("0x%x is a SplitWindow, setting MovingBar \n", sw) );
			MovingBar = sw;

			{
			Window grabwindow = XRoot;
			Bool ownerevents = True;
			int eventmask = ButtonPressMask | ButtonReleaseMask;
			int pointermode = GrabModeAsync;
			int keyboardmode = GrabModeAsync;
			Window confineto = XRoot;
			Cursor cursor = MovingBar->SplitHorizontally ? hbcursor : vbcursor;

			debug ( ("UNGRABBING THE POINTER \n") );
			XGrabPointer (
				XDisplay,
				grabwindow,
				ownerevents,
				eventmask,
				pointermode,
				keyboardmode,
				confineto,
				cursor,
				CurrentTime
				);
			}
			}
		}

		break;

#ifdef DEBUG
	case MapNotify:
		debug ( ("MapNotify: ") );

		w = ev.xmap.window;
		debug ( ("w 0x%x \n", w) );
		break;
#endif DEBUG

	case MapRequest:
		debug ( ("MapRequest: ") );

		{
		w = ev.xmaprequest.window;
		debug ( ("w 0x%x \n", w) );

		wqe = (struct wqe *) XLookUpAssoc (XDisplay, windowinfo, w);

		if (!wqe)
			{
			debug ( ("Not in queue - incorporating into cwm \n") );
			NewConnection(w);
			PrintWindowStructure (wmRootWindow[0], 0);
			}
		else
			/* DBB If this is a "hidden" window trying to
			   map itself, do Expose processing on it.
			*/
			if (W->Hidden)
				{
				debug ( ("it's Hidden - Expose it \n") );
				ExposeWindow (W->MenuTitle);
				}
			else if (W->Shrunk)
				{
				debug ( ("it's Shrunk - Expand it \n") );
				ExpandColumnWindow (W, at_least_min);
				}
			else
				{
				debug ( ("it's not Hidden or Shrunk *IGNORING* \n") );
				}
		}

		break;

	case PropertyNotify:
		debug ( ("PropertyNotify: ") );

		{
		Atom atom = ev.xproperty.atom;
		int state = ev.xproperty.state;
		w = ev.xproperty.window;
		debug ( ("window 0x%x atom %d state %d \n", w, atom, state) );

		wqe = (struct wqe *) XLookUpAssoc (XDisplay, windowinfo, w);
		if (!wqe)
			{
			debug ( ("PropertyNotify: window not in queue \n") );
			break;
			}

		if (state == PropertyDelete)
			{
			debug ( ("Property deleted *IGNORING* \n") );
			break;
			}

		else if (state == PropertyNewValue)
			{
			debug ( ("Property has a new value \n") );

			if (atom == XA_WM_NAME)
				{
				char *namestring;

				debug ( ("It's the NAME atom \n") );
				namestring = GetWindowName (W);

				debug ( ("namestring <%s> ProgramName <%s> \n",
					namestring, W->ProgramName) );

				if (!strcmp(namestring, W->ProgramName) )
					{
					debug ( ("would have no effect *IGNORING* \n") );
					break;
					}

				SetWindowTitle (W, 0, namestring);

				if (W->Visible)
					DrawModeLine (W);
				}

			else if (atom == TITLE_ATOM)
				{
				char *titlestring;

				debug ( ("It's the TITLE atom \n") );
				titlestring = GetWindowTitle (W);

				debug ( ("titlestring <%s> name <%s> \n",
					titlestring, W->name) );

				if (!strcmp(titlestring, W->name) )
					{
					debug ( ("would have no effect *IGNORING* \n") );
					break;
					}

				SetWindowTitle (W, titlestring, 0);

				if (W->Visible)
					DrawModeLine (W);
				}

			else if (atom == HOST_ATOM)
				{
				debug ( ("It's the HOST atom \n") );
				GetWindowHost (W);

				if (W->Visible)
					DrawModeLine (W);
				}

			else if (atom == HELP_ATOM)
				{
				debug ( ("It's the HELP atom \n") );
				GetWindowHelp (W);
				}

			else if (atom == SHRINK_ATOM)
				{
				debug ( ("It's the SHRINK atom \n") );
				if (!W->Hidden)
					if (!ShrinkWindow (W))
					    DeleteWindow (W);
				}

			else if (atom == ENLARGE_ATOM)
				{
				debug ( ("It's the ENLARGE atom \n") );
				if (W->Hidden)
					ShowProcess (W,0);
				if (W->Shrunk)
					ExpandColumnWindow (W, at_least_min);
				}

			else
				debug ( ("Don't care about atom 0x%x \n", atom) );
			}
		else
			cwmError (0, "PropertyNotify: Unknown state \n");
		}

		break;

	case UnmapNotify:
		debug ( ("UnmapNotify: ") );
		w = ev.xunmap.window;

		debug ( ("window 0x%x \n", w ) );
		wqe = (struct wqe *) XLookUpAssoc (XDisplay, windowinfo, w);

		if (!wqe)
			{
			debug ( ("not in queue *IGNORING* \n") );
			}
		else
			{
			if (w == wqe->titlebar)
				{
				debug ( ("it's a title bar *IGNORING* \n") );
				break;
				}

			if (W -> Hidden)
				{
				debug ( ("window is already Hidden *IGNORING* \n") );
				break;
				}

			if (W -> Shrunk)
				{
				debug ( ("window is already Shrunk *IGNORING* \n") );
				break;
				}

			debug ( ("not Hidden or Shrunk \n") );

			if (UnmapByShrinking)
				{
				debug ( ("Unmapping by Shrinking \n") );

				if (!ShrinkWindow (W))
					DeleteWindow (W);

				debug ( ("mapping it 0x%x \n", w) );
				XMapWindow (XDisplay, w);
				}
			else
				{
				debug ( ("Unmapping by Hiding \n") );
				Destroyee = wqe;

				/* DBB as in Hide() */
				W->ShrunkUnder = 1;
				DeleteWindow (W);

				Destroyee = 0;
				}
			}
		break;

	default:
		debug ( ("Event type %d \n", ev.type) );

		break;
	}
    }
}
