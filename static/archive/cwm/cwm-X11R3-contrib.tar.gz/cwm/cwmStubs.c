/***********************************************************
		Copyright IBM Corporation 1987

                      All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the name of IBM not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.  

IBM DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
IBM BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
******************************************************************/
/* $Header: cwmStubs.c,v 1.2 88/09/16 15:57:54 ghoti Exp $ */
/* $ACIS:cwmStubs.c 1.5$ */
/* $Source: /afs/andrew.cmu.edu/itc/src/andrew/overhead/cwm/RCS/cwmStubs.c,v $ */

#ifndef lint
static char *rcsid = "$Header: cwmStubs.c,v 1.2 88/09/16 15:57:54 ghoti Exp $";
#endif

/**   
 ** cwmStubs.c  contains procedures used for storing and fetching property
 **                     information for each window (called "stubs").  
 **
 **/

#include <stdio.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <netdb.h>

   

/*  Define Atom Variables */

Atom TITLE_ATOM, HELP_ATOM, HOST_ATOM, PNAME_ATOM;
Atom SHRINK_ATOM, ENLARGE_ATOM;



/* 
 * cwm_InitProperties - temporary function, will be done automatically
 *                       on fist call to store properties.
 */
int cwm_InitProperties(display) 
Display *display;
{

    PNAME_ATOM = XInternAtom(display, "PNAME_ATOM", False);
    TITLE_ATOM = XInternAtom(display, "TITLE_ATOM", False);
    HOST_ATOM = XInternAtom(display, "HOST_ATOM", False);
    HELP_ATOM = XInternAtom(display, "HELP_ATOM", False);
    SHRINK_ATOM = XInternAtom(display, "SHRINK_ATOM", False);
    ENLARGE_ATOM = XInternAtom(display, "ENLARGE_ATOM", False);

}

int cwm_ShrinkMe(display, w)
    Display *display;
    Window w;
{
    SHRINK_ATOM = XInternAtom(display,"SHRINK_ATOM",False);
    cwm_SetProperty(display, w, SHRINK_ATOM, " ");
}

int cwm_EnlargeMe(display, w)
    Display *display;
    Window w;
{
    ENLARGE_ATOM = XInternAtom(display,"ENLARGE_ATOM",False);
    cwm_SetProperty(display, w, ENLARGE_ATOM, " ");
}


/*
 * cwm_SetProgramName - Set the PROGRAM NAME string of a window (the left
 *                      string that appears in the title bar.
 */
int cwm_SetProgramName(display, w, name)
    Display *display;
    Window w;
    char *name;
{
   
    
     PNAME_ATOM = XInternAtom(display,"PNAME_ATOM",False);
     cwm_SetProperty(display, w, PNAME_ATOM, name);

}




/*
 * cwm_SetTitle - Set the TITLE string of a window (the string that appears
 *                in the middle of the title bar.
 */
int cwm_SetTitle(display, w, name)
    Display *display;
    Window w;
    char *name;
{

    TITLE_ATOM = XInternAtom(display,"TITLE_ATOM",False);
    cwm_SetProperty(display, w, TITLE_ATOM, name);

}




/*
 * cwm_SetHost - Set the HOST string of a window (the right string that
 *               appears in the title bar.
 */
int cwm_SetHost(display, w, host)
    Display *display;
    Window w;
    char *host;
{
    char *cwm_GetHostName();

    HOST_ATOM = XInternAtom(display,"HOST_ATOM",False);
    cwm_SetProperty(display, w, HOST_ATOM, (host != NULL) ? host : (cwm_GetHostName()));

}




/*
 * cwm_SetHelp - Set the file that should be consulted when the user 
 *               selects the HELP menu item.
 */
int cwm_SetHelp(display, w, name)
    Display *display;
    Window w;
    char *name;
{

    HELP_ATOM = XInternAtom(display,"HELP_ATOM",False);
    cwm_SetProperty(display, w, HELP_ATOM, name);
}




/*
 * cwm_SetProperty - Store a defined property value (STUB information) 
 *                   in a window.
 */
int cwm_SetProperty(display, w, atom_type, name)
    Display *display;
    Window w;
    Atom atom_type;
    char *name;
{

    XChangeProperty(display, w, atom_type, XA_STRING, 8,
                    PropModeReplace, (unsigned char *)name, strlen(name));
}




/*
 * cwm_FetchProgramName - Fetch the current PROGRAM NAME string of a 
 *                        window which has been previously stored as 
 *                        stub information.
 */
Status cwm_FetchProgramName(display, w, name)
    Display *display;
    Window w;
    char **name;
{
 
   return(cwm_FetchProperty(display,w,PNAME_ATOM,name));

}



/*
 * cwm_FetchTitle - Fetch the current TITLE string of a 
 *                  window which has been previously stored as 
 *                  stub information.
 */
Status cwm_FetchTitle(display, w, name)
    Display *display;
    Window w;
    char **name;
{
 
   return(cwm_FetchProperty(display,w,TITLE_ATOM,name));

}



/*
 * cwm_FetchHost - Fetch the current HOST string of a 
 *                 window which has been previously stored as 
 *                 stub information.
 */
Status cwm_FetchHost(display, w, name)
    Display *display;
    Window w;
    char **name;
{
   
   if ((!cwm_FetchProperty(display,w,HOST_ATOM,name)) &&
				(*name != NULL))
	return (0);
   else return (-1);

}



/*
 * cwm_FetchHelp - Fetch the current HELP string specifying the file 
 *                 that should be consulted when the user selects the
 *                 HELP menu item for the given window.  Information
 *                 must have been previously stored as stub information.
 */
Status cwm_FetchHelp(display, w, name)
    Display *display;
    Window w;
    char **name;
{
 
   return (cwm_FetchProperty(display,w,HELP_ATOM,name));

}


/* 
 * cwm_FetchProperty - Obtain STUB information of PREDEFINED property 
 *                     of window.  Note that a FetchProperty should not
 *                     be called for the first time unless a SetProperty 
 *                     has been called previously on the given atom_type. 
 */

Status cwm_FetchProperty (display, w, atom_type, name)
    register Display *display;
    Window w;
    Atom atom_type;
    char **name;
{
    Atom actual_type;
    int actual_format;
    unsigned long nitems;
    long leftover;
    unsigned char *data;
    Status status;


    if ((status = XGetWindowProperty(display, w, atom_type , 0L, (long)BUFSIZ, False, 
        XA_STRING, 
	&actual_type,
	&actual_format, &nitems, &leftover, &data)) != Success) {
    	*name = NULL;
	return (status);
	}
    if ( (actual_type == XA_STRING) &&  (actual_format != 32) ) {
	register char *tmp;
	/* 
	 * sort of gross to have to copy it, but C likes null terminated
	 * strings. 
	 */
	tmp = (char *) malloc((unsigned int) nitems + 1);
	(void) strncpy (tmp, (char *)data, (int)nitems);
	tmp[nitems] = '\0'; 
	*name = tmp;
	if (nitems > 0 && data != NULL) free((char *)data);
	return(status);
	}
    if (data) free ((char *)data);
    *name = NULL;
    return(status);
}




/* 
 * cwm_GetHostName - returns a pointer of the host name (for STUBs)
 */

char *cwm_GetHostName()

{

      static char OurHost[100];
 
      /*   Determine our host name  */

      struct hostent *ourhost;
      int namesize = sizeof(OurHost);
      gethostname(OurHost,namesize);
      ourhost = gethostbyname(OurHost);
      if (ourhost) {
          strcpy(OurHost,ourhost->h_name);
      } else {
          strcpy(OurHost,"\0");
      }
      return(OurHost);
}


/*
 * cwmInitialize - Convenience routine
 */

cwmInitialize (display, window, name, title, host, help)
Display *display;
Window window;
char *name, *title, *host, *help;
{

if (name != NULL)
	XStoreName (display, window, name);

if (title != NULL)
	cwm_SetTitle (display, window, title);

cwm_SetHost (display, window, host);

if (help != NULL)
	cwm_SetHelp (display, window, help);

}
