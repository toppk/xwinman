/***********************************************************
		Copyright IBM Corporation 1987

                      All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the name of IBM not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.  

IBM DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
IBM BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
******************************************************************/
/* $Header: MakePixmap.c,v 1.2 88/09/16 15:57:22 ghoti Exp $ */
/* $ACIS:MakePixmap.c 1.7$ */
/* $Source: /afs/andrew.cmu.edu/itc/src/andrew/overhead/cwm/RCS/MakePixmap.c,v $ */
 
#ifndef lint
static char *rcsid = "$Header: MakePixmap.c,v 1.2 88/09/16 15:57:22 ghoti Exp $";
#endif
 
/***********************************************************
Copyright 1987 by Digital Equipment Corporation, Maynard, Massachusetts,
and the Massachusetts Institute of Technology, Cambridge, Massachusetts.
 
                        All Rights Reserved
 
Permission to use, copy, modify, and distribute this software and its
documentation for any purpose and without fee is hereby granted,
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in
supporting documentation, and that the names of Digital or MIT not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.
 
DIGITAL DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
DIGITAL BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
 
******************************************************************/
#include <X11/Xlib.h>
extern GC XCreateGC();
 
Pixmap
MakePixmap(dpy, root, data, width, height, depth)
Display *dpy;
Drawable root; short *data; int width, height, depth;
{
    XImage *ximage;
    GC pgc;
    XGCValues gcv;
    Pixmap pid;
 
    gcv.foreground = BlackPixel(dpy, DefaultScreen(dpy));
    gcv.background = WhitePixel(dpy, DefaultScreen(dpy));
 
    pid = XCreatePixmap(dpy, root, width, height, depth);
    pgc = XCreateGC(dpy, pid, GCForeground | GCBackground , &gcv);
    if ( depth == 1 )
	{
	ximage = XCreateImage(dpy, DefaultVisual(dpy, DefaultScreen(dpy)),
	    1, XYPixmap, 0, data, width, height, 8, width >> 3);
	}
    else
	{
	ximage = XCreateImage(dpy, DefaultVisual(dpy, DefaultScreen(dpy)),
	    1, XYBitmap, 0, data, width, height, 8, width >> 3);
	}
 
    XPutImage(dpy, pid, pgc, ximage, 0, 0, 0, 0, width, height);
    XFreeGC(dpy, pgc);
    XFree(ximage);
    return(pid);
}
