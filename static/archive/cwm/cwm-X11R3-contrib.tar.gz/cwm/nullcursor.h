/***********************************************************
		Copyright IBM Corporation 1987

                      All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the name of IBM not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.  

IBM DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
IBM BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
******************************************************************/
/* $Header: nullcursor.h,v 1.1 88/09/16 11:53:28 ajp Exp $ */
/* $ACIS:nullcursor.h 1.5$ */
/* $Source: /afs/andrew.cmu.edu/itc/src/andrew/overhead/cwm/nullcursor.h,v $ */

#if !defined(lint) && !defined(LOCORE) && defined(RCS_HDRS)
static char *rcsidnullcursor = "$Header: nullcursor.h,v 1.1 88/09/16 11:53:28 ajp Exp $";
#endif

/*********************************************
Cambridge Window Manager
*********************************************/

/** NULL cursor definition **/

#define nullcursor_width 	32
#define nullcursor_height    4
#define nullcursor_hotx      0
#define nullcursor_hoty      0


/**    DEFINITION     **/
/**

00--------------------------------
01--------------------------------
02--------------------------------
03--------------------------------

**/


/**               MASK                          **/
/**

 00   0000 0000 0000 0000 0000 0000 0000 0000   00000000
 01   0000 0000 0000 0000 0000 0000 0000 0000   00000000
 02   0000 0000 0000 0000 0000 0000 0000 0000   00000000
 03   0000 0000 0000 0000 0000 0000 0000 0000   00000000

**/


/**       IMAGE                                  **/        
/**

 00   0000 0000 0000 0000 0000 0000 0000 0000   00000000
 01   0000 0000 0000 0000 0000 0000 0000 0000   00000000
 02   0000 0000 0000 0000 0000 0000 0000 0000   00000000
 03   0000 0000 0000 0000 0000 0000 0000 0000   00000000

 **/

static int nullcursor_mask[] = {
    0x00000000, 
    0x00000000,        
    0x00000000, 
    0x00000000};


static int nullcursor_image[] = {
    0x00000000, 
    0x00000000,        
    0x00000000, 
    0x00000000};

