/***********************************************************
		Copyright IBM Corporation 1987

                      All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the name of IBM not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.  

IBM DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
IBM BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
******************************************************************/

/* $Header: cwmStubs.h,v 1.1 88/09/16 11:53:14 ajp Exp $ */
/* $ACIS:cwmStubs.h 1.6$ */
/* $Source: /afs/andrew.cmu.edu/itc/src/andrew/overhead/cwm/cwmStubs.h,v $ */

#if !defined(lint) && !defined(LOCORE) && defined(RCS_HDRS)
static char *rcsidcwmStubs = "$Header: cwmStubs.h,v 1.1 88/09/16 11:53:14 ajp Exp $";
#endif

/**  Include file for CWM:  Defines stub macros    **/

#ifndef CWM_STUBS_H
#define CWM_STUBS_H

#include <netdb.h>


/**  Function  Definitions  **/

extern int cwm_InitProperties();
extern int cwm_SetProgramName(), cwm_SetTitle();
extern int cwm_SetHost(), cwm_SetHelp();
extern Status cwm_FetchProgramName(), cwm_FetchTitle();
extern Status cwm_FetchHost(), cwm_FetchHelp();
extern char *cwm_GetHostName();



/**  Atom  Variables   **/

extern Atom TITLE_ATOM, HELP_ATOM, HOST_ATOM, PNAME_ATOM;
extern Atom SHRINK_ATOM, ENLARGE_ATOM;

#endif   /* CWM_STUBS_H */
