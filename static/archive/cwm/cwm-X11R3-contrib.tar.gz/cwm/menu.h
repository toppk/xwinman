/***********************************************************
		Copyright IBM Corporation 1987

                      All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the name of IBM not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.  

IBM DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
IBM BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
******************************************************************/
/* $Header: menu.h,v 1.1 88/09/16 11:53:26 ajp Exp $ */
/* $ACIS:menu.h 1.3$ */
/* $Source: /afs/andrew.cmu.edu/itc/src/andrew/overhead/cwm/menu.h,v $ */

#if !defined(lint) && !defined(LOCORE) && defined(RCS_HDRS)
static char *rcsidmenu = "$Header: menu.h,v 1.1 88/09/16 11:53:26 ajp Exp $";
#endif

/*********************************************
Cambridge Window Manager
*********************************************/

int StackedMenus;
int MenuActive;

/* Mouse button definitions */
#define LeftButton	2
#define MiddleButton	1
#define RightButton	0
#define UpMovement	0
#define DownTransition	1
#define UpTransition	2
#define DownMovement	3

struct wmWindow *Reshapee;
int Reshapee_x, Reshapee_y;
