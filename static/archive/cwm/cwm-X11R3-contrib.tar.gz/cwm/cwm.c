/***********************************************************
		Copyright IBM Corporation 1987

                      All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the name of IBM not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.  

IBM DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
IBM BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
******************************************************************/
/* $Header: cwm.c,v 1.2 88/09/16 15:57:42 ghoti Exp $ */
/* $ACIS:cwm.c 1.13$ */
/* $Source: /afs/andrew.cmu.edu/itc/src/andrew/overhead/cwm/RCS/cwm.c,v $ */

#ifndef lint
static char *rcsid = "$Header: cwm.c,v 1.2 88/09/16 15:57:42 ghoti Exp $";
#endif

/*********************************************
Cambridge Window Manager
*********************************************/

#include <stdio.h>
#include <signal.h>
#include <netdb.h>

#include <X11/Xlib.h>
#include <X11/X10.h>
#include <X11/Xutil.h>

#include "window.h"
#include "cwm.h"
#include "display.h"

#include "defaultcursor.h"
#include "boxcursor.h"
#include "hbordercursor.h"
#include "vbordercursor.h"
#include "wheelcursor.h"
#include "nullcursor.h"

void cwmError();		/* forward references */
void InitializeDisplay();
void GrayWindow();
void Greeting();
Cursor MakeCursor();
int ErrorHandler();

static Pixmap GrayPixmap;

#define ASSOCTABLESZ  64
#define ROOT_EVENTS (BUTTONS | SUBS)
#define DEFAULTMODEFONT "andysans12b"

main (argc, argv)
int argc;
char *argv[];
{
	Bool ChildrenExist;
	Window root, parent, *children;
	int nchildren;
	
	/* copyright */
	fprintf(stderr,"\n\nCambridge Window Manager");
	fprintf(stderr,"\n\n(c) Copyright IBM Corporation, 1987, 1988\n");

/*******************************************************
*	Set our error handler
*
*******************************************************/
	debug ( ("Installing cwm error handler \n") );
	XSetErrorHandler (ErrorHandler);

/*******************************************************
*	Open display, set NDisplays
*
*******************************************************/
	InitializeDisplay(argv);

/*******************************************************
*	Sieze the server during initialization
*
*******************************************************/
	XGrabServer (XDisplay);

/*******************************************************
*	Check for another window manager
*
*******************************************************/
	debug ( ("Checking for another window manager \n") );

	{
	XWindowAttributes wa;

	if ( !XGetWindowAttributes (XDisplay, XRoot,&wa) )
		cwmError (1, "Can't inquire about root's events \n");

	/* check for substrucure redirect */
	if (wa.all_event_masks & SUBS)
		{
		fprintf (stderr, "cwm: Root already has substructure selected! \n");
		cwmError (1, "Is there another window manager running? \n");
		}
	}

/*******************************************************
*	Set the window manager's priority
*	Give up super user privelege
*
*******************************************************/
	setpriority (0, getpid(), getprofileint("Priority", -10));

	/*
	setuid (getuid());
	*/

/*******************************************************
*	Initialize the font path
*
*******************************************************/
#define ANDREWFONTDIR "/usr/andrew/X11fonts/"
#define XFONTDIR "/usr/lib/X11/fonts/"
#define MAXFONTDIRS 7
	{
	int i, j, numpaths, finalnumpaths;
	int inserted =0;
	char **fontpaths;
	char *newfontpaths[MAXFONTDIRS];
	char *userfontpath = NULL;

	fontpaths = XGetFontPath (XDisplay, &numpaths);
	debug ( ("Current font path (%d) is: \n", numpaths) );
	for (i=0; i<numpaths; i++)
		debug ( ("	%s \n", fontpaths[i]) );

	/* check for fontpath preference */
	if ((userfontpath = getprofile ("FontPath")) != NULL)
		{
		debug ( (" ** FontPath %s \n", userfontpath) );
		newfontpaths[inserted++] = userfontpath;
		}

	newfontpaths[inserted++] = XFONTDIR;

	newfontpaths[inserted++] = ANDREWFONTDIR;

	finalnumpaths = inserted;

	for (i=0; (i < numpaths) && (i < (MAXFONTDIRS - inserted)); i++)
		{
		Bool alreadythere = False;
		for (j=0; j<finalnumpaths; j++)
		    alreadythere = alreadythere || !strcmp (fontpaths[i], newfontpaths[j]);

		if (alreadythere)
		    {
		    debug ( ("<%s> discarding \n", fontpaths[i]) );
		    }
		else
		    {
		    debug ( ("<%s> adding to fontpath \n", fontpaths[i]) );
		    newfontpaths[finalnumpaths++] = fontpaths[i];
		    }
		}

	debug ( ("New font path (%d) is: \n", finalnumpaths) );
	for (i=0; i<finalnumpaths; i++)
		debug ( ("	%s \n", newfontpaths[i]) );

	/* set the new set of font paths (numpaths + inserted) */
	XSetFontPath (XDisplay, newfontpaths, finalnumpaths);

	XFreeFontPath (fontpaths);
	}

/*******************************************************
*	Check for existing top-level windows
*
*******************************************************/
	debug ( ("Looking for top-level windows \n") );

	XQueryTree (XDisplay, XRoot, &root, &parent, &children, &nchildren);
	ChildrenExist = (Bool) nchildren;
	debug ( ("ChildrenExist %s \n", TorF(ChildrenExist) ) );

/*******************************************************
*	Greeting
*
*******************************************************/
	if (!ChildrenExist)
		{
		debug ( ("Greeting \n") );
		Greeting();
		}
	else
		/* this is normally done while the greeting is up */
		GrayWindow (XRoot);

/*******************************************************
*	Open fonts
*
*******************************************************/
	debug ( ("Open fonts \n") );

	{
	char *fontname;

	if ((fontname = getprofile ("ModeFont")) == NULL)
		fontname = DEFAULTMODEFONT;

	ModeFont = XLoadQueryFont (XDisplay, fontname);
	if (!ModeFont)
		{
		fprintf (stderr, "Can't open ModeFont %s. Using fixed. \n", fontname);
		ModeFont = XLoadQueryFont (XDisplay, "fixed");
		if (!ModeFont)
			cwmError (1, "Can't open fixed! I give up. \n");
		}
	
	TitlebarHeight = ModeFont->max_bounds.ascent + 5;
	debug ( ("TitlebarHeight is %d \n", TitlebarHeight) );
	}

/*******************************************************
*	Create GCs
*
*******************************************************/
	debug ( ("Create GCs \n") );

	{
	XGCValues gcv;
	unsigned long planemask;

	gcv.font = ModeFont->fid;
	gcv.graphics_exposures = False;
	gcv.foreground = BLACKPIXEL;
	gcv.background = WHITEPIXEL;

	blackGC = XCreateGC (XDisplay, XRoot,
	    GCFont | GCGraphicsExposures | GCForeground | GCBackground, &gcv);
	if (!blackGC)
		cwmError (1, "Can't create blackGC \n");

	/* 
	 * XOR white and black to get the plane(s).
	 */
	planemask = WHITEPIXEL ^ BLACKPIXEL;
	debug(("white 0x%x black 0x%x mask 0x%x \n", WHITEPIXEL, BLACKPIXEL, planemask));
			
	gcv.plane_mask = planemask;
	gcv.function = GXinvert;

	invertGC = XCreateGC (XDisplay, XRoot,
	    GCFunction | GCGraphicsExposures | GCPlaneMask, &gcv);
	if (!invertGC)
		cwmError (1, "Can't create invertGC \n");
	}

/*******************************************************
*	Create cursors
*
*******************************************************/
	debug ( ("Create cursors \n") );

	rootcursor = MakeCursor (&defaultcursor_image[0], &defaultcursor_mask[0],
		(int) defaultcursor_width, (int) defaultcursor_height,
		defaultcursor_hotx, defaultcursor_hoty);

	modecursor = MakeCursor (&boxcursor_image[0], &boxcursor_mask[0],
		(int) boxcursor_width, (int) boxcursor_height,
		boxcursor_hotx, boxcursor_hoty);

	hbcursor = MakeCursor (&hbordercursor_image[0], &hbordercursor_mask[0],
		(int) hbordercursor_width, (int) hbordercursor_height,
		hbordercursor_hotx, hbordercursor_hoty);

	vbcursor = MakeCursor (&vbordercursor_image[0], &vbordercursor_mask[0],
		(int) vbordercursor_width, (int) vbordercursor_height,
		vbordercursor_hotx, vbordercursor_hoty);

	movecursor = MakeCursor (&wheelcursor_image[0], &wheelcursor_mask[0],
		(int) wheelcursor_width, (int) wheelcursor_height,
		wheelcursor_hotx, wheelcursor_hoty);

/*******************************************************
*	Create association table
*
*******************************************************/
	windowinfo = XCreateAssocTable (ASSOCTABLESZ);
	if (!windowinfo) 
		cwmError (1, "XCreateAssocTable failed\n");

/*******************************************************
*	Create window queue
*
*******************************************************/
	wqhead = (struct wqe *) malloc (sizeof (struct wqe));
	memdebug ( ("MALLOC wqe 0x%x %d bytes \n", wqhead, sizeof (struct wqe) ) );
	wqhead->next = wqhead;
	wqhead->prev = wqhead;

/*******************************************************
*	Set the root's cursor and event mask
*
*******************************************************/
	debug ( ("Set root cursor and event mask \n") );

	{
	XSetWindowAttributes swa;

	/* consider masking off unwanted events */

	swa.event_mask = ROOT_EVENTS;
	swa.cursor = rootcursor;
	XChangeWindowAttributes (XDisplay, XRoot, CWEventMask | CWCursor, &swa);
	}

/*******************************************************
*	Position the cursor
*
*******************************************************/
	if (!ChildrenExist)
		{
		struct display *dp = &displays[0];

		debug ( ("Positioning the cursor \n") );
		MouseX = (dp->screen.width / 100) * getprofileint("MouseX", 25);
		MouseY = (dp->screen.height / 100) * getprofileint("MouseY", 50);
		debug ( (" ** MouseX %d MouseY %d \n", MouseX, MouseY) );

		XWarpPointer (XDisplay, None, XRoot, 0, 0, 0, 0, MouseX, MouseY);
		}
	else
		debug ( ("NOT positioning the cursor \n") );

/*******************************************************
*	Initialize the window system
*	preferences, columns, etc.
*
*******************************************************/
	InitializeWindowSystem();
	PrintWindowStructure (wmRootWindow[0],0);	/* DEBUG */

/*******************************************************
*	Initialize the  TITLE, HOST and HELP window properties
*
*******************************************************/
	cwm_InitProperties (XDisplay);

/*******************************************************
*	Create the window manager's menu
*	using the cmenu package
*
*******************************************************/
	debug ( ("Create the window manager's menu \n") );
	cwmMenu = ManagersMenu();

/*******************************************************
*	Install SIGHUP handler
*
*******************************************************/
	debug ( ("Installing our SIGHUP handler \n") );
	{
	struct sigvec xvec;
	extern int Exit();

	xvec.sv_handler = Exit;
	xvec.sv_mask = 0;
	xvec.sv_onstack = 0;
	sigvec(SIGHUP, &xvec, 0);
	}

/*******************************************************
*	Determine our host name
*
*******************************************************/
	{
	struct hostent *ourhost;
	int namesize = sizeof(OurHost);
	gethostname(OurHost,namesize);
	ourhost = gethostbyname(OurHost);
	if(ourhost) {
	    strcpy(OurHost,ourhost->h_name);
	} else {
	    strcpy(OurHost,"\0");
	}
	debug ( ("Our host name is %s \n", OurHost) );
	}

/*******************************************************
*	Handle existing top-level mapped windows
*
*******************************************************/
	if (ChildrenExist)
	    {
	    int i;
	    for (i=0; i < nchildren; i++)
		if (Mapped (children[i]))
		    {
		    debug ( ("handling mapped window 0x%x \n", children[i]) );
		    NewConnection (children[i]);
		    }
		else
		    debug ( ("NOT handling unmapped window 0x%x \n", children[i]) );

	    free(children);
	    }

/*******************************************************
*	Process user's Startup preference
*
*******************************************************/
	if (!ChildrenExist)
		{
		char *startup;
		startup = getprofile ("startup");
   		debug ( (" ** startup %s \n",startup) );

		if (startup)
			{
			if (vfork () == 0)
			    {
			    close (0);
			    close (1);
			    close (2);
			    open ("/dev/null", 2);
			    dup (0);
			    dup (0);
			    signal (SIGPIPE, SIG_DFL);
			    signal (SIGURG, SIG_IGN);
			    signal (SIGTERM, SIG_DFL);
			    setpriority(0, getpid(), 0);
			    setuid(getuid());
			    execlp ("sh", "sh", "-c", startup, 0);
			    write(2, "Exec failed!\n", 13);
			    exit (0);
			    }
			}
		else
			Eshell ();
	    }

/*******************************************************
*	Release the server 
*
*******************************************************/
	XUngrabServer (XDisplay);

/*******************************************************
*	Now just wait for something to happen
*
*******************************************************/
	debug ( ("Event Loop \n\n") );

	EventLoop();
}


void
InitializeDisplay(argv)
char *argv[];
{
#ifdef DEBUG
if (argv[1] == NULL)
	debug ( ("NULL argument \n") );
else
	debug ( ("argument is <%s> \n", argv[1]) );
#endif DEBUG

if ((XDisplay = XOpenDisplay (argv[1])) == NULL)
	if (argv[1] == NULL)
		{
		fprintf (stderr, "cwm: Can't open display! \n");
		cwmError (1, "Is your DISPLAY environment set?\n\n");
		}
	else
		{
		fprintf (stderr, "cwm: Can't open display <%s>\n",argv[1]);
		cwmError (1, "\n");
		}

debug ( ("Success on open of <%s> \n", DisplayString(XDisplay)) );

/* set these once for efficiency */
XScreen = DefaultScreenOfDisplay (XDisplay);
XRoot = RootWindowOfScreen (XScreen);

{
Window retroot;
int rootx, rooty;
unsigned int rootwidth, rootheight, bw, depth;
struct display *p;

XGetGeometry (XDisplay, XRoot, &retroot, &rootx, &rooty,
	&rootwidth, &rootheight, &bw, &depth);
debug ( ("Root Info  x:%d y:%d w:%d h:%d \n",
	rootx, rooty, rootwidth, rootheight ) );

/* set up global screen data */
ScreenWidth = rootwidth;
ScreenHeight = rootheight;

WHITEPIXEL = WhitePixelOfScreen (XScreen);
BLACKPIXEL = BlackPixelOfScreen (XScreen);

/* set up Andrew display information */
p = &displays[NDisplays];
p->screen.left = rootx;
p->screen.top = rooty;
p->screen.width = rootwidth;
p->screen.height = rootheight;

display = *p;
}

NDisplays++;
}


void
cwmError(status, message)
int status;
char *message;
{
fprintf(stderr, "%s", message);

if (status)
	exit (status);
}


void
GrayWindow (w)
Window w;
{
int image[8];

image[0] = 0x55555555;
image[1] = 0xAAAAAAAA;
image[2] = 0x55555555;
image[3] = 0xAAAAAAAA;
image[4] = 0x55555555;
image[5] = 0xAAAAAAAA;
image[6] = 0x55555555;
image[7] = 0xAAAAAAAA;

GrayPixmap = MakePixmap (XDisplay, XRoot,(char *) image, 32,
	8, PlanesOfScreen (XScreen));
if (!GrayPixmap)
	cwmError (1, "Can't create GrayPixmap \n");

XSetWindowBackgroundPixmap (XDisplay, w, GrayPixmap);
XClearWindow (XDisplay, w);

XFreePixmap (XDisplay, GrayPixmap);
}


Window greeting;

#define MARGIN 100

static
line (font, fontGC, string, x, y)
XFontStruct *font;
GC fontGC;
char *string;
int x, y;
{
    int width = XTextWidth (font, string, strlen (string));

    if (x==0)
	x = MARGIN;
    else if (x==1)
	x = (display.screen.width - width) / 2;
    else if (x==2)
	x = display.screen.width - width - MARGIN;

    y = (display.screen.height*y) / 100;

    XDrawString (XDisplay, greeting, fontGC, x, y, string, strlen (string));
}

#ifdef DEBUG
#define GREETING_DELAY 1
#else
#define GREETING_DELAY 3
#endif DEBUG

void
Greeting()
{

/* Display the Andrew greeting */
/* if we got here there are no children windows */

struct display *p = &displays[0];
int x,y,width,height;
int i = GREETING_DELAY;
XSetWindowAttributes swa;

/* Create a root-sized window */
x = p->screen.left;
y = p->screen.top;
width = p->screen.width;
height = p->screen.height;

greeting = XCreateSimpleWindow (XDisplay, XRoot, x, y, width, height, 0, None, WHITEPIXEL);
if (!greeting)
	cwmError ( 1, "Can't create greeting window \n" );

nocursor = MakeCursor (&nullcursor_image[0], &nullcursor_mask[0],
	(int) nullcursor_width, (int) nullcursor_height,
	nullcursor_hotx, nullcursor_hoty);
if (!nocursor)
	cwmError ( 1, "Can't create greeting cursor \n" );

swa.cursor = nocursor;
XChangeWindowAttributes (XDisplay, greeting, CWCursor, &swa);

/* Map it */
XMapWindow (XDisplay, greeting);

{
XFontStruct *font1, *font2, *font3;
GC font1GC, font2GC, font3GC;
XGCValues gcv;

#define FONT1 	"andysans22b"
#define FONT2 	"andrew120"
#define FONT3	"andysans12i" 

font1 = XLoadQueryFont (XDisplay, FONT1);
if (!font1)
	fprintf (stderr, "Can't open <%s> \n", FONT1);

font2 = XLoadQueryFont (XDisplay, FONT2);
if (!font2)
	fprintf (stderr, "Can't open <%s> \n", FONT2);

font3 = XLoadQueryFont (XDisplay, FONT3);
if (!font3)
	fprintf (stderr, "Can't open <%s> \n", FONT3);

gcv.font = font1->fid;
gcv.foreground = BLACKPIXEL;
gcv.background = WHITEPIXEL;
font1GC = XCreateGC (XDisplay, XRoot, GCFont | GCForeground | GCBackground, &gcv);
if (!font1GC)
	cwmError (0, "Can't create font1GC \n");

gcv.font = font2->fid;
font2GC = XCreateGC (XDisplay, XRoot, GCFont | GCForeground | GCBackground, &gcv);
if (!font2GC)
	cwmError (0, "Can't create font2GC \n");

gcv.font = font3->fid;
font3GC = XCreateGC (XDisplay, XRoot,  GCFont | GCForeground | GCBackground, &gcv);
if (!font3GC)
	cwmError (0, "Can't create font3GC \n");

line (font1, font1GC, "Welcome To", 1, 20);
line (font2, font2GC, "Andrew", 1, 40);
line (font3, font3GC, "An experimental system produced by", 2, 80);
line (font3, font3GC, "the Information Technology Center,", 2, 85);
line (font3, font3GC, "a joint project of CMU and IBM.", 2, 90);

XFreeGC (XDisplay, font1GC);
XFreeGC (XDisplay, font2GC);
XFreeGC (XDisplay, font3GC);

XFreeFont (XDisplay, font1);
XFreeFont (XDisplay, font2);
XFreeFont (XDisplay, font3);

XFreeCursor (XDisplay, nocursor);
}

/* While the root is hidden, change its background */
GrayWindow (XRoot);

/* Delay */
sleep(i);

/* Unmap and destroy it */
XDestroyWindow (XDisplay, greeting);

}


#ifdef DEBUG
/*
 * A simple procedure that lists a window's children
 */
PrintChildren (w)
Window w;
{
int status;
Window root, parent, *children;
int i, nchildren;

status = XQueryTree (XDisplay, w, &root, &parent, &children, &nchildren );
if ( status == 0 )
	{
	printf( "Couldn't QueryTree window 0x%x \n", w );
	return;
	}

printf( "window 0x%x has %d children \n", w, nchildren );

if (nchildren == 0)
	return;

for (i=0; i<nchildren; i++)
	printf( "  child 0x%x \n", w, (children[i]) );

free( children );
}
#endif DEBUG


Cursor
MakeCursor (imageptr, maskptr, width, height, hotx, hoty)
char *imageptr, *maskptr;
int width, height, hotx, hoty;

{
Pixmap image, mask;
XColor fore, back;
Cursor cursor;

fore.pixel = ~0;
fore.red = fore.green = fore.blue = ~0;
fore.flags = 0;

back.pixel = 0;
back.red = back.green = back.blue = 0;
back.flags = 0;

image = MakePixmap (XDisplay, XRoot, imageptr, width, height, 1);
mask = MakePixmap (XDisplay, XRoot, maskptr, width, height, 1);

cursor = XCreatePixmapCursor (XDisplay, image, mask, &fore, &back, hotx, hoty);

XFreePixmap (XDisplay, image);
XFreePixmap (XDisplay, mask);

if (!cursor)
	cwmError (1, "Can't create cursor \n");
else
	return cursor;
}

extern int ShowErrors;

int
ErrorHandler (XDisplay, ev)
Display *XDisplay;
XErrorEvent *ev;
{

if (!ShowErrors)
	return;

fprintf (stderr, "\n===== cwm X Error =====\n");
fprintf (stderr, "XID %x request: %d error: %d \n", ev->resourceid, ev->request_code,
	ev->error_code);
fprintf (stderr, "===== cwm X Error =====\n\n");

}

Bool
Mapped(w)
Window w;
{
XWindowAttributes wa;

XGetWindowAttributes (XDisplay, w, &wa);
return ((wa.map_state != IsUnmapped) && (wa.override_redirect != True));
}

