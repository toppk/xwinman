/***********************************************************
		Copyright IBM Corporation 1987

                      All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the name of IBM not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.  

IBM DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
IBM BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
******************************************************************/
/* $Header: window.h,v 1.1 88/09/16 11:53:35 ajp Exp $ */
/* $ACIS:window.h 1.8$ */
/* $Source: /afs/andrew.cmu.edu/itc/src/andrew/overhead/cwm/window.h,v $ */

#if !defined(lint) && !defined(LOCORE) && defined(RCS_HDRS)
static char *rcsidwindow = "$Header: window.h,v 1.1 88/09/16 11:53:35 ajp Exp $";
#endif

/************************
Cambridge Window Manager
*************************/

#ifdef DEBUG
#define debug(f) (fileno(stdout)>0 ? (printf f,fflush(stdout)) : 0)
#define nodebug(f)
#define memdebug(f)
#else
#define debug(f)
#define nodebug(f)
#define memdebug(f)
#endif

enum type {
    WindowType,
    SplitWindowType,
    EmptyWindowType
};

/* A ViewPort defines a rectangle within which operations are clipped and
   translated.  It is a patch of the screen whose top left-hand corner is at
   (top,left) and is dimensioned width by height.  Operations within a
   viewport see a coordinate system which runs from (0,0) in the upper left
   to (width,height) in the lower right. */
struct ViewPort {
    int     top,
            left,
            width,
            height;
};

struct ViewPort *CurrentViewPort, *CurrentClipRectangle;

struct TypedObject {
    enum type type;
    int deleted;		/* True iff this window is (being) deleted */
    struct ViewPort ViewPort;	/* Region currently occupied by this object */
    struct SplitWindow *parent;	/* The window containing this window */
    struct display *display;	/* The display on which this window resides */
    short column;		/* Column this window is/should be in */
};

struct wmWindow {
    struct TypedObject  t;
    struct ViewPort SubViewPort;/* Viewport with borders clipped out */
    struct ViewPort ClipRectangle; /* default- or user's- clip rectangle */
    struct ViewPort ModeViewPort;/* Viewport for the mode line */
    int     x,			/* Current cursor position */
            y;
    int     pgrp;		/* Process group of the other end of the
				   channel */
    short   minheight,
            maxheight,
            minwidth,
            maxwidth;
    char    Hidden;		/* true iff this process is hidden -- it
				   doesn't have an attached window and shouldn't have one */
    char    Visible;		/* true iff this process is visible */
    char    Shrunk;		/* true iff window is shrunk */
    char    ShrunkUnder;	/* true iff client is shrunk under titlebar */
    Window SubProcess;		/* ID of the client X Window associated with the
				   wmWindow */
    Window TitleBar;		/* ID of the titlebar X Window associated with the
				   wmWindow */
    char    name[40];		/* The name associated with this process */
    char    ProgramName[20];	/* The name of the program -- name[] should
				   usually name the object being worked on by
				   ProgramName[] */
    char    MenuTitle[40];	/* String for use in the "Expose" menu */
    char    hostname[30];	/* The name of the host on the other end of
				   this connection */
    char    HelpCall[20];	/* called when help is clicked in the mode line */
    short original_column;	/* Column this window was in before shrinking */
};


struct SplitWindow {
    struct TypedObject t;
    struct SplitWindow *top, *bottom /* , *parent */ ;
    int SplitValue;
    int SplitHorizontally;
};

struct SplitWindow *wmRootWindow[5];	/* One for each display */

struct EmptyWindow {
    struct TypedObject t;
    Window xWindow;		/* ID of the associated X Window */
};

struct wmWindow *CurrentWindow;
struct wmWindow *CursorWindow;
int  MouseX;
int  MouseY;


#define MinWindowWidth 40
#define MinWindowHeight 50

struct wmWindow *WindowInFocus;
struct wmWindow *EmphasizedWindow;
int zoomX, zoomY, zoomW, zoomH;	/* for window creation zooming animation */

extern int Shutdown;		/* True when exiting the window manager */


/*
 * How to allocate column space
 */

enum mode {
    at_least_min,	/* new window gets only gray area, if enough */
    as_specified,	/* new window gets specified_height */
    hog,		/* new window gets as much as it can */

    fairly_by_max,	/* new or old window gets fair share */

    fairly_by_height,	/* old window gets height related to current height */    
};

struct cwmmenudata {
    void (*function)();
    char *rock;
};

