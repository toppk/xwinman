/***********************************************************
		Copyright IBM Corporation 1987

                      All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the name of IBM not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.  

IBM DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
IBM BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
******************************************************************/
/* $Header: error.c,v 1.2 88/09/16 15:58:04 ghoti Exp $ */
/* $ACIS:error.c 1.3$ */
/* $Source: /afs/andrew.cmu.edu/itc/src/andrew/overhead/cwm/RCS/error.c,v $ */

#ifndef lint
static char *rcsid = "$Header: error.c,v 1.2 88/09/16 15:58:04 ghoti Exp $";
#endif

/*********************************************
Cambridge Window Manager
*********************************************/

#include <stdio.h>
#include <signal.h>
#include <netdb.h>

#include <X11/Xlib.h>
#include <X11/Xutil.h>

#include "window.h"
#include "cwm.h"
#include "assoc.h"

extern char *XErrDescrip();

int
ErrorHandler (XDisplay, ev)
Display *XDisplay;
XErrorEvent *ev;
{

debug ( ("\n===== Error =====\n") );
debug ( ("XID %x request: %d error: %d \n", ev->resourceid, ev->request_code,
	ev->error_code) );
debug ( ("===== Error =====\n\n") );

