/***********************************************************
		Copyright IBM Corporation 1987

                      All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the name of IBM not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.  

IBM DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
IBM BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
******************************************************************/
/* $Header: windowops.c,v 1.2 88/09/16 15:58:31 ghoti Exp $ */
/* $ACIS:windowops.c 1.13$ */
/* $Source: /afs/andrew.cmu.edu/itc/src/andrew/overhead/cwm/RCS/windowops.c,v $ */

#ifndef lint
static char *rcsid = "$Header: windowops.c,v 1.2 88/09/16 15:58:31 ghoti Exp $";
#endif

/************************
Cambridge Window Manager
*************************/

#include <stdio.h>
#include <ctype.h>
#include <sys/file.h>
#include <signal.h>

#include <X11/Xlib.h>
#include <X11/X10.h>
#include <X11/Xutil.h>
#include "cmenu.h"

#include "window.h"
#include "display.h"
#include "cwm.h"

extern int ZapAll;
extern char SnapShotDir[];

int Shutdown = 0;

Exit () {
    register struct wqe *wqe;

    debug ( ("Exit called \n") );

    Shutdown = 1;

    for (wqe = wqhead->next; wqe != wqhead; wqe = wqe->next)
	    switch (wqe->client_wm->t.type)
		{
		case WindowType:
			{
			register struct wmWindow *w = wqe->client_wm;
			debug ( ("Exit: killing %s %s %s \n", w->name, w->ProgramName, w->hostname) );

			if (ZapAll)
				{
				debug ( ("Killing the client \n") );
				KillProcess (w->SubProcess);
				}
			else
				{
				debug ( ("NOT Killing the client \n") );
				if (w->Hidden)

					/*
					XMapWindow (XDisplay, wqe->client);
					*/

					{
					PutWindowInColumn(w, 0, at_least_min);
					ShowProcess (w, 1);
					}

				KillWindow (w);
				}
			break;

			}

		case EmptyWindowType:
			{
			debug ( ("Exit: killing empty window 0x%x \n", ew) );

			/* remove associations with this window queue element */
			debug ( ("Delete Assoc on empty window \n") );
			XDeleteAssoc (XDisplay, windowinfo, wqe->client);

			/* unmap and destroy this empty window */
			debug ( ("Unmap and destroy empty window \n") );
			XDestroyWindow (XDisplay, wqe->client);

			/* free allocated storage within the EmptyWindow */
			/*
			 * DBB none yet
			 */

			/* remove from the window queue */
			remque (wqe);
			}
		}

    XSetInputFocus (XDisplay, PointerRoot, PointerRoot, CurrentTime);

    XUndefineCursor (XDisplay, XRoot);

    /* Destroy the association table */
    XDestroyAssocTable (windowinfo);

    /* Destroy the menu */
    cmenu_Destroy(cwmMenu);

    /* Free the head of the window queue */
    free (wqhead);
    memdebug ( ("FREE wqe 0x%x %d bytes \n", wqhead, sizeof (struct wqe) ) );

    /* Free cursors */
    XFreeCursor (XDisplay, rootcursor);
    XFreeCursor (XDisplay, modecursor);
    XFreeCursor (XDisplay, hbcursor);
    XFreeCursor (XDisplay, vbcursor);
    XFreeCursor (XDisplay, movecursor);

    /* Free GCs */
    XFreeGC (XDisplay, blackGC);
    XFreeGC (XDisplay, invertGC);

    /* Free fonts */
    XFreeFont (XDisplay, ModeFont);

    /* Restore server default font path */
    XSetFontPath (XDisplay, NULL, 0);

    /* Reset the root's event mask */
    {
    XSetWindowAttributes swa;

    swa.event_mask = 0;
    swa.background_pixmap = None;
    XChangeWindowAttributes (XDisplay, XRoot, CWEventMask | CWBackPixmap, &swa);
    }

    /* Restore the root background */
    XClearWindow (XDisplay, XRoot);

    /* Close the display */
    XCloseDisplay (XDisplay);

    printf ("Toodles...\n"); 

    if ( getppid() == 1 )  {
	/* cwm was exec'd from a login:  logout */
	char cmd [200];
	sprintf(cmd, "%s/.logout", getenv("HOME"));
	execl("/bin/csh", "csh", cmd, 0);
    }
    exit (0);
}

/*
 * Reshape stuff
 */

static int was_shrunk;		/* whether window started reshape shrunk */
				/* this is because DeleteWindow unshrinks */
				/* would it be better to allow a window to */
				/* remain "shrunk" while it is hidden? */

Reshape () {
    debug ( ("Reshape called \n") );
    if (CursorWindow && CursorWindow -> t.type == WindowType
	    && CursorWindow -> SubProcess > 0) {
	Reshapee = CursorWindow;
	was_shrunk = CursorWindow->Shrunk;
	DeleteWindow (CursorWindow);
    }
    debug ( ("Reshape leaving \n") );
}

static    int     left,
            right,
            top,
            bottom;

static struct SplitWindow *FindContainer (w)
register struct SplitWindow *w; {
    if (w) {
	if (w -> t.ViewPort.top > top
		|| w -> t.ViewPort.left > left
		|| w -> t.ViewPort.top + w -> t.ViewPort.height <= bottom
		|| w -> t.ViewPort.left + w -> t.ViewPort.width <= right)
	    return 0;
	if (w -> t.type == SplitWindowType) {
	    register struct SplitWindow *tw;
	    if ((tw = FindContainer (w -> top))
	      || (tw = FindContainer (w -> bottom)))
		return tw;
	}
    }
    return w;
}


FinishReshape(x, y)
{
struct SplitWindow *target;
	debug ( ("FinishReshape x %d y %d \n", x, y) );
	top = bottom = y,  left = right = x;    /* HACK */
	target = FindContainer (wmRootWindow[CursorDisplayNumber]);
	Reshapee->t.column = target->t.column;
	if (target->t.parent->SplitHorizontally
	  && target->t.type!=EmptyWindowType
	  && y > target->t.ViewPort.top + target->t.ViewPort.height/2)
	    target = target->t.parent->bottom->top;
	Reshapee->Shrunk = was_shrunk;
	PutWindowInColumn(Reshapee, target, at_least_min);
	Reshapee->original_column = Reshapee->t.column;
	ShowProcess (Reshapee, 1);
	Reshapee = 0;
	debug ( ("FinishReshape leaving \n") );
}



HideOrShrink () {
    debug ( ("HideOrShrink called \n") );
    if (!ShrinkWindow (CursorWindow))
	DeleteWindow (CursorWindow);
}

static
Hide() {
    debug ( ("Hide called \n") );
    if (CursorWindow)
	{
	/* This window will be resized before it is hidden. */
	CursorWindow->ShrunkUnder = 1;
	DeleteWindow (CursorWindow);
	}
}

static
Kill () {
    debug ( ("Kill called \n") );
    if (CursorWindow && CursorWindow -> t.type == WindowType) {
	KillProcess (CursorWindow -> SubProcess);
/*TAG
	DeleteWindow (CursorWindow);
*/
    }
    debug ( ("Kill leaving \n") );
}

RedrawTotalDisplay()
{
Window refresher;

debug ( ("RedrawTotalDisplay called \n") );

/* DBB
   create a root-sized invisible window
   map it, unmap it, destroy it
*/


refresher = XCreateSimpleWindow (XDisplay, XRoot, 0, 0, ScreenWidth, ScreenHeight,
	0, WHITEPIXEL, WHITEPIXEL);

if (!refresher)
	cwmError (1, "Can't create refresh window \n");

XMapRaised (XDisplay, refresher);

#ifdef DEBUG
{ int i = 1000000; while (i--); }
#endif DEBUG

XDestroyWindow (XDisplay, refresher);

}

#define W ((struct wmWindow *) w)

FindWindowSize (w, horizontal, min)
register struct SplitWindow *w; {
    if (w) {
	switch (w -> t.type) {
	    case SplitWindowType: 
		{
		    register    t1 = FindWindowSize (w -> top, horizontal, min);
		    register    t2 = FindWindowSize (w -> bottom, horizontal, min);
		    if (w -> SplitHorizontally == horizontal)
			if (t1 > t2)
			    return t1;
			else
			    return t2;
		    else
			return t1 + t2;
		}

	    case EmptyWindowType:
		/* ??? -bl */
		return 0;

	    case WindowType: 
		return min ? horizontal ? W -> minwidth : W -> minheight
			   : horizontal ? W -> maxwidth : W -> maxheight;

	}
    }
    return 0;
}


static
ExpandWindow () {

    debug ( ("ExpandWindow called \n") );

    if (CursorWindow && CursorWindow->t.type == WindowType)
	ExpandColumnWindow(CursorWindow, hog);
}


StraightenAllOut () {
    debug ( ("StraightenAllOut called \n") );
    ReproportionColumns();
}


ExposeWindow (name)
char   *name; {
    register struct wmWindow *w;
    register struct wqe *wqe;

    debug ( ("ExposeWindow <%s> called \n", name) );

    for (wqe = wqhead->next; wqe != wqhead; wqe = wqe->next)
	{
	w = wqe->client_wm;

	if (w->t.type == EmptyWindowType)
		break;

	debug ( ("0x%x <%s> \n", w, w->MenuTitle) );

	if (w -> MenuTitle[0] == name[0] && strcmp (w -> MenuTitle, name) == 0) {
		debug ( ("   ExposeWindow calling PutWindowInColumn \n") ); 
		PutWindowInColumn(w, 0, at_least_min);
		ShowProcess (w, 1);
	}
	}
}

/*
 * Fixed to add/delete using window manager internal procedures
 * so that it no longer gets indigestion on program names with
 * colons (or tilde, or even comma).  7/30/85  -wdh
 *
 */

#define AorD(x) ( (x) ? "Add" : "Delete" )

#if 0
FiddleExposeMenu(program, add)
char *program;
int add;
{
int pane, selection;

debug ( ("FiddleExposeMenu <%s> %s \n", program, AorD(add) ) );
pane = cmenuFindPane (cwmMenu, "Expose");
if (add)
	{
	selection = cmenuFindSelection(cwmMenu, pane, "New Typescript");
	if (selection == 0)
		{
		cmenuInsertSelection (cwmMenu, pane,0, ExposeWindow, program, True);
		cmenuInsSpace (cwmMenu, pane, 1);
    		}
	else
		cmenuInsertSelection (cwmMenu, pane,0, ExposeWindow, program, True);
	}
else
	{
	selection = cmenuFindSelection (cwmMenu, pane, program);
	cmenuDeleteSelection (cwmMenu, pane, selection);
	}
}
#else
FiddleExposeMenu(program, add)
char *program;
int add;
{
/* This isn't correct. We are going to have to specify some data here somewhere. */
    if (add) {

        struct cwmmenudata *data = (struct cwmmenudata *) malloc(sizeof(struct cwmmenudata));
        
        if (data == NULL)
            cwmError (1, "Can't allocate a menu data.\n" );

/* Item priority is 1 so these items get added after the "New Typescript" item. */
        data->function = (void (*)()) ExposeWindow;
        data->rock = program;

        cmenu_AddSelection(cwmMenu, "Expose", 0, program, 10, (long) data, 0);
    }
    else
        cmenu_DeleteSelection(cwmMenu, "Expose", 0, program, 0, 0);
}
#endif

SetWindowTitle (w, name, progname)
register struct wmWindow *w;
char   *name, *progname;
{
    register struct wmWindow *p;
    register struct wqe *wqe;
    char    buf[200];
    int     seq = 1;
    char   *fname,
           *fpname,
	   *DigitStart = 0;
    int     lenn,
            lenp;

    debug ( ("SetWindowTitle 0x%x <%s> <%s> \n", w, name, progname) );

    if (name && !progname && !*w->ProgramName) {
	progname = name;
	name = 0;
    }
    else if (progname && *w->ProgramName && !name && !*w->name) {
	name = w->ProgramName;
    }
    if (name) {
	strncpy (w -> name, name, sizeof w -> name);
	w -> name[sizeof w -> name - 1] = 0;
    }
    if (progname) {
	strncpy (w -> ProgramName, progname, sizeof w -> ProgramName);
	w -> ProgramName[sizeof w -> ProgramName - 1] = 0;
    }
    fname = w -> name;
    fpname = w -> ProgramName;
    if (lenp = strlen (fpname))
	lenp++;
    if (lenp >= sizeof w -> MenuTitle / 2) {
	fpname += lenp >> 1;
	lenp -= lenp >> 1;
    }
    lenn = strlen (fname);
    while (seq < 20) {
	if (lenp + lenn >= sizeof w -> MenuTitle) {
	    register char  *s = fname + sizeof w -> MenuTitle - lenp + 1;
	    fname = s;
	    while (*s) {
		if (*s == ' ' || *s == '/') {
		    while (*++s == ' ');
		    if (*s)
			fname = s;
		    break;
		}
		s++;
	    }
	}
	sprintf (buf, fpname[0] ? "%s %s" : (fname[0]?"%s%s":"1"),
		fpname, fname);
	buf[sizeof w -> MenuTitle - 1] = 0;

	for (wqe = wqhead->prev; wqe != wqhead; wqe = wqe->prev)
	    {
	    p = wqe->client_wm;

	    if (p != w && p -> SubProcess > 0 && strcmp (p -> MenuTitle, buf) == 0)
		break;
	    }

	if (wqe == wqhead)
	    break;

	if (DigitStart == 0)
	    if (w -> name[0] == 0) DigitStart = w -> name;
	    else
		if (lenn + 3 < sizeof w -> name) {
		    DigitStart = w -> name + lenn;
		    *DigitStart++ = '-';
		} else DigitStart = w -> name + sizeof w -> name - 3;
	sprintf (DigitStart, "%d", ++seq);
	lenn = strlen (fname);
    }

    if (w->Hidden)
    	FiddleExposeMenu (w->MenuTitle, 0);

    strcpy (w -> MenuTitle, buf);

    if (w -> Hidden)
	FiddleExposeMenu (w->MenuTitle, 1);
}

ShowProcess (w, SendSig)
register struct wmWindow *w; {
    w -> Hidden = 0;

    debug ( ("cwm not sending E to process \n") );

    debug ( ("mapping titlebar \n") );
    XMapWindow (XDisplay, w->TitleBar);

    XMapWindow (XDisplay, w->SubProcess);

    FiddleExposeMenu (w->MenuTitle, 0);

    debug ( ("ShowProcess leaving \n") );
}


DestroyChannel(w)
register struct wmWindow *w; {
    struct wqe *wqe;

    debug (("DestroyChannel 0x%x \n", w) );
    wqe = (struct wqe *) XLookUpAssoc (XDisplay, windowinfo, w->SubProcess);
    if (!wqe)
	cwmError (1, "DestroyChannel: window 0x%x not in queue \n", w);
  
    /* remove associations with this window queue element */
    debug ( ("Delete Assoc on titlebar and client \n") );
    XDeleteAssoc (XDisplay, windowinfo, wqe->client);
    XDeleteAssoc (XDisplay, windowinfo, wqe->titlebar);

    /* unmap and destroy this client's title bar window */
    debug ( ("Destroy titlebar \n") );
    XDestroyWindow (XDisplay, wqe->titlebar);

    /* free allocated storage within the wmWindow */
    /*
     * DBB none yet
     */

    /* free the wmWindow itself */
    free (wqe->client_wm);
    memdebug ( ("FREE wmWindow 0x%x %d bytes \n", wqe->client_wm, sizeof (struct wmWindow) ) );

    /* remove from the window queue */
    remque (wqe);

    FiddleExposeMenu(w->MenuTitle, 0);

    debug ( ("DestroyChannel leaving \n") );
}

KillWindow (w)
register struct wmWindow *w; {
    struct wqe *wqe;

    debug ( ("KillWindow 0x%x \n", w) );
    if (w) {

        debug ( ("0x%x\n", w->SubProcess) );
	wqe = (struct wqe *) XLookUpAssoc (XDisplay, windowinfo, w->SubProcess);
	if (!wqe) {
	    debug ( ("KillWindow: window 0x%x not in queue \n", w) );
	}

	/* flag this as the wqe being destroyed, dealt with in DestroyNotify processing */
	Destroyee = wqe;

	DeleteWindow (w);
	debug ( ("Not sending K to 0x%x \n", w) );
	DestroyChannel(w);
    }
    debug ( ("KillWindow leaving \n") );
}


KillProcess (Xwindow)
Window Xwindow;
{
debug ( ("KillProcess X window 0x%x \n", Xwindow) );
if (Xwindow)
	{
	register struct wqe *wqe;
	register struct wmWindow  *w;

	wqe = (struct wqe *) XLookUpAssoc (XDisplay, windowinfo, Xwindow);
	if (!wqe)
		cwmError (1, "KillProcess: Can't associate window 0x%x \n", Xwindow);

	w = wqe->client_wm;

	debug (("Killing %s %s %s \n", w->ProgramName, w->name, w->hostname));

	/* DBB hopefully not necessary */
	/*
	if (w -> pgrp > 0)
	    killpg (w -> pgrp, SIGTERM);
	*/

	KillWindow (w);

	debug ( ("Killing Client 0x%x \n", Xwindow) );
	XKillClient (XDisplay, Xwindow);

	}

	debug ( ("KillProcess leaving \n") );
}


HideProcess(w)
register struct wmWindow *w; {

    debug ( ("HideProcess 0x%x \n", w) );
    if (w) {
	if (w->Hidden)
	    return;
	if (w->SubProcess > 0)
	    {
	    debug ( ("Not sending H to 0x%x \n", w) );
	    debug ( ("unmapping titlebar \n") );
	    XUnmapWindow (XDisplay, w->TitleBar);
	    }

	w->Shrunk = 0;
	w->Hidden = 1;
	FiddleExposeMenu(w->MenuTitle, 1);

    }
}

SnapShot ()
{
	static sequence = 0;
	char command[100];
	char *snapper;

	debug ( ("SnapShot called \n") );

#ifdef notdef
	snapper = getprofile ("snapshotcommand");
   	debug ( (" ** snapshotcommand %s \n",snapper) );

	if (!snapper)
		snapper = "bitprt -16 -t >";
#endif notdef

	snapper = "xwd -root -out ";

	sprintf (command, "%s %s/snapshot-%d", snapper, SnapShotDir, ++sequence);
	debug ( ("constructed command is %s \n", command) );

	if (vfork () == 0)
	    {
	    close (0);
	    close (1);
	    close (2);
	    open ("/dev/null", 2);
	    dup (0);
	    dup (0);
	    signal (SIGPIPE, SIG_DFL);
	    signal (SIGURG, SIG_IGN);
	    signal (SIGTERM, SIG_DFL);
	    setpriority(0, getpid(), 0);
	    setuid(getuid());
	    execlp ("sh", "sh", "-c", command, 0);
	    write(2, "Exec failed!\n", 13);
	    exit (0);
	    }
}

/*
 * This procedure attempts to give help for the given window.
 * If the HelpCall string has not been set, it tries calling
 * help on the program name.  If the program name is blank,
 * it simply call help.  Added 8/5/85 -wdh
 */

GiveHelp ()
{

    debug ( ("GiveHelp called \n") );

    if (!CursorWindow || CursorWindow->t.type != WindowType)
	return;

    debug ( ("*(CursorWindow->HelpCall) is <%x> \n", *(CursorWindow->HelpCall)) );

    if (*(CursorWindow->HelpCall)) {
	debug ( ("calling <help %s> \n", *(CursorWindow->HelpCall)) );
	/* needs way for client to specify help program?  -bl */
	if (vfork()==0) {
	    setpriority(0, getpid(), 0);
	    setuid(getuid());
	    execlp("help", "help", *(CursorWindow->HelpCall), 0);
	    write(2, "Exec failed\n!", 13);
	    exit(-1);
	}
	/* debug error if vfork fails */
    } else {
	char name[1000];
	if (*(CursorWindow->ProgramName)) {
	    debug ( ("ProgramName is <%s> \n", CursorWindow->ProgramName) );
	    strncpy(name, CursorWindow->ProgramName, sizeof(name));
	    name[sizeof(name)-1] = 0;
	    {
		/* HACK, there should be a case fold some where else */
		/* folddown(helpcall,helpcall); is standard at CMU-CS */
		register char *p;
		for (p=name; *p != 0; p++)
		    if (isupper(*p))
			*p = tolower(*p);
	    }
	}
	
	debug ( ("calling <help %s> \n", name) );
	if (vfork()==0) {
	    setpriority(0, getpid(), 0);
	    setuid(getuid());
	    execlp("help", "help", name, 0);
	    write(2, "Exec failed\n!", 13);
	    exit(-1);
	}
	/* debug error if vfork fails */
    }
}

/*
 * Nice related help procedure, obvious function. Added 8/5/85 -wdh
 */

SetHelpCall(win,helpcall)
register struct wmWindow *win;
char *helpcall;
{
    if (helpcall)
	{
	strcpy (win->HelpCall, helpcall);
	}
    else
	strcpy (win->HelpCall, "");
}


extern Eshell ();

#if 0
struct cmenu *
ManagersMenu () 
{
register int stat;		/* Return status. */
register struct cmenu *menu;		/* Menu structure. */
extern void (*free)();
   
menu = (struct cmenu *) cmenu_Create(XDisplay, XRoot, NULL, free);
if (menu == NULL) 
    cwmError (1, "Can't create my menu \n");

/* We pass pointers to procedures as the data items */

stat = cmenuAddPane (menu, "This Window", 1);
stat = cmenuAddSelection (menu, 0, GiveHelp, "Help", 1);
stat = cmenuAddSpace (menu, 0);
stat = cmenuAddSelection (menu, 0, ExpandWindow, "Enlarge", 1);
stat = cmenuAddSelection (menu, 0, Hide, "Hide", 1);
stat = cmenuAddSpace (menu,0);
stat = cmenuAddSelection (menu, 0, Kill, "Zap", 1);

stat = cmenuAddPane (menu, "Expose", 1);
stat = cmenuAddSelection (menu, 1, Eshell, "New Typescript", 1);
   
stat = cmenuAddPane (menu, "All Windows", 1);
stat = cmenuAddSelection (menu, 2, StraightenAllOut, "Proportion", 1);
stat = cmenuAddSelection (menu, 2, RedrawTotalDisplay, "Redisplay", 1);
stat = cmenuAddSpace (menu, 2);
stat = cmenuAddSelection (menu, 2, SnapShot, "Snapshot", 1);
stat = cmenuAddSpace (menu, 2);

/* If cwm was exec'ed from a login shell; exiting will log the user out */
if ( getppid() == 1 )
	stat = cmenuAddSelection (menu, 2, Exit, "Logout", 1);
else
	stat = cmenuAddSelection (menu, 2, Exit, "Zap", 1);

stat = cmenuRecompute (menu);

return menu;
}
#else
struct cmenu *
ManagersMenu() 
{
    int paneNumber;
    int priority;
    struct cmenu *newMenu;

    static char *panes[] = {"This Window", "Expose", "All Windows"};

#define NextGroup 1 /* Put this item in the next grouping on a pane. */
#define NextPane 2  /* Start putting items on the next pane. */
/* The programmer is responsible for making sure there are no more NextPane flags in the following than there are pane titles in the above panes array. */
    static struct selectionSpec {
        char *label;
        void (*function)(); /* We pass pointers to procedures as the data items */
        int positionFlags;  /* Either 0, NextGroup, or NextPane . */
    } selections[] = {
      /* This Window */
        {"Help", (void (*)()) GiveHelp, 0},
        {"Expand", (void (*)()) ExpandWindow, NextGroup},
        {"Hide", (void (*)()) Hide, 0},
        {"Zap", (void (*)()) Kill, NextGroup},
      /* Expose */
        {"New Typescript", (void (*)()) Eshell, NextPane},
      /* All Windows */
        {"Redisplay", (void (*)()) RedrawTotalDisplay, NextPane},
        {"Snapshot", (void (*)()) SnapShot, NextGroup},
#ifdef DEBUG
        {"Toggle Debugging", (void (*)()) ToggleDebug, NextGroup}
#endif
    };
    struct selectionSpec *selection;
    char *exitLabel;
    struct cwmmenudata *data;

    newMenu = cmenu_Create(XDisplay, XRoot, "cwm", free);
    if (newMenu == NULL)
        cwmError (1, "Can't create my menu \n");

    for (paneNumber = 0; paneNumber < (sizeof(panes) / sizeof(char *)); paneNumber++)
        cmenu_AddPane(newMenu, panes[paneNumber], paneNumber, 0);

    paneNumber = 0;
    priority = 0;
    for (selection = selections; selection < selections + (sizeof(selections) / sizeof(struct selectionSpec)); selection++) {
        data = (struct cwmmenudata *) malloc(sizeof(struct cwmmenudata));
        if (data == NULL)
            cwmError (1, "Can't allocate a menu data.\n" );
        data->function = selection->function;

        if (selection->positionFlags == NextPane) {
            paneNumber++;
            priority = 0;
        }
        else if (selection->positionFlags == NextGroup)
            priority = (priority / 10 + 1) * 10;

        
        cmenu_AddSelection(newMenu, NULL, paneNumber, selection->label, priority, (long) data, 0);
    }

    /* If owm was exec'ed from a login shell; exiting will log the user out */
    data = (struct cwmmenudata *) malloc(sizeof(struct cwmmenudata));
    if (data == NULL)
        cwmError (1, "Can't allocate a menu data.\n" );
    data->function = (void (*)()) Exit;
    priority = (priority / 10 + 1) * 10;
    if (getppid() == 1)
        exitLabel = "Logout";
    else
        exitLabel = "Zap";
    cmenu_AddSelection(newMenu, NULL, paneNumber, exitLabel, priority, (long) data, 0);

    return newMenu;
}
#endif
