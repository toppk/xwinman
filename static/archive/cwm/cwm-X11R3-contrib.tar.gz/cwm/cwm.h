/***********************************************************
		Copyright IBM Corporation 1987

                      All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the name of IBM not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.  

IBM DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
IBM BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
******************************************************************/
/* $Header: cwm.h,v 1.1 88/09/16 11:53:12 ajp Exp $ */
/* $ACIS:cwm.h 1.7$ */
/* $Source: /afs/andrew.cmu.edu/itc/src/andrew/overhead/cwm/cwm.h,v $ */

#if !defined(lint) && !defined(LOCORE) && defined(RCS_HDRS)
static char *rcsidcwm = "$Header: cwm.h,v 1.1 88/09/16 11:53:12 ajp Exp $";
#endif

/*********************************************
Cambridge Window Manager
*********************************************/

#define ONorOFF(x) ( (x) ? "ON" : "OFF" )
#define YorN(x) ( (x) ? "YES" : "NO" )
#define TorF(x) ( (x) ? "TRUE" : "FALSE" )

#define BUTTONS (ButtonPressMask | ButtonReleaseMask)
#define SUBS (SubstructureRedirectMask | SubstructureNotifyMask)

/* Definition of a window queue element */
struct wqe {
	struct wqe *next;
	struct wqe *prev;
	Window client;				/* the X window id */
	struct wmWindow *client_wm;		/* the wm window id */
	Window titlebar;			/* the X window id */
};

/* Procedure declarations */
char *getprofile();
struct cmenu *ManagersMenu();
char *malloc();

/* Global variables */
struct wmWindow *Reshapee;			/* the window being moved */
char OurHost[100];				/* host name of machine we're on */
struct cmenu *cwmMenu;					/* cwm's own menu */
int TitlebarHeight;				/* height in pels */
struct wqe *wqhead,				/* head of the window queue */
	*Destroyee;				/* the window being destroyed */

int ScreenHeight, ScreenWidth;

/* X structures */
long BLACKPIXEL, WHITEPIXEL;
Cursor rootcursor, modecursor, hbcursor, vbcursor, movecursor, nocursor;
Display *XDisplay;
GC blackGC, invertGC;
Screen *XScreen;
Window XRoot;
XAssocTable *windowinfo;
XFontStruct *ModeFont;
