/***********************************************************
		Copyright IBM Corporation 1987

                      All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the name of IBM not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.  

IBM DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
IBM BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
******************************************************************/
/* $Header: crosscursor.h,v 1.1 88/09/16 11:53:09 ajp Exp $ */
/* $ACIS:crosscursor.h 1.5$ */
/* $Source: /afs/andrew.cmu.edu/itc/src/andrew/overhead/cwm/crosscursor.h,v $ */

#if !defined(lint) && !defined(LOCORE) && defined(RCS_HDRS)
static char *rcsidcrosscursor = "$Header: crosscursor.h,v 1.1 88/09/16 11:53:09 ajp Exp $";
#endif

/*********************************************
Cambridge Window Manager
*********************************************/

/**    Cross Cursor Definition    **/


#define crosscursor_width 	32
#define crosscursor_height 	24
#define crosscursor_hotx        15
#define crosscursor_hoty        13


/**         DEFINITION         ***/
/**
00  --------------------------------
01  -----***---------------***------
02  -----*/**-------------**/*------
03  -----**/**-----------**/**------
04  ------**/**---------**/**-------
05  -------**/**-------**/**--------
06  --------**/**-----**/**---------
07  ---------**/**---**/**----------
08  ----------**/**-**/**-----------
09  -----------**/***/**------------
10  ------------**/*/**-------------
11  -------------**/**--------------
12  ------------**/*/**-------------
13  -----------**/***/**------------
14  ----------**/**-**/**-----------
15  ---------**/**---**/**----------
16  --------**/**-----**/**---------
17  -------**/**-------**/**--------
18  ------**/**---------**/**-------
19  -----**/**-----------**/**------
20  -----*/**-------------**/*------
21  -----***---------------***------
22  --------------------------------
23  --------------------------------

**/


/**                   MASK                  **/
/**
00  1111 1111 1111 1111 1111 1111 1111 1111     FFFFFFFF
01  1111 1000 1111 1111 1111 1110 0011 1111     F8FFFE3F
02  1111 1000 0111 1111 1111 1100 0011 1111     F87FFC3F
03  1111 1000 0011 1111 1111 1000 0011 1111     F83FF83F
04  1111 1100 0001 1111 1111 0000 0111 1111     FC1FF07F
05  1111 1110 0000 1111 1110 0000 1111 1111     FE0FE0FF
06  1111 1111 0000 0111 1100 0001 1111 1111     FF07C1FF
07  1111 1111 1000 0011 1000 0011 1111 1111     FF8383FF
08  1111 1111 1100 0001 0000 0111 1111 1111     FFC107FF
09  1111 1111 1110 0000 0000 1111 1111 1111     FFE00FFF
10  1111 1111 1111 0000 0001 1111 1111 1111     FFF01FFF
11  1111 1111 1111 1000 0011 1111 1111 1111     FFF83FFF
12  1111 1111 1111 0000 0001 1111 1111 1111     FFF01FFF
13  1111 1111 1110 0000 0000 1111 1111 1111     FFE00FFF
14  1111 1111 1100 0001 0000 0111 1111 1111     FFC107FF
15  1111 1111 1000 0011 1000 0011 1111 1111     FF8383FF
16  1111 1111 0000 0111 1100 0001 1111 1111     FF07C1FF
17  1111 1110 0000 1111 1110 0000 1111 1111     FE0FE0FF
18  1111 1100 0001 1111 1111 0000 0111 1111     FC1FF07F
19  1111 1000 0011 1111 1111 1000 0011 1111     F83FF83F
20  1111 1000 0111 1111 1111 1100 0011 1111     F87FFC3F
21  1111 1000 1111 1111 1111 1110 0011 1111     F8FFFE3F
22  1111 1111 1111 1111 1111 1111 1111 1111     FFFFFFFF
23  1111 1111 1111 1111 1111 1111 1111 1111     FFFFFFFF

**/



/**          IMAGE                      **/
/**
00  1111 1111 1111 1111 1111 1111 1111 1111     FFFFFFFF
01  1111 1000 1111 1111 1111 1110 0011 1111     F8FFFE3F
02  1111 1010 0111 1111 1111 1100 1011 1111     FA7FFCBF
03  1111 1001 0011 1111 1111 1001 0011 1111     F93FF93F
04  1111 1100 1001 1111 1111 0010 0111 1111     FC9FF27F
05  1111 1110 0100 1111 1110 0100 1111 1111     FE4FE4FF
06  1111 1111 0010 0111 1100 1001 1111 1111     FF27C9FF
07  1111 1111 1001 0011 1001 0011 1111 1111     FF9393FF
08  1111 1111 1100 1001 0010 0111 1111 1111     FFC927FF
09  1111 1111 1110 0100 0100 1111 1111 1111     FFE44FFF
10  1111 1111 1111 0010 1001 1111 1111 1111     FFF29FFF
11  1111 1111 1111 1001 0011 1111 1111 1111     FFF93FFF
12  1111 1111 1111 0010 1001 1111 1111 1111     FFF29FFF
13  1111 1111 1110 0100 0100 1111 1111 1111     FFE44FFF
14  1111 1111 1100 1001 0010 0111 1111 1111     FFC927FF
15  1111 1111 1001 0011 1001 0011 1111 1111     FF9393FF
16  1111 1111 0010 0111 1100 1001 1111 1111     FF27C9FF
17  1111 1110 0100 1111 1110 0100 1111 1111     FE4FE4FF
18  1111 1100 1001 1111 1111 0010 0111 1111     FC9FF27F
19  1111 1001 0011 1111 1111 1001 0011 1111     F93FF93F
20  1111 1010 0111 1111 1111 1100 1011 1111     FA7FFCBF
21  1111 1000 1111 1111 1111 1110 0011 1111     F8FFFE3F
22  1111 1111 1111 1111 1111 1111 1111 1111     FFFFFFFF
23  1111 1111 1111 1111 1111 1111 1111 1111     FFFFFFFF

**/


static int croscursor_mask[] = {
    0x00000000,
    0x070001C0,
    0x078003C0,
    0x07C007C0,
    0x03E00F80,
    0x01F01F00,
    0x00F83E00,
    0x007C7C00,
    0x003EF800,
    0x001FF000,
    0x000FE000,
    0x0007C000,
    0x000FE000,
    0x001FF000,
    0x003EF800,
    0x007C7C00,
    0x00F83E00,
    0x01F01F00,
    0x03E00F80,
    0x07C007C0,
    0x078003C0,
    0x070001C0,
    0x00000000,
    0x00000000};


static int crosscursor_image[] = {
    0x00000000,
    0x070001C0,
    0x05800340,
    0x06C006C0,
    0x03600D80,
    0x01B01B00,
    0x00D83600,
    0x006C6C00,
    0x0036D800,
    0x001BB000,
    0x000D6000,
    0x0006C000,
    0x000D6000,
    0x001BB000,
    0x0036D800,
    0x006C6C00,
    0x00D83600,
    0x01B01B00,
    0x03600D80,
    0x06C006C0,
    0x05800340,
    0x070001C0,
    0x00000000,
    0x00000000};

