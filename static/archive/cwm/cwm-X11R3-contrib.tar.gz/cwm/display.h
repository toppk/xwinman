/***********************************************************
		Copyright IBM Corporation 1987

                      All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the name of IBM not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.  

IBM DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
IBM BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
******************************************************************/
/* $Header: display.h,v 1.1 88/09/16 11:53:19 ajp Exp $ */
/* $ACIS:display.h 1.5$ */
/* $Source: /afs/andrew.cmu.edu/itc/src/andrew/overhead/cwm/display.h,v $ */

#if !defined(lint) && !defined(LOCORE) && defined(RCS_HDRS)
static char *rcsiddisplay = "$Header: display.h,v 1.1 88/09/16 11:53:19 ajp Exp $";
#endif

/*********************************************
Cambridge Window Manager
*********************************************/


struct display {
    struct ViewPort screen;
    char *DeviceFileName;
    int d_CurrentColor;
    int base;
};

#define MaxDisplays 5		/* Maximum number of displays */

int NDisplays;
struct display *CurrentDisplay;
struct display 	displays[MaxDisplays];
struct display display;
struct display *CursorDisplay;
int CursorDisplayNumber;

