/***********************************************************
		Copyright IBM Corporation 1988

                      All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the name of IBM not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.  

IBM DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
IBM BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
******************************************************************/
/* $Header: cursorimage.h,v 1.3 88/09/15 00:43:53 ghoti Exp $ */
/* $Source: /afs/andrew.cmu.edu/itc/src/andrew/overhead/cmenu/RCS/cursorimage.h,v $ */

#define cursor_width 18
#define cursor_height 13
#define cursor_x_hot 16
#define cursor_y_hot 6
static char cursor_bits[] = {
   0x00, 0x00, 0x00, 0x00, 0x0c, 0x00, 0x00, 0x1c, 0x00, 0x00, 0x3c, 0x00,
   0x00, 0x78, 0x00, 0xfe, 0xff, 0x00, 0xfe, 0xff, 0x01, 0xfe, 0xff, 0x00,
   0x00, 0x78, 0x00, 0x00, 0x3c, 0x00, 0x00, 0x1c, 0x00, 0x00, 0x0c, 0x00,
   0x00, 0x00, 0x00};

#define cursormask_width 18
#define cursormask_height 13
#define cursormask_x_hot 16
#define cursormask_y_hot 6
static char cursormask_bits[] = {
   0xff, 0xf1, 0xff, 0xff, 0xe1, 0xff, 0xff, 0xc1, 0xff, 0xff, 0x81, 0xff,
   0x00, 0x00, 0xff, 0x00, 0x00, 0xfe, 0x00, 0x00, 0xfc, 0x00, 0x00, 0xfe,
   0x00, 0x00, 0xff, 0xff, 0x81, 0xff, 0xff, 0xc1, 0xff, 0xff, 0xe1, 0xff,
   0xff, 0xf1, 0xff};
