/***********************************************************
		Copyright IBM Corporation 1988,1988

                      All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the name of IBM not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.  

IBM DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
IBM BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
******************************************************************/
/* $Header: cmenu.h,v 1.3 88/09/15 00:41:20 ghoti Exp $ */
/* $Source: /afs/andrew.cmu.edu/itc/src/andrew/overhead/cmenu/RCS/cmenu.h,v $ */

#include <cmenuError.h>

/* Could have just as easily used TRUE and FALSE for these. */
#define cmenu_Inactive                  0
#define cmenu_Active                    1

#define cmenu_DisallowDuplicates        1
#define cmenu_CreatePane                2
#define cmenu_DeleteEmptyPanes          4

#define cmenu_NoBackground              0
#define cmenu_BackgroundPixel           1
#define cmenu_BackgroundPixmap          2
#define cmenu_NoSaveUnder               3

#ifdef _STDC_
extern struct cmenu *cmenu_Create(Display *display, Window parent,
                         char *defaultEnvironment, void (*freeFunction)());
extern cmenu_Destroy(struct cmenu *menu);
extern int cmenu_AddPane(struct cmenu *menu, char *paneTitle,
                         int panePriority, int flags);
extern int cmenu_DeletePane(struct cmenu *menu, char *paneTitle, int priority);
extern int cmenu_AddSelection(struct cmenu *menu, char *paneTitle,
               int panePriority, char *selectionLabel, int selectionPriority,
               long selectionData, int flags);
extern int cmenu_DeleteSelection(struct cmenu *menu, char *paneTitle,
               int panePriority, char *slectionLabel, int selectionPriority,
               int flags);
extern int cmenu_Activate(struct cmenu *menu, XButtonEvent *menuEvent,
               long *data, int backgroundType, long backgroundValue);
#else
extern struct cmenu *cmenu_Create();
extern int cmenu_AddPane();
extern int cmenu_AddSelection();
extern int cmenu_DeletePane();
extern int cmenu_DeleteSelection();
#endif
